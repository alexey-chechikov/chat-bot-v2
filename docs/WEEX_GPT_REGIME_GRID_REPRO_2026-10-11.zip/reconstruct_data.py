"""GET-only public SPOT archives and USD-M funding; preserve original files."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlencode
import hashlib, io, json, time, zipfile, os
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
DATA = HERE / 'data'
RAW = HERE / 'raw'
END = 1791723540000
COLS = ['ts','open','high','low','close','volume']
SOURCE_ROOT = Path(os.environ.get('WEEX_SOURCE_ROOT', Path.cwd()))

def get(url):
    for trial in range(3):
        try:
            with urlopen(Request(url, headers={'User-Agent':'Public-regime-audit/1.0'}),timeout=20) as r:
                return r.read()
        except Exception:
            if trial==2: raise
            time.sleep(1+trial)

def archive(sym, period, frequency):
    url = f'https://data.binance.vision/data/spot/{frequency}/klines/{sym}/1m/{sym}-1m-{period}.zip'
    p = RAW / f'{sym}-1m-{period}.zip'
    if not p.exists(): p.write_bytes(get(url))
    with zipfile.ZipFile(p) as z:
        with z.open(z.namelist()[0]) as f:
            d = pd.read_csv(f,header=None,usecols=range(6),names=COLS)
    d['ts'] = d['ts'].astype('int64')
    if d.ts.min()>10**14: d['ts'] //= 1000
    return d, {'url':url,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':len(d)}

def one(sym):
    first = 1715731200000 + (60000 if sym=='ETHUSDT' else 0)
    old_path=SOURCE_ROOT/'backtests'/'frozen'/f'{sym}_1m_2y.csv'
    parts=[]
    manifest={'archives':[]}
    if old_path.exists():
        old=pd.read_csv(old_path)
        # Official May onward supersedes any old unfinished tail, even when the
        # operator's file has since been extended. Keep historical prefix only.
        parts.append(old[(old.ts>=first)&(old.ts<1777593600000)])
        manifest.update(old_path=str(old_path),old_sha256=hashlib.sha256(old_path.read_bytes()).hexdigest())
    else:
        for year in range(2024,2027):
            for month in range(1,13):
                if (year,month)<(2024,5) or (year,month)>(2026,4):continue
                d,m=archive(sym,f'{year}-{month:02d}','monthly');parts.append(d);manifest['archives'].append(m)
        old=pd.DataFrame(columns=COLS)
        manifest['historical_prefix_source']='Official SPOT archives, no local frozen present'
    for month in range(5,10):
        d,m=archive(sym,f'2026-{month:02d}','monthly'); parts.append(d); manifest['archives'].append(m)
        print(sym,'monthly',month,len(d),flush=True)
    for day in range(1,11):
        d,m=archive(sym,f'2026-10-{day:02d}','daily'); parts.append(d); manifest['archives'].append(m)
    start=int(pd.Timestamp('2026-10-11',tz='UTC').timestamp()*1000)
    rows=[]
    while start<=END:
        url='https://api.binance.com/api/v3/klines?'+urlencode({'symbol':sym,'interval':'1m','startTime':start,'endTime':END,'limit':1000})
        r=json.loads(get(url));
        if not isinstance(r,list) or not r: raise ValueError(f'Empty/nonlist page {url}')
        rows.extend([x[:6] for x in r]); start=int(r[-1][0])+60000
    tail=pd.DataFrame(rows,columns=COLS).astype({'ts':'int64',**{k:'float64' for k in COLS[1:]}})
    (RAW/f'{sym}_oct11_rest.json').write_text(json.dumps(rows),encoding='utf-8')
    parts.append(tail)
    all_d=pd.concat(parts,ignore_index=True)
    dup=all_d[all_d.ts.duplicated(False)]
    conflict=dup.groupby('ts')[COLS[1:]].nunique().max().to_dict() if len(dup) else {}
    conflicting_times=[]
    if len(dup):
        nu=dup.groupby('ts')[COLS[1:]].nunique()
        conflicting_times=nu.index[nu.max(axis=1)>1].tolist()
    # Frozen downloads contained their still-open final minute. Only the official
    # completed archived candle may supersede it; every other overlap must agree.
    if conflicting_times and (old.empty or any(t!=int(old.ts.iloc[-1]) for t in conflicting_times)):
        raise ValueError(f'Unexpected conflicting duplicate bars {sym}: {conflicting_times}')
    all_d=all_d.drop_duplicates('ts',keep='last').sort_values('ts')
    all_d=all_d[(all_d.ts>=first)&(all_d.ts<=END)]
    gaps=np.flatnonzero(np.diff(all_d.ts.to_numpy())!=60000)
    if len(gaps): raise ValueError(f'Missing minutes {sym}: {len(gaps)}')
    p=DATA/f'{sym}_1m_reconstructed.csv'; all_d.to_csv(p,index=False)
    manifest.update(rows=len(all_d),first_ms=int(all_d.ts.iloc[0]),last_ms=int(all_d.ts.iloc[-1]),duplicates_compared=len(dup),overlap_conflict=conflict,superseded_open_final_candle_ms=conflicting_times,gaps=0,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    # Funding cache is the original recorded public event history, extended by public API.
    fp=SOURCE_ROOT/'research'/'expectancy_20261006'/'public_data'/f'binance_futures_{sym}_funding.csv'
    if fp.exists():
        f=pd.read_csv(fp); fs=int(f.fundingTime.max())+1
    else:
        f=pd.DataFrame(columns=['symbol','fundingTime','fundingRate','markPrice','rateType']);fs=first
    fr=[]
    while fs<=END+59999:
        url='https://fapi.binance.com/fapi/v1/fundingRate?'+urlencode({'symbol':sym,'startTime':fs,'endTime':END+59999,'limit':1000})
        r=json.loads(get(url))
        if not isinstance(r,list): raise ValueError(f'Funding nonlist {url}')
        if not r: break
        fr.extend(r); fs=int(r[-1]['fundingTime'])+1
    (RAW/f'{sym}_funding_extension.json').write_text(json.dumps(fr),encoding='utf-8')
    f=pd.concat([f,pd.DataFrame(fr)],ignore_index=True).drop_duplicates('fundingTime').sort_values('fundingTime')
    f=f[(f.fundingTime>=first)&(f.fundingTime<=END+59999)]
    f.to_csv(DATA/f'{sym}_funding.csv',index=False)
    manifest['funding']={'old_source':str(fp) if fp.exists() else None,'old_sha256':hashlib.sha256(fp.read_bytes()).hexdigest() if fp.exists() else None,'rows':len(f),'first_ms':int(f.fundingTime.iloc[0]),'last_ms':int(f.fundingTime.iloc[-1]),'mark_missing':int(f.markPrice.isna().sum())}
    (DATA/f'{sym}_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(sym,'DONE',manifest['rows'],manifest['first_ms'],manifest['last_ms'],'funding',len(f),flush=True)
    return manifest

if __name__=='__main__':
    DATA.mkdir(exist_ok=True); RAW.mkdir(exist_ok=True)
    with ThreadPoolExecutor(max_workers=2) as ex: results=list(ex.map(one,['BTCUSDT','ETHUSDT']))
    (DATA/'manifest.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
