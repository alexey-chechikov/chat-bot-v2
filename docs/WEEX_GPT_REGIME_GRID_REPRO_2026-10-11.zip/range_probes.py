"""Independent offline probes of pinned c7f5d02 range and risk semantics."""
import ast
import csv
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
SNAP = HERE / "snapshot"
sys.path.insert(0, str(SNAP))
spec = importlib.util.spec_from_file_location("qa_range", SNAP / "research/weex/range_episode.py")
re = importlib.util.module_from_spec(spec)
spec.loader.exec_module(re)
out = {}


# The minute starts inside the corridor and its low crosses resting long levels
# BEFORE the lower boundary. Endpoint-first boundary check skips all these fills.
L, U, step, tp = 98., 102., .006, .014
ts = np.array([0, 60])
c = np.array([100., 100.])
points = np.array([[100., 100., 100., 100.], [100., 97.5, 100., 100.]])
log = []
end, net, why, volume = re.run_episode(points, ts, c, 0, L, U, step, tp, log)
P = (L+U)/2
lv = [(1, P*(1-step)**j) for j in range(1, 5) if P*(1-step)**j >= L] + \
     [(-1, P*(1+step)**j) for j in range(1, 5) if P*(1+step)**j <= U]
loss = sum(e-L*.994 if side==1 else U*1.006-e for side,e in lv) + \
       sum(e*re.MAKER + e*(re.TAKER+re.SLIP) for _,e in lv)
q = min(re.C0*re.RISK/loss, re.C0*re.GROSS/sum(e for _,e in lv))
crossed_longs = [(side,e) for side,e in lv if side==1 and e*(1-re.PEN)>L]
exit_px = L*(1-re.SLIP)
causal_net = sum(q*(exit_px-e)-q*e*re.MAKER-q*exit_px*re.TAKER for _,e in crossed_longs)
assert why == "пробой" and net == 0 and volume == 0 and len(crossed_longs)==3 and causal_net<0
out["crossed_limits_omitted"] = {"model_net":net, "model_volume":volume, "exit_reason":why,
    "resting_long_entries_crossed_before_boundary":[e for _,e in crossed_longs],
    "common_qty":q, "net_if_filled_and_closed_at_first_boundary":causal_net}


# A missing hour is silently removed; two good *rows* become two consecutive
# checks despite their actual closes being two hours apart.
minutes = np.r_[np.arange(48*60), np.arange(49*60,51*60)]
base_seconds = int(pd.Timestamp("2026-10-01",tz="UTC").timestamp())
ts_gap = base_seconds + minutes*60
arr = np.full(len(minutes),100.)
data = (ts_gap, arr, arr+2, arr-2, arr)
native_checks = re.checks(*data)
out["datetime_unit_portability"] = {"pandas":pd.__version__,"native_complete_checks":len(native_checks),
    "index_dtype":str(pd.to_datetime(ts_gap,unit="s",utc=True).dtype)}
# Only this QA process normalizes datetime resolution to test the old intended
# algorithm independently of pandas3's asi8 units. Source is never changed.
native_to_datetime = re.pd.to_datetime
re.pd.to_datetime = lambda *args,**kwargs:native_to_datetime(*args,**kwargs).as_unit("ns")
checks = re.checks(*data)
assert checks.iloc[1]["i"]-checks.iloc[0]["i"] == 60
first_close = int(ts_gap[int(checks.iloc[0]["i"])] + 60)
next_close = int(ts_gap[int(checks.iloc[1]["i"])] + 60)
eps,_ = re.simulate(data)
assert next_close-first_close == 7200 and not eps.empty
out["missing_hour_consecutive_checks"] = {"first_close":first_close,"next_close":next_close,
    "elapsed_seconds":next_close-first_close,"episode_activated":bool(len(eps))}
re.pd.to_datetime = native_to_datetime


# n*4 oversampling followed by chronological earliest-n acceptance is not a
# uniform set of random start times. When n*4>=number of candidates it becomes
# deterministic earliest-n in this no-overlap toy.
real_checks, real_episode = re.checks, re.run_episode
candidate_rows = pd.DataFrame([{"i":(j+1)*60,"ok":True,"L":98.,"U":102.,"w":.04} for j in range(8)])
re.checks = lambda *args: candidate_rows
re.run_episode = lambda pts,ts,c,i,L,U,step,tp,log: (i+1,1.,"toy",1.)
ts_control = np.arange(600)*60
constant = np.full(600,100.)
starts=[]
for seed in (0,1,2):
    ep,_ = re.simulate((ts_control,constant,constant,constant,constant),rng=np.random.default_rng(seed),widths=[.04,.04])
    starts.append(ep.t.tolist())
assert starts == [[3600,7200]]*3
out["control_earliest_n_bias"] = {"candidate_starts":[3600*(j+1) for j in range(8)],"starts_three_seeds":starts}
re.checks, re.run_episode = real_checks, real_episode


# Published range halves are entry cohorts; closed-episode DD does not see bags.
toy_eps = pd.DataFrame([{"t":100,"pnl":10.},{"t":300,"pnl":-5.}])
mid=150
h1=toy_eps.loc[toy_eps.t<mid,"pnl"].sum()
closed=toy_eps.pnl.cumsum().to_numpy()
dd_closed=float((np.r_[0.,closed]-np.maximum.accumulate(np.r_[0.,closed])).min())
true_marked=np.array([0.,-50.,10.,10.,5.])
dd_marked=float((true_marked-np.maximum.accumulate(true_marked)).min())
out["cohort_half_and_closed_dd"] = {"reported_half1":float(h1),"marked_half1":-50.,
                                   "closed_episode_dd":dd_closed,"marked_path_dd":dd_marked}


# Isolate fetch() with fake network/clock. Do not import its executable module.
# A downloaded forming minute is appended permanently; later fetch resumes at
# next minute, so the first row's eventual high/close never get refreshed.
fetch_path = SNAP / "research/weex/fetch_1m.py"
tree=ast.parse(fetch_path.read_text(encoding="utf-8"))
fn=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=="fetch")
base=int(pd.Timestamp("2026-10-11",tz="UTC").timestamp()*1000)
clock={"now":base/1000+30}
requests=[]
def fake_urlopen(url,timeout):
    start=int(url.split("startTime=")[1])
    requests.append(start)
    row=[base,"100","110","90","100"] if start==base else [base+60000,"140","145","139","141"]
    return SimpleNamespace(read=lambda:json.dumps([row]).encode())
data_dir=HERE / "fetch_probe_tmp"
data_dir.mkdir(exist_ok=True)
path=data_dir / "ETHUSDT_1m.csv"
if path.exists():
    # This exact task-owned file is reset so the reproduction is idempotent.
    path.write_text("ts,open,high,low,close\n",encoding="utf-8")
ns={"START":"2026-10-11","DATA":data_dir,"datetime":datetime,"timezone":timezone,"csv":csv,"json":json,
    "time":SimpleNamespace(time=lambda:clock["now"],sleep=lambda *args:None),
    "urllib":SimpleNamespace(request=SimpleNamespace(urlopen=fake_urlopen))}
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(fetch_path),"exec"),ns)
ns["fetch"]("ETHUSDT")
clock["now"]=base/1000+90
ns["fetch"]("ETHUSDT")
rows=list(csv.reader(path.open()))
assert requests==[base,base+60000] and rows[1][-1]=="100"
out["forming_minute_frozen"] = {"requests_start_ms":requests,"first_row_stored_close":float(rows[1][-1]),
                               "first_row_eventual_final_close":140.}


# Existing grid 'daily stop' freezes entry permission, not the marked loss.
from services.weex_grid import engine as eg
eg.atomic_write=lambda p,s:Path(p).write_text(s,encoding="utf-8")
cfg={**eg.DEFAULT,"enabled":True,"dry_run":True,"sides":["LONG"],"order_qty":"1.000",
     "qty_step":.001,"price_tick":.01,"max_notional_usd":6000.,"daily_loss_stop_usd":10.,"stress_budget_frac":0.}
exchange=eg.DryExchange(lambda:(95.,95.),symbol="BTCUSDT")
state_path=HERE / "risk_probe_state.json"
if state_path.exists():
    state_path.write_text("{}",encoding="utf-8")
grid=eg.Grid(exchange,cfg,state_path=state_path,journal_path=HERE / "risk_probe_journal.jsonl")
grid.st["LONG"]["lots"]=[{"entry":100.,"qty":"10.000","tp":101.4,"t":0,"tp_order":None}]
grid.st["day_start_pnl"]=0.
grid._risk(95.)
assert grid.st["halted"] and len(grid.st["LONG"]["lots"])==1
after_stop=grid.bot_pnl(95.)
grid._risk(80.)
out["daily_stop_is_entry_halt"]={"configured_daily_stop":10.,"pnl_when_halted":after_stop,
    "pnl_after_more_price_loss":grid.bot_pnl(80.),"remaining_qty":sum(float(x["qty"]) for x in grid.st["LONG"]["lots"])}

# Wide-grid sparse points: newly created buy above market is not a maker fill.
minute=(np.array([0]),np.array([100.]),np.array([100.]),np.array([98.]),np.array([98.]))
fast=re.fg.run(minute,sides=("LONG",),step=.6,target=1.4,order_qty=1.,cap_usd=6000.)
px={"mid":100.}
clock2={"t":1800000000.}
exchange=eg.DryExchange(lambda:(px["mid"]-.01,px["mid"]+.01),symbol="BTCUSDT",now_fn=lambda:clock2["t"])
state2=HERE / "coupling_probe_state.json"
if state2.exists():
    state2.write_text("{}",encoding="utf-8")
cfg2={**cfg,"step_pct":.6,"target_pct":1.4,"daily_loss_stop_usd":0.,"poll_sec":0}
g=eg.Grid(exchange,cfg2,state_path=state2,journal_path=HERE / "coupling_probe_journal.jsonl",now_fn=lambda:clock2["t"])
for mid in [100.,100.,98.,98.]:
    px["mid"]=mid
    clock2["t"]+=15
    g.tick()
live_entries=[x["entry"] for x in g.st["LONG"]["lots"]]
assert live_entries==[99.4]
assert abs(fast["оборот"]-(99.4+98.8036))<1e-8
out["wide_fast_vs_postonly_grid"]={"path":[100.,100.,98.,98.],"fast_entry_turnover":fast["оборот"],
    "fast_implied_entries":[99.4,98.8036],"live_fake_entries":live_entries,
    "live_next_postonly_entry":g.st["LONG"]["entry"]["price"],"fast_final_net":fast["итог"],
    "live_fake_final_net":g.bot_pnl(98.)}

(HERE / "range_probe_results.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(out,ensure_ascii=True,indent=2))
