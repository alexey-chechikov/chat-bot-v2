"""Independent strict QA of root-generated reconstruction; no downloads/mutations."""
import ast
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
COLS=["open","high","low","close","volume"]
START={"BTCUSDT":1715731200000,"ETHUSDT":1715731260000}
END=1791723540000
out=[]
for sym in ("BTCUSDT","ETHUSDT"):
    p=HERE/"data"/f"{sym}_1m_reconstructed.csv"
    d=pd.read_csv(p)
    ts=d.ts.to_numpy(dtype=np.int64)
    x=d[COLS].to_numpy(dtype=float)
    rec={"symbol":sym,"rows":len(d),"expected_unique_rows":(END-START[sym])//60000+1,
        "first_ms":int(ts[0]),"last_ms":int(ts[-1]),
        "sha256":hashlib.sha256(p.read_bytes()).hexdigest(),
        "duplicates":int(pd.Series(ts).duplicated().sum()),
        "non60second_steps":int((np.diff(ts)!=60000).sum()),
        "off_minute_grid":int((ts%60000!=0).sum()),
        "nonfinite_rows":int((~np.isfinite(x).all(axis=1)).sum()),
        "invalid_ohlc":int(((d.high<d[["open","low","close"]].max(axis=1))|
                            (d.low>d[["open","high","close"]].min(axis=1))).sum()),
        "nonpositive_prices":int(d[COLS[:4]].le(0).any(axis=1).sum()),
        "negative_volume":int(d.volume.lt(0).sum())}
    assert rec["rows"]==rec["expected_unique_rows"]
    assert rec["first_ms"]==START[sym] and rec["last_ms"]==END
    for k in ("duplicates","non60second_steps","off_minute_grid","nonfinite_rows",
              "invalid_ohlc","nonpositive_prices","negative_volume"):
        assert rec[k]==0,(sym,k,rec[k])
    manifest=json.loads((HERE/"data"/f"{sym}_manifest.json").read_text())
    rec["manifest_hash_match"]=rec["sha256"]==manifest["sha256"]
    assert rec["manifest_hash_match"]
    direct=pd.read_csv(ROOT/"research/expectancy_20261006/public_data"/f"binance_spot_{sym}_1h.csv").set_index("ts")
    ag=d.assign(bucket=d.ts//3600000*3600000).groupby("bucket").agg(
        open=("open","first"),high=("high","max"),low=("low","min"),
        close=("close","last"),volume=("volume","sum"),N=("ts","size"))
    ag=ag[ag.N==60]
    common=ag.index.intersection(direct.index)
    a,b=ag.loc[common],direct.loc[common]
    counts={k:int((~np.isclose(a[k],b[k],rtol=1e-10,atol=1e-9)).sum()) for k in COLS}
    rec["public_spot1h_overlap"]={"full_hours":len(common),"mismatch_counts":counts,
        "start":str(pd.to_datetime(common.min(),unit="ms",utc=True)),
        "last_open":str(pd.to_datetime(common.max(),unit="ms",utc=True))}
    # Price differences are not silently tolerated or suppressed.
    for k in COLS[:4]:
        assert counts[k]==0,(sym,k,counts[k])
    fp=HERE/"data"/f"{sym}_funding.csv"
    f=pd.read_csv(fp)
    ft=f.fundingTime.to_numpy(dtype=np.int64)
    canonical=ft//1000*1000
    values=f[["fundingRate","markPrice"]].to_numpy(dtype=float)
    fc={"rows":len(f),"first":str(pd.to_datetime(ft.min(),unit="ms",utc=True)),
        "last":str(pd.to_datetime(ft.max(),unit="ms",utc=True)),
        "duplicate_actual":int(pd.Series(ft).duplicated().sum()),
        "duplicate_canonical":int(pd.Series(canonical).duplicated().sum()),
        "non8h_canonical_steps":int((np.diff(canonical)!=28800000).sum()),
        "non8h_grid":int((canonical%28800000!=0).sum()),
        "nonfinite_rate_mark_rows":int((~np.isfinite(values).all(axis=1)).sum()),
        "nonpositive_mark_rows":int(f.markPrice.le(0).sum()),
        "max_offset_ms":int((ft-canonical).max()),
        "sha256":hashlib.sha256(fp.read_bytes()).hexdigest()}
    for k in ("duplicate_actual","duplicate_canonical","non8h_canonical_steps","non8h_grid",
              "nonfinite_rate_mark_rows","nonpositive_mark_rows"):
        assert fc[k]==0,(sym,k,fc[k])
    rec["funding"]=fc
    out.append(rec)
(HERE/"reconstructed_data_qa.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(out,ensure_ascii=True,indent=2))
