"""Isolate known unfinished final candles retained by append-only old downloader."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import audit_replay as ar
from reconstruct_data import SOURCE_ROOT
HERE=Path(__file__).resolve().parent
rows=[]
for sym in ['BTCUSDT','ETHUSDT']:
    v,f,idx,rate,mark,bound=ar.data(sym);ts,o,h,l,c,reg=v
    o,h,l,c=(x.copy() for x in (o,h,l,c))
    old=pd.read_csv(SOURCE_ROOT/'backtests'/'frozen'/f'{sym}_1m_2y.csv').iloc[-1]
    i=int(np.searchsorted(ts,int(old.ts)//1000))
    assert ts[i]==int(old.ts)//1000
    for k,x in enumerate([o,h,l,c]):x[i]=float(old[['open','high','low','close'][k]])
    for step,tgt in [(.6,1.4),(.8,1.65),(.2,.21)]:
        for mode in ['regime','both','long','short','invert']:
            if mode in ['regime','invert']:act=np.column_stack((reg if mode=='regime' else ~reg,~reg if mode=='regime' else reg))
            elif mode=='both':act=np.ones((len(ts),2),bool)
            else:act=np.column_stack((np.full(len(ts),mode=='long'),np.full(len(ts),mode=='short')))
            curve,qp,qo,qe,split,fund,fcut,dd,stats,seg=ar.replay(o,h,l,c,act,bound,{'BTCUSDT':.0012,'ETHUSDT':.04}[sym],step/100,tgt/100,rate,mark,0)
            row={'symbol':sym,'mode':mode,'step':step,'target':tgt,'net':float(curve[-1].sum()),'half1':float(split[1].sum()),'half2':float(curve[-1].sum()-split[1].sum()),'dd':float(dd[0]),'funding':fund[1].tolist(),'sides':curve[-1].tolist()}
            rows.append(row)
            if mode=='regime' or step==.6:print(row,flush=True)
(HERE/'partial_candle_results.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
