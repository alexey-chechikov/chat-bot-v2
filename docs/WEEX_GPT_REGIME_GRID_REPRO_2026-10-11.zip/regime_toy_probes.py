"""Offline probes of pinned regime-grid logic. No production edits or account state."""
from __future__ import annotations
import importlib.util
import json
import sys
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
SRC = HERE / "snapshot/research/weex"

def mod(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m

fg = mod("fast_grid", SRC / "fast_grid.py")
rg = mod("regime_grid_audit", SRC / "regime_grid.py")
rg.QTY = 1.0

def data(ts, o, h, l, c, reg):
    return tuple(np.asarray(v) for v in (ts, o, h, l, c, reg))

def row(r):
    name, mode, seed, step, target, eq, eqmid, dd, flips, sides = r
    return {"name": name, "mode": mode, "seed": seed, "eq": eq, "first_half": eqmid,
            "second_half": eq - eqmid, "close_dd": dd, "flips": flips, "sides": sides}

out = {"commit": "c7f5d02d18402a28890858246a4d712184ec582f", "cases": {}}

# A regime flip occurs at the first row of the second half and includes a gap.
half = data([0, 86340, 86400, 86460], [100., 99., 200., 200.],
            [100., 100., 200., 200.], [99., 99., 200., 200.], [99., 100., 200., 200.],
            [True, True, False, False])
rg.init(half)
r = row(rg.run(("boundary", "regime", 0, .6, 1.4)))
correct_boundary = fg.run(tuple(x[:2] for x in half[:5]), sides=("LONG",), step=.6, target=1.4,
                         order_qty=1., cap_usd=6000.)["итог"]
r.update(correct_first_half=correct_boundary, correct_second_half=r["eq"] - correct_boundary,
         shifted_from_second_to_first=r["first_half"] - correct_boundary)
assert abs(r["first_half"] - 100.4481152) < 1e-8
assert abs(correct_boundary - .584096) < 1e-8
out["cases"]["midpoint_after_future_liquidation"] = r

# A standing TP already crossed at the new minute's known open precedes a new
# market liquidation unless the simulator explicitly models a confirmed cancel.
raw_source = (SRC / "regime_grid.py").read_text(encoding="utf-8")
priority_source = raw_source[raw_source.index("def run(args):"):raw_source.index("\ndef init(data):")]
priority_source = priority_source.replace("def run(args):", "def run_tp_open_first(args):")
insertion = '''        # Audit clone: existing resting TP fills at known open before new decisions.
        for d, s in S.items():
            keep = []
            for e, q, tp in s["lots"]:
                if (d > 0 and o[i] >= tp) or (d < 0 and o[i] <= tp):
                    s["real"] += d * q * (tp - e)
                    s["fee"] += q * tp * MAKER
                else:
                    keep.append([e, q, tp])
            s["lots"] = keep
'''
priority_source = priority_source.replace('        if prev is not None and act != prev:', insertion + '        if prev is not None and act != prev:')
exec(priority_source, rg.__dict__)
rg.init(half)
tp_first = row(rg.run_tp_open_first(("tp_priority", "regime", 0, .6, 1.4)))
out["cases"]["standing_tp_at_flip_open"] = {"original_market_first": r, "resting_tp_first": tp_first,
    "total_difference": r["eq"] - tp_first["eq"],
    "comment": "Conditional execution-model defect; does not estimate its contribution on real BTC."}
expected_tp_net = 99.4 * .014 - .00016 * (99.4 + 99.4 * 1.014)
assert abs(tp_first["eq"] - expected_tp_net) < 1e-8

# The original 32 alternating segments have 31 event boundaries. IID labels merge.
lengths = np.arange(1, 33)
reg = np.repeat(np.arange(32) % 2 == 0, lengths)
n = len(reg)
flat = np.full(n, 100.)
bench = data(np.arange(n) * 60, flat, flat, flat, flat, reg)
rg.init(bench)
actual = row(rg.run(("segment_counts", "regime", 0, .6, 1.4)))
segments = np.r_[0, np.flatnonzero(reg[1:] != reg[:-1]) + 1, n]
controls = []
for seed in range(20):
    rng = np.random.default_rng(seed)
    shuffled = reg.copy()
    for a, b in zip(segments[:-1], segments[1:]):
        shuffled[a:b] = rng.random() < .5
    rr = row(rg.run(("segment_counts", "shuffle", seed, .6, 1.4)))
    rr["long_fraction"] = float(shuffled.mean())
    controls.append(rr)
out["cases"]["segment_labels_do_not_preserve_events"] = {
    "original_flips": actual["flips"], "original_long_fraction": float(reg.mean()),
    "control_flips": [x["flips"] for x in controls],
    "control_long_fractions": [x["long_fraction"] for x in controls],
    "control_average_flips": float(np.mean([x["flips"] for x in controls]))}
assert actual["flips"] == 31 and any(x["flips"] != 31 for x in controls)

# Same four segment boundaries; corrected clone exits at every original boundary.
source = (SRC / "regime_grid.py").read_text(encoding="utf-8")
run_source = source[source.index("def run(args):"):source.index("\ndef init(data):")]
run_source = run_source.replace("def run(args):", "def run_fixed_boundary_control(args):")
run_source = run_source.replace("ts, o, h, l, c, reg = DATA", "ts, o, h, l, c, reg = DATA\n    original_boundaries = set((np.flatnonzero(reg[1:] != reg[:-1]) + 1).tolist())")
run_source = run_source.replace("if prev is not None and act != prev:", "if prev is not None and (act != prev or i in original_boundaries):")
run_source = run_source.replace("if prev[d] and not act[d]:", "if prev[d] and (not act[d] or i in original_boundaries):")
exec(run_source, rg.__dict__)
financial = data([0, 86400, 172800, 259200], [100., 99., 110., 105.],
                 [100., 99., 110., 105.], [99., 98., 110., 105.], [99., 98., 110., 105.],
                 [True, False, True, False])
rg.init(financial)
old_control = row(rg.run(("financial", "shuffle", 3, .6, 1.4)))
fixed_control = row(rg.run_fixed_boundary_control(("financial", "shuffle", 3, .6, 1.4)))
out["cases"]["merged_segments_change_cashflows"] = {"iid_labels_seed3": [True, True, False, False],
    "original_control": old_control, "fixed_original_boundaries_control": fixed_control,
    "pnl_difference": old_control["eq"] - fixed_control["eq"]}
assert old_control["flips"] == 1 and fixed_control["flips"] == 3
assert abs(old_control["eq"] - fixed_control["eq"]) > 1.

# Prefix causality check: today's partial close affects tomorrow only, not today.
start = pd.Timestamp("2024-01-01", tz="UTC").timestamp()
records = []
for d in range(125):
    op = 100. + d * .03
    cl = op + np.sin(d / 6.)
    for sec, px in ((0, op), (86340, cl)):
        records.append({"ts": int((start + d * 86400 + sec) * 1000), "open": px, "high": px,
                        "low": px, "close": px, "volume": 1.})
frame = pd.DataFrame(records)
prefix = frame.iloc[:241].copy()  # ends at day120 opening, before that day's close
with patch.object(pd, "read_csv", return_value=frame):
    full_loaded = rg.load()
with patch.object(pd, "read_csv", return_value=prefix):
    prefix_loaded = rg.load()
lookup = dict(zip(full_loaded[0], full_loaded[5]))
ok = all(lookup[t] == v for t, v in zip(prefix_loaded[0], prefix_loaded[5]))
out["cases"]["normal_sma_prefix_causality"] = {"prefix_rows_after_warmup": len(prefix_loaded[0]), "matched": ok}
assert ok

# Constant both-side mode is an exact implementation check against fast_grid.
rng = np.random.default_rng(51)
cc = 100. * np.exp(np.cumsum(rng.normal(0, .003, 250)))
oo = np.r_[100., cc[:-1]]
hh = np.maximum(oo, cc) * (1 + rng.uniform(0, .002, 250))
ll = np.minimum(oo, cc) * (1 - rng.uniform(0, .002, 250))
random_data = data(np.arange(250) * 60, oo, hh, ll, cc, np.ones(250, dtype=bool))
rg.init(random_data)
reg_both = row(rg.run(("same_model", "both", 0, .6, 1.4)))
fast_both = fg.run(random_data[:5], sides=("LONG", "SHORT"), step=.6, target=1.4,
                   order_qty=1., cap_usd=6000., max_orders=50)
out["cases"]["both_mode_matches_fast_on_same_toy_path"] = {
    "regime_both_eq": reg_both["eq"], "fast_eq": fast_both["итог"],
    "regime_dd": reg_both["close_dd"], "fast_dd": fast_both["просадка капитала"]}
assert abs(reg_both["eq"] - fast_both["итог"]) < 1e-8

# Missing warmup is accidentally converted to bool states rather than rejected.
short_frame = frame.iloc[:20].copy()
with patch.object(pd, "read_csv", return_value=short_frame):
    bad = rg.load()
out["cases"]["insufficient_warmup_still_returns_tradable_regimes"] = {
    "input_days": 10, "returned_rows": len(bad[0]), "long_rows": int(bad[5].sum()),
    "short_rows": int((~bad[5]).sum()), "returned_boolean_regimes": bad[5].tolist(),
    "comment": "No day has 100 closes. argmax on all-false starts at0, then None/NaN convert to bool."}
assert len(bad[0]) == 20

out["cases"]["monte_carlo_rank"] = {"reported_not_worse": 2, "randomizations": 20,
    "raw_fraction": 2 / 20, "with_observed_rank": (2 + 1) / (20 + 1)}
(HERE / "regime_toy_results.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
sys.stdout.buffer.write(json.dumps(out, ensure_ascii=False, indent=2).encode("utf-8"))
