"""Independent compiled mirror of pinned regime_grid; original verified separately.
No account access. Funding is an overlay on SPOT fills, not a WEEX backtest.
"""
from pathlib import Path
import sys, json, time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
sys.path.insert(0,str(HERE/'snapshot/research/weex'))
import numpy as np
import pandas as pd
from numba import njit
import regime_grid as original

@njit(cache=True)
def replay(o,h,l,c,act,boundary,qty,step,target,frate,fmark,force,penetration=0.,entry_limit=4,exit_slip=.0002,cap=6000.):
    n=len(c); ep=np.zeros((2,50)); lots=np.zeros(2,np.int64); refs=np.zeros(2); hasref=np.zeros(2,np.bool_)
    real=np.zeros(2); fee=np.zeros(2); fund=np.zeros((3,2)); fcut=np.zeros(2)
    curve=np.zeros((n,2)); qpre=np.zeros((n,2)); qopen=np.zeros((n,2)); qend=np.zeros((n,2))
    split=np.zeros((2,2)); segment=np.zeros((int(boundary.sum())+1,2)); seg_start=np.zeros(2); segid=0
    peak=0.;dd=0.; peakf=0.;ddf=0.; peakintra=0.;ddintra=0.;maxcost=np.zeros(2);maxlots=np.zeros(2,np.int64)
    entries=np.zeros(2,np.int64); tps=np.zeros(2,np.int64); exits=np.zeros(2,np.int64); turnover=np.zeros(2)
    for i in range(n):
        filled=np.zeros(2,np.int64)
        if i==n//2:
            for s in range(2):
                d=1 if s==0 else -1
                split[0,s]=real[s]-fee[s]
                for j in range(lots[s]):split[0,s]+=d*qty*(c[i-1]-ep[s,j])
                fcut[s]=fund[1,s]
        for s in range(2):
            d=1 if s==0 else -1
            qpre[i,s]=lots[s]*qty
            fund[0,s]-=d*qpre[i,s]*fmark[i]*frate[i]
        # force=1: close every original boundary; force=0: original act change only.
        if i>0:
            for s in range(2):
                if (force==1 and boundary[i]) or (act[i-1,s] and not act[i,s]):
                    d=1 if s==0 else -1;px=o[i]*(1-d*exit_slip)
                    for j in range(lots[s]):
                        real[s]+=d*qty*(px-ep[s,j]);fee[s]+=qty*px*.00048;turnover[s]+=qty*px
                    if lots[s]>0:exits[s]+=1
                    lots[s]=0;hasref[s]=False
            if boundary[i]:
                for s in range(2):segment[segid,s]=real[s]-fee[s]-seg_start[s];seg_start[s]=real[s]-fee[s]
                segid+=1
        if i==n//2:
            for s in range(2):
                d=1 if s==0 else -1
                split[1,s]=real[s]-fee[s]
                for j in range(lots[s]):split[1,s]+=d*qty*(c[i-1]-ep[s,j])
        for s in range(2):
            d=1 if s==0 else -1
            qopen[i,s]=lots[s]*qty
            fund[1,s]-=d*qopen[i,s]*fmark[i]*frate[i]
        for k in range(4):
            if k==0:p=o[i]
            elif k==3:p=c[i]
            elif (k==1 and c[i]>=o[i]) or (k==2 and c[i]<o[i]):p=l[i]
            else:p=h[i]
            for s in range(2):
                d=1 if s==0 else -1;kept=0
                for j in range(lots[s]):
                    e=ep[s,j];tp=e*(1+d*target)
                    if (d==1 and p>=tp*(1+penetration)) or (d==-1 and p<=tp*(1-penetration)):
                        real[s]+=d*qty*(tp-e);fee[s]+=qty*tp*.00016;turnover[s]+=qty*tp;tps[s]+=1
                    else:ep[s,kept]=e;kept+=1
                lots[s]=kept
                if not act[i,s]:continue
                if kept:
                    ref=ep[s,0]
                    for j in range(1,kept):
                        if (d==1 and ep[s,j]<ref) or (d==-1 and ep[s,j]>ref):ref=ep[s,j]
                    refs[s]=ref;hasref[s]=True
                elif not hasref[s]:refs[s]=p;hasref[s]=True
                elif (d==1 and p>refs[s]) or (d==-1 and p<refs[s]):refs[s]=p
                lvl=refs[s]*(1-d*step)
                if kept<50 and filled[s]<entry_limit and ((d==1 and p<=lvl*(1-penetration)) or (d==-1 and p>=lvl*(1+penetration))):
                    cost=0.
                    for j in range(kept):cost+=qty*ep[s,j]
                    if max(cost,kept*qty*p)+qty*lvl<=cap:
                        ep[s,kept]=lvl;lots[s]+=1;fee[s]+=qty*lvl*.00016;turnover[s]+=qty*lvl;entries[s]+=1
                        filled[s]+=1
                maxlots[s]=max(maxlots[s],lots[s]);cost=0.
                for j in range(lots[s]):cost+=qty*ep[s,j]
                maxcost[s]=max(maxcost[s],cost)
            eqp=0.
            for s in range(2):
                d=1 if s==0 else -1;eqp+=real[s]-fee[s]
                for j in range(lots[s]):eqp+=d*qty*(p-ep[s,j])
            peakintra=max(peakintra,eqp);ddintra=min(ddintra,eqp-peakintra)
        for s in range(2):
            d=1 if s==0 else -1;qend[i,s]=lots[s]*qty
            fund[2,s]-=d*qend[i,s]*fmark[i]*frate[i]
            curve[i,s]=real[s]-fee[s]
            for j in range(lots[s]):curve[i,s]+=d*qty*(c[i]-ep[s,j])
        eq=curve[i,0]+curve[i,1];ef=eq+fund[1,0]+fund[1,1]
        peak=max(peak,eq);dd=min(dd,eq-peak);peakf=max(peakf,ef);ddf=min(ddf,ef-peakf)
    for s in range(2):segment[segid,s]=curve[-1,s]-seg_start[s]
    stats=np.zeros((2,9))
    for s in range(2):
        stats[s,0]=real[s];stats[s,1]=fee[s];stats[s,2]=turnover[s];stats[s,3]=entries[s];stats[s,4]=tps[s];stats[s,5]=exits[s];stats[s,6]=maxcost[s];stats[s,7]=maxlots[s];stats[s,8]=lots[s]
    return curve, qpre,qopen,qend,split,fund,fcut,np.array([dd,ddf,ddintra]),stats,segment

def data(sym):
    original.SRC=HERE/'data'/f'{sym}_1m_reconstructed.csv'
    v=original.load();ts,o,h,l,c,reg=v
    f=pd.read_csv(HERE/'data'/f'{sym}_funding.csv')
    f=f[(f.fundingTime>=int(ts[0])*1000)&(f.fundingTime<int(ts[-1])*1000+60000)].copy()
    idx=np.searchsorted(ts, f.fundingTime.to_numpy()//60000*60)
    assert np.all(idx<len(ts))
    rate=np.zeros(len(ts));mark=np.zeros(len(ts))
    rate[idx]=f.fundingRate;mark[idx]=f.markPrice
    assert len(np.unique(idx))==len(f)
    boundary=np.r_[False,reg[1:]!=reg[:-1]]
    return v,f,idx,rate,mark,boundary

def execute(sym,mode,step=.6,target=1.4,seed=0,force=0,save=False):
    v,f,idx,rate,mark,boundary=CONTEXT
    ts,o,h,l,c,reg=v;reg=reg.copy()
    if mode=='invert':reg=~reg
    if mode=='shuffle':
        rng=np.random.default_rng(seed);edges=np.r_[0,np.flatnonzero(boundary),len(reg)]
        for a,b in zip(edges[:-1],edges[1:]):reg[a:b]=rng.random()<.5
    if mode in ['regime','invert','shuffle']:act=np.column_stack((reg,~reg))
    elif mode=='long_regime':act=np.column_stack((reg,np.zeros(len(reg),bool)))
    elif mode=='short_regime':act=np.column_stack((np.zeros(len(reg),bool),~reg))
    elif mode=='both':act=np.ones((len(reg),2),bool)
    elif mode=='long':act=np.column_stack((np.ones(len(reg),bool),np.zeros(len(reg),bool)))
    else:act=np.column_stack((np.zeros(len(reg),bool),np.ones(len(reg),bool)))
    result=replay(o,h,l,c,act,boundary,{'BTCUSDT':.0012,'ETHUSDT':.04}[sym],step/100,target/100,rate,mark,force)
    curve,qp,qo,qe,split,fund,fcut,dd,stats,segments=result
    row={'symbol':sym,'mode':mode,'step':step,'target':target,'seed':seed,'force':force,'net':float(curve[-1].sum()),'half1_original':float(split[1].sum()),'half2_original':float(curve[-1].sum()-split[1].sum()),'half1_corrected':float(split[0].sum()),'half2_corrected':float(curve[-1].sum()-split[0].sum()),'sides':curve[-1].tolist(),'funding_pre':fund[0].tolist(),'funding_open':fund[1].tolist(),'funding_end':fund[2].tolist(),'net_funding':float(curve[-1].sum()+fund[1].sum()),'half1_funding':float(split[0].sum()+fcut.sum()),'half2_funding':float(curve[-1].sum()+fund[1].sum()-split[0].sum()-fcut.sum()),'dd':dd.tolist(),'statistics':stats.tolist(),'flips':int(np.any(act[1:]!=act[:-1],axis=1).sum())}
    if save:
        tag=f'{sym}_{mode}_{step}_{target}'
        np.savez_compressed(HERE/f'{tag}_trace.npz',ts=ts,eq=curve,qty_before=qp,qty_open=qo,qty_end=qe,act=act)
        ff=f.copy()
        for s,label in enumerate(['long','short']):
            ff[f'{label}_qty_pre']=qp[idx,s];ff[f'{label}_qty_open']=qo[idx,s];ff[f'{label}_qty_end']=qe[idx,s]
            ff[f'{label}_cash_open']=-(1 if s==0 else -1)*qo[idx,s]*ff.markPrice*ff.fundingRate
        ff.to_csv(HERE/f'{tag}_funding_events.csv',index=False)
    return row,segments

def main():
    global CONTEXT
    allrows=[];controls={}
    for sym in ['BTCUSDT','ETHUSDT']:
        CONTEXT=data(sym);v=CONTEXT[0]
        print(sym,'bars',len(v[0]),'start/end',v[0][[0,-1]],'long%',v[5].mean(),'flips',CONTEXT[-1].sum(),flush=True)
        for step,target in [(0.6,1.4),(0.8,1.65),(0.2,0.21)]:
            for mode in ['regime','both','long','short','invert']:
                row,_=execute(sym,mode,step,target,save=mode=='regime' and step==.6);allrows.append(row)
                print(sym,mode,step,round(row['net'],5),row['funding_open'],flush=True)
        for mode in ['long_regime','short_regime']:
            row,_=execute(sym,mode,save=True);allrows.append(row);print(sym,mode,round(row['net'],5),'fund',row['funding_open'],flush=True)
        sh=[]
        for seed in range(20):
            row,_=execute(sym,'shuffle',seed=seed);sh.append(row['net'])
        base=next(x for x in allrows if x['symbol']==sym and x['mode']=='regime' and x['step']==.6)
        # Independent per-side inventory resets on every boundary allow exact additive random labels.
        forced,seg=execute(sym,'both',force=1)
        edges=np.r_[0,np.flatnonzero(CONTEXT[-1]),len(v[0])]
        labels=v[5][edges[:-1]]
        actual=float(np.where(labels,seg[:,0],seg[:,1]).sum())
        assert abs(actual-base['net'])<1e-7, (actual,base['net'])
        ctl=[]
        for seed in range(999):
            labels=np.random.default_rng(seed).random(len(seg))<.5
            ctl.append(float(np.where(labels,seg[:,0],seg[:,1]).sum()))
        controls[sym]={'original_values':sh,'original_median':float(np.median(sh)),'original_q10_q90':np.quantile(sh,[.1,.9]).tolist(),'original_no_worse':int(np.sum(np.array(sh)>=base['net'])),'forced_values':ctl,'forced_median':float(np.median(ctl)),'forced_q10_q90':np.quantile(ctl,[.1,.9]).tolist(),'forced_no_worse':int(np.sum(np.array(ctl)>=base['net'])),'forced_mc_p':float((1+np.sum(np.array(ctl)>=base['net']))/1000),'segment_pnl':seg.tolist(),'actual_sum':actual}
        print(sym,'CONTROLS', {k:x for k,x in controls[sym].items() if not k.endswith('values') and k!='segment_pnl'},flush=True)
        (HERE/'results.json').write_text(json.dumps({'rows':allrows,'controls':controls},indent=2),encoding='utf-8')
    # Joint drawdown uses synchronous MTM, not sum of separate worst drawdowns.
    joint={}
    for mode in ['regime','long_regime']:
        b=np.load(HERE/f'BTCUSDT_{mode}_0.6_1.4_trace.npz');e=np.load(HERE/f'ETHUSDT_{mode}_0.6_1.4_trace.npz')
        assert np.array_equal(b['ts'],e['ts'])
        gross=b['eq'].sum(axis=1)+e['eq'].sum(axis=1)
        funding=np.zeros(len(gross))
        for sym in ['BTCUSDT','ETHUSDT']:
            f=pd.read_csv(HERE/f'{sym}_{mode}_0.6_1.4_funding_events.csv');ix=np.searchsorted(b['ts'],f.fundingTime.to_numpy()//60000*60)
            np.add.at(funding,ix,f.long_cash_open+f.short_cash_open)
        funded=gross+funding.cumsum()
        joint[mode]={'net':float(gross[-1]),'net_funding':float(funded[-1]),'dd':float(np.min(gross-np.maximum.accumulate(np.r_[0,gross])[1:])),'dd_funding':float(np.min(funded-np.maximum.accumulate(np.r_[0,funded])[1:]))}
    (HERE/'joint_results.json').write_text(json.dumps(joint,indent=2),encoding='utf-8')
    print('JOINT',joint,flush=True)

if __name__=='__main__':main()
