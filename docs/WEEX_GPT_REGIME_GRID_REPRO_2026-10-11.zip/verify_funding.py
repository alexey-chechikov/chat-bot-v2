"""Independent public funding history check and vectorized ledger cross-check."""
from pathlib import Path
from urllib.parse import urlencode
import json
import numpy as np
import pandas as pd
from reconstruct_data import get, END
HERE=Path(__file__).resolve().parent
out={}
for sym in ['BTCUSDT','ETHUSDT']:
    start=1724371200000;raw=[]
    while start<=END+59999:
        url='https://fapi.binance.com/fapi/v1/fundingRate?'+urlencode({'symbol':sym,'startTime':start,'endTime':END+59999,'limit':1000})
        page=json.loads(get(url))
        if not page:break
        raw.extend(page);start=int(page[-1]['fundingTime'])+1
    p=HERE/'raw'/f'{sym}_funding_full_verification.json';p.write_text(json.dumps(raw),encoding='utf-8')
    api=pd.DataFrame(raw).astype({'fundingTime':'int64','fundingRate':'float64','markPrice':'float64'})
    local=pd.read_csv(HERE/'data'/f'{sym}_funding.csv');local=local[local.fundingTime>=1724371200000]
    assert np.array_equal(api.fundingTime.to_numpy(),local.fundingTime.to_numpy())
    assert np.allclose(api.fundingRate,local.fundingRate,rtol=0,atol=1e-15)
    assert np.allclose(api.markPrice,local.markPrice,rtol=0,atol=1e-8)
    f=pd.read_csv(HERE/f'{sym}_regime_0.6_1.4_funding_events.csv')
    x=np.load(HERE/f'{sym}_regime_0.6_1.4_trace.npz')
    idx=np.searchsorted(x['ts'],api.fundingTime.to_numpy()//60000*60)
    qa={}
    for s,label in enumerate(['long','short']):
        q=x['qty_open'][idx,s]
        cash=-(1 if s==0 else -1)*q*api.markPrice*api.fundingRate
        assert np.array_equal(q,f[f'{label}_qty_open'].to_numpy()) or np.allclose(q,f[f'{label}_qty_open'],atol=1e-14,rtol=0)
        assert np.allclose(cash,f[f'{label}_cash_open'],rtol=0,atol=1e-12)
        qa[label]={'cash':float(cash.sum()),'nonzero_settlements':int((q>0).sum()),'settlements_paying':int((cash<0).sum()),'settlements_receiving':int((cash>0).sum())}
    out[sym]={'events':len(api),'public_history_equal':True,'rate_max_abs_diff':float((api.fundingRate.to_numpy()-local.fundingRate.to_numpy()).max()),'mark_max_abs_diff':float(abs(api.markPrice.to_numpy()-local.markPrice.to_numpy()).max()),'ledger':qa}
    print(sym,out[sym],flush=True)
# Unit signs, no position and actual mark (not entry price) assertions.
assert -1*2*100*.001==-.2
assert -(-1)*2*100*.001==.2
assert -1*2*100*(-.001)==.2
assert -1*0*100*.001==0
(HERE/'funding_verification.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
