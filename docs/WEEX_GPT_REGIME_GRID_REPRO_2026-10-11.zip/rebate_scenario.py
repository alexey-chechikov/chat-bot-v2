"""Conditional effective taker1bps, unchanged filled cohort; no refund assumed paid."""
from pathlib import Path
import json
import pandas as pd
P=Path(__file__).resolve().parent
raw=json.loads((P/'newbasket/results.json').read_text());out={}
cut=1758047400
for nominal in ['100','25']:
    r=raw[nominal];d=pd.read_csv(P/f'newbasket/events_{nominal}.csv')
    market=d[d.kind>=3].copy();market['notional']=market.price*market.qty
    refund=.00038*market.notional.sum()
    before=.00038*market.loc[market.ts<cut,'notional'].sum()
    out[nominal]={'baseline_net':r['net'],'market_exit_notional':float(market.notional.sum()),'conditional_refund_accrual':float(refund),'conditional_net':float(r['net']+refund),'conditional_half1':float(r['half1_marked']+before),'conditional_half2':float(r['half2_marked']+refund-before),'conditional_2bps_extra_cost_net':float(r['net']+refund-.0002*r['turnover']),'warning':'Same executions. Entire taker refund must actually apply and pay; accrued here to originating trade, not a factual cash ledger. Maker fee remains .016%. No additional new backtest or proof of personal deal.'}
(P/'rebate_scenario.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
