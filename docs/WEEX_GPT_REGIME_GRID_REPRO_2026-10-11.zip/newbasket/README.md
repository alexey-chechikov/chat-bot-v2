# Hypothesis 3: bounded BTC LONG basket, SMA100 -> FLAT

One frozen exploratory test on the already researched window. No optimization,
no new untouched holdout, no live code/config/orders. Script `bounded_long.py`,
semantic probes `toy_qa.py`, outputs `results.json`, `toy_qa_results.json`,
`events_100.csv`/`events_25.csv`, `equity_100.npy`/`equity_25.npy`.

## Frozen rules

- C=3300, basket budget R=8.25 (0.25%C), order notional <=100, <=4 open plus
  pending lots, admission gross including next order <=400. Paired <=25/cap100
  uses the same rules and R, not a selected replacement strategy.
- Regime is the existing causal yesterday-UTC-close vs SMA100. LONG enabled
  above; below cancels entry and market-closes inventory. No short trading.
- While flat, reference follows maximum observed minute close. Standing buy is
  reference*.994; with inventory it is min(open entries)*.994. At end of each
  minute a new buy can be posted for the NEXT minute; if crossing current price,
  clamp downward to close*(1-.0001). Reference resets after a completed basket.
- First fill fixes shared stop S=.98*entry for the whole basket. Never lower S.
  Subsequent entry must remain >S*(1+.0002). No averaging outside this boundary.
  Individual TP=entry*1.014; new TP only becomes available NEXT minute. If the
  initial TP is already passed when posting, move the sell upward to at least
  close*(1+.0001) to model POST_ONLY. Subsequent existing TP stays at its posted
  price. Maximum one NEW basket per UTC day; a prior-day basket can finish today.
- Quote quantity is floor(.0001) of min(notional/entry, remaining-risk/unit-loss).
  Remaining risk subtracts all existing stopped-loss exposure, entry maker fee,
  taker exit fee, .02% adverse stop fill, already-paid negative basket funding,
  and exactly $0.10 future funding reserve per open/pending lot. Gross/minimum
  quantity/stop-distance conditions can still reject the whole quote.
- Day liquidation loss 33 (1%C) closes own basket and halts until next UTC day.
  Account liquidation-equity peak DD 99 (3%C) closes and ends trading for the
  entire remaining window. Fee jumps at entry are checked immediately as well
  as continuous price crossings. No daily/peak reset to finance another loss.
- TTL 24h from first fill; regime flip exits at opening price; hard stop at S
  with .02% adverse market fill, opening gap at actual open with that slip.
  Market exits pay taker .048%; maker entries/TP pay .016%. No rebates assumed.
- Minute path retains the declared OHLC four-point route, but crosses prices
  in order rather than skipping all intermediate events. Only prior resting
  orders can execute at a minute's open. A standing buy can fill on a gap BEFORE
  stop/regime cancellation, then the actual filled remainder is flattened.
- Funding uses actual Binance USD-M rate/markPrice and old quantity present
  before this minute. It is charged BEFORE opening fills, cancellation and
  intraminute exits; new opening fills do not retroactively pay that settlement.
  Day baseline is prior close equity before the new day's settlement. This is
  an explicitly conservative minute-boundary convention, not subsecond replay.
- Last inventory is force-flattened at final close with adverse slip and taker
  fee. Net reconciles exactly to gross - paid fees + funding.

## Results

BTC spot-fill reconstruction plus futures funding overlay, 23.08.2024 00:00 —
11.10.2026 13:00 UTC, continuously carried across the half-window cut.

| Order cap | Net | Gross incl. market slip | Fees | Funding | Half 1 | Half 2 | DD |
|---|---:|---:|---:|---:|---:|---:|---:|
| 100 / gross400 | +8.926321 | +60.064838 | 45.405079 | -5.733439 | +29.878980 | -20.952659 | -51.567974 |
| 25 / gross100 | +0.510211 | +11.945095 | 10.149580 | -1.285304 | +5.289263 | -4.779053 | -12.151650 |

Both have 377 baskets, 914 entries and 333 TP fills. The 100 version has 241
winning baskets, worst basket -4.764298, maximum reserved basket risk 5.164298,
<=4 open/pending lots. Maximum **minute-close marked gross plus pending** is
397.103770; paired version 98.345026. That metric is not an intraminute gross
maximum or guarantee that price appreciation cannot exceed an admission cap.

DD uses liquidation equity, including estimated taker/exit slip while positions
remain open, evaluated at path extrema and execution/controller events. It
therefore differs from both a cash-only DD and the old gross marked bag curve.
Stop execution price adverse slip is already inside reported gross PnL; fees
are separate. Final forced exits include their actual modeled exit costs.

**Both fail the second-half requirement.** A +$8.93 / +$0.51 whole-window result
over more than two years is not evidence of useful profitable expectation.
The 100 version generates only $173962.59 turnover in the entire window;
another .01% of execution cost on that turnover would cost approximately $17.40,
larger than its apparent positive total. This is arithmetic sensitivity, not a
new tuned stress strategy or estimate of actual fills.

## QA and limits

Six grouped deterministic probes pass: first-entry then stop in the same minute;
new TP eligibility/post-only repricing and no new same-day basket; gap standing
entry before stop with correct PRE-open funding; exact 24h TTL; peak fee-jump
halt with no later trades; terminal market flatten and cash/fee reconciliation.
All helper ledgers reconcile net=gross-fees+funding and admission reserve<=8.25.
The gap probe loses -8.538974 even with a smaller planned reserve: **gaps do not
guarantee R, daily kill or peak kill fills at the trigger**. One price-jump
controller probe exits at -99.073987 rather than exactly -99 because newly
paid entry and liquidation costs cannot be undone. These are disclosed risks.

This is not a WEEX execution backtest: historical spot quotes, ideal complete
touch fills after eligibility, no queue or API latency, fixed estimated market
slip, and a futures funding overlay. Price levels in this research are floating
and **not rounded to WEEX's 0.1 price tick**. Qty floor .0001 is the assumed
research lot step, consistent with the public generic WEEX BTC filter root
retrieved (`../raw/weex_exchange_info.json`); no account-specific commission
endpoint or private account data was queried. These assumptions and the tiny
economic margin prevent a live profitability claim.
