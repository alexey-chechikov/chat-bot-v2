"""Frozen hypothesis 3. No live client/config/API. A single long basket/day."""
from pathlib import Path
import sys, json, time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import audit_replay as ar
import numpy as np
import pandas as pd
from numba import njit

C=3300.; R=8.25; MF=.00016; TF=.00048; SL=.0002; RES=.001

@njit(cache=True)
def mark(cash,e,q,n,p):
    z=cash
    for j in range(n):z+=q[j]*(p*(1-SL)*(1-TF)-e[j])
    return z

@njit(cache=True)
def flat(cash,e,q,n,p):
    f=0.;v=0.;g=0.;x=p*(1-SL)
    for j in range(n):
        g+=q[j]*(x-e[j]);f+=q[j]*x*TF;v+=q[j]*x
    return cash+g-f,f,v,g

@njit(cache=True)
def replay(ts,o,h,l,c,reg,fr,fm,nominal,cap):
    n=len(c);curve=np.zeros(n);events=np.zeros((20000,8));ev=0
    e=np.zeros(4);q=np.zeros(4);tp=np.zeros(4);born=np.zeros(4,np.int64);count=0
    cash=C;fees=0.;fund=0.;gross=0.;turnover=0.;peak=C;dd=0.;day_start=C
    day=-1;used_day=-1;halt_day=-1;peak_halt=False;peak_at=-1
    anchor=0.;buy=0.;bq=0.;stop=0.;first=-1;epactive=False;epcash=0.;epfund=0.
    episodes=0;wins=0;entries=0;takes=0;maxgross=0.;maxlots=0;maxrisk=0.;worstep=0.
    last_eq=C
    for i in range(n):
        d=ts[i]//86400
        if d!=day:
            day=d;day_start=last_eq
        # Funding on inventory held before this minute, before standing fills and exits.
        flow=0.
        for j in range(count):flow-=q[j]*fm[i]*fr[i]
        cash+=flow;fund+=flow;epfund+=flow
        # Existing orders at an opening gap: conservative limit-price fill first.
        j=0
        while j<count:
            if born[j]<i and o[i]>=tp[j]:
                g=q[j]*(tp[j]-e[j]);f=q[j]*tp[j]*MF
                cash+=g-f;gross+=g;fees+=f;turnover+=q[j]*tp[j];takes+=1
                events[ev]=np.array([ts[i],2.,tp[j],q[j],cash,float(episodes),float(count-1),0.]);ev+=1
                for k in range(j,count-1):e[k]=e[k+1];q[k]=q[k+1];tp[k]=tp[k+1];born[k]=born[k+1]
                count-=1
            else:j+=1
        if epactive and count==0:
            net=cash-epcash;wins+=net>0;worstep=min(worstep,net);epactive=False;buy=0.;anchor=0.;stop=0.;first=-1
        if buy>0 and o[i]<=buy:
            if count==0:
                epactive=True;epcash=cash;epfund=0.;episodes+=1;used_day=day;first=i;stop=buy*.98
            e[count]=buy;q[count]=bq;tp[count]=buy*1.014;born[count]=i;count+=1
            f=bq*buy*MF;cash-=f;fees+=f;turnover+=bq*buy;entries+=1
            events[ev]=np.array([ts[i],1.,buy,bq,cash,float(episodes),float(count),stop]);ev+=1
            buy=0.;bq=0.
        eq=mark(cash,e,q,count,o[i]);peak=max(peak,eq);dd=min(dd,eq-peak)
        reason=0
        if eq<=peak-99.:
            reason=7
            if not peak_halt:peak_at=i
            peak_halt=True
        elif eq<=day_start-33.:reason=6;halt_day=day
        elif count and o[i]<=stop:reason=3
        elif count and not reg[i]:reason=5
        elif count and i>=first+1440:reason=4
        if reason:
            if count:
                qty=0.
                for j in range(count):qty+=q[j]
                cash,f,v,g=flat(cash,e,q,count,o[i]);fees+=f;turnover+=v;gross+=g
                events[ev]=np.array([ts[i],float(reason),o[i]*(1-SL),qty,cash,float(episodes),0.,stop]);ev+=1
                net=cash-epcash;wins+=net>0;worstep=min(worstep,net)
            count=0;epactive=False;stop=0.;first=-1;anchor=0.;buy=0.;bq=0.
        if not reg[i] or peak_halt or halt_day==day:buy=0.;bq=0.
        # Continuous price crossings inside the declared 4-point minute path.
        points=np.empty(4);points[0]=o[i];points[3]=c[i]
        if c[i]>=o[i]:points[1]=l[i];points[2]=h[i]
        else:points[1]=h[i];points[2]=l[i]
        for seg in range(3):
            cur=points[seg];end=points[seg+1]
            for safety in range(12):
                event=0;price=end;lot=-1
                if end>cur:
                    best=end+1.
                    for j in range(count):
                        if born[j]<i and tp[j]>cur and tp[j]<=end and tp[j]<best:
                            best=tp[j];event=2;lot=j;price=best
                elif end<cur:
                    best=end-1.
                    if buy>0 and buy<=cur and buy>=end:
                        best=buy;event=1;price=buy
                    if count:
                        if stop<=cur and stop>=end and stop>best:best=stop;price=stop;event=3
                        totalq=0.;cost=0.
                        for j in range(count):totalq+=q[j];cost+=q[j]*e[j]
                        slope=totalq*(1-SL)*(1-TF)
                        for kind in range(2):
                            threshold=(day_start-33. if kind==0 else peak-99.)
                            barrier=(threshold-cash+cost)/slope
                            if barrier<=cur and barrier>=end and barrier>best:
                                best=barrier;price=barrier;event=6 if kind==0 else 7
                eq=mark(cash,e,q,count,price);peak=max(peak,eq);dd=min(dd,eq-peak)
                if event==0:break
                if event==1:
                    if count==0:
                        epactive=True;epcash=cash;epfund=0.;episodes+=1;used_day=day;first=i;stop=buy*.98
                    e[count]=buy;q[count]=bq;tp[count]=buy*1.014;born[count]=i;count+=1
                    f=bq*buy*MF;cash-=f;fees+=f;turnover+=bq*buy;entries+=1
                    events[ev]=np.array([ts[i],1.,buy,bq,cash,float(episodes),float(count),stop]);ev+=1
                    buy=0.;bq=0.
                elif event==2:
                    g=q[lot]*(price-e[lot]);f=q[lot]*price*MF
                    cash+=g-f;gross+=g;fees+=f;turnover+=q[lot]*price;takes+=1
                    events[ev]=np.array([ts[i],2.,price,q[lot],cash,float(episodes),float(count-1),0.]);ev+=1
                    for j in range(lot,count-1):e[j]=e[j+1];q[j]=q[j+1];tp[j]=tp[j+1];born[j]=born[j+1]
                    count-=1
                    if count==0:
                        net=cash-epcash;wins+=net>0;worstep=min(worstep,net)
                        epactive=False;first=-1;stop=0.;buy=0.;anchor=0.
                else:
                    qty=0.
                    for j in range(count):qty+=q[j]
                    cash,f,v,g=flat(cash,e,q,count,price);fees+=f;turnover+=v;gross+=g
                    events[ev]=np.array([ts[i],float(event),price*(1-SL),qty,cash,float(episodes),0.,stop]);ev+=1
                    net=cash-epcash;wins+=net>0;worstep=min(worstep,net)
                    if event==6:halt_day=day
                    if event==7:peak_halt=True;peak_at=i
                    count=0;epactive=False;first=-1;stop=0.;buy=0.;bq=0.;anchor=0.
                eq=mark(cash,e,q,count,price);peak=max(peak,eq);dd=min(dd,eq-peak)
                # Entry fee/liquidation cost jumps can breach a controller at the
                # same price. A continuous-price crossing alone would miss it.
                if count and (eq<=peak-99. or eq<=day_start-33.):
                    why=7 if eq<=peak-99. else 6;qty=0.
                    for j in range(count):qty+=q[j]
                    cash,f,v,g=flat(cash,e,q,count,price);fees+=f;turnover+=v;gross+=g
                    events[ev]=np.array([ts[i],float(why),price*(1-SL),qty,cash,float(episodes),0.,stop]);ev+=1
                    net=cash-epcash;wins+=net>0;worstep=min(worstep,net)
                    if why==7:peak_halt=True;peak_at=i
                    else:halt_day=day
                    count=0;epactive=False;first=-1;stop=0.;buy=0.;bq=0.;anchor=0.
                cur=price
        # Requote only for NEXT minute. Newly filled TP cannot fill in this minute.
        for j in range(count):
            if born[j]==i:tp[j]=max(e[j]*1.014,c[i]*(1+.0001))
        buy=0.;bq=0.
        if reg[i] and not peak_halt and halt_day!=day and count<4 and (count>0 or used_day!=day):
            if count:
                ref=e[0]
                for j in range(1,count):ref=min(ref,e[j])
            else:
                anchor=max(anchor,c[i]);ref=anchor
            price=min(ref*.994,c[i]*(1-.0001))
            s=stop if count else price*.98
            sx=s*(1-SL);risk=max(-epfund,0.) if count else 0.;cost=0.;value=0.
            for j in range(count):
                risk+=q[j]*(e[j]-sx+MF*e[j]+TF*sx)+.1;cost+=q[j]*e[j];value+=q[j]*c[i]
            unitloss=price-sx+MF*price+TF*sx
            risk_qty=max(R-risk-.1,0.)/unitloss if unitloss>0 else 0.
            qty=np.floor(min(nominal/price,risk_qty)/.0001+1e-9)*.0001
            risk+=qty*unitloss+.1
            if qty>=.0001 and price>s*(1+.0002) and risk<=R+1e-9 and max(cost,value)+qty*price<=cap+1e-9:
                buy=price;bq=qty;maxrisk=max(maxrisk,risk)
        value=0.
        for j in range(count):value+=q[j]*c[i]
        maxgross=max(maxgross,value+buy*bq);maxlots=max(maxlots,count+(buy>0))
        if i==n-1 and count:
            qty=0.
            for j in range(count):qty+=q[j]
            cash,f,v,g=flat(cash,e,q,count,c[i]);fees+=f;turnover+=v;gross+=g
            events[ev]=np.array([ts[i]+60.,8.,c[i]*(1-SL),qty,cash,float(episodes),0.,stop]);ev+=1
            net=cash-epcash;wins+=net>0;worstep=min(worstep,net);count=0;epactive=False
        last_eq=mark(cash,e,q,count,c[i]);peak=max(peak,last_eq);dd=min(dd,last_eq-peak);curve[i]=last_eq
    return curve,np.array([cash-C,gross,fees,fund,turnover,float(entries),float(takes),float(episodes),float(wins),dd,maxgross,float(maxlots),maxrisk,worstep,float(peak_at)]),events[:ev]

def main():
    start=time.time();v,f,idx,fr,fm,boundary=ar.data('BTCUSDT');ts,o,h,l,c,reg=v
    results={}
    for nominal,cap in [(100.,400.),(25.,100.)]:
        curve,s,events=replay(ts,o,h,l,c,reg,fr,fm,nominal,cap)
        assert abs(s[0]-(s[1]-s[2]+s[3]))<1e-6
        assert s[11]<=4 and s[12]<=8.25+1e-9
        half=curve[len(curve)//2-1]-C
        results[str(int(nominal))]={"net":s[0],"gross":s[1],"fees":s[2],"funding":s[3],"turnover":s[4],
          "entries":int(s[5]),"TPs":int(s[6]),"baskets":int(s[7]),"winning_baskets":int(s[8]),"DD":s[9],
          "maximum_close_mark_gross_plus_pending":s[10],"maximum_lots_plus_pending":int(s[11]),"maximum_reserved_risk":s[12],
          "worst_basket_net":s[13],"peak_halt_at":str(pd.to_datetime(ts[int(s[14])],unit='s',utc=True)) if s[14]>=0 else None,
          "half1_marked":half,"half2_marked":s[0]-half,"start":str(pd.to_datetime(ts[0],unit='s',utc=True)),
          "end":str(pd.to_datetime(ts[-1]+60,unit='s',utc=True)),"known_window_not_holdout":True}
        pd.DataFrame(events,columns=['ts','kind','price','qty','cash','basket','lots','stop']).to_csv(HERE/f'events_{int(nominal)}.csv',index=False)
        np.save(HERE/f'equity_{int(nominal)}.npy',curve)
        (HERE/'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(nominal,json.dumps(results[str(int(nominal))]),flush=True)
    print('seconds',time.time()-start,flush=True)

if __name__=='__main__':main()
