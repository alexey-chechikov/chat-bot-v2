"""Frozen strategy semantic QA, using synthetic prices, no API."""
from pathlib import Path
import json
import numpy as np
import bounded_long as b

HERE=Path(__file__).resolve().parent
out={}

def run(o,h,l,c,ts=None,fr=None,fm=None):
    o,h,l,c=[np.asarray(x,dtype=float) for x in [o,h,l,c]]
    n=len(c)
    if ts is None:ts=np.arange(n,dtype=np.int64)*60
    if fr is None:fr=np.zeros(n)
    if fm is None:fm=np.zeros(n)
    eq,s,events=b.replay(np.asarray(ts,dtype=np.int64),o,h,l,c,np.ones(n,dtype=np.bool_),np.asarray(fr,dtype=float),np.asarray(fm,dtype=float),100.,400.)
    assert abs(s[0]-(s[1]-s[2]+s[3]))<1e-7
    assert s[11]<=4 and s[12]<=8.25+1e-9
    return eq,s,events

# First pending limit is crossed before the stop: do not skip it at minute low.
eq,s,ev=run([100,100,95],[100,100,95],[100,95,95],[100,95,95])
assert list(ev[:,1])==[1.,3.]
assert ev[0,2]==99.4 and abs(ev[1,2]-99.4*.98*(1-.0002))<1e-9
out['entry_then_first_boundary_stop']={'entry':ev[0,2],'exit':ev[1,2],'net':s[0]}

# New TP is not available in its entry minute. It is repriced post-only at close.
eq,s,ev=run([100,100,102,100],[100,103,102.1,100],[100,99.4,102,98],[100,102,102.05,99])
entry=ev[ev[:,1]==1];tp=ev[ev[:,1]==2]
assert len(entry)==1 and len(tp)==1 and tp[0,0]>entry[0,0]
assert abs(tp[0,2]-102*(1+.0001))<1e-9
out['tp_next_minute_and_one_basket_day']={'entries':len(entry),'entry_ts':entry[0,0],'tp_ts':tp[0,0],'postonly_tp':tp[0,2]}

# Opening gap fills the already-standing second buy BEFORE flattening both lots.
# First-minute funding ignores the new entry; later funding charges old quantity.
eq,s,ev=run([100,100,95],[100,100,95],[100,99.4,95],[100,99.4,95],fr=[0,.001,.001],fm=[0,100,100])
assert list(ev[:,1])==[1.,1.,3.] and ev[1,0]==ev[2,0]
q1=ev[0,3]
assert abs(s[3]+q1*100*.001)<1e-9 and abs(ev[2,2]-95*(1-.0002))<1e-9
out['gap_standing_entry_and_funding']={'old_qty':q1,'funding':s[3],'events':ev[:,1].tolist(),'gap_exit':ev[2,2],'net':s[0]}

# Exact 24h TTL from first fill, charged using actual opening market exit.
n=1443;o=np.full(n,99.4);o[:2]=100
h=np.full(n,99.4);h[:2]=100
l=np.full(n,99.4);l[0]=100
c=np.full(n,99.4);c[0]=100
eq,s,ev=run(o,h,l,c)
ttl=ev[ev[:,1]==4]
assert len(ttl)==1 and ttl[0,0]-ev[0,0]==86400
out['ttl_24h']={'first_entry_ts':ev[0,0],'exit_ts':ttl[0,0],'net':s[0]}

# A fee/liquidation cost jump at a new fill can cross peak limit with no price
# decline afterwards. Controller must flatten immediately and halt all future bars.
e1=99.4;q1=np.floor(100/e1/.0001+1e-9)*.0001
e2=e1*.994;q2=np.floor(100/e2/.0001+1e-9)*.0001
cost=e1*q1+e2*q2
priorpeak=b.C  # down-colored first-fill minute visits high BEFORE the entry
gap=(priorpeak-98.99-(b.C-cost*b.MF)+cost)/((q1+q2)*(1-b.SL)*(1-b.TF))
ts=np.array([0,60,86400,172800,172860,172920],dtype=np.int64)
eq,s,ev=run([100,100,gap,100,100,100],[100,100,gap,100,100,100],
            [100,99.4,gap,100,99.4,95],[100,99.4,gap,100,99.4,95],ts=ts)
pk=ev[ev[:,1]==7]
assert len(pk)==1 and pk[0,0]==ts[4] and int(s[14])==4
assert np.all(ev[:,0]<=ts[4])
out['peak_jump_halt']={'gap_price':gap,'peak_halt_ts':pk[0,0],'net':s[0],'DD':s[9]}

# Terminal inventory is liquidated with adverse slip and taker fee.
eq,s,ev=run([100,100],[100,100],[100,99.4],[100,99.4])
assert ev[-1,1]==8 and abs(ev[-1,2]-99.4*(1-b.SL))<1e-9
assert abs(eq[-1]-(b.C+s[0]))<1e-9 and s[2]>0
out['terminal_flatten']={'reason':int(ev[-1,1]),'exit':ev[-1,2],'net':s[0],'fees':s[2]}

(HERE/'toy_qa_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
