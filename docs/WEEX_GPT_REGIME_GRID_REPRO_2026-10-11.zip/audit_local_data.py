"""Audit local SPOT source coverage only; no downloader and no raw source changes."""
from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PUB = ROOT / "research/expectancy_20261006/public_data"
START = {"BTCUSDT": 1715731200000, "ETHUSDT": 1715731260000}
DECLARED_LAST = 1791723540000
DECLARED_ROWS = 1266540
DECLARED_SHA = {
    "BTCUSDT": "40cb4facb5119d07e9f55559287c1a744110ffda1d9f0a9e42f335edd319a742",
    "ETHUSDT": "6c024b6729e4a419227e7cf5304ac64908e38c8fddf16ab2487405380c45724d"}


def stamp(ts):
    return str(pd.to_datetime(int(ts), unit="ms", utc=True))


def audit(d, path, step=60000):
    ts = d.ts.to_numpy(dtype=np.int64)
    delta = np.diff(ts)
    x = d[["open", "high", "low", "close", "volume"]].to_numpy(dtype=float)
    return {"file": str(path.relative_to(ROOT)), "rows": len(d), "start_ms": int(ts.min()),
            "last_ms": int(ts.max()), "start": stamp(ts.min()), "last": stamp(ts.max()),
            "end_exclusive": stamp(ts.max() + step),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "duplicates": int(pd.Series(ts).duplicated().sum()),
            "nonincreasing_order_steps": int((delta <= 0).sum()),
            "nonstandard_positive_steps": int(((delta > 0) & (delta != step)).sum()),
            "missing_bars": int(np.maximum(delta // step - 1, 0).sum()),
            "off_grid": int((ts % step != 0).sum()),
            "nonfinite_ohlcv_rows": int((~np.isfinite(x).all(axis=1)).sum()),
            "invalid_ohlc": int(((d.high < d[["open", "low", "close"]].max(axis=1)) |
                                  (d.low > d[["open", "high", "close"]].min(axis=1))).sum()),
            "nonpositive_prices_rows": int(d[["open", "high", "low", "close"]].le(0).any(axis=1).sum()),
            "negative_volume_rows": int(d.volume.lt(0).sum())}


out = {"declared_brief": [], "sources": [], "numeric_overlap": [], "funding_coverage": [],
       "spot_minute_tail_available_locally": False, "source_mix": "SPOT sources only in hourly overlap; FUTURES candles explicitly excluded"}
for sym in ("BTCUSDT", "ETHUSDT"):
    out["declared_brief"].append({"symbol": sym, "first_ms": START[sym], "last_ms": DECLARED_LAST,
         "first": stamp(START[sym]), "last": stamp(DECLARED_LAST), "declared_rows": DECLARED_ROWS,
         "expected_inclusive_rows_if_contiguous_unique": (DECLARED_LAST - START[sym]) // 60000 + 1,
         "declared_minus_expected": DECLARED_ROWS - ((DECLARED_LAST - START[sym]) // 60000 + 1)})
    path = ROOT / "backtests/frozen" / f"{sym}_1m_2y.csv"
    d = pd.read_csv(path)
    rec = audit(d, path)
    rec["declared_sha_match"] = rec["sha256"] == DECLARED_SHA[sym]
    trim = d[d.ts >= START[sym]]
    rec["trim_start_to_brief"] = {"rows": len(trim), "first_ms": int(trim.ts.iloc[0]),
                                   "last_ms": int(trim.ts.iloc[-1]),
                                   "source_contains_exact_brief_first": bool((d.ts == START[sym]).any())}
    out["sources"].append(rec)
    hpath = PUB / f"binance_spot_{sym}_1h.csv"
    hour = pd.read_csv(hpath)
    out["sources"].append(audit(hour, hpath, 3600000))
    ag = d.assign(bucket=d.ts//3600000*3600000).groupby("bucket").agg(
        open=("open", "first"), high=("high", "max"), low=("low", "min"),
        close=("close", "last"), volume=("volume", "sum"), N=("ts", "size"))
    ag = ag[ag.N == 60]
    direct = hour.set_index("ts")
    common = ag.index.intersection(direct.index)
    a, b = ag.loc[common], direct.loc[common]
    bad = np.zeros(len(common), dtype=bool)
    mismatch, maximum = {}, {}
    for col in ("open", "high", "low", "close", "volume"):
        mask = ~np.isclose(a[col], b[col], rtol=1e-10, atol=1e-9)
        bad |= mask
        mismatch[col] = int(mask.sum())
        maximum[col] = float(np.abs(a[col]-b[col]).max())
    detail = [{"hour": stamp(ts),
               "frozen_1m_aggregate": {k: float(a.loc[ts,k]) for k in ("open","high","low","close","volume")},
               "public_spot_1h": {k: float(b.loc[ts,k]) for k in ("open","high","low","close","volume")}}
              for ts in common[bad]]
    out["numeric_overlap"].append({"symbol": sym, "common_full_hours": len(common),
        "first": stamp(common.min()), "last_open": stamp(common.max()),
        "mismatching_hours": mismatch, "max_abs_difference": maximum,
        "mismatch_details": detail})
    fpath = PUB / f"binance_futures_{sym}_funding.csv"
    f = pd.read_csv(fpath)
    ft = f.fundingTime.to_numpy(dtype=np.int64)
    cf = ft//1000*1000
    fd = np.diff(cf)
    out["funding_coverage"].append({"symbol":sym, "file":str(fpath.relative_to(ROOT)),
        "rows":len(f),"first":stamp(ft.min()),"last":stamp(ft.max()),
        "sha256":hashlib.sha256(fpath.read_bytes()).hexdigest(),
        "max_offset_ms_from_second": int(np.max(ft-cf)),
        "non8h_boundary_floorsecond": int((cf%28800000 != 0).sum()),
        "missing8h_events":int(np.maximum(fd//28800000-1,0).sum()),
        "not_WEEX_funding":True,
        "does_not_cover_brief_tail_after": "2026-10-05T16:00:00Z"})

# Remaining local minute source: its coverage ends before the CSV tail.
path = ROOT / "frozen/ETHUSDT_1m.parquet"
if path.exists():
    p = pd.read_parquet(path)
    out["parquet_columns"] = list(p.columns)
    tsname = next((x for x in ("ts", "timestamp", "open_time", "datetime", "time") if x in p.columns), None)
    if tsname:
        s = p[tsname]
    else:
        s = pd.Series(p.index)
    if pd.api.types.is_datetime64_any_dtype(s):
        v = pd.to_datetime(s, utc=True).astype("int64") // 1000000
    elif pd.api.types.is_numeric_dtype(s):
        v = s.astype("int64")
        if v.abs().max() < 10**11:
            v = v*1000
    else:
        v = pd.to_datetime(s, utc=True).astype("int64") // 1000000
    out["other_minute_parquet"] = {"file":str(path.relative_to(ROOT)), "rows":len(p),
        "start_ms":int(v.min()),"last_ms":int(v.max()), "start":stamp(v.min()),"last":stamp(v.max()),
        "sha256":hashlib.sha256(path.read_bytes()).hexdigest()}

(HERE / "local_data_audit.json").write_text(json.dumps(out, ensure_ascii=False, indent=2),encoding="utf-8")
print(json.dumps({"declared_brief":out["declared_brief"], "sources":out["sources"],
                  "overlap_counts":[{k:v for k,v in x.items() if k!="mismatch_details"} for x in out["numeric_overlap"]],
                  "other_parquet":out.get("other_minute_parquet")},ensure_ascii=True,indent=2))
