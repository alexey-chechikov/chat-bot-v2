"""Inspect already downloaded official SPOT archives; never download or mutate sources."""
import hashlib
import json
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
COLS=["ts","open","high","low","close","volume"]
out=[]
for sym in ("BTCUSDT","ETHUSDT"):
    old_path=ROOT/"backtests/frozen"/f"{sym}_1m_2y.csv"
    old=pd.read_csv(old_path).set_index("ts")
    path=HERE/"raw"/f"{sym}-1m-2026-05.zip"
    assert path.exists(), str(path)
    with zipfile.ZipFile(path) as z:
        with z.open(z.namelist()[0]) as f:
            a=pd.read_csv(f,header=None,usecols=range(6),names=COLS)
    a.ts=a.ts.astype("int64")
    unit="ms"
    if a.ts.min()>10**14:
        a.ts //=1000
        unit="microseconds converted to milliseconds"
    archive=a.set_index("ts")
    common=old.index.intersection(archive.index)
    x,y=old.loc[common],archive.loc[common]
    exact={k:int((x[k]!=y[k]).sum()) for k in COLS[1:]}
    mask=np.zeros(len(common),dtype=bool)
    numerical={}
    maxdiff={}
    for k in COLS[1:]:
        bad=~np.isclose(x[k],y[k],rtol=1e-10,atol=1e-9)
        numerical[k]=int(bad.sum())
        maxdiff[k]=float(np.abs(x[k]-y[k]).max())
        mask |= bad
    details=[{"ts":int(ts),"time":str(pd.to_datetime(ts,unit="ms",utc=True)),
              "local_frozen":{k:float(x.loc[ts,k]) for k in COLS[1:]},
              "official_archive":{k:float(y.loc[ts,k]) for k in COLS[1:]}}
             for ts in common[mask]]
    hour_path=ROOT/"research/expectancy_20261006/public_data"/f"binance_spot_{sym}_1h.csv"
    hour=pd.read_csv(hour_path).set_index("ts")
    ah=a.assign(bucket=a.ts//3600000*3600000).groupby("bucket").agg(
        open=("open","first"),high=("high","max"),low=("low","min"),
        close=("close","last"),volume=("volume","sum"),N=("ts","size"))
    hidx=ah.index.intersection(hour.index)
    ax,bx=ah.loc[hidx],hour.loc[hidx]
    hm={k:int((~np.isclose(ax[k],bx[k],rtol=1e-10,atol=1e-9)).sum()) for k in COLS[1:]}
    out.append({"symbol":sym,"archive":str(path.relative_to(ROOT)),
                "archive_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
                "archive_timestamp_unit":unit,"archive_rows":len(a),
                "overlap_rows":len(common),"first_overlap":str(pd.to_datetime(common.min(),unit="ms",utc=True)),
                "last_overlap":str(pd.to_datetime(common.max(),unit="ms",utc=True)),
                "exact_binary_differences":exact,"numerical_tolerance_differences":numerical,
                "max_abs_difference":maxdiff,"details":details,
                "archive_vs_public_spot1h":{"common_hours":len(hidx),
                    "non60minute_groups":int((ax.N!=60).sum()),"mismatch_counts":hm}})

(HERE/"may_overlap_audit.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(out,ensure_ascii=True,indent=2))
