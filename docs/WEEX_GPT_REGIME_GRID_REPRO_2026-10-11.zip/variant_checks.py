"""Predeclared additional checks: fixed common warmup for SMA80/100/120;
BTC 1/4 scaling is confirmed with proportionally scaled cap, not a $25 fixed-USD test.
"""
import json
import numpy as np
import pandas as pd
import audit_replay as ar
out={'scale':[],'neighbors':[]}
for sym in ['BTCUSDT','ETHUSDT']:
    context=ar.data(sym);v,f,idx,rate,mark,bound=context
    ts,o,h,l,c,reg=v
    if sym=='BTCUSDT':
        act=np.column_stack((reg,~reg))
        for step,target in [(.6,1.4),(.8,1.65)]:
            r=ar.replay(o,h,l,c,act,bound,.0003,step/100,target/100,rate,mark,0,cap=1500.)
            curve,_,_,_,split,fund,fcut,dd,stats,seg=r
            base=ar.replay(o,h,l,c,act,bound,.0012,step/100,target/100,rate,mark,0)
            assert np.allclose(curve,base[0]/4,rtol=0,atol=1e-8)
            assert np.allclose(fund,base[5]/4,rtol=0,atol=1e-8)
            row={'step':step,'target':target,'qty':.0003,'cap':1500,'net_funding':float(curve[-1].sum()+fund[1].sum()),'dd_funding':float(dd[1]),'scale_identity':True,'half1_funding':float(split[0].sum()+fcut.sum()),'half2_funding':float(curve[-1].sum()+fund[1].sum()-split[0].sum()-fcut.sum())}
            out['scale'].append(row);print('SCALE',row,flush=True)
    d=pd.read_csv(ar.HERE/'data'/f'{sym}_1m_reconstructed.csv')
    allts=d.ts.to_numpy()//1000; day=pd.to_datetime(allts,unit='s',utc=True).floor('D')
    dc=pd.Series(d.close.to_numpy(),index=day).groupby(level=0).last()
    # Every lookback uses the same minute window starting after 120 complete days.
    common=int(pd.Timestamp('2024-09-12',tz='UTC').timestamp())
    start=int(np.searchsorted(ts,common))
    for sma in [80,100,120]:
        mask=(dc>dc.rolling(sma).mean()).shift(1).reindex(day).to_numpy()[len(allts)-len(ts)+start:].astype(bool)
        yy=tuple(x[start:] for x in [o,h,l,c]);rr=rate[start:];mm=mark[start:]
        bb=np.r_[False,mask[1:]!=mask[:-1]]
        for mode in ['regime','long_regime']:
            act=np.column_stack((mask,~mask if mode=='regime' else np.zeros(len(mask),bool)))
            for step,target in [(.6,1.4),(.8,1.65)]:
                r=ar.replay(*yy,act,bb,{'BTCUSDT':.0012,'ETHUSDT':.04}[sym],step/100,target/100,rr,mm,0)
                curve,_,_,_,split,fund,fcut,dd,stats,seg=r
                row={'symbol':sym,'sma':sma,'mode':mode,'step':step,'target':target,'first_ts_seconds':int(ts[start]),'net_funding':float(curve[-1].sum()+fund[1].sum()),'half1_funding':float(split[0].sum()+fcut.sum()),'half2_funding':float(curve[-1].sum()+fund[1].sum()-split[0].sum()-fcut.sum()),'dd_funding':float(dd[1])}
                out['neighbors'].append(row);print('NEIGHBOR',row,flush=True)
(ar.HERE/'variant_checks.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
