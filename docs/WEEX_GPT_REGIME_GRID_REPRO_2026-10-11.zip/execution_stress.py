"""Declared sensitivities, not substitutes for exact live-engine replay."""
import json
import numpy as np
import audit_replay as ar
out=[]
for sym in ['BTCUSDT','ETHUSDT']:
    v,f,idx,rate,mark,bound=ar.data(sym);ts,o,h,l,c,reg=v
    for mode in ['regime','long_regime']:
        act=np.column_stack((reg,~reg if mode=='regime' else np.zeros(len(reg),bool)))
        for label,pen,limit,slip in [('base',0.,4,.0002),('penetration2bps',.0002,4,.0002),('penetration2bps_one_entry_minute_exit4bps',.0002,1,.0004)]:
            curve,qp,qo,qe,split,fund,fcut,dd,stats,seg=ar.replay(o,h,l,c,act,bound,{'BTCUSDT':.0012,'ETHUSDT':.04}[sym],.006,.014,rate,mark,0,pen,limit,slip)
            row={'symbol':sym,'mode':mode,'scenario':label,'net':float(curve[-1].sum()),'net_funding':float(curve[-1].sum()+fund[1].sum()),'half1_funding':float(split[0].sum()+fcut.sum()),'half2_funding':float(curve[-1].sum()+fund[1].sum()-split[0].sum()-fcut.sum()),'dd_funding':float(dd[1])}
            out.append(row);print(row,flush=True)
(ar.HERE/'execution_stress.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
