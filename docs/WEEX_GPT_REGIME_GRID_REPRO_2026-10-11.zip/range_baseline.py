"""Single original range baseline on root's public reconstruction; no controls."""
from pathlib import Path
import hashlib
import importlib.util
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
p=HERE/'snapshot/research/weex/range_episode.py'
spec=importlib.util.spec_from_file_location('range_original',p)
r=importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
native=pd.to_datetime
# Compatibility only; algorithm unmodified. Explicitly preserve its intended ns.
r.pd.to_datetime=lambda *a,**k:native(*a,**k).as_unit('ns')
start=int(pd.Timestamp('2025-12-11',tz='UTC').timestamp())
out={}
for symbol in ['BTCUSDT','ETHUSDT']:
    source=HERE/'data'/f'{symbol}_1m_reconstructed.csv'
    d=pd.read_csv(source)
    d=d[(d.ts//1000)>=start]
    ts=(d.ts.to_numpy(dtype=np.int64)//1000)
    data=(ts,)+tuple(d[col].to_numpy(dtype=float) for col in ['open','high','low','close'])
    eps,log=r.simulate(data)
    midpoint=int(ts[len(ts)//2])
    res={'N':len(eps),'net':float(eps.pnl.sum()),
         'half1_entry_cohort':float(eps.loc[eps.t<midpoint,'pnl'].sum()),
         'half2_entry_cohort':float(eps.loc[eps.t>=midpoint,'pnl'].sum()),
         'reasons':eps.why.value_counts().to_dict(),'turnover':float(eps.vol.sum()),
         'first_minute_seconds':int(ts[0]),'last_minute_seconds':int(ts[-1]),
         'midpoint_seconds':midpoint,'rows':len(ts),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
         'correction_scope':'datetime units only; original endpoint fills and control defects retained'}
    eps.to_csv(HERE/f'{symbol}_range_baseline_episodes.csv',index=False)
    out[symbol]=res
    print(symbol,json.dumps(res),flush=True)
(HERE/'range_baseline_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
