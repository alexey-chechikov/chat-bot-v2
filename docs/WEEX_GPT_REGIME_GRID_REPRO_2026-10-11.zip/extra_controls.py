"""Matched boundary controls, including held-time matching and funding.
These conditional randomizations do not validate the selected SMA or boundary timing.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import audit_replay as ar
HERE=Path(__file__).resolve().parent

def ranks(values,actual):
    x=np.asarray(values)
    return {'actual':float(actual),'median':float(np.median(x)),'q10_q90':np.quantile(x,[.1,.9]).tolist(),'no_worse':int((x>=actual).sum()),'N':len(x),'mc_rank':float((1+(x>=actual).sum())/(len(x)+1))}

out={}
for sym in ['BTCUSDT','ETHUSDT']:
    ar.CONTEXT=ar.data(sym)
    v=ar.CONTEXT[0];ts,_,_,_,_,reg=v
    row,seg=ar.execute(sym,'both',force=1,save=True)
    edges=np.r_[0,np.flatnonzero(ar.CONTEXT[-1]),len(reg)]
    actual_labels=reg[edges[:-1]]
    duration=np.diff(edges)
    f=pd.read_csv(HERE/f'{sym}_both_0.6_1.4_funding_events.csv')
    fidx=np.searchsorted(ts,f.fundingTime.to_numpy()//60000*60)
    segment_id=np.searchsorted(edges[1:],fidx,side='right')
    fs=np.zeros_like(seg)
    for s,label in enumerate(['long','short']):np.add.at(fs[:,s],segment_id,f[f'{label}_cash_open'])
    funded=seg+fs
    actual_switch=float(np.where(actual_labels,funded[:,0],funded[:,1]).sum())
    actual_long=float(funded[actual_labels,0].sum())
    actual_exposure=float(duration[actual_labels].sum()/duration.sum())
    iid_sw=[];iid_long=[];matched_sw=[];matched_long=[];exposures=[]
    for seed in range(999):
        labels=np.random.default_rng(seed).random(len(seg))<.5
        iid_sw.append(float(np.where(labels,funded[:,0],funded[:,1]).sum()))
        iid_long.append(float(funded[labels,0].sum()))
        rng=np.random.default_rng(seed+10000)
        for attempt in range(10000):
            labels=np.zeros(len(seg),bool)
            labels[rng.choice(len(seg),size=int(actual_labels.sum()),replace=False)]=True
            exposure=duration[labels].sum()/duration.sum()
            if abs(exposure-actual_exposure)<=.01:break
        else:raise ValueError('No matched draw')
        matched_sw.append(float(np.where(labels,funded[:,0],funded[:,1]).sum()))
        matched_long.append(float(funded[labels,0].sum()))
        exposures.append(float(exposure))
    out[sym]={'funded_iid_switch':ranks(iid_sw,actual_switch),'funded_iid_long_flat':ranks(iid_long,actual_long),'funded_matched_switch':ranks(matched_sw,actual_switch),'funded_matched_long_flat':ranks(matched_long,actual_long),'actual_long_time_fraction':actual_exposure,'matched_time_fraction_range':[min(exposures),max(exposures)],'matched_long_segment_count':int(actual_labels.sum()),'segment_funding':fs.tolist(),'boundaries_ms':(ts[edges[:-1]]*1000).tolist()}
    print(sym,out[sym],flush=True)
(HERE/'extra_controls.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
