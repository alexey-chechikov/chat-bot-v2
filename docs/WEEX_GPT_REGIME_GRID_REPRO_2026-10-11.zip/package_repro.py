from pathlib import Path
import json,hashlib,zipfile
P=Path(__file__).resolve().parent
target=P/'WEEX_GPT_REGIME_GRID_REPRO_2026-10-11.zip'
files=[]
for pat in ['*.py','*.json','*.md','*_funding_events.csv','*_range_baseline_episodes.csv','snapshot/**/*','data/*.json','data/*funding.csv','raw/*funding*.json','raw/weex_exchange_info.json','newbasket/*.py','newbasket/*.json','newbasket/*.csv','newbasket/*.md']:
    files.extend(x for x in P.glob(pat) if x.is_file() and '__pycache__' not in x.parts)
files=sorted(set(files))
assert (P/'newbasket/toy_qa_results.json') in files
assert '__BASKET_RESULT__' not in (P/'REVIEW.md').read_text(encoding='utf-8')
manifest={'pinned_commit':'c7f5d02d18402a28890858246a4d712184ec582f','files':[{'path':x.relative_to(P).as_posix(),'sha256':hashlib.sha256(x.read_bytes()).hexdigest(),'bytes':x.stat().st_size} for x in files],'excluded':'Minute CSVs, spot ZIP downloads, runtime/vendor, generated .npz/.npy traces; no private state included.'}
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for x in files:z.write(x,x.relative_to(P).as_posix())
    z.writestr('PACKAGE_MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for f in manifest['files']:assert hashlib.sha256(z.read(f['path'])).hexdigest()==f['sha256']
print(json.dumps({'zip':str(target),'bytes':target.stat().st_size,'files':len(files),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
