"""Run the unmodified pinned run() on restored SPOT data (full window)."""
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import sys,json,time
import pandas as pd
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'snapshot/research/weex'))
import regime_grid as original

def verify(sym):
    original.SRC=HERE/'data'/f'{sym}_1m_reconstructed.csv'
    original.QTY={'BTCUSDT':.0012,'ETHUSDT':.04}[sym]
    original.init(original.load());t=time.time()
    r=original.run(('0.6/1.4','regime',0,.6,1.4))
    out={'symbol':sym,'original_result':r,'elapsed_seconds':time.time()-t,'mid_ms':int(original.DATA[0][len(original.DATA[0])//2])*1000,'mid_is_regime_change':bool(original.DATA[5][len(original.DATA[0])//2]!=original.DATA[5][len(original.DATA[0])//2-1]),'funding_events_in_window':None}
    (HERE/f'{sym}_original_result.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(out,flush=True)
    return out

if __name__=='__main__':
    with ProcessPoolExecutor(max_workers=2) as ex:
        rows=list(ex.map(verify,['BTCUSDT','ETHUSDT']))
    (HERE/'original_verification.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
