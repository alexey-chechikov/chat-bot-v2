"""Independent QA of audit_replay mirror against pinned original; synthetic data only."""
from __future__ import annotations
import inspect
import json
from pathlib import Path
import numpy as np
import audit_replay as ar

HERE = Path(__file__).resolve().parent
orig = ar.original
source = inspect.getsource(orig.run).replace("def run(args):", "def qa_original_run(args):")
source = source.replace("return name, mode, seed, step, tgt, eq, eq_mid, dd, flips, side",
                        "return name, mode, seed, step, tgt, eq, eq_mid, dd, flips, side, S")
exec(source, orig.__dict__)

def arrays(kind, seed):
    rng = np.random.default_rng(seed)
    n = 1800
    base = 100000. if seed % 2 else 2500.
    if kind == "random":
        c = base * np.exp(np.cumsum(rng.normal(0, .006, n)))
    elif kind == "down":
        c = base * np.exp(np.linspace(0, -.7, n))
    elif kind == "up":
        c = base * np.exp(np.linspace(0, .7, n))
    elif kind == "zigzag":
        c = base * (1 + .25 * np.sin(np.arange(n) / 37))
    else:
        c = np.full(n, base)
    o = np.r_[base, c[:-1]].copy()
    h = np.maximum(o, c) * (1 + rng.uniform(0, .003, n))
    l = np.minimum(o, c) * (1 - rng.uniform(0, .003, n))
    reg = (np.arange(n) // 57) % 2 == 0
    return np.arange(n, dtype=np.int64) * 60, o, h, l, c, reg

def act_for(reg, mode, seed):
    reg = reg.copy()
    boundary = np.r_[False, reg[1:] != reg[:-1]]
    if mode == "invert":
        reg = ~reg
    if mode == "shuffle":
        rng = np.random.default_rng(seed)
        edge = np.r_[0, np.flatnonzero(boundary), len(reg)]
        for a, b in zip(edge[:-1], edge[1:]):
            reg[a:b] = rng.random() < .5
    if mode in ("regime", "invert", "shuffle"):
        return np.column_stack((reg, ~reg)), boundary
    if mode == "both":
        return np.ones((len(reg), 2), dtype=bool), boundary
    return np.column_stack((np.full(len(reg), mode == "long"), np.full(len(reg), mode == "short"))), boundary

out = {"original_commit": "c7f5d02d18402a28890858246a4d712184ec582f", "cases": [], "additive_cases": []}
maxdiff = 0.
for kind, seed in (("random", 1), ("random", 2), ("down", 2), ("up", 2), ("zigzag", 1), ("flat", 2)):
    dat = arrays(kind, seed)
    ts, o, h, l, c, reg = dat
    zero = np.zeros(len(ts))
    for qty in (.0012, .04):
        orig.QTY = qty
        orig.init(dat)
        for mode in ("regime", "both", "long", "short", "invert", "shuffle"):
            for step, target in ((.6, 1.4), (.2, .21)):
                rr = orig.qa_original_run(("qa", mode, 3, step, target))
                act, boundary = act_for(reg, mode, 3)
                r = ar.replay(o, h, l, c, act, boundary, qty, step / 100, target / 100, zero, zero, 0)
                curve, qp, qo, qe, split, fund, fcut, dd, stats, segments = r
                ds = [abs(float(curve[-1].sum()) - rr[5]), abs(float(split[1].sum()) - rr[6]), abs(float(dd[0]) - rr[7])]
                for s, direction in enumerate((1, -1)):
                    state = rr[-1][direction]
                    ds += [abs(stats[s, 0] - state["real"]), abs(stats[s, 1] - state["fee"]),
                           abs(stats[s, 8] - len(state["lots"]))]
                diff = max(ds)
                assert diff < 1e-7, (kind, seed, qty, mode, step, diff)
                assert np.all(stats[:, 6] <= 6000. + 1e-7)
                assert np.all(stats[:, 7] <= 50)
                maxdiff = max(maxdiff, diff)
                out["cases"].append({"path": kind, "seed": seed, "qty": qty, "mode": mode,
                                     "step": step, "target": target, "max_diff": diff})
        # Additive per-segment forced-reset accounting: selecting actual sides must
        # recover original regime (fixed qty/cap/fees, no shared portfolio cap).
        bothact = np.ones((len(reg), 2), dtype=bool)
        _, boundary = act_for(reg, "both", 0)
        forced = ar.replay(o, h, l, c, bothact, boundary, qty, .006, .014, zero, zero, 1)
        edges = np.r_[0, np.flatnonzero(boundary), len(reg)]
        labels = reg[edges[:-1]]
        selected = float(np.where(labels, forced[-1][:, 0], forced[-1][:, 1]).sum())
        orig_reg = orig.run(("additive", "regime", 0, .6, 1.4))[5]
        assert abs(selected - orig_reg) < 1e-7, (kind, qty, selected, orig_reg)
        # Arbitrary iid segment labels are compared to an independent original
        # clone that explicitly liquidates each active side at original boundaries.
        clone = inspect.getsource(orig.run).replace("def run(args):", "def qa_forced_original_run(args):")
        clone = clone.replace("ts, o, h, l, c, reg = DATA", "ts, o, h, l, c, reg = DATA\n    original_boundaries = set((np.flatnonzero(reg[1:] != reg[:-1]) + 1).tolist())")
        clone = clone.replace("if prev is not None and act != prev:", "if prev is not None and (act != prev or i in original_boundaries):")
        clone = clone.replace("if prev[d] and not act[d]:", "if prev[d] and (not act[d] or i in original_boundaries):")
        exec(clone, orig.__dict__)
        for shuffle_seed in (0, 3, 15):
            rng = np.random.default_rng(shuffle_seed)
            labels = rng.random(len(edges) - 1) < .5
            additive = float(np.where(labels, forced[-1][:, 0], forced[-1][:, 1]).sum())
            explicit = orig.qa_forced_original_run(("fixed", "shuffle", shuffle_seed, .6, 1.4))[5]
            assert abs(additive - explicit) < 1e-7, (kind, qty, shuffle_seed, additive, explicit)
            out["additive_cases"].append({"path": kind, "qty": qty, "seed": shuffle_seed,
                                           "additive": additive, "explicit": explicit,
                                           "difference": additive - explicit})

out["summary"] = {"ordinary_cases": len(out["cases"]), "forced_additive_cases": len(out["additive_cases"]),
                  "max_original_mirror_difference": maxdiff, "all_assertions_passed": True,
                  "limits": "Synthetic QA only, no funding overlay verification and no validation of actual execution or private account."}
(HERE / "qa_replay_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
print(json.dumps(out["summary"], indent=2))
