# Reproduction package — WEEX regime audit, 2026-10-11

Pinned repository source: alexey-chechikov/chat-bot-v2,
alexey/mac-2026-05-29, c7f5d02d18402a28890858246a4d712184ec582f.
`snapshot/` contains only the seven public files reviewed. No live code edits.

Runtime used: Python3.12, pandas3.0.1, numpy2.3.5,
numba0.63.1, llvmlite0.46.0. Install in a separate research environment,
not the running bot. No keys or signed requests are used by downloaders.

## Input

Minute data are not bundled. `audit_replay.py` expects:

- data/BTCUSDT_1m_reconstructed.csv
- data/ETHUSDT_1m_reconstructed.csv

Columns: ts (millisecond minute-open),open,high,low,close,volume.
BTC begins2024-05-15 00:00; ETH00:01. Both end2026-10-11 12:59 UTC inclusive.
The audited hashes and source manifests are in data/. Funding data ARE bundled.

`reconstruct_data.py` is a GET-only portable input builder. Set WEEX_SOURCE_ROOT
to the repository folder holding backtests/frozen if reusing its historical prefix.
It uses only the prefix before2026-05-01 and official SPOT archives after that;
this avoids preserving old still-open final candles. Without that prefix, it
downloads the complete SPOT monthly archives for2024-05 through2026-04 too.
No futures klines may substitute for missing spot minutes. REST completes Oct11.
It extends public USD-M funding from a local public cache if present; otherwise
it downloads funding from the beginning. Existing input files are not modified.
The report's May overlap QA records the two old forming-minute corrections.

If using the author's CSV directly instead of reconstruction, copy to the expected
data filenames and record its hash. Exact author hashes were not available to us;
small ETH differences must not silently be described as byte-identical replay.
Different CSV float formatting or fully-archived historical volume can alter byte
hashes; compare numeric prices/ts, manifests and gap QA as well as hashes.

## Execution

Run each from the extracted package with Python:

1. reconstruct_data.py (optional, if the required input CSVs are absent)
2. verify_original.py (unaltered pinned primary BTC and ETH full-window replay)
3. audit_replay.py (all modes, original shuffles, funding, corrected999controls)
4. extra_controls.py (funded controls; count and time-exposure matching)
5. execution_stress.py (declared penetration/delay/slippage sensitivities)
6. variant_checks.py (SMA80/100/120 same window; separately verified1/4scale)
7. verify_funding.py (fresh public API vs cache; independent ledger calculation)
8. qa_replay.py, regime_toy_probes.py, range_probes.py (offline QA)
9. range_baseline.py (one BTC/ETH baseline; explicit ns compatibility conversion)
10. newbasket/bounded_long.py and newbasket QA (new frozen hypothesis, rejected)

Normal replay writes .npz trace files locally, not bundled here. Funding ledgers
are included for full regime, LONG→FLAT, SHORT→FLAT and boundary-reset both-side
models. Baseline funding uses inventory AFTER regime-flatten and BEFORE minute
fills; pre-flatten/end-minute quantities are also recorded. Newbasket uses funding
before opening fills/flip: see its own README; it cannot be called an identical
execution model. Both are hypothetical SPOT-fill/USD-M funding overlays.

`partial_candle_check.py` is a diagnostic that needs the ORIGINAL old short local
frozen files (ending May7), not a newer full author dataset. It restores the two
known old final-minute values and confirms that their replacement did not explain
the listed ETH differences. Do not run it on an unrelated extended file.

Manifests, public endpoint responses, original results and assertions are evidence
of the reported computations. There is no real WEEX fill/tick/queue backtest,
proof of positive expected return, complete account reconciliation, or untouched
forward sample. Final report is the authoritative interpretation.
