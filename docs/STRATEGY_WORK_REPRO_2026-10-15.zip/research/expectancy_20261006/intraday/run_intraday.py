"""Frozen, small hypothesis test. No strategy/config/API writes outside this folder.

Run: C:\\Program Files\\Python310\\python.exe research/expectancy_20261006/intraday/run_intraday.py
All candidates are declared in SPEC before data loading or outcome inspection.
"""
from pathlib import Path
import hashlib
import json
import math
import time
import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
SPEC = {
    'created_before_results': True,
    'symbols': ['BTCUSDT','ETHUSDT','XRPUSDT'],
    'common_start': '2024-03-13 00:00:00+00:00',
    'common_end': '2026-05-07 11:45:00+00:00',
    'fee_side': 0.0005, 'slip_base_side': 0.0002, 'slip_stress_side': 0.0004,
    'notional_usd': 1000, 'bootstrap_reps': 4000, 'placebo_reps': 64,
    'seed': 20261006,
    'families': [
        {'family':'scalp_impulse_follow','bar_minutes':5,'impulse_minutes':15,
         'thresholds':[2.0,2.5],'hold_minutes':[15,30],
         'minimum_impulse':0.0035,'volume_ratio':2.0,'stop_fraction':0.006,'target_R':2.0,'direction':1},
        {'family':'intraday_impulse_follow','bar_minutes':15,'impulse_minutes':60,
         'thresholds':[2.0,2.5],'hold_minutes':[60,120],
         'minimum_impulse':0.006,'volume_ratio':2.0,'stop_fraction':0.009,'target_R':2.0,'direction':1},
        {'family':'intraday_impulse_fade_control','bar_minutes':15,'impulse_minutes':60,
         'thresholds':[2.0,2.5],'hold_minutes':[60,120],
         'minimum_impulse':0.006,'volume_ratio':2.0,'stop_fraction':0.009,'target_R':2.0,'direction':-1},
    ],
    'rules': [
        'Spot minute OHLCV proxy; no funding or live-futures execution evidence.',
        'Impulse: close/close lag L minus one; volatility baseline: preceding 24h bar returns, excluding impulse window.',
        'Volume: L-bar volume / median L-bar volume over preceding 24h excluding impulse window.',
        'Only closed complete bars; market at the following minute open.',
        'Signal onset (threshold crossing or side change), fixed refractory interval = family maximum hold, independent of exits.',
        'One position; stop and target relative to actual slipped entry price, next-minute market at timed exit.',
        'Minute gap at stop uses worse opening price; gap at target uses threshold, no favorable gap credit.',
        'If stop and target both touched within one minute, stop first.',
        'Chronological equal-duration thirds; no selection by final third.',
        'Placebo: same signal onsets, sides and clustering shifted by integral weeks independently within each third.',
        'Discard boundary signals without full horizon; reject placebo draws whose executed count differs by over 2%.',
        'Monthly block bootstrap of trade expectancy; minute-close equity + immediate liquidation valuation at entry.',
    ]
}

def metric(t, idx=None, equity=None, bootstrap=True):
    if idx is not None: t=t.loc[idx]
    if not len(t): return {'n':0}
    net=t.net.to_numpy(); gross=t.gross.to_numpy()
    r=t.net_R.to_numpy(); up=net[net>0].sum(); down=-net[net<0].sum()
    ans={'n':len(t),'net_avg_pct':net.mean()*100,'gross_avg_pct':gross.mean()*100,
         'net_avg_R':r.mean(),'PF':float(up/down) if down else None,
         'net_usd':net.sum()*1000,'gross_usd':gross.sum()*1000,
         'win_rate':float((net>0).mean()),'mean_duration_min':float(t.duration.mean()),
         'median_stop_pct':float(t.stop_fraction.median()*100),
         'stress_net_avg_pct':float(t.stress_net.mean()*100),
         'cost_avg_pct':float((t.gross-t.net).mean()*100),
         'stop_n':int((t.reason=='stop').sum()),'target_n':int((t.reason=='target').sum()),
         'time_n':int((t.reason=='time').sum())}
    if equity is not None:
        peak=np.maximum.accumulate(np.r_[1000.,equity]); eq=np.r_[1000.,equity]
        ans['maxDD_usd']=float((peak-eq).max())
        ans['maxDD_pct_initial']=ans['maxDD_usd']/10
        ans['terminal_equity_usd']=float(equity[-1])
        ans['capital_breached']=bool((equity<=0).any())
    if bootstrap:
        months=t.groupby('month').agg(net=('net','sum'),nr=('net_R','sum'),n=('net','size'))
        values=months.to_numpy(); rng=np.random.default_rng(SPEC['seed'])
        sel=rng.integers(0,len(values),(SPEC['bootstrap_reps'],len(values)))
        sums=values[sel].sum(axis=1)
        ans['monthly_block_95_net_pct']=(np.quantile(sums[:,0]/sums[:,2]*100,[.025,.975])).tolist()
        ans['monthly_block_95_net_R']=(np.quantile(sums[:,1]/sums[:,2],[.025,.975])).tolist()
        ans['months_with_trades']=len(months)
    return ans

def build_events(d,f,threshold):
    bm=f['bar_minutes']; lag=f['impulse_minutes']//bm; win=1440//bm
    z=d.set_index('dt').resample(f'{bm}min',origin='epoch').agg(
        open=('open','first'),high=('high','max'),low=('low','min'),close=('close','last'),
        volume=('volume','sum'),count=('close','size'))
    ret=z.close.pct_change(fill_method=None)
    scale=ret.shift(lag).rolling(win,min_periods=win).std(ddof=1)*math.sqrt(lag)
    move=z.close/z.close.shift(lag)-1
    vsum=z.volume.rolling(lag,min_periods=lag).sum()
    vm=vsum.shift(lag).rolling(win,min_periods=win).median()
    full=z['count'].eq(bm).rolling(lag,min_periods=lag).sum().eq(lag)
    qualify=(move.abs()/scale>=threshold)&(move.abs()>=f['minimum_impulse'])&(vsum/vm>=f['volume_ratio'])&full
    sides=np.sign(move).fillna(0).to_numpy().astype(np.int8)*f['direction']
    q=qualify.fillna(False).to_numpy()
    onset=q & (~np.r_[False,q[:-1]] | (sides != np.r_[0,sides[:-1]]))
    entry_ts=(z.index.view('int64')//1_000_000 + bm*60000).to_numpy() if hasattr(z.index.view('int64'),'to_numpy') else z.index.view('int64')//1_000_000 + bm*60000
    ix=np.searchsorted(d.ts.to_numpy(),entry_ts)
    valid=(ix<len(d)) & onset
    selected=[]; next_ix=-1
    for j in np.flatnonzero(valid):
        i=int(ix[j])
        if i < next_ix: continue
        selected.append((i,int(sides[j])))
        next_ix=i+max(f['hold_minutes'])+1
    return np.array(selected,dtype=np.int64).reshape(-1,2)

def net_for(e,x,side,slip):
    ee=e*(1+side*slip); xx=x*(1-side*slip); ratio=xx/ee
    return side*(ratio-1)-SPEC['fee_side']*(1+ratio)

def simulate(d,events,f,hold,segments,make_equity=False,lean=False):
    o=d.open.to_numpy();h=d.high.to_numpy();l=d.low.to_numpy();c=d.close.to_numpy();ts=d.ts.to_numpy()
    rows=[]
    equity=np.full(len(d),1000.,dtype=np.float64) if make_equity else None
    realized=0.; prev=0; last_exit=-1
    for entry,side in events:
        entry=int(entry);side=int(side)
        if entry<=last_exit:continue
        segment=next((k for k,(a,b) in enumerate(segments) if a<=entry<b),None)
        if segment is None:continue
        a,b=segments[segment];timed=entry+hold
        if timed>=b:continue
        e=float(o[entry]); ee=e*(1+side*SPEC['slip_base_side'])
        stop=ee*(1-side*f['stop_fraction']);target=ee*(1+side*f['stop_fraction']*f['target_R'])
        seg=slice(entry,timed)
        hits_stop=np.flatnonzero(l[seg]<=stop) if side==1 else np.flatnonzero(h[seg]>=stop)
        hits_target=np.flatnonzero(h[seg]>=target) if side==1 else np.flatnonzero(l[seg]<=target)
        si=int(hits_stop[0]) if len(hits_stop) else hold
        ti=int(hits_target[0]) if len(hits_target) else hold
        if si<=ti and si<hold:
            ex=entry+si;x=min(stop,o[ex]) if side==1 else max(stop,o[ex]);reason='stop'
        elif ti<hold:
            ex=entry+ti;x=target;reason='target'
        else:ex=timed;x=float(o[ex]);reason='time'
        gross=side*(x/e-1);net=net_for(e,x,side,SPEC['slip_base_side'])
        # Stress re-runs the adverse stop/target geometry, rather than subtracting a constant from an exit.
        stress=np.nan;sex=ex
        if not lean:
            see=e*(1+side*SPEC['slip_stress_side'])
            sstop=see*(1-side*f['stop_fraction']);starget=see*(1+side*f['stop_fraction']*f['target_R'])
            shs=np.flatnonzero(l[seg]<=sstop) if side==1 else np.flatnonzero(h[seg]>=sstop)
            sht=np.flatnonzero(h[seg]>=starget) if side==1 else np.flatnonzero(l[seg]<=starget)
            ssi=int(shs[0]) if len(shs) else hold;sti=int(sht[0]) if len(sht) else hold
            if ssi<=sti and ssi<hold:
                sex=entry+ssi;sx=min(sstop,o[sex]) if side==1 else max(sstop,o[sex])
            elif sti<hold:sex=entry+sti;sx=starget
            else:sex=timed;sx=float(o[timed])
            stress=net_for(e,sx,side,SPEC['slip_stress_side'])
        et=pd.to_datetime(int(ts[entry]),unit='ms',utc=True) if not lean else None
        xt=pd.to_datetime(int(ts[ex]),unit='ms',utc=True) if not lean else None
        rows.append({'entry_ix':entry,'exit_ix':ex,'stress_exit_ix':sex,'entry_time':str(et),'exit_time':str(xt),
                     'side':side,'entry_mid':e,'entry_exec':ee,'exit_mid':x,
                     'gross':gross,'net':net,'stress_net':stress,'net_R':net/f['stop_fraction'],
                     'stop_fraction':f['stop_fraction'],'duration':ex-entry,'reason':reason,
                     'segment':['train','validation','test'][segment],'year':et.year if et is not None else None,'month':str(et)[:7]})
        if make_equity:
            equity[prev:entry]=1000+realized
            if ex>entry:
                ratios=c[entry:ex]*(1-side*SPEC['slip_base_side'])/ee
                mtm=side*(ratios-1)-SPEC['fee_side']*(1+ratios)
                equity[entry:ex]=1000+realized+1000*mtm
                # Entry-to-liquidation friction is observable before the first minute close.
                equity[entry]=min(equity[entry],1000+realized+1000*net_for(e,e,side,SPEC['slip_base_side']))
            realized+=1000*net;equity[ex]=1000+realized;prev=ex+1
        last_exit=ex
    if make_equity:equity[prev:]=1000+realized
    return pd.DataFrame(rows),equity

def shifted_events(events,segments,rng):
    result=[]
    shifts=[]
    week=7*1440
    for a,b in segments:
        selected=events[(events[:,0]>=a)&(events[:,0]<b)].copy()
        maxweeks=(b-a)//week
        weeks=int(rng.integers(2,maxweeks-1));shift=weeks*week;shifts.append(weeks)
        selected[:,0]=a+(selected[:,0]-a+shift)%(b-a)
        result.extend(selected.tolist())
    return np.array(sorted(result),dtype=np.int64).reshape(-1,2),shifts

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'spec.json').write_text(json.dumps(SPEC,ensure_ascii=False,indent=2),encoding='utf-8')
    metrics=[];placebos=[];audit={}
    st=pd.Timestamp(SPEC['common_start']);end=pd.Timestamp(SPEC['common_end'])
    for symbol in SPEC['symbols']:
        path=ROOT/'backtests'/'frozen'/f'{symbol}_1m_2y.csv'
        d=pd.read_csv(path);d['dt']=pd.to_datetime(d.ts,unit='ms',utc=True)
        audit[symbol]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_rows':len(d),
                       'source_start':str(d.dt.min()),'source_end':str(d.dt.max()),
                       'duplicates':int(d.ts.duplicated().sum()),'gap_steps':int(d.ts.diff().dropna().ne(60000).sum())}
        assert audit[symbol]['duplicates']==0 and audit[symbol]['gap_steps']==0
        d=d[(d.dt>=st)&(d.dt<=end)].reset_index(drop=True)
        n=len(d);cuts=[0,n//3,2*n//3,n];segments=list(zip(cuts[:-1],cuts[1:]))
        audit[symbol]['used_rows']=n
        audit[symbol]['thirds']={k:[str(d.dt.iloc[a]),str(d.dt.iloc[b-1])] for k,(a,b) in zip(['train','validation','test'],segments)}
        for f in SPEC['families']:
            for threshold in f['thresholds']:
                events=build_events(d,f,threshold)
                # Prefix independence must hold including cooldown, without filtering by future exits.
                prefix_n=n//2;pe=build_events(d.iloc[:prefix_n].copy(),f,threshold)
                assert np.array_equal(pe,events[events[:,0]<prefix_n]),'prefix causality failed'
                for hold in f['hold_minutes']:
                    name=f"{symbol}_{f['family']}_z{threshold:g}_h{hold}"
                    t,eq=simulate(d,events,f,hold,segments,True)
                    t.to_csv(OUT/f'trades_{name}.csv',index=False)
                    full=metric(t,equity=eq)
                    full.update({'name':name,'symbol':symbol,'family':f['family'],'threshold':threshold,'hold':hold,'period':'all'})
                    metrics.append(full)
                    for segname,(a,b) in zip(['train','validation','test'],segments):
                        # Rebase segment equity to $1000; positions cannot cross segment boundary.
                        seg_eq=eq[a:b]-eq[a-1]+1000 if a else eq[a:b]
                        row=metric(t,t.segment.eq(segname),seg_eq)
                        row.update({k:full[k] for k in ['name','symbol','family','threshold','hold']});row['period']=segname
                        metrics.append(row)
                    for year in sorted(t.year.unique()):
                        row=metric(t,t.year.eq(year),bootstrap=False)
                        row.update({k:full[k] for k in ['name','symbol','family','threshold','hold']});row['period']=str(year)
                        metrics.append(row)
                    rng=np.random.default_rng(SPEC['seed']);draw=0;accepted=0
                    while accepted<SPEC['placebo_reps'] and draw<SPEC['placebo_reps']*3:
                        draw+=1;se,shifts=shifted_events(events,segments,rng)
                        pt,_=simulate(d,se,f,hold,segments,lean=True)
                        if abs(len(pt)/len(t)-1)>.02:continue
                        accepted+=1
                        for period in ['all','train','validation','test']:
                            p=pt if period=='all' else pt[pt.segment.eq(period)]
                            pm=metric(p,bootstrap=False)
                            pm.update({'name':name,'period':period,'draw':accepted,'shift_weeks':str(shifts)})
                            placebos.append(pm)
                    print(name,'n',len(t),'avg%',round(full['net_avg_pct'],4),'PF',round(full['PF'],3),'placebos',accepted,flush=True)
        (OUT/'audit_full.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
        pd.DataFrame(metrics).to_csv(OUT/'metrics.csv',index=False)
        pd.DataFrame(placebos).to_csv(OUT/'placebos.csv',index=False)
    pd.DataFrame(metrics).to_json(OUT/'metrics.json',orient='records',indent=2)
    report=pd.DataFrame([m for m in metrics if m['period']=='all'])
    p=pd.DataFrame(placebos)
    for i,row in report.iterrows():
        null=p[(p.name==row['name'])&(p.period=='all')].net_avg_pct
        report.loc[i,'placebo_median_net_pct']=null.median()
        report.loc[i,'placebo_95th_net_pct']=null.quantile(.95)
        report.loc[i,'placebo_one_sided_p']=(1+(null>=row.net_avg_pct).sum())/(1+len(null))
        mtest=next(m for m in metrics if m['name']==row['name'] and m['period']=='test')
        report.loc[i,'test_net_avg_pct']=mtest.get('net_avg_pct',np.nan)
        report.loc[i,'test_n']=mtest['n']
        report.loc[i,'test_CI_lo_pct']=mtest.get('monthly_block_95_net_pct',[np.nan,np.nan])[0]
    report.to_csv(OUT/'summary.csv',index=False)
    print('FINISHED',len(report),'candidates',flush=True)

if __name__=='__main__':main()
