"""Apply the already frozen 36 candidates to subsequently supplied USD-M candles.
No parameter selection; real historical funding is included at settlement timestamps.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import run_intraday as lab

OUT=Path(__file__).resolve().parent
PUBLIC=OUT.parent/'public_data'

def add_funding(d,t,eq,funding):
    ts=d.ts.to_numpy();fx=funding.fundingTime.to_numpy();fr=funding.fundingRate.to_numpy()
    marks=pd.to_numeric(funding.markPrice,errors='coerce').to_numpy()
    cash=np.zeros(len(d)) if eq is not None else None
    # Funding quantity is constant within each trade: q * sum(rate * mark).
    # Prefix sums make the same exact settlement calculation efficient for placebo repeats.
    invalid=~np.isfinite(marks)|(marks<=0)
    if invalid.any():
        mi=np.clip(np.searchsorted(ts,fx[invalid]),0,len(d)-1)
        marks[invalid]=d.open.to_numpy()[mi]
    fp=np.r_[0.,np.cumsum(fr*marks)]
    entry=t.entry_ix.to_numpy(dtype=np.int64);ex=t.exit_ix.to_numpy(dtype=np.int64)
    sex=t.stress_exit_ix.to_numpy(dtype=np.int64)
    j0=np.searchsorted(fx,ts[entry],side='right');j1=np.searchsorted(fx,ts[ex],side='right')
    js=np.searchsorted(fx,ts[sex],side='right')
    sides=t.side.to_numpy();entry_exec=t.entry_exec.to_numpy()
    ret=-sides/entry_exec*(fp[j1]-fp[j0])
    stress_entry=t.entry_mid.to_numpy()*(1+sides*lab.SPEC['slip_stress_side'])
    stress_ret=-sides/stress_entry*(fp[js]-fp[j0])
    t['funding_return']=ret;t['net_ex_funding']=t.net.copy();t['net']=t.net+ret
    t['net_R']=t.net/t.stop_fraction;t['stress_net']=t.stress_net+stress_ret
    fund_rows=[]
    if cash is not None:
        for i in np.flatnonzero(j1>j0):
            for j in range(int(j0[i]),int(j1[i])):
                market_ix=int(np.searchsorted(ts,fx[j]));mark=marks[j]
                value=-sides[i]*fr[j]*mark/entry_exec[i]
                cash[market_ix]+=value*1000
                fund_rows.append({'trade_row':int(i),'fundingTime':int(fx[j]),'rate':float(fr[j]),'mark':float(mark),'net_usd':float(value*1000)})
    if cash is not None:eq=eq+cash.cumsum()
    return t,eq,fund_rows

def main():
    metrics=[];audit={};placebos=[]
    for symbol in lab.SPEC['symbols']:
        source=PUBLIC/f'binance_futures_{symbol}_1m.csv'
        d=pd.read_csv(source);d['dt']=pd.to_datetime(d.ts,unit='ms',utc=True)
        # Starting fresh data includes May 7, but all actual entries are after the frozen window.
        # The first 24h also serves as causal volatility/volume warmup.
        funding=pd.read_csv(PUBLIC/f'binance_futures_{symbol}_funding.csv').sort_values('fundingTime').reset_index(drop=True)
        assert d.ts.duplicated().sum()==0 and d.ts.diff().dropna().eq(60000).all()
        audit[symbol]={'rows':len(d),'start':str(d.dt.iloc[0]),'end':str(d.dt.iloc[-1]),
                       'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'duplicate_ts':0,'gaps':0,
                       'funding_rows':len(funding),'same_parameters_as_frozen_spec':True}
        segments=[(0,len(d))]
        for f in lab.SPEC['families']:
            for threshold in f['thresholds']:
                events=lab.build_events(d,f,threshold)
                for hold in f['hold_minutes']:
                    name=f"{symbol}_{f['family']}_z{threshold:g}_h{hold}"
                    t,eq=lab.simulate(d,events,f,hold,segments,True)
                    t,eq,fund_rows=add_funding(d,t,eq,funding)
                    t['segment']='fresh_futures_20260507_20261005'
                    t.to_csv(OUT/f'fresh_trades_{name}.csv',index=False)
                    pd.DataFrame(fund_rows).to_csv(OUT/f'fresh_funding_{name}.csv',index=False)
                    m=lab.metric(t,equity=eq)
                    m.update({'name':name,'symbol':symbol,'family':f['family'],'threshold':threshold,'hold':hold,
                              'period':'fresh_futures_20260507_20261005','funding_usd':float(t.funding_return.sum()*1000),
                              'net_ex_funding_avg_pct':float(t.net_ex_funding.mean()*100),
                              # WEEX taker .06% sensitivity: additional .01% on each actual traded notional.
                              'fee06_side_avg_pct':float((t.net-.0001*(1+t.exit_mid*(1-t.side*lab.SPEC['slip_base_side'])/t.entry_exec)).mean()*100)})
                    metrics.append(m)
                    rng=np.random.default_rng(lab.SPEC['seed']);draw=0;accepted=0
                    while accepted<64 and draw<192:
                        draw+=1;pe,shift=lab.shifted_events(events,segments,rng)
                        pt,_=lab.simulate(d,pe,f,hold,segments,lean=True)
                        if abs(len(pt)/len(t)-1)>.02:continue
                        # Lean rows carry no separate stress outcome, but net funding remains exact for baseline.
                        pt,_,_=add_funding(d,pt,None,funding)
                        accepted+=1
                        pm=lab.metric(pt,bootstrap=False)
                        pm.update({'name':name,'draw':accepted,'shift_weeks':str(shift)})
                        placebos.append(pm)
                    print(name,'fresh n',len(t),'net%',round(m['net_avg_pct'],4),'PF',round(m['PF'],3),'fund$',round(m['funding_usd'],2),flush=True)
        pd.DataFrame(metrics).to_csv(OUT/'fresh_metrics.csv',index=False)
        pd.DataFrame(placebos).to_csv(OUT/'fresh_placebos.csv',index=False)
        (OUT/'fresh_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    d=pd.DataFrame(metrics);p=pd.DataFrame(placebos)
    for i,row in d.iterrows():
        null=p[p.name==row['name']].net_avg_pct
        d.loc[i,'placebo_median_net_pct']=null.median()
        d.loc[i,'placebo_one_sided_p']=(1+(null>=row.net_avg_pct).sum())/(1+len(null))
    d.to_csv(OUT/'fresh_summary.csv',index=False)
    print('FRESH FINISHED',len(d),flush=True)

if __name__=='__main__':main()
