"""Read one simulated ETH ledger; diagnose cost and selective non-fill sensitivity.

No network, account, key, state, order or original-data writes. This is not a maker-fill model.
Run with Python 3.10+: python research/execution_focus_20261015/eth_diagnostic.py
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from statistics import mean, median

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / "expectancy_20261006" / "intraday" / (
    "fresh_trades_ETHUSDT_intraday_impulse_follow_z2.5_h120.csv"
)
COST_ROUND = 0.0004
ILLUSTRATIVE_NOTIONAL = 1000.0


def summarize(rows: list[dict]) -> dict:
    values = [r["gross_calc"] - COST_ROUND for r in rows]
    upside = sum(x for x in values if x > 0)
    downside = -sum(x for x in values if x < 0)
    return {
        "n": len(rows),
        "gross_mean_pct": mean(r["gross_calc"] for r in rows) * 100,
        "net_mean_pct": mean(values) * 100,
        "net_total_illustrative_usd": sum(values) * ILLUSTRATIVE_NOTIONAL,
        "profit_factor": upside / downside if downside else None,
        "win_rate": sum(x > 0 for x in values) / len(values),
    }


def main() -> None:
    raw = SOURCE.read_bytes()
    with SOURCE.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert rows, "empty simulated ledger"
    max_error = 0.0
    for number, row in enumerate(rows):
        row["row_0based"] = number
        row["side"] = int(row["side"])
        assert row["side"] in (-1, 1)
        for field in ("entry_mid", "exit_mid", "gross", "duration"):
            row[field] = float(row[field])
            assert math.isfinite(row[field]), (number, field)
        assert row["entry_mid"] > 0 and row["exit_mid"] > 0
        row["gross_calc"] = row["side"] * (row["exit_mid"] / row["entry_mid"] - 1)
        max_error = max(max_error, abs(row["gross_calc"] - row["gross"]))
    assert max_error < 1e-12, "stored gross disagrees with reconstructed signed price return"
    baseline = summarize(rows)
    ranked = sorted(rows, key=lambda r: r["gross_calc"] - COST_ROUND, reverse=True)
    exclusions = []
    for count in (1, 2, 3):
        removed_ids = {r["row_0based"] for r in ranked[:count]}
        remaining = [r for r in rows if r["row_0based"] not in removed_ids]
        exclusions.append({
            "missed_best_trades": count,
            "missed_signal_share": count / len(rows),
            "assumption": "These selected winners are absent; every other historical trajectory is unchanged.",
            "remaining": summarize(remaining),
        })
    entry_turnover = len(rows) * ILLUSTRATIVE_NOTIONAL
    exit_turnover = sum(ILLUSTRATIVE_NOTIONAL * r["exit_mid"] / r["entry_mid"] for r in rows)
    total_turnover = entry_turnover + exit_turnover
    cost_dollars = len(rows) * ILLUSTRATIVE_NOTIONAL * COST_ROUND
    data = {
        "as_of": "2026-10-15",
        "source": {
            "research_relative_path": "expectancy_20261006/intraday/" + SOURCE.name,
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "kind": "simulated historical trade ledger, not account executions",
            "venue": "Binance USD-M public minute candles; not WEEX",
            "first_entry_utc": min(r["entry_time"] for r in rows),
            "last_entry_utc": max(r["entry_time"] for r in rows),
            "max_abs_gross_reconstruction_error": max_error,
        },
        "cost": {
            "round_fraction_of_entry_notional": COST_ROUND,
            "round_bps": COST_ROUND * 10000,
            "interpretation": "All-in sensitivity cap; funding and legacy slippage are not charged again.",
            "illustrative_fixed_entry_notional_usd": ILLUSTRATIVE_NOTIONAL,
        },
        "baseline": baseline,
        "exit_reason_counts": dict(Counter(r["reason"] for r in rows)),
        "duration_minutes": {"mean": mean(r["duration"] for r in rows), "median": median(r["duration"] for r in rows)},
        "posthoc_direction_split_not_selection_rule": {
            "long": summarize([r for r in rows if r["side"] == 1]),
            "short": summarize([r for r in rows if r["side"] == -1]),
        },
        "selective_nonfill_stress_not_fill_probability_model": exclusions,
        "best_three": [{
            "row_0based": r["row_0based"], "entry_time": r["entry_time"],
            "side": r["side"], "reason": r["reason"],
            "net_illustrative_usd": (r["gross_calc"] - COST_ROUND) * ILLUSTRATIVE_NOTIONAL,
        } for r in ranked[:3]],
        "best_three_total_net_illustrative_usd": sum((r["gross_calc"] - COST_ROUND) * ILLUSTRATIVE_NOTIONAL for r in ranked[:3]),
        "turnover_units": {
            "definition": "sum of absolute entry and exit traded notional; no leverage multiplier",
            "illustrative_entry_turnover_usd": entry_turnover,
            "illustrative_exit_turnover_usd": exit_turnover,
            "illustrative_total_turnover_usd": total_turnover,
            "assumed_cost_total_usd": cost_dollars,
            "cost_per_million_total_turnover_usd_exact_ledger": cost_dollars / total_turnover * 1e6,
            "cost_per_million_total_turnover_usd_equal_legs": COST_ROUND / 2 * 1e6,
            "one_bp_fee_per_fill_per_million_turnover_usd": 0.0001 * 1e6,
            "limitation": "This is unit normalization, not a measured WEEX maker strategy cost.",
        },
        "inherited_source_rules": {
            "family": "intraday_impulse_follow", "signal_bar_minutes": 15,
            "impulse_minutes": 60, "abs_impulse_min_fraction": 0.006,
            "z_threshold": 2.5, "volume_ratio_min": 2.0,
            "volatility": "std(ddof=1) of preceding 96 fifteen-minute returns excluding the four impulse returns, multiplied by sqrt(4)",
            "volume": "sum of last four bar volumes / median of four-bar rolling volumes over preceding 96 bars excluding impulse window",
            "entry": "first qualification or side change; market at next minute open",
            "cooldown_minutes": 121,
            "one_position": True, "stop_fraction": 0.009,
            "target_fraction": 0.018, "time_exit_minutes": 120,
            "legacy_entry_adverse_slippage_fraction": 0.0002,
            "level_anchor": "legacy slipped entry; existing exit path is preserved in this diagnostic",
            "stop_and_target_same_minute": "stop first", "stop_gap": "worse opening price",
            "original_sizing": "fixed $1000 entry notional, not money-risk sizing",
        },
        "limits": [
            "Previously inspected data and post-hoc diagnostic; not a new out-of-sample test.",
            "No maker queue, latency, partials, reject, cancel or missing-winner probability is estimated.",
            "Existing stop/target exit paths were not rebuilt from a new actual entry fill.",
            "No WEEX book/trade CSV was available in inspected public research paths; private state was not inspected.",
            "The long/short split is diagnostic only and does not authorize selecting a side.",
        ],
    }
    (OUT / "eth_diagnostic.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    post = data["posthoc_direction_split_not_selection_rule"]
    after3 = exclusions[2]["remaining"]
    text = f"""# ETH execution diagnostic — 15.10.2026

Это **диагностика ранее просмотренного simulated ledger Binance USD-M**, не maker-fill модель и не результат WEEX.

Фиксированный кандидат: ETH / follow часового импульса / z2.5 / максимум120min. Все издержки сценария: **4bps за круг от входного номинала**, без повторного вычета funding/slippage.

| Наблюдение | Результат |
|---|---:|
| Сделок | {baseline['n']} |
| Средний gross | {baseline['gross_mean_pct']:+.9f}% |
| Средний net при4bps | {baseline['net_mean_pct']:+.9f}% |
| PF | {baseline['profit_factor']:.6f} |
| Net при условном фиксированном $1000 входе | ${baseline['net_total_illustrative_usd']:+.6f} |
| Сумма трёх лучших сделок | ${data['best_three_total_net_illustrative_usd']:+.6f} |
| Net среднего после исключения трёх лучших | {after3['net_mean_pct']:+.9f}% ({after3['n']} сделка) |

Если лимитное исполнение пропустит эти3 сделки ({3/len(rows):.3%} сигналов), исторический плюс исчезает. **Это выбранный adversarial stress; вероятность такого пропуска здесь не оценивалась.** Остальные сделки и их цена/выход не меняются.

Post-hoc разложение: long {post['long']['n']} / {post['long']['net_mean_pct']:+.9f}% на сделку; short {post['short']['n']} / {post['short']['net_mean_pct']:+.9f}%. Это не правило выбора только short.

Выходы: время {data['exit_reason_counts'].get('time', 0)}, стоп {data['exit_reason_counts'].get('stop', 0)}, тейк {data['exit_reason_counts'].get('target', 0)}. Медиана удержания {data['duration_minutes']['median']:.1f}min, средняя {data['duration_minutes']['mean']:.6f}min.

Правила источника: закрытые15m; часовой ход минимум0.6%, z≥2.5, volume ratio≥2; onset/side-change, cooldown121min; следующий minute-open market; stop0.9%, TP1.8%, максимум120min. Исторические уровни привязаны к прежнему slipped entry. Размер источника фиксированный$1000, не от риска. Смена исполнения требует нового replay, а не переименования этих fills в maker.

**Единицы оборота:** оборот=вход+выход. Круг4bps от входного номинала — примерно **$200/$1млн совокупного оборота** при равных ногах; точно по этому ledger ${data['turnover_units']['cost_per_million_total_turnover_usd_exact_ledger']:.6f}/$1млн. Fee1bp за каждое исполнение — $100/$1млн. Это пересчёт единиц, не оценка прибыльности maker-бота.

Исходник: `{SOURCE.name}`; SHA256 `{data['source']['sha256']}`. Gross независимо восстановлен из side/entry_mid/exit_mid; максимальная ошибка {max_error:.3g}. Скрипт читает только этот simulated CSV; исходник не меняет. Полные цифры — `eth_diagnostic.json`.

Следующая проверка заморожена в `ETH_EXECUTION_FROZEN_PROTOCOL_2026-10-15.md`. Исторических WEEX depth/trades в проверенных публичных исследовательских каталогах не найдено; очередь по Binance minute OHLCV доказать нельзя. Без соответствующего потока — только ограниченная candle sensitivity и перспективная бумажная запись.
"""
    (OUT / "eth_diagnostic.md").write_text(text, encoding="utf-8")
    print(json.dumps({"n": baseline["n"], "net_mean_pct": baseline["net_mean_pct"],
                      "drop_best3_net_mean_pct": after3["net_mean_pct"],
                      "source_sha256": data["source"]["sha256"],
                      "gross_reconstruction_max_error": max_error}, indent=2))


if __name__ == "__main__":
    main()
