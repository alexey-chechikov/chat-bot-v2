# Research reproducibility package, 15 October 2026

Public Binance inputs, historical simulations and explicitly synthetic CG/helper fixtures only. No raw CoinGlass screenshots/journal, WEEX recordings, private fills, credentials or account state. No live collector, bot deployment or Claude/Anthropic calls.

Extract to a NEW directory preserving research/ paths. Inspect docs/TRADING_SYSTEM_WORKPLAN_2026-10-15.md. ETH requires Python with numpy/pandas; CG, exporter and historical loader use the standard library.

From research/eth_causal_replay_20261015: python -m unittest -v test_replay; python run_replay.py; python root_independent_qa.py. The replay replaces only its own local result files.

From research/cg_sr1_20261015: python -m unittest -v test_cg_sr1. make_synthetic_fixture.py creates only clearly labeled fictional inputs; see README.

From research/strategy_workplan_20261015: python -m unittest -v test_spot_flow_history; python fetch_spot_flow_history.py (included cache makes this offline).

From research/public_market_export_20261015: python -m unittest -v test_export_public_market. Do not use the exporter on an account directory; its explicit whitelist expects recorder public CSV. Native Mac run is unverified. This helper exports existing files and is NOT a recorder.

Windows sandbox TMP failures: choose a writable task-local temporary directory for the test process; this does not alter algorithm/data. One symlink test may skip when OS forbids creating symlinks.

Every member except this manifest is hashed in PACKAGE_MANIFEST.json. Numerical correctness, synthetic PASS and inspected historical gains are not evidence of out-of-sample profit.
