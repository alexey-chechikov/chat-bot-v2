# Offline parser reproductions

Source commit: `3c9575befda56f14ee10f6ae6da8a30f61474474`.
The three snapshot files are unchanged public repository source; see SHA256.
No live account data, API credentials, TradingView market data or full third-party
video transcript is included.

Extract into a new writable directory and run with Python 3.10+:

```text
python verify_public_parser.py
```

The script extracts only the AST of each `_parse` function and supplies synthetic
globals/fixtures; production modules and network clients are not imported.
It asserts the existing bad behavior and returns zero when reproduced, rather
than claiming the parsers are correct. Compare parser_check_results.json.

Bybit: the documented allLiquidation shape becomes empty symbol / zero qty and
price, wrong side and synthetic local timestamp. OKX: a hypothetical linear
ctVal=0.01 demonstrates that sz*price is not correct contract normalization;
the multiplier is an illustration, not a live instrument query. Hyperliquid:
documented public trade without liquidation flag is discarded; that schema does
not establish liquidation-feed coverage. Live failure frequency was not measured.

After fixes, write safety tests that assert correct behavior on the same fixtures.
Recheck latest repository HEAD: this archive records a pinned historical version.
