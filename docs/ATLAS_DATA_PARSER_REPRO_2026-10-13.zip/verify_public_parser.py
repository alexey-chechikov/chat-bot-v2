"""Offline checks of documented payload handling; no live imports or API keys."""
import ast, json, subprocess, sys
from pathlib import Path
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]) if len(sys.argv)>1 else Path(r'C:\bot7\research\weex_publish_20261010')
PIN='3c9575befda56f14ee10f6ae6da8a30f61474474'
def parse_source(rel,globals_extra):
    local=HERE/'snapshot'/rel
    source=local.read_text(encoding='utf-8-sig') if local.exists() else subprocess.check_output(['git','show',PIN+':'+rel],cwd=REPO).decode('utf-8-sig')
    tree=ast.parse(source)
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_parse')
    ns={'time':SimpleNamespace(time=lambda:1800000000.0),**globals_extra}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),rel,'exec'),ns)
    return ns['_parse']

bybit=parse_source('collectors/liquidations/bybit.py',{})
msg={'topic':'allLiquidation.BTCUSDT','type':'delta','ts':1740000000010,
     'data':[{'T':1740000000000,'s':'BTCUSDT','S':'Buy','v':'0.01','p':'83000'}]}
got=bybit(msg)
assert got[0]['symbol']=='' and got[0]['qty']==0 and got[0]['price']==0
assert got[0]['side']=='short' and got[0]['ts_ms']==1800000000000

okx=parse_source('collectors/liquidations/okx.py',{'OKX_SYMBOL_MAP':{'BTC-USDT-SWAP':'BTCUSDT'}})
msg2={'arg':{'channel':'liquidation-orders'},'data':[{'instId':'BTC-USDT-SWAP',
    'details':[{'side':'sell','sz':'10','bkPx':'83000','ts':'1740000000000'}]}]}
got2=okx(msg2)
assert got2[0]['value_usd']==830000
# Hypothetical linear contract multiplier; not a live contract-spec query.
ct_val=.01
expected=10*ct_val*83000
assert expected==8300

hl=parse_source('collectors/liquidations/hyperliquid.py',{'HL_SYMBOL_MAP':{'BTC':'BTCUSDT'}})
msg3={'channel':'trades','data':[{'coin':'BTC','side':'A','px':'83000','sz':'0.01',
    'time':1740000000000,'hash':'fake','tid':123,'users':['fakeA','fakeB']}]}
got3=hl(msg3)
assert got3 is None
out={'source_commit':PIN,'scope':'documented-shape synthetic fixtures, not live incident',
 'bybit_documented_payload':{'actual':got,'expected':{'symbol':'BTCUSDT','side':'long',
     'qty':.01,'bankruptcy_price':83000,'update_time':1740000000000}},
 'okx_linear_contract_example':{'actual_value_usd':got2[0]['value_usd'],
     'assumed_ctVal':ct_val,'expected_value_usd':expected,'not_live_spec':True},
 'hyperliquid_documented_public_trade':{'actual':got3,
     'conclusion':'public WsTrade has no documented liquidation flag; this stream does not establish liquidation coverage'}}
(HERE/'parser_check_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
