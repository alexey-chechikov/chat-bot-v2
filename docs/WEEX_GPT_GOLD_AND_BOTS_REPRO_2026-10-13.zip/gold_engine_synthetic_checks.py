"""Offline counterexamples against the audited public gold research snapshot.

Only imports research/gold/sweep_backtest.py. No live code, network, or source edits.
The fixtures are synthetic and cannot reproduce the unpublished historical runs.
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "snapshot" / "research" / "gold" / "sweep_backtest.py"
spec = importlib.util.spec_from_file_location("gold_audited_sb", SOURCE)
sb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sb)

BASE_DAY = 20_000


def block(day: int, start_min: int, minutes: int, price: float, volume: float = 1.0):
    ts = (BASE_DAY + day) * sb.DAY + np.arange(start_min, start_min + minutes) * sb.MIN
    return {"ts": ts.astype(np.int64), **{k: np.full(minutes, price, dtype=float)
            for k in ("open", "high", "low", "close")}, "volume": np.full(minutes, volume, dtype=float)}


def combine(*parts):
    return {k: np.concatenate([p[k] for p in parts]) for k in parts[0]}


def set_bar(a, day, bar_min, *, o, h, l, c, volume=None):
    mask = (a["ts"] >= (BASE_DAY + day) * sb.DAY + bar_min * sb.MIN) & (
        a["ts"] < (BASE_DAY + day) * sb.DAY + (bar_min + 15) * sb.MIN)
    for k, val in (("open", o), ("high", h), ("low", l), ("close", c)):
        a[k][mask] = val
    if volume is not None:
        a["volume"][mask] = volume


def normal_fixture(minutes=360):
    a = combine(block(0, 0, 15, 100), block(1, 0, minutes, 104))
    set_bar(a, 1, 0, o=100.5, h=101, l=99, c=100.5)
    set_bar(a, 1, 15, o=100.5, h=102, l=99.5, c=101.5)
    return a


def first_trade(a, costs="net"):
    out = sb.simulate(sb.Market(a, "PAXG", False), "A", 3000.0, costs)
    assert out["trades"], "fixture failed to produce its intended trade"
    return out["trades"][0]


def main():
    result = {"source": str(SOURCE), "data": "synthetic only", "checks": {}}
    checks = result["checks"]

    # The human specification cancels an updated signal low before entry.
    a = normal_fixture()
    set_bar(a, 1, 30, o=98.99, h=99.10, l=98.99, c=99.04)
    t = first_trade(a, "gross")
    assert t["entry"] < t["sig_low"] and t["why"] == "цель"
    checks["entry_gap_after_confirmation"] = {
        "signal_low": t["sig_low"], "entry_open": t["entry"], "stop": t["stop"],
        "accepted_trades": 1, "exit": t["why"], "R": t["R"],
        "finding": "SPEC cancels this at the entry open; published protocol narrowed cancellation to confirmation."}

    # Missing data allows a nominal four-hour trade to last until next available bar.
    a = combine(normal_fixture(120), block(2, 0, 90, 90))
    t = first_trade(a)
    elapsed = (t["exit_ts"] - t["entry_ts"]) / 3_600_000
    assert elapsed == 23.5 and t["why"] == "время"
    checks["holding_limit_over_data_gap"] = {
        "hours_held": elapsed, "deadline_hours": 4, "exit": t["why"], "R": t["R"],
        "finding": "Code agrees with protocol's 'or later'; strict SPEC four-hour limit is not guaranteed."}

    # The final-data liquidation omits the exit fee and slippage charged on normal market exits.
    a = normal_fixture(90)
    t = first_trade(a)
    assert t["why"] == "конец данных"
    raw_end = float(a["close"][-1])
    correct_exit = raw_end * (1 - sb.SLIP)
    correct_fee = t["entry"] * t["qty"] * sb.INST["PAXG"]["taker"] + correct_exit * t["qty"] * sb.INST["PAXG"]["taker"]
    correct_pnl = (correct_exit - t["entry"]) * t["qty"] - correct_fee
    assert correct_pnl < t["pnl"]
    checks["end_of_data_exit_costs"] = {
        "qty": t["qty"], "recorded_exit": t["exit"], "recorded_fee": t["fee"],
        "entry_fee_only": t["entry"] * t["qty"] * sb.INST["PAXG"]["taker"],
        "recorded_pnl": t["pnl"], "costed_market_exit_pnl": correct_pnl,
        "optimism_usd": t["pnl"] - correct_pnl,
        "finding": "If open positions at EOF exist, missing liquidation costs bias reported PnL upward."}

    # The <=12h data rule and count(volume>0) rule differ even with full minute coverage.
    a = combine(block(0, 0, 720, 90), block(1, 0, 720, 100), block(2, 0, 60, 105))
    a["volume"][720] = 0
    m = sb.Market(a, "XAU", False)
    assert m.level[BASE_DAY + 2] == 90
    checks["day_completeness_counts_activity"] = {
        "previous_day_rows": 720, "previous_day_positive_volume_rows": 719,
        "previous_day_low": 100, "chosen_level": m.level[BASE_DAY + 2],
        "finding": "Protocol says data coverage >=12h; implementation requires >=720 positive-volume minutes."}

    # Selected complete days are not actually selected in the profile slice.
    a = combine(block(0, 0, 720, 100), block(1, 0, 1, 200, 500), block(2, 0, 720, 300), block(3, 0, 720, 400))
    m = sb.Market(a, "XAU", False)
    z = m.lvn(BASE_DAY + 3)
    width = 300 * sb.BIN_PCT
    base = np.floor(100 / width) * width
    missing_day_bin = int((200 - base) // width)
    i0 = np.floor((a["low"][:1441] - base) / width).astype(int)
    prof = np.bincount(i0, weights=a["volume"][:1441])
    assert prof[missing_day_bin] == 500
    checks["lvn_includes_incomplete_intermediate_day"] = {
        "selected_complete_day_offsets": [0, 2], "profile_slice_day_offsets": [0, 1, 2],
        "excluded_day_volume_in_profile": float(prof[missing_day_bin]),
        "finding": "Continuous slice includes incomplete days between selected complete days."}

    # A missing calendar day after the selected final day opens the slice through EOF.
    a = combine(block(0, 0, 15, 100), block(1, 0, 15, 105), block(3, 0, 15, 110), block(4, 0, 15, 120))
    z1 = sb.Market(a, "PAXG", False).lvn(BASE_DAY + 3)
    altered = {k: v.copy() for k, v in a.items()}
    future = altered["ts"] >= (BASE_DAY + 4) * sb.DAY
    for k in ("open", "high", "low", "close"):
        altered[k][future] = 300
    z2 = sb.Market(altered, "PAXG", False).lvn(BASE_DAY + 3)
    assert z2[0][-1] > z1[0][-1]
    checks["lvn_future_leak_when_next_calendar_day_absent"] = {
        "signal_day_offset": 3, "modified_future_day_offset": 4,
        "profile_max_edge_before_future_change": float(z1[0][-1]),
        "profile_max_edge_after_future_change": float(z2[0][-1]),
        "finding": "Changing later prices changes an earlier day's profile; G5 in report acknowledges possibility."}

    # Some otherwise confirmable signals near EOF are dropped by nb-4, regardless of confirmation at +1.
    a = combine(block(0, 0, 15, 100), block(1, 0, 90, 104))
    set_bar(a, 1, 30, o=100.5, h=101, l=99, c=100.5)
    set_bar(a, 1, 45, o=100.5, h=102, l=99.5, c=101.5)
    out = sb.simulate(sb.Market(a, "PAXG", False), "A", 3000, "net")
    assert not out["trades"]
    checks["final_four_signal_bars_excluded"] = {
        "bars_in_file": 7, "signal_bar_index": 3, "confirmation_bar_index": 4, "entry_bar_index": 5,
        "accepted_trades": len(out["trades"]),
        "finding": "while b < nb-4 removes a valid +1 confirmation followed by available entry."}

    # A no-gap stop has the specified gap-aware and cost-aware behavior.
    a = normal_fixture()
    set_bar(a, 1, 45, o=97, h=98, l=96, c=97)
    t = first_trade(a)
    assert t["why"] == "стоп" and t["R"] < -1
    checks["gap_stop_not_clamped_to_one_R_PASS"] = {"R": t["R"], "exit": t["exit"], "stop": t["stop"]}

    # A position-state filter can free time for an E signal missing from the B ledger.
    # Inject a fixed, already-known profile to isolate trade-state behavior from profile construction.
    a = combine(block(0, 0, 15, 100), block(1, 0, 1440, 100.1), block(2, 0, 360, 99.2))
    set_bar(a, 1, 1380, o=100.5, h=101, l=99, c=100.5)
    set_bar(a, 1, 1395, o=100.5, h=102, l=99.5, c=101.5)
    set_bar(a, 1, 1410, o=104, h=104, l=104, c=104)
    set_bar(a, 1, 1425, o=104, h=104, l=104, c=104)
    set_bar(a, 2, 60, o=99.2, h=100, l=98.99, c=99.5)
    set_bar(a, 2, 75, o=99.5, h=101, l=99.2, c=100.5)
    set_bar(a, 2, 90, o=101, h=106, l=101, c=105)
    m = sb.Market(a, "PAXG", False)
    m.lvn = lambda day, window=2: (np.array([98.9, 99.1]), np.array([True]), np.array([True]))
    btr = sb.simulate(m, "B", 3000, "net")["trades"]
    etr = sb.simulate(m, "E", 3000, "net")["trades"]
    bsignals, esignals = {t["sig_ts"] for t in btr}, {t["sig_ts"] for t in etr}
    assert len(btr) == len(etr) == 1 and esignals - bsignals
    checks["E_ledger_not_necessarily_subset_of_B"] = {
        "B_signal_offsets_hours": [(t["sig_ts"] - BASE_DAY * sb.DAY) / 3_600_000 for t in btr],
        "E_signal_offsets_hours": [(t["sig_ts"] - BASE_DAY * sb.DAY) / 3_600_000 for t in etr],
        "B_net_R": btr[0]["R"], "E_net_R": etr[0]["R"],
        "finding": "Filtering the fixed B trade ledger cannot reproduce separately simulated E when position state changes."}

    output = ROOT / "gold_engine_synthetic_results.json"
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
