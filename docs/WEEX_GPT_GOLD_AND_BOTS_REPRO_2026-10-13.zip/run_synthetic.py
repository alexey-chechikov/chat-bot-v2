"""Run only the offline audit fixtures, refusing outbound socket connections."""
from pathlib import Path
import contextlib
import io
import os
import runpy
import socket
import sys

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
for key in ('WEEX_API_KEY', 'WEEX_API_SECRET', 'WEEX_PASSPHRASE'):
    os.environ.pop(key, None)

def denied(*args, **kwargs):
    raise RuntimeError('Offline synthetic audit: outbound connection prohibited')

socket.socket.connect = denied
socket.socket.connect_ex = denied
socket.create_connection = denied

for name in ('gold_engine_synthetic_checks.py', 'gold_stats_probe.py',
             'repair_probes.py', 'research_contract_probes.py',
             'additional_boundary_probes.py',
             'weex_monitor_probes.py'):
    output = io.StringIO()
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            runpy.run_path(str(HERE / name), run_name='__main__')
    except Exception:
        print(output.getvalue())
        raise
    print(f'{name}: PASS (details in JSON)')
