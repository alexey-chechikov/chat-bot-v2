"""Offline synthetic/numerical audit. Never loads data or calls any exchange.

Run with the bundled Python. Imports only the pinned public gold source modules.
Synthetic ledgers are counterexamples, not estimates of real market performance.
"""
from __future__ import annotations

import contextlib
import importlib.util
import io
import json
import math
import re
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SOURCE = HERE / "snapshot"
sys.path.insert(0, str(SOURCE / "research/gold"))
import sweep_backtest as sb
import sweep_lvn_controls as ctl


def fake_ledger(values, start="2026-01-05", per_week=5, capital=3000.0):
    eq = capital
    out = []
    base = pd.Timestamp(start).value // 1_000_000
    for i, r in enumerate(values):
        entry_ts = int(base + (i // per_week) * 7 * sb.DAY + (i % per_week) * 3600_000)
        risk = sb.RISK * eq
        pnl = risk * r
        eq += pnl
        out.append(dict(R=float(r), pnl=float(pnl), eq=float(eq), r_usd=float(risk),
                        entry_ts=entry_ts, sig_ts=entry_ts, fee=0., slip=0., notional=0.,
                        entry=100., stop=99., why="время", same_minute=False))
    return out


def subset_counterexample():
    # Matches the reported PAXG B net n, WR (rounded), mean win/loss (rounded), and expectation.
    selected = []
    for week in range(20):
        nw = 3 if week < 5 else 2
        selected.extend([0.45] * nw + [-0.1] * (5 - nw))
    residual = (-0.451 * 194 - sum(selected)) / 94
    all_r = np.array(selected + [residual] * 94)
    tr = fake_ledger(selected)
    split = int(pd.Timestamp("2026-04-13").value // 1_000_000)  # 14 weeks of development, 6 holdout
    st = sb.stats(tr, 3000., split)
    st2 = sb.stats(fake_ledger([r - .03 for r in selected]), 3000., split)
    return {
        "label": "Synthetic aggregate-compatible counterexample; not a claimed footprint result",
        "B_n": len(all_r), "B_net_mean_R": float(all_r.mean()),
        "B_net_wr": float((all_r > 0).mean()), "B_avg_win_R": float(all_r[all_r > 0].mean()),
        "B_avg_loss_R": float(all_r[all_r <= 0].mean()),
        "C_subset_n": len(selected), "C_net_mean_R": st["exp_R"],
        "C_week_bootstrap_ci_R": st["ci_R"], "C_holdout": st["holdout"],
        "C_net_2slip_mean_R": st2["exp_R"], "C_status_from_actual_source": sb.status(st, st2),
        "not_identified_by_unconditional_mean": True,
    }


def actual_controls_probe(mask, level, n_trades=1):
    """Calls actual ctl.main() with stubbed data. Records real/random masks passed to near_zone."""
    edges = 1000. + .5 * np.arange(len(mask) + 1)
    calls = []
    trades = [dict(R=-.5 if i % 2 == 0 else .5, sig_ts=0, level=level,
                   entry=1001., stop=1000.) for i in range(n_trades)]
    real_market = sb.Market
    real_load = sb.load
    real_sim = sb.simulate
    oldargv = sys.argv

    class StubMarket:
        def __init__(self, *args, **kwargs):
            pass

        def lvn(self, day, window):
            return edges, np.asarray(mask, dtype=bool), np.ones(len(mask), dtype=bool)

        @staticmethod
        def near_zone(level_arg, edges_arg, mask_arg):
            calls.append(np.array(mask_arg, copy=True))
            return real_market.near_zone(level_arg, edges_arg, mask_arg)

    try:
        sb.Market = StubMarket
        sb.load = lambda _: ({}, {})
        sb.simulate = lambda *args, **kwargs: {"trades": trades}
        sys.argv = ["sweep_lvn_controls.py", "PAXG"]
        stream = io.StringIO()
        with warnings.catch_warnings(record=True) as caught, contextlib.redirect_stdout(stream):
            warnings.simplefilter("always")
            ctl.main()
        output = stream.getvalue()
        random_masks = [calls[i * (ctl.N_CTL + 1) + 1:(i + 1) * (ctl.N_CTL + 1)]
                        for i in range(n_trades)]
        return dict(output=output, warnings=[str(w.message) for w in caught], random_masks=random_masks)
    finally:
        sb.Market, sb.load, sb.simulate, sys.argv = real_market, real_load, real_sim, oldargv


def control_counterexamples():
    original = np.array([0, 0, 1, 0, 0, 1, 0, 0], dtype=bool)
    overlap = actual_controls_probe(original, 1001.25)
    masks = overlap["random_masks"][0]
    sizes = np.array([m.sum() for m in masks])
    zones = np.array([len(ctl.runs(m)) for m in masks])
    no_room = actual_controls_probe([0, 1, 1, 0, 1, 1, 0], 1001.)
    same_day = actual_controls_probe([0] * 10 + [1] + [0] * 9, 1005.25, n_trades=2)
    day0, day1 = same_day["random_masks"]
    edges = 1000. + .5 * np.arange(21)
    hits0 = np.array([sb.Market.near_zone(1005.25, edges, m) for m in day0])
    hits1 = np.array([sb.Market.near_zone(1005.25, edges, m) for m in day1])
    return {
        "overlapping_placements_actual_source": {
            "real_bins": int(original.sum()), "real_zones": len(ctl.runs(original)),
            "random_mean_bins": float(sizes.mean()), "random_mean_zones": float(zones.mean()),
            "draws_missing_a_bin": int((sizes < original.sum()).sum()),
            "draws_wrong_zone_count": int((zones != len(ctl.runs(original))).sum()),
            "draws": ctl.N_CTL, "exact_expected_bins": 11/6, "exact_expected_zones": 5/3,
        },
        "no_legal_width_matched_placement_actual_source": {
            "real_bins": 4, "real_zones": 2,
            "all_control_masks_empty": bool(all(not m.any() for m in no_room["random_masks"][0])),
            "actual_main_output": no_room["output"], "warnings": no_room["warnings"],
        },
        "same_day_identical_signals_actual_source": {
            "two_identical_levels_and_same_profile": True,
            "different_random_hit_decisions": int((hits0 != hits1).sum()), "draws": ctl.N_CTL,
            "first_signal_random_hits": int(hits0.sum()), "second_signal_random_hits": int(hits1.sum()),
            "exact_disagreement_probability": 2 * (6/19) * (13/19),
            "expected_disagreement_with_one_profile_per_day": 0.,
        },
    }


def bootstrap_and_r_units():
    one_week = fake_ledger([.52] + [(-.505*8-.52)/7]*7, per_week=8)
    ci = sb.stats(one_week, 3000., 0)["ci_R"]
    d, cost = .003, .0024
    # Code uses fee-inclusive planned stop risk for net size / account R, not bare price-stop risk.
    entry, stop = 1000., 997.
    unit = entry - stop + entry * .001 + stop * (.001 + .0002)
    return {
        "one_observed_iso_week_n8_ci_from_actual_source": ci,
        "meaning": "With one observed week, every block resample is the same ledger; CI is degenerate",
        "price_stop_R_round_trip_cost_at_median": cost/d,
        "exact_code_unit_at_entry_1000_stop_997": unit,
        "exact_code_total_round_trip_friction_account_R_approx": 2.4/unit,
        "account_return_identity": "equity_after/equity_before = 1 + 0.0025 * R",
    }


def number(s):
    return float(s.replace("$", "").replace(",", ""))


def table_audit():
    lines = (SOURCE / "docs/GOLD_LIQUIDITY_SWEEP_RESEARCH_2026-10-13.md").read_text(encoding="utf-8").splitlines()
    section = None
    perf = {}
    money = []
    quarters = []
    mode = None
    for line_no, line in enumerate(lines, 1):
        if line.startswith("### gold_"):
            section = line.split(":", 1)[0][4:]
            mode = None
        if section is None:
            continue
        if line.startswith("| Версия | n | WR"):
            mode = "perf"
        elif line.startswith("| Версия | Капитал"):
            mode = "money"
        elif line.startswith("| ") and not line.startswith("| Версия"):
            cols = [x.strip() for x in line.strip("|").split("|")]
            if cols[0] not in ("A", "B", "E"):
                continue
            if mode == "perf":
                match = lambda s: re.fullmatch(r"([+-]?(?:[\d.]+|nan)) \((\d+)\)", s)
                dev, hold = match(cols[7]), match(cols[8])
                perf[(section, cols[0])] = dict(line=line_no, n=int(cols[1]), wr=int(cols[2][:-1]),
                                                exp=float(cols[4]), dev=float(dev[1]), dev_n=int(dev[2]),
                                                hold=float(hold[1]), hold_n=int(hold[2]),
                                                exits=list(map(int, cols[12].split("/"))))
            elif mode == "money":
                money.append(dict(section=section, version=cols[0], line=line_no, cap=number(cols[1]),
                                  n=int(cols[2]), mean_usd=number(cols[3]), win=float(cols[4]), loss=float(cols[5]),
                                  fee=number(cols[6]), slip=number(cols[7]), turnover=number(cols[8]),
                                  final=number(cols[9])))
        if line.startswith("A по кварталам"):
            entries = re.findall(r"(\d{4}Q\d) ([+-]?[\d.]+) \((\d+)\)", line)
            quarters.append(dict(section=section, line=line_no,
                                 n=sum(int(e[2]) for e in entries), sum_R=sum(float(e[1]) for e in entries),
                                 quarters=len(entries)))
    perf_checks = []
    for (name, ver), row in perf.items():
        weighted = ((row["dev"]*row["dev_n"] + row["hold"]*row["hold_n"])/row["n"]
                    if row["hold_n"] else row["dev"])
        perf_checks.append(dict(section=name, version=ver, line=row["line"], n=row["n"],
                                exits_count_matches=sum(row["exits"])==row["n"],
                                split_count_matches=row["dev_n"]+row["hold_n"]==row["n"],
                                split_mean_minus_printed_mean=weighted-row["exp"],
                                split_mean_matches_at_printed_precision=abs(weighted-row["exp"])<=.001+1e-12))
    cash_checks = []
    for row in money:
        summary = perf[(row["section"], row["version"])]
        candidates = []
        for nw in range(row["n"]+1):
            if f"{nw/row['n']:.0%}" != str(summary["wr"])+"%":
                continue
            exp_from_win_loss = (nw*row["win"]+(row["n"]-nw)*row["loss"])/row["n"]
            if abs(exp_from_win_loss-summary["exp"]) <= .0055+1e-12:
                candidates.append(nw)
        cash_delta = row["final"]-row["cap"]
        exp_sum = row["mean_usd"]*row["n"]
        upper_compound_bound = row["cap"]*(1+sb.RISK*(summary["exp"]+.0005))**row["n"]
        cash_checks.append(dict(section=row["section"], version=row["version"], cap=row["cap"], line=row["line"],
                                possible_integer_wins_matching_WR_and_R=candidates,
                                cash_delta_minus_n_times_mean_usd=cash_delta-exp_sum,
                                cash_matches_rounding=abs(cash_delta-exp_sum)<=.5+row["n"]*.005+1e-12,
                                final_not_above_compound_mean_bound=(row["final"]-.5)<=upper_compound_bound))
    for row in quarters:
        a=perf[(row["section"],"A")]
        row["counts_match"] = row["n"]==a["n"]
        row["sum_R_minus_n_exp_R"] = row["sum_R"]-a["n"]*a["exp"]
        row["sums_match_rounding"] = abs(row["sum_R_minus_n_exp_R"]) <= row["quarters"]*.05+a["n"]*.0005+1e-12
    return {"performance_rows":perf_checks,"cash_rows":cash_checks,"quarters":quarters,
            "notes": ["Raw candle/trade JSON ledgers absent from supplied public snapshot; no empirical replication claimed",
                      "R profit factor and cash profit factor need not match because risk dollars compound across trades",
                      "Gross and net rows are different size/entry/target simulations; their R difference is not a pure cost attribution"]}


def main():
    out = {"commit":"8f093390b53615f5cb37545ffca5441443982d59",
           "subset_counterexample":subset_counterexample(),
           "lvn_control_probes":control_counterexamples(),
           "bootstrap_R_probe":bootstrap_and_r_units(),
           "published_table_self_consistency":table_audit()}
    path=HERE / "gold_stats_probe_results.json"
    path.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps({"output":str(path),"subset":out["subset_counterexample"],
                      "lvn":out["lvn_control_probes"],"R":out["bootstrap_R_probe"],
                      "performance_rows":len(out["published_table_self_consistency"]["performance_rows"]),
                      "cash_rows":len(out["published_table_self_consistency"]["cash_rows"])},indent=2,ensure_ascii=False))


if __name__ == "__main__":
    main()
