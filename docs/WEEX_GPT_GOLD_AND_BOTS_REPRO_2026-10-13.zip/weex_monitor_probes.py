"""Offline probes of public WEEX monitoring at 8f093390.

Source is parsed/compiled with AST; services imports and path manipulation are
removed. Only stdlib imports, synthetic files, and fake clients are executed.
No credentials are loaded and no network or private API is called.
Assertions document observed behavior, including deliberately bad-state results.
"""
from __future__ import annotations

import ast
import contextlib
import copy
import io
import json
import logging
import os
from pathlib import Path
import socket
import sys
import tempfile
import time
import types
from datetime import datetime, timezone

REVIEW = Path(__file__).resolve().parent
SNAPSHOT = REVIEW / "snapshot"
RESULTS = []


def parsed(relative, functions_only=False):
    path = SNAPSHOT / relative
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    body = []
    for node in tree.body:
        if isinstance(node, ast.ImportFrom) and (node.module or "").startswith(("services", "tests")):
            continue
        if isinstance(node, ast.Import) and any(a.name.startswith(("services", "tests", "pytest")) for a in node.names):
            continue
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
            func = node.value.func
            if isinstance(func, ast.Attribute) and func.attr == "insert":
                continue
        if isinstance(node, ast.If) and isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name) and node.test.left.id == "__name__":
            continue
        if functions_only and not isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.ClassDef, ast.Assign, ast.AnnAssign)):
            continue
        body.append(node)
    tree.body = body
    return compile(ast.fix_missing_locations(tree), str(path), "exec"), str(path)


def run_source(relative, bindings, argv=None, call_main=False):
    code, path = parsed(relative)
    env = {"__file__": path, "__name__": "offline_audit", **bindings}
    before = sys.argv
    sys.argv = [path] + (argv or [])
    out = io.StringIO()
    exit_code = 0
    try:
        with contextlib.redirect_stdout(out):
            try:
                exec(code, env)
                if call_main:
                    env["main"]()
            except SystemExit as exc:
                exit_code = exc.code
    finally:
        sys.argv = before
    return exit_code, out.getvalue(), env


class FakeClient:
    def __init__(self, trades=None, infos=None, opens=None, algos=None):
        self.trade_rows = [] if trades is None else trades
        self.infos = infos or {}
        self.opens = opens or []
        self.algos = algos or []
        self.info_calls = []

    def sync_time(self):
        return 0

    def book(self, symbol):
        return 100.0, 100.0

    def futures_balance(self):
        return [{"asset": "USDT", "balance": "14000", "availableBalance": "13000"}]

    def futures_positions(self):
        return []

    def open_orders(self, symbol):
        return self.opens

    def open_algo_orders(self, symbol):
        return self.algos

    def order_info(self, oid):
        self.info_calls.append(str(oid))
        return self.infos.get(str(oid), {})

    def user_trades(self, symbol, order_id=None, start_ms=None, end_ms=None):
        if self.trade_rows is False:
            return None
        if start_ms is None:
            return self.trade_rows
        return [t for t in self.trade_rows if start_ms <= int(t["time"]) <= end_ms]


def side():
    return {"lots": [], "entry": None, "strays": [], "pending": None,
            "realized": 0.0, "fees": 0.0, "n_entries": 0, "n_tps": 0}


def fixture(directory, cfg=None, st=None, journal=None, client=None):
    directory.mkdir(parents=True, exist_ok=True)
    cp, sp, jp = (directory / n for n in ("config.json", "state.json", "journal.jsonl"))
    config = {"symbol": "BTCUSDT", "dry_run": False, "enabled": True,
              "sides": ["LONG"], "release_sides": ["SHORT"], **(cfg or {})}
    state = st or {"symbol": "BTCUSDT", "LONG": side(), "SHORT": side(), "halted": False}
    cp.write_text(json.dumps(config), encoding="utf-8")
    sp.write_text(json.dumps(state), encoding="utf-8")
    records = journal if journal is not None else [{"ts": "2026-10-11T10:00:00+00:00", "side": "SHORT", "kind": "передано оператору"}]
    jp.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in records), encoding="utf-8")
    eg = types.SimpleNamespace(GRIDS=("BTC",), PREFIX="b7g", grid_files=lambda _: (cp, sp, jp))
    c = client or FakeClient()
    return {"WeexClient": lambda: c, "eg": eg}, (cp, sp, jp), state


def trade(tid, oid, pos="SHORT", side="SELL", price=100.0, qty=1.0, when="2026-10-12T10:00:00+00:00"):
    return {"id": tid, "orderId": oid, "positionSide": pos, "side": side,
            "price": str(price), "qty": str(qty), "commission": "0",
            "time": int(datetime.fromisoformat(when).timestamp() * 1000)}


def record(name, output, **details):
    RESULTS.append({"probe": name, **details, "output": output})


def account_probes(tmp):
    # A: a correctly matched order ID is not proof that ownership was read.
    c = FakeClient(trades=[trade("t1", "o1")], infos={"o1": {"orderId": "o1"}})
    bind, _, _ = fixture(tmp / "missing_owner", client=c)
    rc, out, _ = run_source("research/weex/account_now.py", bind, call_main=True)
    assert rc == 0 and "сделок бота после передачи 0" in out and "ИТОГ: ок" in out
    record("account_matching_id_missing_cid_false_ok", out, exit_code=rc)

    # B: without an immutable release record, an after-config-change bot fill is
    # unknowable. Current account output nevertheless says untouched + OK.
    c = FakeClient(trades=[trade("t1", "o1")], infos={"o1": {"orderId": "o1", "clientOrderId": "b7gBSx"}})
    journal = [{"ts": "2026-10-09T10:00:00+00:00", "side": "LONG", "kind": "вход"}]
    bind, _, _ = fixture(tmp / "no_release_record", journal=journal, client=c)
    rc, out, _ = run_source("research/weex/account_now.py", bind, call_main=True)
    assert rc == 0 and "после передачи н/д" in out and "бот сторону не трогал" in out
    record("account_no_release_record_false_ok", out, exit_code=rc)

    # C: null is a schema failure, not an empty, successful history response.
    bind, _, _ = fixture(tmp / "null_history", client=FakeClient(trades=False))
    rc, out, _ = run_source("research/weex/account_now.py", bind, call_main=True)
    assert rc == 0 and "ИТОГ: ок" in out
    record("account_null_history_false_ok", out, exit_code=rc)

    # D: positive control; unknown/wrong-order identity is detected.
    c = FakeClient(trades=[trade("t1", "o1")], infos={"o1": {"orderId": "wrong", "clientOrderId": "manual"}})
    bind, _, _ = fixture(tmp / "wrong_order_id", client=c)
    rc, out, _ = run_source("research/weex/account_now.py", bind, call_main=True)
    assert rc == 2 and "НЕ ВСЁ ПРОЧИТАНО" in out
    record("account_wrong_order_id_guard_passes", out, exit_code=rc)

    # E: halted is correctly a problem even with a fresh state file.
    bind, paths, st = fixture(tmp / "halted")
    st["halted"], st["halt_reason"] = True, "three failed closes"
    paths[1].write_text(json.dumps(st), encoding="utf-8")
    rc, out, _ = run_source("research/weex/account_now.py", bind, call_main=True)
    assert rc == 1 and "halted" in out
    record("account_halted_guard_passes", out, exit_code=rc)

    # G: time-window splitting refuses to silently certify saturated 1s data.
    saturated = [trade(str(i), f"o{i}") for i in range(100)]
    c = FakeClient(trades=saturated, infos={f"o{i}": {"orderId": f"o{i}", "clientOrderId": "manual"} for i in range(100)})
    bind, _, _ = fixture(tmp / "saturated_history", client=c)
    rc, out, _ = run_source("research/weex/account_now.py", bind, call_main=True)
    assert rc == 2 and "ВЫБОРКА СДЕЛОК НЕПОЛНА" in out
    record("account_saturated_second_incomplete_guard_passes", out, exit_code=rc)

    # H: diagnostic SMA lacks the live engine's recency/continuity validation.
    bind, _, _ = fixture(tmp / "stale_sma", cfg={"regime_sma": 100})
    today = int(time.time() // 86400)
    daily = [[d * 86400000, 0, 0, 0, str(100 + i), 0, (d + 1) * 86400000 - 1]
             for i, d in enumerate(range(today - 205, today - 100))]
    bind["eg"]._fetch_daily = lambda sym, n: daily
    rc, out, _ = run_source("research/weex/account_now.py", bind, call_main=True)
    assert rc == 0 and "режим ЛОНГ" in out
    record("account_stale_sma_prints_long_and_ok", out, exit_code=rc, last_bar_days_old=101)


def reconciliation_probes(tmp):
    # Removed, flat, unreleased SHORT retains accounting/history. Its wrong
    # realized total must not disappear just because it no longer has leftovers.
    st = {"symbol": "BTCUSDT", "LONG": side(), "SHORT": side(), "halted": False}
    st["SHORT"].update(realized=7.0, n_entries=1, n_tps=1)
    trs = [trade("1", "open", price=105.0), trade("2", "close", side="BUY", price=100.0)]
    c = FakeClient(trades=trs, infos={oid: {"orderId": oid, "clientOrderId": "b7gBS" + oid} for oid in ("open", "close")})
    bind, _, _ = fixture(tmp / "removed_flat", cfg={"release_sides": []}, st=st,
                         journal=[{"ts": "2026-10-09T10:00:00+00:00", "side": "SHORT", "kind": "вход"}], client=c)
    rc, out, env = run_source("research/weex/pnl_reconcile.py", bind)
    assert rc == 0 and env["SIDES"] == ["LONG"] and "SHORT:" not in out
    record("pnl_removed_flat_unreleased_side_skips_2usd_error", out, exit_code=rc, selected_sides=env["SIDES"], true_short_pnl=5.0, recorded_short_pnl=7.0)

    # Matching identity but missing cid causes both real bot fills to be counted
    # as manual; the zeroed owned state then 'reconciles'.
    trs = [trade("1", "open", pos="LONG", side="BUY", price=100.0), trade("2", "close", pos="LONG", side="SELL", price=105.0)]
    c = FakeClient(trades=trs, infos={oid: {"orderId": oid} for oid in ("open", "close")})
    bind, _, _ = fixture(tmp / "pnl_missing_cid", cfg={"release_sides": []}, client=c,
                         journal=[{"ts": "2026-10-09T10:00:00+00:00", "side": "LONG", "kind": "вход"}])
    rc, out, _ = run_source("research/weex/pnl_reconcile.py", bind)
    assert rc == 0 and "сетки 0, ручных 2" in out and "совпадает по LONG" in out
    record("pnl_missing_cid_5usd_bot_pnl_hidden_as_manual", out, exit_code=rc)


def orphan_probe(tmp):
    st = {"symbol": "BTCUSDT", "LONG": side(), "SHORT": side(), "halted": False}
    st["LONG"]["lots"] = [{"entry": 100.0, "qty": "1", "tp_order": {"id": "tp1"}}]
    c = FakeClient(infos={"tp1": {"orderId": "tp1", "status": "FILLED", "executedQty": "1"}}, opens=[])
    bind, _, _ = fixture(tmp / "tp_fill_race", cfg={"release_sides": []}, st=st, client=c)
    rc, out, _ = run_source("research/weex/orphan_check.py", bind)
    assert rc == 1 and "без тейка на бирже 1" in out and not c.info_calls
    record("orphan_filled_tp_false_unprotected_alarm", out, exit_code=rc, detail_query_count=len(c.info_calls), actual_bot_position=0)


def engine_module():
    code, path = parsed("services/weex_grid/engine.py")
    env = {"__file__": path, "__name__": "offline_engine"}
    exec(code, env)
    return types.SimpleNamespace(**env)


def engine_probes(tmp):
    eg = engine_module()
    px = {"mid": 100000.0}
    clock = {"t": time.time()}

    def now():
        clock["t"] += 10
        return clock["t"]

    directory = tmp / "engine_tp"
    directory.mkdir()
    ex = eg.DryExchange(lambda: (px["mid"] - .05, px["mid"] + .05), now_fn=lambda: clock["t"])
    cfg = {**eg.DEFAULT, "enabled": True, "dry_run": True, "sides": ["LONG"], "daily_loss_stop_usd": 0.0}
    g = eg.Grid(ex, cfg, state_path=directory / "state.json", journal_path=directory / "journal.jsonl", now_fn=now)
    g.tick()
    px["mid"] = 99790.0
    g.tick()
    old_tp = g.st["LONG"]["lots"][0]["tp_order"]["id"]
    original_open, original_info = ex.open_orders, ex.order_info
    ex.open_orders = lambda sym: [o for o in original_open(sym) if str(o["orderId"]) != old_tp]
    ex.order_info = lambda oid: {} if str(oid) == old_tp else original_info(oid)
    g.tick()
    new_tp = g.st["LONG"]["lots"][0]["tp_order"]["id"]
    active_tps = [oid for oid, o in ex.orders.items() if o["status"] in eg.LIVE and o["reduceOnly"]]
    assert new_tp != old_tp and old_tp in active_tps and new_tp in active_tps
    record("engine_unknown_missing_open_tp_places_duplicate", "", old_tp=old_tp, new_tp=new_tp, active_tp_ids=active_tps,
           old_tp_status=ex.orders[old_tp]["status"], bot_lot_qty=g.st["LONG"]["lots"][0]["qty"],
           combined_tp_qty=sum(float(ex.orders[o]["origQty"]) for o in active_tps))

    # Conditional same-side manual LONG: both limit TPs can execute within the
    # total exchange side size. The operator's present manual SHORT is separate.
    ex.orders["manual_long"] = {"clientOrderId": "manual-long", "side": "BUY", "positionSide": "LONG", "price": "100000",
                                "origQty": "0.0050", "status": "FILLED", "executedQty": "0.0050", "avgPrice": "100000", "reduceOnly": False}
    before_long = float(next(p["size"] for p in ex.futures_positions() if p["side"] == "LONG"))
    px["mid"] = 100200.0
    ex.book("BTCUSDT")
    after_long = float(next(p["size"] for p in ex.futures_positions() if p["side"] == "LONG"))
    assert ex.orders[old_tp]["status"] == ex.orders[new_tp]["status"] == "FILLED"
    assert abs(before_long - .0051) < 1e-9 and abs(after_long - .0049) < 1e-9
    record("engine_duplicate_tp_conditional_manual_long_reduced", "", before_long=before_long, after_long=after_long,
           manual_long_initial_qty=.0050, bot_long_qty=.0001, unexpected_manual_reduction=.0001,
           both_tp_statuses=[ex.orders[old_tp]["status"], ex.orders[new_tp]["status"]])
    px["mid"] = 99790.0

    # Wrong identity with a terminal status has the same replacement effect.
    directory_wrong = tmp / "engine_wrong_identity"
    directory_wrong.mkdir()
    ex_wrong = eg.DryExchange(lambda: (px["mid"] - .05, px["mid"] + .05), now_fn=lambda: clock["t"])
    px["mid"] = 100000.0
    g_wrong = eg.Grid(ex_wrong, cfg.copy(), state_path=directory_wrong / "state.json", journal_path=directory_wrong / "journal.jsonl", now_fn=now)
    g_wrong.tick()
    px["mid"] = 99790.0
    g_wrong.tick()
    wrong_old = g_wrong.st["LONG"]["lots"][0]["tp_order"]["id"]
    original_wrong_open, original_wrong_info = ex_wrong.open_orders, ex_wrong.order_info
    ex_wrong.open_orders = lambda sym: [o for o in original_wrong_open(sym) if str(o["orderId"]) != wrong_old]
    ex_wrong.order_info = lambda oid: {"orderId": "OTHER", "status": "FILLED", "executedQty": "0"} if str(oid) == wrong_old else original_wrong_info(oid)
    g_wrong.tick()
    wrong_new = g_wrong.st["LONG"]["lots"][0]["tp_order"]["id"]
    assert wrong_new != wrong_old and ex_wrong.orders[wrong_old]["status"] == ex_wrong.orders[wrong_new]["status"] == "NEW"
    record("engine_wrong_identity_tp_places_duplicate", "", old_tp=wrong_old, new_tp=wrong_new,
           active_tp_ids=[wrong_old, wrong_new], old_tp_status=ex_wrong.orders[wrong_old]["status"])

    # _orphans.save runs before _side; unsuccessful repeated ticks still renew
    # the file timestamp consumed by account_now's liveness check.
    cfg["dry_run"] = False
    cfg_path = directory / "config.json"
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")

    def fail_side(*args, **kwargs):
        raise TimeoutError("synthetic later-in-tick failure")

    g._side = fail_side
    failures = 0
    for _ in range(3):
        try:
            g.tick()
        except TimeoutError:
            failures += 1
    bind = {"WeexClient": lambda: FakeClient(), "eg": types.SimpleNamespace(GRIDS=("BTC",), PREFIX="b7g",
            grid_files=lambda _: (cfg_path, g.state_path, g.journal_path))}
    rc, out, _ = run_source("research/weex/account_now.py", bind, call_main=True)
    assert failures == 3 and rc == 0 and "цикл жив" in out
    record("account_failed_ticks_keep_mtime_alive", out, failed_ticks=failures, exit_code=rc)

    # A handed-over side with a tracked stray can be released on unknown detail;
    # this path still bypasses _detail's confirmed-terminal requirement.
    directory = tmp / "engine_release_stray"
    directory.mkdir()
    ex = eg.DryExchange(lambda: (99999.95, 100000.05), now_fn=lambda: clock["t"])
    cfg = {**eg.DEFAULT, "enabled": True, "dry_run": True, "sides": ["LONG"], "release_sides": ["SHORT"], "daily_loss_stop_usd": 0}
    g = eg.Grid(ex, cfg, state_path=directory / "state.json", journal_path=directory / "journal.jsonl", now_fn=now)
    ex.orders["stray"] = {"clientOrderId": "b7gBSt_old", "side": "BUY", "positionSide": "SHORT", "price": "99000",
                          "origQty": "0.0001", "status": "NEW", "executedQty": "0", "avgPrice": "0", "reduceOnly": True}
    g.st["SHORT"]["lots"] = [{"entry": 100000.0, "qty": "0.0001", "tp": 99000.0, "tp_order": None, "t": clock["t"]}]
    g.st["SHORT"]["strays"] = [{"id": "stray", "cid": "b7gBSt_old", "price": 99000.0, "qty": "0.0001", "kind": "t"}]
    real_info = ex.order_info
    ex.order_info = lambda oid: {} if str(oid) == "stray" else real_info(oid)
    g.tick()
    assert ex.orders["stray"]["status"] == "NEW" and not g.st["SHORT"]["lots"] and not g.st["SHORT"]["strays"]
    assert "передано оператору" in g.journal_path.read_text(encoding="utf-8")
    record("engine_release_unknown_stray_forgets_live_bot_tp", "", stray_status=ex.orders["stray"]["status"],
           short_lots=g.st["SHORT"]["lots"], short_strays=g.st["SHORT"]["strays"],
           journal=g.journal_path.read_text(encoding="utf-8"))


def errors_probe(tmp):
    # Day lookup has no UTC normalization; a Moscow-local source can straddle
    # the requested UTC day. This fixture only establishes coverage/level output.
    directory = tmp / "errors"
    directory.mkdir()
    (directory / "errors.log").write_text("2026-10-12 23:00:00,001 | ERROR | weex_grid | tick_failed\nTimeoutError: earlier\n", encoding="utf-8")
    (directory / "launchd_app_runner.err").write_text("2026-10-12 23:00:00,001 | ERROR | weex_grid | tick_failed\nTimeoutError: earlier\n2026-10-13 10:00:00,001 | ERROR | weex_grid | tick_failed\nTimeoutError: current\n", encoding="utf-8")
    code, path = parsed("research/weex/errors_today.py")
    env = {"__file__": path, "__name__": "offline_errors"}
    exec(code, env)
    env["LOGS"] = directory
    env["ERR_FILES"] = [directory / "errors.log"]
    env["CONSOLE"] = directory / "launchd_app_runner.err"
    before = sys.argv
    sys.argv = [path, "2026-10-13"]
    out = io.StringIO()
    try:
        with contextlib.redirect_stdout(out):
            env["main"]()
    finally:
        sys.argv = before
    output = out.getvalue()
    assert "ERROR «weex» 0" in output and "ПОКРЫТИЕ" not in output
    record("errors_missing_today_error_file_tail_claims_full_coverage", output,
           current_error_present_in_console=True, coverage_warning=False)


def main():
    logging.disable(logging.CRITICAL)
    def deny_socket(*args, **kwargs):
        raise RuntimeError("Network explicitly disabled for offline monitoring probes")
    socket.socket = deny_socket
    socket.create_connection = deny_socket
    with tempfile.TemporaryDirectory(prefix="weex_monitor_fixture_", dir=REVIEW) as directory:
        tmp = Path(directory)
        account_probes(tmp)
        reconciliation_probes(tmp)
        orphan_probe(tmp)
        engine_probes(tmp)
        errors_probe(tmp)
    target = REVIEW / "weex_monitor_probe_results.json"
    target.write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{len(RESULTS)} offline probes passed; evidence: {target}")
    for result in RESULTS:
        print(result["probe"])


if __name__ == "__main__":
    main()
