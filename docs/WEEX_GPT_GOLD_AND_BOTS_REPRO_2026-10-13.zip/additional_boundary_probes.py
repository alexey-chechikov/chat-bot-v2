"""Synthetic-only boundary tests; no private bundle, credentials or API imports."""
from pathlib import Path
import ast
import contextlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
import csv
import io
import json
import socket
import tempfile
import types
from urllib.parse import parse_qs, urlparse
import numpy as np

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'snapshot/research/weex'
def denied(*args, **kwargs):
    raise RuntimeError('Offline audit: outbound connections prohibited')
socket.socket.connect = denied
socket.socket.connect_ex = denied

tree = ast.parse((SOURCE / 'fast_grid.py').read_text(encoding='utf-8-sig'))
selected = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))
            and n.name in ('path4', 'Side', 'run')]
ns = {'np': np, 'dataclass': dataclass, 'field': field,
      'datetime': datetime, 'timezone': timezone, 'MAKER': .00016,
      '__name__': '__main__'}
exec(compile(ast.Module(body=selected, type_ignores=[]), str(SOURCE / 'fast_grid.py'), 'exec'), ns)

reg = ast.parse((SOURCE / 'regime_grid.py').read_text(encoding='utf-8-sig'))
fn = next(n for n in reg.body if isinstance(n, ast.FunctionDef) and n.name == 'run')
o, h, l, c = (np.array(x, float) for x in ([100,100,120,120], [100,100,120,120],
                                        [99,100,120,120], [100,100,120,120]))
rn = {'np': np, 'fg': types.SimpleNamespace(path4=ns['path4']),
      'DATA': (np.array([0,60,120,180]), o,h,l,c, np.array([True,True,False,False])),
      'SLIP': .0002, 'TAKER': .00048, 'MAKER': .00016, 'QTY': 1}
exec(compile(ast.Module(body=[fn], type_ignores=[]), str(SOURCE / 'regime_grid.py'), 'exec'), rn)
r = rn['run'](('synthetic', 'longflat', 0, 1, 100, 1, 10000))
expected_mid = (100-99)-99*.00016
assert abs(r[6]-expected_mid) > 19
assert abs(r[5]-r[6]) < 1e-10

ts = np.array([int(datetime(2026,1,31,23,59,tzinfo=timezone.utc).timestamp())+i*60
               for i in range(3)])
o, h, l, c = (np.array(x,float) for x in ([100,100,100], [100,100,100],
                                        [99,100,100], [99,100,100]))
month = ns['run']((ts,o,h,l,c), sides=('LONG',), step=1, target=1,
                  order_qty=1, cap_usd=10000)
true_jan = -99*.00016
true_feb = month['итог']-true_jan
assert month['по месяцам'] == [('2026-01', .96), ('2026-02', 0.)]
assert round(true_jan,2) == -.02 and round(true_feb,2) == .97

# Exercise only fetch() with fake responses and synthetic files. No network.
fetch_ast = ast.parse((SOURCE / 'fetch_1m.py').read_text(encoding='utf-8-sig'))
fetch_fn = next(n for n in fetch_ast.body if isinstance(n, ast.FunctionDef) and n.name == 'fetch')
base_ms = int(datetime(2025,12,11,tzinfo=timezone.utc).timestamp()*1000)
clock = types.SimpleNamespace(now=base_ms+30_000)
queried = []
def fake_urlopen(url, timeout=30):
    start_ms = int(parse_qs(urlparse(url).query)['startTime'][0])
    queried.append(start_ms)
    if clock.now < base_ms+60_000:
        candles = [[base_ms, '100', '105', '99', '101', '1', base_ms+59_999]]
    else:
        # Server would return the corrected older minute if it were requested.
        candles = [[base_ms, '100', '110', '98', '102', '2', base_ms+59_999],
                   [base_ms+60_000, '102', '103', '101', '102', '1', base_ms+119_999]]
    return io.BytesIO(json.dumps([k for k in candles if k[0]>=start_ms]).encode())

with tempfile.TemporaryDirectory(prefix='offline_fetch_', dir=HERE) as tmp:
    fn = {'DATA': Path(tmp), 'START': '2025-12-11', 'datetime': datetime,
          'timezone': timezone, 'csv': csv, 'json': json,
          'time': types.SimpleNamespace(time=lambda: clock.now/1000, sleep=lambda _:None),
          'urllib': types.SimpleNamespace(request=types.SimpleNamespace(urlopen=fake_urlopen))}
    exec(compile(ast.Module(body=[fetch_fn], type_ignores=[]), str(SOURCE / 'fetch_1m.py'), 'exec'), fn)
    with contextlib.redirect_stdout(io.StringIO()):
        fn['fetch']('FAKEUSDT')
    clock.now = base_ms+90_000
    with contextlib.redirect_stdout(io.StringIO()):
        fn['fetch']('FAKEUSDT')
    with (Path(tmp)/'FAKEUSDT_1m.csv').open() as f:
        rows = list(csv.reader(f))
    assert rows[1][4] == '101' and queried == [base_ms, base_ms+60_000]
    fetch_result = {'first_bar_was_unclosed_when_written': True,
                    'first_bar_stored_close': rows[1][4], 'first_bar_final_server_close': '102',
                    'second_download_skips_previous_minute': True}

out = {'data': 'synthetic only; no empirical historical effect measured',
       'units': 'USD-equivalent PnL, not R',
       'regime_midpoint_after_switch': {'recorded_mid': r[6], 'correct_mid': expected_mid,
           'recorded_second_half': r[5]-r[6], 'correct_second_half': r[5]-expected_mid},
       'calendar_month_boundary': {'recorded_months': month['по месяцам'],
           'correct_january': true_jan, 'correct_february': true_feb,
           'full_window_pnl': month['итог']},
       'research_downloader_unclosed_bar': fetch_result,
       'release_reporting_example': {'synthetic_old_realized_less_fees': 2.,
           'synthetic_transferred_bag': -5., 'before_release_display': -3.,
           'after_release_display': 2., 'display_increase': 5.,
           'realized_pnl_change': 0., 'label': 'Arithmetic example; not a live account event'}}
(HERE / 'additional_boundary_results.json').write_text(json.dumps(out, indent=2), encoding='utf-8')
print(json.dumps(out, indent=2))
