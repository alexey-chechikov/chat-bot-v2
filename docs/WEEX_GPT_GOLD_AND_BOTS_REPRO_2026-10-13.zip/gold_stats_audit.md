# Gold statistical / interpretation audit

Pinned source: public snapshot `8f093390b53615f5cb37545ffca5441443982d59`, as recorded in `source_manifest.json`. Read the whole protocol, research report, and all three sweep files. No raw candles or trade JSON ledgers were supplied. No exchange/private API was called; synthetic probes import only these offline source modules. Source files were not edited.

Reproducible evidence: `gold_stats_probe.py` → `gold_stats_probe_results.json`. Use the bundled Python at `C:\Users\Kemper\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe`. This exercises the actual `stats`, `status`, and `sweep_lvn_controls.main` functions with stubbed market data.

## Findings that affect interpretation

### Funding is omitted on a false duration argument

Protocol line 21 says XAU funding is excluded because holding time is ≤4h. Backtest PnL at lines 241–249 includes only execution PnL and fees; there is no funding ledger. A position open 07:45–08:15 crosses an 08:00 settlement while lasting only 30 minutes. More seriously, Binance's official announcement changed XAUUSDT from an 8-hour to a 4-hour funding interval effective 2026-01-30 18:15 UTC, with settlements beginning 20:00 and rate cap/floor ±0.50%. Thus the four-hour maximum hold is the funding interval for most of the tested sample, not grounds to omit funding.

Binance defines the payment as mark price × quantity × funding rate and charges positions open at a funding time. Negative rates credit a long, so the missing term cannot simply be assumed to worsen results. Actual counts/rates and the changed trade/equity path require replay against historical public funding data. A scale example, not an observed rate: XAU entry 1000, stop 997 gives planned risk per unit 4.1979 using the source fees/slippage; one funding event at 0.01% changes R by roughly 0.0238, at the stated ±0.50% cap by roughly ±1.191R. Do not claim these numbers occurred.

Primary sources: [Binance XAU funding interval notice](https://www.binance.com/en-TR/support/announcement/detail/55bd3594394a46daa910df5746355ff4), [Binance funding calculation and eligibility](https://www.binance.com/en/support/faq/detail/360033525031).

### The stated rejection gates do not establish the broad opening claim

Research lines 7–9 say there is no edge in the price setup or additions. The evidence supports failure to qualify the tested net proxy strategies, with stronger negative evidence for the sufficiently sampled main A/B ledgers. It does not establish the absence of a price edge or the absence of every addition:

- Line 8 itself gives gross PAXG A 95% CI −0.19…+0.05R, which includes a positive price expectation.
- C/D footprint are untested (lines 17–18, 30–33).
- E has n8/n10; XAU E's net CI is −0.843…+0.296R (line 106). The report correctly admits there is no evidence either way at these sample sizes (line 19), which contradicts the unqualified opening.
- S1 XAU B has n61 and CI −0.361…+0.043R (line 165), and S1 XAU E is actually +0.081R on n3 (line 166).

Protocol lines 91–95 define operational statuses and contain overlapping conditions: n<100 is insufficient, while a nonpositive estimate is rejected. Code lines 309–312 resolves this by testing rejection first. That can coherently mean "does not meet the frozen candidate gate"; it does not mean a small sample scientifically excludes positive expectation. Suggested wording: "The tested proxy variants do not qualify under the protocol at the modeled costs. Price edge is unconfirmed; footprint is untested; LVN samples are too small to establish an effect."

The report's incremental A↔B claim is also not accompanied by a CI for the difference. Point net improvements B−A are +0.059R PAXG, +0.066R XAU, +0.095R PAXG S1 and +0.086R XAU S1. Both strategy means being negative does not prove zero incremental benefit. A common calendar-week resample of both ledgers would be needed to estimate the difference and its uncertainty.

### B's unconditional mean is no upper bound on a footprint-selected C

Research lines 32–33 call C⊂B with B's near-zero raw price mean an "upper bound". A parent mean does not bound a conditional mean. The offline example is deliberately compatible with the report's PAXG B aggregate net values: n194, mean −0.451R, 45 positive trades (WR23%), mean win +0.45R, mean loss −0.723R (displayed −0.72R). It contains 45 winners +0.45R, 55 mild losses −0.10R, and 94 losses −1.0877R. Selecting the first 100 yields +0.1475R; balanced weekly placement gives the actual source bootstrap CI [+0.131,+0.1695], holdout +0.120R and +0.1175R after an illustrative extra 0.03R charge. The source status function calls this a candidate. This is a logical counterexample, not a claimed result for footprint.

The fixed >+0.45R price threshold also does not follow from the B average: selected trades can have different stop widths, costs in R, fee/price-risk normalization, and quantity rounding. Separately, implementing a filter with stateful one-position constraints can change which later signals are available; the implementation audit demonstrated that independently for E versus B.

## LVN controls fail to preserve the specified null

Protocol lines 82–83 specifies the same number and widths of random non-LVN zones. Controls lines 53–60 computes `free` once, draws every zone independently and never removes occupied bins. The actual-source stub probes quantify three problems:

1. With two separate one-bin real LVNs and six legal free bins, 172/999 draws place both zones on the same bin. 338/999 draws have a different contiguous-zone count; mean random coverage is 1.8278 bins and 1.6617 zones versus 2 bins and 2 real zones. Exact expectations are 11/6 bins and 5/3 zones. Adjacent placements merge zones, and overlapping placements lose coverage.
2. With two two-bin LVNs and only isolated one-bin non-LVN gaps, no zone has a legal replacement. Every control is empty. Actual source lines 65–70 drops all NaNs and still prints `0/0, rank 1.000`, with an All-NaN warning. Zero valid controls has no interpretable rank.
3. Lines 44–61 redraw a new random profile per trade rather than per profile/day. Two identical same-day levels with the same known profile receive different hit decisions in 390/999 draws. A random daily profile would give identical hit decisions. This changes within-day dependence and the null distribution.

These are reproducible algorithm errors; their effects on the published .258/.845 ranks are not quantified without the original profiles and trades. Both ranks are non-significant as published, but they cannot support a valid matched-zone comparison until the null is corrected. Draw nonoverlapping placements preserving the zone-width multiset (or explicitly state a different null), share each randomized daily profile across that day's signals, report draw validity/selected counts, and rerun the strategy for each control if comparing implemented E rather than fixed-B subsets.

Controls lines 39–65 filter an already completed B ledger; reported E comes from a fresh E simulation. The implementation agent's offline fixture produced B −0.9582R on one signal and E +1.7155R on a different later signal. Therefore these controls do not directly assess the full implemented E strategy.

## R, bootstrap, and MGC scope

`R = PnL/(0.0025×pretrade equity)` (backtest lines 200,247–249); sizing includes fees and stop slippage (line 201). This is realized account-risk R. The price-stop cost ratio .24%/.30%=.8 is another normalization. For entry 1000/stop997 and PAXG source costs, planned unit risk is 5.1964, and 2.4 of round-trip friction is approximately .462 account-risk R. Label the cost gate's price-stop R explicitly instead of treating every displayed R as identical. Gross and net runs additionally use different entry prices, targets, quantity caps and potentially paths, so subtracting their average R is not pure cost attribution. The report already acknowledges gross nominal-cap distortion at line 45 but leaves the stale gross rows in the main tables (A −.053, B +.011 versus corrected −.070/−.005).

The ISO-week bootstrap (backtest lines 270–280) correctly samples observed week clusters and concatenates their trades, estimating a per-trade mean, not an equal-week mean or account-return interval. It excludes empty weeks and does not resimulate sizing/capital under each reordered sample. Those choices are not automatically a bug for the stated per-trade conditional mean. Report the number of nonempty week clusters, particularly for E; the actual implementation with eight trades all in one observed ISO week returns a degenerate CI [−.505,−.505], illustrating that repeating a cluster 9,999 times does not create independent information. This synthetic case is not claimed for the real E ledger.

MGC quantity and tick value are correct: 10 troy ounces and .10 dollars per ounce, hence $1 per tick ([CME contract overview](https://www.cmegroup.com/education/lessons/micro-gold-and-micro-silver-futures-product-overview)). However, controls lines 81–86 apply `(PAXG/XAU entry−stop)×10+3` to proxy trades, not MGC data or MGC tick-rounded entry/stop rules. At $1000 the assumed $3 expenses alone exceed the $2.50 budget; at $3000 and $5000 this test requires proxy stop gaps ≤$0.45 and ≤$0.95. The 0/312 and 0/139 statements are proxy gap-budget screens under fixed expense assumptions, not a historical MGC backtest or a universal assertion that the actual MGC setup is impossible. Current PAXG ticks were also applied through history; the report's G2 sensitivity acknowledges this but the committed engine remains constant-tick.

## Published numbers: checks passed, replication unavailable

All 12 strategy table rows have consistent exit counts, development/holdout counts and weighted means within reported rounding. All 36 cash rows admit integer win counts compatible with the printed WR and rounded average win/loss R, agree with `final-capital = n×mean dollar PnL` within rounding, and respect the compound-mean bound. Quarter counts and R sums agree within rounding for all four sections. Main quarter sums: PAXG −159.1R versus 312×−.510=−159.12R; XAU −52.9R versus 139×−.381=−52.959R.

This supports internal arithmetic consistency, not the claim of 312/312 independent empirical replication in research lines 40–41. That requires the absent candles, trade JSON, full hashes and independent replay artifact. No observed-market CI, tick correction, LVN rank, MGC count or funding-adjusted mean was independently reproduced in this audit.
