"""Run only offline tests, with outbound socket connections prohibited."""
from pathlib import Path
import json,os,socket,sys,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'snapshot'));os.chdir(HERE/'snapshot')
def denied(*args,**kwargs):raise RuntimeError('Offline audit: outbound connection prohibited')
socket.socket.connect=denied;socket.socket.connect_ex=denied
for key in ('WEEX_API_KEY','WEEX_API_SECRET','WEEX_PASSPHRASE'):os.environ.pop(key,None)
native=os.replace;retry_count=0
def replace(src,dst,*args,**kw):
    global retry_count
    for attempt in range(20):
        try:return native(src,dst,*args,**kw)
        except PermissionError as e:
            if getattr(e,'winerror',None)!=5 or attempt==19:raise
            retry_count+=1;time.sleep(.025)
os.replace=replace
import pytest
args=sys.argv[1:] or ['tests/services/weex_grid','-q',f'--basetemp={HERE / "pytest_offline"}']
rc=pytest.main(args)
(HERE/'test_summary.json').write_text(json.dumps({'returncode':int(rc),'args':args,
    'outbound_network':'blocked','windows_actual_replace_retries':retry_count},indent=2),encoding='utf-8')
sys.exit(rc)
