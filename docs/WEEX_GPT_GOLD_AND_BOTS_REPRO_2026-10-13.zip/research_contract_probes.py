"""Synthetic checks of declared research preconditions, no exchange calls."""
from pathlib import Path
import ast,hashlib,io,json,sys
import numpy as np
import pandas as pd
HERE=Path(__file__).resolve().parent
folder=HERE/'research_cases';folder.mkdir(exist_ok=True)
p=folder/'BTCUSDT_sparse_1m.csv'
ts=np.array([int(t.timestamp()*1000) for t in pd.date_range('2024-01-01',periods=101,freq='D',tz='UTC')],dtype=np.int64)
pd.DataFrame({'ts':ts,'open':100.,'high':101.,'low':99.,'close':100.+np.arange(101)*.1}).to_csv(p,index=False)
src=HERE/'snapshot/research/weex/regime_grid.py'
tree=ast.parse(src.read_text(encoding='utf-8-sig'))
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='load')
ns={'SRC':p,'pd':pd,'np':np,'sys':sys,'io':io,'hashlib':hashlib}
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(src),'exec'),ns)
got=ns['load']()
assert len(got[0])==1
out={'sma_warmup_with_sparse_days':{'rows':101,'observed_minutes_per_day':1,
    'claimed_required_complete_days':100,'accepted_research_minutes':len(got[0]),
    'proof':'load accepted 100 prior days having one minute each'}}

# Exact key shape used by the GinArea runner, not a remote backtest.
def key(a,b,side,gs,target):return (a.date().isoformat(),b.date().isoformat(),side,gs,target)
a=pd.Timestamp('2026-10-01',tz='UTC')
b1=pd.Timestamp('2026-10-13 08:00',tz='UTC');b2=pd.Timestamp('2026-10-13 12:00',tz='UTC')
k1=key(a,b1,1,.6,1.4);k2=key(a,b2,1,.6,1.4)
assert k1==k2
out['ginarea_intraday_endpoint_collision']={'key':k1,'first_end':str(b1),
    'second_end':str(b2),'identical_skip_key':True,
    'full_spec_and_snapshot_hash_also_missing':True}
(HERE/'research_contract_probe_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
