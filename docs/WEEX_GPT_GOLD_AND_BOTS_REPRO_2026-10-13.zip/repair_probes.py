"""Offline file repair counterexamples using synthetic files only."""
from pathlib import Path
import importlib.util,json,os,time

HERE=Path(__file__).resolve().parent
p=HERE/'snapshot/research/weex/repair_frozen_1m.py'
spec=importlib.util.spec_from_file_location('repair_under_review',p)
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
base=HERE/'repair_cases';base.mkdir(exist_ok=True)
native_replace=os.replace
def replace(src,dst):
    for attempt in range(20):
        try:return native_replace(src,dst)
        except PermissionError as e:
            if getattr(e,'winerror',None)!=5 or attempt==19:raise
            time.sleep(.025)
r.os.replace=replace

path=base/'race_1m.csv'
initial=b'ts,open,high,low,close,volume\r\n0,1,1,1,1,1\r\n'
appended=b'60000,2,2,2,2,2\r\n'
path.write_bytes(initial);stat0=path.stat()
original_changed=r._changed
def check_then_append(p,st):
    changed=original_changed(p,st)
    assert not changed
    with p.open('ab') as f:f.write(appended);f.flush();os.fsync(f.fileno())
    return changed
r._changed=check_then_append
accepted=r.write_atomic(path,[initial.replace(b'0,1,1,1,1,1',b'0,1,2,1,2,1')],stat0)
r._changed=original_changed
assert accepted and appended not in path.read_bytes()
out={'check_replace_race':{'atomic_replace_returned_success':accepted,
     'append_between_check_and_replace_lost':appended not in path.read_bytes(),
     'final_bytes':path.read_bytes().decode()}}

# Sixty rows are not necessarily sixty distinct contiguous minutes.
r.FROZEN=base
hour=base/'FAKEUSDT_1h_2y.csv'
hour.write_bytes(b'ts,open,high,low,close,volume\r\n0,1,1,1,1,1\r\n')
rows=[]
for minute in range(60):
    if minute==17:continue
    rows.append(r.fmt(minute*60000,(100.,101.,99.,100.,1.)))
rows.insert(1,r.fmt(0,(100.,101.,99.,100.,1.)))
assert len(rows)==60
r.fix_hours('FAKEUSDT',rows,0,True)
after=hour.read_bytes().decode()
assert '60.0' in after
out['duplicate_missing_minute_hour']={'rows':60,'unique_minutes':59,
    'missing_minute':17,'treated_as_complete_hour':True,'rewritten_hour':after}

(HERE/'repair_probe_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
