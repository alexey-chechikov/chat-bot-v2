"""Offline quality/lineage audit of the first anonymous public WEEX capture.

Reads frozen public files only, writes quality_report.json/.md beside the capture.
No network, account keys, order clients, fills, FIFO estimates or PnL simulation.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parent
CAPTURE = ROOT / "market_capture_001"
SYMBOLS = ("BTCUSDT", "ETHUSDT")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc(value):
    return datetime.fromtimestamp(value / 1000, timezone.utc).isoformat()


def distribution(values):
    if not values:
        return {"n": 0}
    values = sorted(float(x) for x in values)
    def pct(f):
        at = (len(values)-1)*f
        left = int(at); weight = at-left
        return values[left]*(1-weight)+values[min(left+1,len(values)-1)]*weight
    return {"n":len(values),"min":values[0],"p50":pct(.5),"p95":pct(.95),"p99":pct(.99),"max":values[-1],"mean":mean(values)}


def read_csv(path):
    with path.open(encoding="utf-8-sig",newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    manifest = json.loads((CAPTURE/"capture_manifest.json").read_text())
    checksums = [{"file":f["file"],"sha256_matches_manifest":sha(CAPTURE/f["file"])==f["sha256"]} for f in manifest["files"]]
    assert all(r["sha256_matches_manifest"] for r in checksums), "frozen capture hash mismatch"
    frames = [json.loads(line) for line in (CAPTURE/"ordered_public.jsonl").read_text().splitlines()]
    seq = [f["receive_seq"] for f in frames]
    mono = [f["recv_monotonic_ns"] for f in frames]
    recv = [f["recv_ms"] for f in frames]
    raw_counts = Counter()
    raw_depth = defaultdict(list)
    raw_trades = defaultdict(list)
    raw_snapshot_trades = defaultdict(list)
    raw_receive_groups = defaultdict(set)
    for frame in frames:
        raw = json.loads(frame["raw_json"])
        typ = raw.get("e",raw.get("event","other"))
        raw_counts[typ] += 1
        symbol = raw.get("s")
        if symbol not in SYMBOLS:
            continue
        if typ in ("depthSnapshot","depth"):
            kind = "snapshot" if typ=="depthSnapshot" else "delta"
            key = (symbol,kind,int(raw["U"]) if "U" in raw else None,int(raw["u"]),int(raw["E"]))
            raw_depth[key].append((frame,raw))
            raw_receive_groups[(symbol,frame["session"],frame["recv_ms"])].add("depth")
        elif typ == "trade":
            raw_receive_groups[(symbol,frame["session"],frame["recv_ms"])].add("trades2")
            for batch_ix, trade in enumerate(raw.get("d",[])):
                raw_trades[(symbol,str(trade["t"]))].append((frame,batch_ix,trade))
        elif typ == "tradeSnapshot":
            for batch_ix, trade in enumerate(raw.get("d",[])):
                raw_snapshot_trades[symbol].append((frame,batch_ix,trade))
    ordered = {"frames":len(frames),"manifest_frames":manifest["received_frames"],
               "receive_seq_exact_1_to_n":seq==list(range(1,len(frames)+1)),
               "receive_seq_duplicates":len(seq)-len(set(seq)),
               "monotonic_reversals":sum(b<a for a,b in zip(mono,mono[1:])),
               "monotonic_equal_neighbor_pairs":sum(b==a for a,b in zip(mono,mono[1:])),
               "wallclock_reversals":sum(b<a for a,b in zip(recv,recv[1:])),
               "sessions":len({f["session"] for f in frames}),"event_counts":dict(raw_counts),
               "recv_span_ms":recv[-1]-recv[0],"monotonic_span_ms":(mono[-1]-mono[0])/1e6,
               "first_recv_utc":utc(recv[0]),"last_recv_utc":utc(recv[-1]),
               "raw_same_symbol_cross_stream_tie_groups":{s:sum(1 for (sym,_,_),kinds in raw_receive_groups.items() if sym==s and len(kinds)>1) for s in SYMBOLS}}
    assert ordered["receive_seq_exact_1_to_n"] and not ordered["monotonic_reversals"] and len(frames)==manifest["received_frames"]
    symbols = {}
    for symbol in SYMBOLS:
        depth = read_csv(CAPTURE/f"{symbol}_20261015_depth.csv")
        trades = read_csv(CAPTURE/f"{symbol}_20261015_trades2.csv")
        events = read_csv(CAPTURE/f"{symbol}_20261015_events.csv")
        state = {"b":{},"a":{}}; previous_u = None
        spreads, gaps, source_differences, minimum_levels = [], [], [], []
        lineage = Counter(); groups = defaultdict(list); directions=Counter()
        raw_offsets = []
        receive_differences = []
        for row in depth:
            U = int(row["U"]) if row["U"] else None
            u = int(row["u"]); E = int(row["E"])
            if row["kind"] == "snapshot":
                state = {"b":{},"a":{}}
            elif previous_u != U:
                gaps.append({"previous_u":previous_u,"next_U":U})
            if row["applied"] != "1":
                lineage["unapplied_depth"] += 1
            for side in ("b","a"):
                for p,q in json.loads(row[side]):
                    p,q=Decimal(p),Decimal(q)
                    if q > 0: state[side][p] = q
                    else: state[side].pop(p,None)
            previous_u = u
            minimum_levels.append((len(state["b"]),len(state["a"])))
            bid,ask=max(state["b"]),min(state["a"])
            assert bid<ask, "crossed reconstructed book"
            spreads.append(float((ask-bid)/((ask+bid)/2)*10000))
            source_differences.append(int(row["recv_ms"])-E)
            key=(symbol,row["kind"],U,u,E)
            candidates=raw_depth[key]
            if len(candidates)!=1:
                lineage["depth_unresolved_raw_match"]+=1; continue
            frame,raw=candidates[0]
            assert json.loads(row["b"])==raw["b"] and json.loads(row["a"])==raw["a"]
            assert row["session"]==frame["session"]
            lineage["depth_unique_raw_match"]+=1
            receive_differences.append(int(row["recv_ms"])-frame["recv_ms"])
            raw_offsets.append(frame["recv_ms"]-E)
            groups[(row["session"],int(row["recv_ms"]))].append(("depth",frame["receive_seq"],None))
        for row in trades:
            candidates=raw_trades[(symbol,row["t"])]
            if len(candidates)!=1:
                lineage["trade_unresolved_raw_match"]+=1; continue
            frame,batch_ix,raw=candidates[0]
            assert type(raw["m"]) is bool, "raw trade direction is not a JSON boolean"
            assert int(row["T"])==int(raw["T"]) and Decimal(row["p"])==Decimal(raw["p"]) and Decimal(row["q"])==Decimal(raw["q"])
            assert row["m_raw"] in ("True","False") and (row["m_raw"]=="True")==raw["m"]
            assert row["session"]==frame["session"]
            lineage["trade_unique_raw_match"]+=1
            directions["documented_seller_taker" if raw["m"] else "documented_buyer_taker"]+=1
            receive_differences.append(int(row["recv_ms"])-frame["recv_ms"])
            groups[(row["session"],int(row["recv_ms"]))].append(("trades2",frame["receive_seq"],batch_ix))
        cross=[items for items in groups.values() if len({x[0] for x in items})>1]
        resolved=sum(all(item[1] is not None for item in items) and len({(item[0],item[1]) for item in items})>=2
                     for items in cross)
        drecv=[int(row["recv_ms"]) for row in depth]
        trecv=[int(row["recv_ms"]) for row in trades]
        silences=[b-a for a,b in zip(drecv,drecv[1:])]
        overlap=max(0,min(drecv[-1],max(trecv))-max(drecv[0],min(trecv)))
        weighted_spread=sum(value*dt for value,dt in zip(spreads,silences))/sum(silences)
        both15_duration=sum(dt for counts,dt in zip(minimum_levels,silences) if min(counts)>=15)
        snapshot_ids={str(trade["t"]) for _,_,trade in raw_snapshot_trades[symbol]}
        csv_ids={row["t"] for row in trades}
        live_ids={ident for (sym,ident) in raw_trades if sym==symbol}
        snapshot_stats={"raw_snapshot_trade_rows":len(raw_snapshot_trades[symbol]),
                        "raw_snapshot_unique_ids":len(snapshot_ids),"snapshot_ids_also_in_csv":len(snapshot_ids&csv_ids),
                        "snapshot_ids_also_in_raw_live":len(snapshot_ids&live_ids),
                        "snapshot_only_ids_in_csv":len((snapshot_ids-live_ids)&csv_ids),
                        "snapshot_overlap_was_live_before_snapshot":sum(
                            min(frame["receive_seq"] for frame,_,_ in raw_trades[(symbol,ident)]) <
                            min(frame["receive_seq"] for frame,_,trade in raw_snapshot_trades[symbol] if str(trade["t"])==ident)
                            for ident in snapshot_ids&csv_ids&live_ids)}
        symbols[symbol]={"depth_rows":len(depth),"trade_rows":len(trades),"trade_unique_ids":len({row["t"] for row in trades}),
                         "event_counts":dict(Counter(row["event"] for row in events)),"sequence_chain_gaps":len(gaps),
                         "unapplied_depth":lineage["unapplied_depth"],"min_bid_levels":min(x[0] for x in minimum_levels),
                         "min_ask_levels":min(x[1] for x in minimum_levels),"spread_bps_event_weighted":distribution(spreads),
                         "spread_bps_time_weighted":weighted_spread,"depth_interval_ms":distribution(silences),
                         "depth_intervals_gt_1000ms":sum(t>1000 for t in silences),
                         "stale_excess_ms_after_1000":sum(max(0,t-1000) for t in silences),
                         "reconstructed_15level_coverage_ms_between_first_last_depth":both15_duration,
                         "depth_span_ms":drecv[-1]-drecv[0],"depth_trade_overlap_ms":overlap,
                         "coverage_endpoints_are_not_exchange_completeness":True,
                         "csv_recv_minus_exchange_E_ms_depth":distribution(source_differences),
                         "raw_recv_minus_exchange_E_ms_depth":distribution(raw_offsets),
                         "csv_recv_minus_sidecar_recv_ms":distribution(receive_differences),
                         "raw_lineage_matches":dict(lineage),"v2_same_ms_cross_stream_groups":len(cross),
                         "v2_groups_mapped_to_distinct_sidecar_sequence":int(resolved),
                         "trade_direction_documented_counts":dict(directions),"snapshot_backlog_audit":snapshot_stats}
        assert len(depth)==lineage["depth_unique_raw_match"] and len(trades)==lineage["trade_unique_raw_match"]
        assert resolved==len(cross)
    preflight=json.loads((ROOT/"quality_preflight.json").read_text())
    result={"status":"bounded_received_order_model_research_only","frozen_capture_integrity":checksums,
            "preflight_csv_status":preflight["status"],"preflight_issue_counts":preflight["issue_counts"],
            "ordered_sidecar":ordered,"symbols":symbols,
            "conclusion":"Sidecar resolves observed local receive-frame order, including the16CSV cross-stream tie groups; it does not establish exchange order/FIFO or feed completeness.",
            "clock_domain":"recv_ms and exchange E differ by about−5.4s. No network/order latency is inferred and no arbitrary historical clock shift is applied.",
            "next_gate":"Use monotonic+receive_seq received-order replay, retain explicit quality bounds, then collect several consecutive days/session regimes before any economics conclusion.",
            "snapshot_backlog_rule":"tradeSnapshot is historical bootstrap, not new aggressor flow for a paper order. Distinguish raw event types and deduplicate by trade ID; do not retroactively remove live events merely repeated in a later snapshot.",
            "not_established":["exact exchange ordering/FIFO queue", "complete public trade feed", "actual order/cancel latency", "maker fills or profitability", "multiday representativeness"],
            "scope":"offline public market data quality only; no network/account/order/model calls"}
    (ROOT/"quality_report.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    lines=["# Первый публичный WEEX capture: проверка качества —15.10.2026","",
           "**Вердикт: пригоден для ограниченной разработки received-order модели; экономику maker/точную FIFO-очередь эта запись не доказывает.**","",
           f"Проверены {len(frames)} raw frames и SHA256 всех {len(checksums)} файлов manifest. Сессия одна; receive_seq=1…N без пропусков/повторов, monotonic reversals=0. Длительность по monotonic {ordered['monotonic_span_ms']/1000:.3f}s. Все v2 depth/trades строки однозначно сопоставлены с исходным raw frame.","",
           "| Метрика | BTC | ETH |","|---|---:|---:|"]
    metrics=[("Depth updates", "depth_rows"),("Уникальные trades","trade_unique_ids"),("Depth U/u gaps","sequence_chain_gaps"),
             ("Интервалы depth>1000ms","depth_intervals_gt_1000ms"),("Depth/trade overlap,ms","depth_trade_overlap_ms"),
             ("CSV cross-stream ties,групп","v2_same_ms_cross_stream_groups"),("Из них привязаны к distinct receive_seq","v2_groups_mapped_to_distinct_sidecar_sequence")]
    for label,key in metrics: lines.append(f"|{label}|{symbols['BTCUSDT'][key]}|{symbols['ETHUSDT'][key]}|")
    lines.append(f"|Spread median,bps|{symbols['BTCUSDT']['spread_bps_event_weighted']['p50']:.6f}|{symbols['ETHUSDT']['spread_bps_event_weighted']['p50']:.6f}|")
    lines.append(f"|Spread time-weighted,bps|{symbols['BTCUSDT']['spread_bps_time_weighted']:.6f}|{symbols['ETHUSDT']['spread_bps_time_weighted']:.6f}|")
    lines.append(f"|Spread max,bps|{symbols['BTCUSDT']['spread_bps_event_weighted']['max']:.6f}|{symbols['ETHUSDT']['spread_bps_event_weighted']['max']:.6f}|")
    lines += ["", "Preflight v2 CSV: **incomplete** только из-за межпоточных совпадений wallclock millisecond. Sidecar с global receive_seq задаёт локальный порядок отдельных depth/trade frames; порядок записей внутри trade batch сохранён batch index. Monotonic совпадает у145 пар соседних кадров, поэтому один monotonic без seq недостаточен. Эти дополнительные ключи не меняют официальный статус старого CSV-only preflight задним числом.","",
              "На исходных sidecar recv_ms получаются10 BTC/5 ETH cross-stream tie groups; на CSV recv_ms —10/6. Между clock reads sidecar и Writer есть0–2ms, поэтому timestamp-совпадения сами могут различаться. Сопоставление по payload/sequence даёт однозначную lineage всех16 CSV-групп к отдельным raw frames.","",
              "Минимум15 положительных уровней каждой стороны наблюдалось на обоих символах; U/u цепочка непрерывна, unapplied/gap/resync/disconnect и receive-time silence>1000ms не найдены. Это контроль наблюдённого отрезка между endpoints, а не гарантия полноты публичной биржевой ленты или всего периода запроса. Завершение capture по ограничению времени не является доказанной websocket-доставкой всех последующих пакетов.","",
              "**Часы:** recv_ms−exchange E около−5.4секунды. Это несовпадение clock domains, не отрицательная network latency. Произвольный сдвиг исторических timestamp не применялся. Длительность/порядок локальной записи можно считать по monotonic+seq; точную send/ack/cancel latency ордера из публичного потока измерить нельзя.","",
              "**Направление trades:** raw m является JSON boolean и совпадает с m_raw CSV; true трактуется как seller taker, false как buyer taker согласно публичному recorder. Это проверка сохранения исходного поля и документированного mapping, не независимая сверка с собственными исполнениями/внутренней биржей.","",
              "**Snapshot/backlog:** в raw по20 сделок tradeSnapshot на символ. В BTC CSV snapshot IDs отсутствуют; в ETH CSV встречаются3 такихID, и все3 также пришли отдельными live trade frames. Snapshot-only IDs в CSV=0 для обоих. Одни лишьID-пересечения не доказывают загрязнение: CSV не хранит e/type, но sidecar сохраняет его и позволяет установить фактическую lineage. Для следующего replay tradeSnapshot — bootstrap/backlog, не новый агрессивный поток для исполнения paper-ордера. События надо разделять по raw type и дедуплицировать поID; live, повторённый в более позднем snapshot, не удалять задним числом.","",
              "**Что sidecar решает:** однозначную локальную lineage CSV→frame, receive-frame ties и воспроизводимый observed order на одном websocket. **Что остаётся:** exchange ordering между каналами, coalescing/задержки до клиента, скрытая ликвидность, собственное место в очереди, market impact, trade completeness и качество вне пяти минут.","",
              "Следующий минимальный gate: replay по monotonic+receive_seq с явными пределами качества и частичными fills; несколько последовательных суток разных сессий для статистики. Сначала проверяем механику/coverage, без заявления exact FIFO/прибыли. Ни maker PnL, ни fill probability в этой проверке не рассчитывались."]
    (ROOT/"quality_report.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps({"status":result["status"],"ordered":ordered,"symbols":symbols},ensure_ascii=False,indent=2))


if __name__=="__main__": main()
