import asyncio
import io
import json
import unittest
from capture_public import PublicSocket

class FakeSocket:
    def __init__(self):self.sent=[]
    async def send(self,value):self.sent.append(value)
    async def recv(self):return '{"e":"ping"}'

class PublicOnlyTests(unittest.TestCase):
    def test_trade_and_private_operations_cannot_be_sent(self):
        async def check():
            ws=FakeSocket();p=PublicSocket(ws,io.StringIO(),'synthetic')
            for data in ({'method':'ORDER'},{'method':'LOGIN'},
                         {'method':'SUBSCRIBE','params':['BTCUSDT@private']},
                         {'method':'SUBSCRIBE','params':[]}):
                with self.assertRaises(ValueError):await p.send(json.dumps(data))
            self.assertEqual(ws.sent,[])
        asyncio.run(check())

    def test_documented_public_subscription_and_pong(self):
        async def check():
            ws=FakeSocket();p=PublicSocket(ws,io.StringIO(),'synthetic')
            for data in ({'method':'SUBSCRIBE','params':['ETHUSDT@depth15','ETHUSDT@trade']},
                         {'method':'PONG','id':1}):await p.send(json.dumps(data))
            self.assertEqual(len(ws.sent),2)
        asyncio.run(check())

    def test_raw_capture_preserves_receipt_order(self):
        async def check():
            raw=io.StringIO();p=PublicSocket(FakeSocket(),raw,'synthetic')
            await p.recv();await p.recv()
            rows=[json.loads(x) for x in raw.getvalue().splitlines()]
            self.assertEqual([x['receive_seq'] for x in rows],[1,2])
            self.assertLessEqual(rows[0]['recv_monotonic_ns'],rows[1]['recv_monotonic_ns'])
            self.assertEqual(rows[0]['raw_json'],'{"e":"ping"}')
        asyncio.run(check())

if __name__=='__main__':unittest.main()
