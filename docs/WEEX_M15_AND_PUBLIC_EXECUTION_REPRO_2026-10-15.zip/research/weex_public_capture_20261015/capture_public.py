"""Finite anonymous WEEX public-market capture. No account config or trading clients.

Exact reviewed recorder snapshot is imported in isolation. Rotation is disabled.
An ordered raw sidecar retains wall+monotonic receipt and one connection sequence.
"""
from pathlib import Path
import argparse
import asyncio
import hashlib
import json
import sys
import time
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'))
import recorder_snapshot as recorder

URL='wss://ws-contract.weex.com/v3/ws/public'
CHANNELS={'BTCUSDT@depth15','ETHUSDT@depth15','BTCUSDT@trade','ETHUSDT@trade'}


class NoPruneWriter(recorder.Writer):
    def _prune(self):
        pass


class PublicSocket:
    def __init__(self,ws,raw_file,session):
        self.ws,self.raw_file,self.session=ws,raw_file,session
        self.seq=0

    async def send(self,text):
        data=json.loads(text)
        method=data.get('method')
        if method not in ('SUBSCRIBE','UNSUBSCRIBE','PONG'):
            raise ValueError('Only public subscribe/unsubscribe/pong is allowed')
        if method!='PONG' and (not isinstance(data.get('params'),list) or
                              not data['params'] or not set(data['params'])<=CHANNELS):
            raise ValueError('Non-allowlisted market channel')
        await self.ws.send(text)

    async def recv(self):
        raw=await self.ws.recv()
        received=time.time_ns()//1_000_000
        mono=time.monotonic_ns()
        self.seq+=1
        if isinstance(raw,bytes):
            raw=raw.decode('utf-8',errors='strict')
        self.raw_file.write(json.dumps({'receive_seq':self.seq,'recv_ms':received,
            'recv_monotonic_ns':mono,'session':self.session,'raw_json':raw},ensure_ascii=False)+'\n')
        self.raw_file.flush()
        return raw


async def capture(out,seconds):
    from websockets.asyncio.client import connect
    out.mkdir(parents=True,exist_ok=False)
    session=str(time.time_ns()//1_000_000)
    started=datetime.now(timezone.utc).isoformat()
    writer=NoPruneWriter(out)
    status='error';error_type=None;frames=0
    try:
        with (out/'ordered_public.jsonl').open('x',encoding='utf-8') as raw:
            async with connect(URL,user_agent_header='research-public-book-capture',
                               ping_interval=None,open_timeout=15,close_timeout=5,
                               max_size=2**22,proxy=None) as ws:
                public=PublicSocket(ws,raw,session)
                try:
                    await asyncio.wait_for(recorder._session(public,('BTCUSDT','ETHUSDT'),
                        writer,asyncio.Event(),session),timeout=seconds)
                except asyncio.TimeoutError:
                    status='bounded_capture_complete'
                frames=public.seq
    except Exception as exc:
        error_type=type(exc).__name__
        for symbol in ('BTCUSDT','ETHUSDT'):
            writer.event(symbol,time.time_ns()//1_000_000,session,'disconnect',error_type)
    finally:
        writer.flush();writer.close()
    files=[]
    for path in sorted(out.iterdir()):
        if path.is_file():
            body=path.read_bytes()
            files.append({'file':path.name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
    manifest={'source':'WEEX anonymous public futures websocket','endpoint':URL,
        'symbols':['BTCUSDT','ETHUSDT'],'channels':sorted(CHANNELS),
        'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),
        'requested_seconds':seconds,'status':status,'error_type':error_type,'received_frames':frames,
        'account_keys_read':False,'orders_sent':False,'claude_or_anthropic_used':False,
        'retention_deletions':False,'ordered_sidecar':'ordered_public.jsonl','files':files,
        'recorder_snapshot_sha256':hashlib.sha256((ROOT/'recorder_snapshot.py').read_bytes()).hexdigest()}
    (out/'capture_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:manifest[k] for k in ('status','error_type','received_frames','started_utc','finished_utc')},ensure_ascii=False))
    return 0 if status=='bounded_capture_complete' and frames else 1


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--seconds',type=int,default=300)
    args=p.parse_args()
    if not 10<=args.seconds<=600:
        p.error('seconds must be in [10,600]')
    if args.out.exists():
        p.error('use a new output folder; existing data are immutable')
    return asyncio.run(capture(args.out.resolve(),args.seconds))

if __name__=='__main__':
    raise SystemExit(main())
