# Первый публичный WEEX capture: проверка качества —15.10.2026

**Вердикт: пригоден для ограниченной разработки received-order модели; экономику maker/точную FIFO-очередь эта запись не доказывает.**

Проверены 2215 raw frames и SHA256 всех 11 файлов manifest. Сессия одна; receive_seq=1…N без пропусков/повторов, monotonic reversals=0. Длительность по monotonic 299.984s. Все v2 depth/trades строки однозначно сопоставлены с исходным raw frame.

| Метрика | BTC | ETH |
|---|---:|---:|
|Depth updates|601|601|
|Уникальные trades|1955|2340|
|Depth U/u gaps|0|0|
|Интервалы depth>1000ms|0|0|
|Depth/trade overlap,ms|299096|299734|
|CSV cross-stream ties,групп|10|6|
|Из них привязаны к distinct receive_seq|10|6|
|Spread median,bps|0.012152|0.041212|
|Spread time-weighted,bps|0.013311|0.045027|
|Spread max,bps|0.534400|1.561762|

Preflight v2 CSV: **incomplete** только из-за межпоточных совпадений wallclock millisecond. Sidecar с global receive_seq задаёт локальный порядок отдельных depth/trade frames; порядок записей внутри trade batch сохранён batch index. Monotonic совпадает у145 пар соседних кадров, поэтому один monotonic без seq недостаточен. Эти дополнительные ключи не меняют официальный статус старого CSV-only preflight задним числом.

На исходных sidecar recv_ms получаются10 BTC/5 ETH cross-stream tie groups; на CSV recv_ms —10/6. Между clock reads sidecar и Writer есть0–2ms, поэтому timestamp-совпадения сами могут различаться. Сопоставление по payload/sequence даёт однозначную lineage всех16 CSV-групп к отдельным raw frames.

Минимум15 положительных уровней каждой стороны наблюдалось на обоих символах; U/u цепочка непрерывна, unapplied/gap/resync/disconnect и receive-time silence>1000ms не найдены. Это контроль наблюдённого отрезка между endpoints, а не гарантия полноты публичной биржевой ленты или всего периода запроса. Завершение capture по ограничению времени не является доказанной websocket-доставкой всех последующих пакетов.

**Часы:** recv_ms−exchange E около−5.4секунды. Это несовпадение clock domains, не отрицательная network latency. Произвольный сдвиг исторических timestamp не применялся. Длительность/порядок локальной записи можно считать по monotonic+seq; точную send/ack/cancel latency ордера из публичного потока измерить нельзя.

**Направление trades:** raw m является JSON boolean и совпадает с m_raw CSV; true трактуется как seller taker, false как buyer taker согласно публичному recorder. Это проверка сохранения исходного поля и документированного mapping, не независимая сверка с собственными исполнениями/внутренней биржей.

**Snapshot/backlog:** в raw по20 сделок tradeSnapshot на символ. В BTC CSV snapshot IDs отсутствуют; в ETH CSV встречаются3 такихID, и все3 также пришли отдельными live trade frames. Snapshot-only IDs в CSV=0 для обоих. Одни лишьID-пересечения не доказывают загрязнение: CSV не хранит e/type, но sidecar сохраняет его и позволяет установить фактическую lineage. Для следующего replay tradeSnapshot — bootstrap/backlog, не новый агрессивный поток для исполнения paper-ордера. События надо разделять по raw type и дедуплицировать поID; live, повторённый в более позднем snapshot, не удалять задним числом.

**Что sidecar решает:** однозначную локальную lineage CSV→frame, receive-frame ties и воспроизводимый observed order на одном websocket. **Что остаётся:** exchange ordering между каналами, coalescing/задержки до клиента, скрытая ликвидность, собственное место в очереди, market impact, trade completeness и качество вне пяти минут.

Следующий минимальный gate: replay по monotonic+receive_seq с явными пределами качества и частичными fills; несколько последовательных суток разных сессий для статистики. Сначала проверяем механику/coverage, без заявления exact FIFO/прибыли. Ни maker PnL, ни fill probability в этой проверке не рассчитывались.
