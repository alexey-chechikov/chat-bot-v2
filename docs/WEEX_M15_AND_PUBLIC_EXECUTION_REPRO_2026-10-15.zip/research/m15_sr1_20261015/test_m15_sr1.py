"""Offline synthetic regression tests; these do not load the research market history."""
import math
import unittest

import numpy as np
import pandas as pd

import run_m15_sr1 as lab

T = 1_800_000_000_000


def market(n=6, changes=None, start=T):
    data = {}
    for symbol in lab.SYMBOLS:
        rows = [{"ts": start+i*lab.MINUTE, "open": 100., "high": 100., "low": 100., "close": 100.} for i in range(n)]
        for (s, i), values in (changes or {}).items():
            if s == symbol:
                rows[i].update(values)
        data[symbol] = pd.DataFrame(rows)
    return data


def signal(symbol="BTCUSDT", ix=0, side=1, stop=98., ident="level-1"):
    return lab.Signal(symbol, ix, side, stop, ident, T-3*15*lab.MINUTE, T-15*lab.MINUTE)


def custom_bars(low, high=None, minutes=15, start=T):
    high = high if high is not None else [x+1 for x in low]
    return pd.DataFrame({"ts": [start+i*minutes*lab.MINUTE for i in range(len(low))],
                         "low": low, "high": high, "open": [(l+h)/2 for l,h in zip(low,high)],
                         "close": [(l+h)/2 for l,h in zip(low,high)], "valid": True})


class IndicatorTests(unittest.TestCase):
    def test_pivot_only_available_at_start_i_plus_3(self):
        b = custom_bars([5,4,1,3,4,5,6])
        ix, ready = lab.available_pivots(b, "low", 15)
        self.assertEqual(ix.tolist(), [2])
        self.assertEqual(int(np.searchsorted(ready, T+4*15*lab.MINUTE, side="right")), 0)
        self.assertEqual(int(np.searchsorted(ready, T+5*15*lab.MINUTE, side="right")), 1)

    def test_equal_neighbors_are_not_pivots(self):
        b = custom_bars([5,4,1,1,4,5])
        self.assertEqual(lab.pivot_indices(b, "low").tolist(), [])

    def test_incomplete_right_confirmation_bar_invalidates_pivot(self):
        b = custom_bars([5,4,1,3,4,5]); b.loc[4, "valid"] = False
        self.assertEqual(lab.pivot_indices(b, "low").tolist(), [])

    def test_context_frozen_at_signal_start_not_end(self):
        lows = [100,99,95,99,100,101,102,101,97,101,102,103,104,103,99,103,104]
        highs = [l+1 for l in lows]; highs[5]=110; highs[11]=112
        h = custom_bars(lows, highs, minutes=60)
        lows15 = [100.] * 65; lows15[53]=90.; lows15[57]=80.
        q = custom_bars(lows15, [105.]*65)
        self.assertIsNone(lab.frozen_context(q, h, 55))  # second1h high unavailable before14:00
        at59 = lab.frozen_context(q, h, 59)
        self.assertEqual(at59["pivot_ix"], 53)  # pivot57 only confirmed by close59
        self.assertEqual(lab.frozen_context(q, h, 60)["pivot_ix"], 57)
        changed = q.copy(); changed.loc[59, "low"] = 70.
        self.assertEqual(lab.frozen_context(changed, h, 59), at59)

    def test_wilder_seed_and_previous_atr(self):
        b = custom_bars([99.]*16, [101.]*16)
        b.loc[14, "high"] = 105.
        atr = lab.wilder_atr(b)
        self.assertTrue(np.isnan(atr[12]))
        self.assertEqual(atr[13], 2.)
        self.assertAlmostEqual(atr[14], (13*2+6)/14)
        changed = b.copy(); changed.loc[14, "high"] = 150.
        self.assertEqual(lab.wilder_atr(changed)[13], atr[13])


class ExecutionTests(unittest.TestCase):
    def test_entry_minute_stop_and_same_minute_tie_stop_first(self):
        d = market(changes={("BTCUSDT",0): {"high":110., "low":90.}})
        ledger, equity, counts, _ = lab.simulate(d, [signal()], {}, lab.Config())
        row = ledger.iloc[0]
        self.assertEqual(row.reason, "stop_both_touched")
        self.assertEqual(row.duration_minutes, 0)
        self.assertEqual(row.exit_time_ms, T+lab.MINUTE-1)
        self.assertLess(row.net_usd, 0)
        self.assertAlmostEqual(equity.liquidation_equity.iloc[-1]-10000, row.net_usd)

    def test_gap_stop_worse_than_trigger_and_plan_is_not_hard_cap(self):
        d = market(changes={("BTCUSDT",1): {"open":95., "high":96., "low":94., "close":95.}})
        ledger, _, _, _ = lab.simulate(d, [signal()], {}, lab.Config())
        self.assertEqual(ledger.iloc[0].reason, "stop_gap")
        self.assertEqual(ledger.iloc[0].exit_mid, 95.)
        self.assertLess(ledger.iloc[0].net_R, -1.)
        self.assertEqual(ledger.iloc[0].exit_time_ms, T+lab.MINUTE)

    def test_target_gap_gives_no_favorable_open_credit(self):
        d = market(changes={("BTCUSDT",1): {"open":120., "high":121., "low":110., "close":120.}})
        ledger, _, _, _ = lab.simulate(d, [signal()], {}, lab.Config())
        self.assertEqual(ledger.iloc[0].reason, "target_gap")
        self.assertAlmostEqual(ledger.iloc[0].exit_mid, ledger.iloc[0].target)
        self.assertLess(ledger.iloc[0].exit_mid, 120.)

    def test_known_target_gap_precedes_later_stop_and_excludes_later_funding(self):
        d = market(changes={("BTCUSDT",1): {"open":120.,"high":121.,"low":90.,"close":95.}})
        funding = {"BTCUSDT": [{"fundingTime":T+lab.MINUTE+5,"fundingRate":.01,"markPrice":100.}]}
        ledger, _, _, _ = lab.simulate(d, [signal()], funding, lab.Config())
        self.assertEqual(ledger.iloc[0].reason, "target_gap")
        self.assertEqual(ledger.iloc[0].exit_time_ms, T+lab.MINUTE)
        self.assertEqual(ledger.iloc[0].funding_settlements, 0)
        self.assertGreater(ledger.iloc[0].net_usd, 0)

    def test_short_stop_and_directional_cost_signs(self):
        d = market(changes={("BTCUSDT",0): {"high":103., "low":90.}})
        ledger, _, _, _ = lab.simulate(d, [signal(side=-1, stop=102.)], {}, lab.Config())
        r = ledger.iloc[0]
        self.assertEqual(r.reason, "stop_both_touched")
        self.assertLess(r.entry_exec, r.entry_mid)
        self.assertGreater(r.exit_exec, r.exit_mid)
        self.assertGreater(r.slippage_cost_usd, 0)

    def test_simultaneous_crosssymbol_uses_btc_priority(self):
        ledger, _, counts, _ = lab.simulate(market(), [signal("ETHUSDT",ident="eth"), signal()], {}, lab.Config(hold_minutes=1))
        self.assertEqual(ledger.symbol.tolist(), ["BTCUSDT"])
        self.assertEqual(counts["signal_skip_crosssymbol_priority"], 1)

    def test_busy_portfolio_cannot_reenter_on_same_exit_minute(self):
        ledger, _, counts, _ = lab.simulate(market(), [signal(), signal("ETHUSDT",ix=1,ident="eth")], {}, lab.Config(hold_minutes=1))
        self.assertEqual(len(ledger), 1)
        self.assertEqual(counts["signal_skip_busy"], 1)

    def test_pivot_cannot_be_used_twice_after_stop(self):
        d = market(changes={("BTCUSDT",0): {"low":97.}})
        ledger, _, counts, _ = lab.simulate(d, [signal(), signal(ix=1)], {}, lab.Config())
        self.assertEqual(len(ledger), 1)
        self.assertEqual(counts["signal_skip_used_pivot"], 1)

    def test_max_three_entries_per_utc_day(self):
        d = market(changes={("BTCUSDT",i): {"low":97.} for i in range(5)})
        ledger, _, counts, _ = lab.simulate(d, [signal(ix=i,ident=f"p{i}") for i in range(5)], {}, lab.Config())
        self.assertEqual(len(ledger), 3)
        self.assertEqual(counts["signal_skip_daily_entry_limit"], 2)

    def test_daily_kill_uses_mtm_and_next_open_causally(self):
        d = market(changes={("BTCUSDT",1): {"high":100., "low":99., "close":99.},
                            ("BTCUSDT",2): {"open":98., "high":98., "low":98., "close":98.}})
        cfg = lab.Config(risk_fraction=.1)
        ledger, equity, counts, incidents = lab.simulate(d, [signal(stop=90.), signal(ix=3,stop=90.,ident="later")], {}, cfg)
        self.assertEqual(ledger.reason.tolist(), ["daily_kill"])
        self.assertEqual(ledger.exit_ix.tolist(), [2])
        self.assertEqual(incidents[0]["event"], "daily_kill_close")
        self.assertEqual(incidents[0]["ts"], T+lab.MINUTE)
        self.assertEqual(counts["signal_skip_daily_kill"], 1)
        self.assertEqual(equity.loc[1,"daily_kill_active"], 1)

    def test_funding_real_jitter_new_entry_pays_open_plus_5ms(self):
        funding = {"BTCUSDT": [{"fundingTime":T, "fundingRate":.01,"markPrice":100.},
                               {"fundingTime":T+5, "fundingRate":.01,"markPrice":100.}]}
        ledger, _, _, _ = lab.simulate(market(), [signal()], funding, lab.Config(hold_minutes=1))
        r = ledger.iloc[0]
        self.assertEqual(r.funding_settlements, 1)
        self.assertAlmostEqual(r.funding_cashflow, -r.q)

    def test_open_exit_does_not_pay_later_jitter(self):
        funding = {"BTCUSDT": [{"fundingTime":T+lab.MINUTE, "fundingRate":.01,"markPrice":100.},
                               {"fundingTime":T+lab.MINUTE+5, "fundingRate":.01,"markPrice":100.}]}
        ledger, _, _, _ = lab.simulate(market(), [signal()], funding, lab.Config(hold_minutes=1))
        self.assertEqual(ledger.iloc[0].funding_settlements, 1)
        self.assertEqual(ledger.iloc[0].exit_time_ms, T+lab.MINUTE)

    def test_intraminute_stop_uses_end_stamp_and_includes_prior_funding(self):
        d = market(changes={("BTCUSDT",0): {"low":97.}})
        funding = {"BTCUSDT": [{"fundingTime":T+5, "fundingRate":.01,"markPrice":100.}]}
        ledger, _, _, _ = lab.simulate(d, [signal()], funding, lab.Config())
        self.assertEqual(ledger.iloc[0].funding_settlements, 1)
        self.assertEqual(ledger.iloc[0].exit_time_ms, T+lab.MINUTE-1)

    def test_short_receives_positive_funding_and_ledger_cash_reconciles(self):
        funding = {"BTCUSDT": [{"fundingTime":T+5,"fundingRate":.01,"markPrice":100.}]}
        ledger, equity, _, _ = lab.simulate(market(), [signal(side=-1,stop=102.)], funding, lab.Config(hold_minutes=1))
        self.assertGreater(ledger.iloc[0].funding_cashflow, 0.)
        self.assertAlmostEqual(equity.cash.iloc[-1]-10000, ledger.net_usd.sum())

    def test_risk_rounding_notional_and_reserve_not_cash_fee(self):
        cfg = lab.Config()
        result = lab.size_position(10000., 100., 98., 1, "BTCUSDT", cfg)
        self.assertLessEqual(result["planned_risk_usd"], 25.+1e-9)
        self.assertLessEqual(result["q"]*result["entry_exec"], 10000.+1e-9)
        self.assertAlmostEqual(result["q"]/.001, round(result["q"]/.001))
        self.assertGreater(result["funding_reserve_usd"], 0)
        self.assertIsNone(lab.size_position(1.,10000.,9000.,1,"BTCUSDT",cfg))
        ledger, _, _, _ = lab.simulate(market(), [signal()], {}, lab.Config(hold_minutes=1))
        r = ledger.iloc[0]
        self.assertAlmostEqual(r.net_usd, r.raw_gross_usd-r.slippage_cost_usd-r.fees_usd)
        self.assertEqual(r.funding_cashflow, 0.)
        self.assertAlmostEqual(r.fixed_trajectory_allin4bps_net_usd, r.raw_gross_usd-.0004*r.raw_entry_notional)


if __name__ == "__main__":
    unittest.main()
