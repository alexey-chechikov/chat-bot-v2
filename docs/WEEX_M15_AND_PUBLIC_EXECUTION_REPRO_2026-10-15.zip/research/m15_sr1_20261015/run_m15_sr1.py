"""Frozen M15-SR1 v1 portfolio test: local public Binance data, no API or bot clients."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
PUBLIC = OUT.parent / "expectancy_20261006" / "public_data"
SPEC_PATH = OUT.parent / "execution_focus_20261015" / "M15_SR1_FROZEN_SPEC_2026-10-15.md"
MINUTE = 60_000
DAY = 1440 * MINUTE
SYMBOLS = ("BTCUSDT", "ETHUSDT")
TICKS = {"BTCUSDT": .1, "ETHUSDT": .01}
STEPS = {"BTCUSDT": .001, "ETHUSDT": .001}
SEED = 20261015


@dataclass(frozen=True)
class Config:
    fee: float = .0001
    slip: float = .0001
    initial: float = 10000.
    risk_fraction: float = .0025
    funding_reserve: float = .0001
    max_notional_equity: float = 1.
    daily_loss_fraction: float = .0075
    max_entries_day: int = 3
    hold_minutes: int = 240


@dataclass(frozen=True)
class Signal:
    symbol: str
    entry_ix: int
    side: int
    stop: float
    pivot_id: str
    pivot_time_ms: int
    signal_start_ms: int


def utc(ts):
    return datetime.fromtimestamp(int(ts) / 1000, timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bars(d, minutes):
    indexed = d.assign(dt=pd.to_datetime(d.ts, unit="ms", utc=True)).set_index("dt")
    b = indexed.resample(f"{minutes}min", origin="epoch").agg(
        open=("open", "first"), high=("high", "max"), low=("low", "min"), close=("close", "last"), count=("close", "size"))
    b["ts"] = b.index.as_unit("ms").asi8
    b["valid"] = b["count"].eq(minutes)
    return b.reset_index(drop=True)


def pivot_indices(b, kind):
    a = b["low" if kind == "low" else "high"].to_numpy(float)
    valid = b.valid.to_numpy(bool)
    found = []
    for i in range(2, len(b) - 2):
        if not valid[i-2:i+3].all():
            continue
        neighbors = a[[i-2, i-1, i+1, i+2]]
        if (a[i] < neighbors).all() if kind == "low" else (a[i] > neighbors).all():
            found.append(i)
    return np.array(found, dtype=np.int64)


def available_pivots(b, kind, minutes):
    ix = pivot_indices(b, kind)
    # i+2 closes at start(i+3); no decision at the historical pivot itself.
    ready = b.ts.to_numpy(np.int64)[ix] + 3 * minutes * MINUTE
    return ix, ready


def latest_two(b, ix, ready, start_ms, kind):
    count = int(np.searchsorted(ready, start_ms, side="right"))
    if count < 2:
        return None
    column = "low" if kind == "low" else "high"
    return (float(b.iloc[ix[count-2]][column]), float(b.iloc[ix[count-1]][column]))


def wilder_atr(b, period=14):
    result = np.full(len(b), np.nan)
    seed, previous_close, last = [], None, None
    for i, row in enumerate(b.itertuples(index=False)):
        if not row.valid:
            seed, previous_close, last = [], None, None
            continue
        tr = row.high - row.low if previous_close is None else max(row.high-row.low, abs(row.high-previous_close), abs(row.low-previous_close))
        previous_close = row.close
        if last is None:
            seed.append(tr)
            if len(seed) == period:
                last = sum(seed) / period
        else:
            last = ((period - 1) * last + tr) / period
        if last is not None:
            result[i] = last
    return result


def frozen_context(b15, b60, signal_ix):
    """Exposed independently for causality tests. Never looks at signal-bar OHLC."""
    start = int(b15.ts.iloc[signal_ix])
    trend = {}
    for kind in ("high", "low"):
        ix, ready = available_pivots(b60, kind, 60)
        trend[kind] = latest_two(b60, ix, ready, start, kind)
    if trend["high"] is None or trend["low"] is None:
        return None
    hh, ll = trend["high"], trend["low"]
    side = 1 if hh[1] > hh[0] and ll[1] > ll[0] else -1 if hh[1] < hh[0] and ll[1] < ll[0] else 0
    if not side:
        return None
    kind = "low" if side == 1 else "high"
    ix, ready = available_pivots(b15, kind, 15)
    count = int(np.searchsorted(ready, start, side="right"))
    if not count:
        return None
    pivot_ix = int(ix[count - 1])
    if signal_ix - pivot_ix > 32:
        return None
    return {"side": side, "pivot_ix": pivot_ix, "pivot_time_ms": int(b15.ts.iloc[pivot_ix]),
            "level": float(b15.iloc[pivot_ix][kind]), "kind": kind}


def build_signals(d, symbol, *, full_horizon=True):
    b15, b60 = bars(d, 15), bars(d, 60)
    atr = wilder_atr(b15)
    # Build each pivot set once, keeping the same semantics as frozen_context().
    piv15 = {k: available_pivots(b15, k, 15) for k in ("low", "high")}
    piv60 = {k: available_pivots(b60, k, 60) for k in ("low", "high")}
    events, counts = [], Counter()
    times = d.ts.to_numpy(np.int64)
    for t in range(1, len(b15)):
        counts["15m_bars_considered"] += 1
        row = b15.iloc[t]
        if not row.valid or not math.isfinite(atr[t-1]):
            counts["incomplete_or_atr_warmup"] += 1; continue
        start = int(row.ts)
        high = latest_two(b60, *piv60["high"], start, "high")
        low = latest_two(b60, *piv60["low"], start, "low")
        if high is None or low is None:
            counts["1h_pivots_unavailable"] += 1; continue
        side = 1 if high[1] > high[0] and low[1] > low[0] else -1 if high[1] < high[0] and low[1] < low[0] else 0
        if not side:
            counts["1h_structure_not_directional"] += 1; continue
        kind = "low" if side == 1 else "high"
        pix, ready = piv15[kind]
        n = int(np.searchsorted(ready, start, side="right"))
        if not n or t - int(pix[n-1]) > 32:
            counts["15m_level_unavailable_or_old"] += 1; continue
        pivot_ix = int(pix[n-1]); level = float(b15.iloc[pivot_ix][kind]); tick = TICKS[symbol]
        reclaim = row.low <= level-tick and row.close >= level+tick if side == 1 else row.high >= level+tick and row.close <= level-tick
        if not reclaim:
            counts["no_sweep_reclaim"] += 1; continue
        if row.high-row.low < atr[t-1]:
            counts["signal_range_below_atr_prev"] += 1; continue
        entry_time = start + 15 * MINUTE
        entry = int(np.searchsorted(times, entry_time))
        counts["qualified_signals_before_boundary"] += 1
        if entry >= len(d) or times[entry] != entry_time or full_horizon and entry + 240 >= len(d):
            counts["boundary_censored_signals"] += 1; continue
        stop = math.floor((row.low - 2*tick)/tick + 1e-9)*tick if side == 1 else math.ceil((row.high+2*tick)/tick - 1e-9)*tick
        pivot_time = int(b15.ts.iloc[pivot_ix])
        events.append(Signal(symbol, entry, side, float(stop), f"{symbol}:{kind}:{pivot_time}", pivot_time, start))
        counts["eligible_signals"] += 1
    return events, dict(counts)


def size_position(equity, entry_mid, stop, side, symbol, cfg):
    ee = entry_mid * (1 + side * cfg.slip)
    if side * (entry_mid - stop) <= 0 or side * (ee-stop) <= 0 or equity <= 0:
        return None
    stop_exec = stop * (1-side*cfg.slip)
    per_unit = side*(ee-stop_exec) + cfg.fee*(ee+stop_exec) + cfg.funding_reserve*ee
    if per_unit <= 0:
        return None
    raw = min(cfg.risk_fraction*equity/per_unit, cfg.max_notional_equity*equity/ee)
    q = math.floor(raw/STEPS[symbol]+1e-10)*STEPS[symbol]
    if q <= 0:
        return None
    return {"q": q, "entry_exec": ee, "planned_unit_risk": per_unit,
            "planned_risk_usd": q*per_unit, "funding_reserve_usd": q*cfg.funding_reserve*ee,
            "risk_budget_usd": equity*cfg.risk_fraction}


def liquidation(cash, pos, mid, cfg):
    if pos is None:
        return cash
    executable = mid*(1-pos["side"]*cfg.slip)
    return cash + pos["side"]*pos["q"]*(executable-pos["entry_exec"]) - cfg.fee*pos["q"]*executable


def exit_event(pos, minute_ix, o, h, l):
    side, stop, target = pos["side"], pos["stop"], pos["target"]
    gap_stop = o <= stop if side == 1 else o >= stop
    gap_target = o >= target if side == 1 else o <= target
    if gap_stop:
        return o, "stop_gap_deadline" if minute_ix >= pos["deadline_ix"] else "stop_gap"
    if gap_target:
        return target, "target_gap"
    if minute_ix >= pos["deadline_ix"]:
        return o, "time"
    stop_hit = l <= stop if side == 1 else h >= stop
    target_hit = h >= target if side == 1 else l <= target
    if stop_hit:
        px = min(stop, o) if side == 1 else max(stop, o)
        return px, "stop_gap" if gap_stop else "stop_both_touched" if target_hit else "stop"
    if target_hit:
        return target, "target"
    return None


def simulate(data, signals, funding, cfg=Config()):
    ts = data[SYMBOLS[0]].ts.to_numpy(np.int64)
    arrays = {s: {k: data[s][k].to_numpy(float) for k in ("open", "high", "low", "close")} for s in SYMBOLS}
    assert all(np.array_equal(ts, data[s].ts.to_numpy(np.int64)) for s in SYMBOLS)
    by_time = {}
    for signal in signals:
        by_time.setdefault(signal.entry_ix, []).append(signal)
    for group in by_time.values():
        group.sort(key=lambda s: SYMBOLS.index(s.symbol))
    fund = {s: [] for s in SYMBOLS}
    fund_times = {}
    for s in SYMBOLS:
        fund[s] = sorted(funding.get(s, []), key=lambda f: int(f["fundingTime"]))
        fund_times[s] = np.array([int(f["fundingTime"]) for f in fund[s]], dtype=np.int64)
    cash, pos = cfg.initial, None
    ledger, curve, incidents = [], [], []
    counters = Counter(); used = set()
    current_day, day_start, day_entries, day_killed, pending_kill = None, cfg.initial, 0, False, False

    def apply_funding(until_ms, i):
        nonlocal cash
        if pos is None:
            return
        s = pos["symbol"]
        first = int(np.searchsorted(fund_times[s], pos["funding_applied_through_ms"], side="right"))
        last = int(np.searchsorted(fund_times[s], until_ms, side="right"))
        for f in fund[s][first:last]:
            mark = f.get("markPrice", float("nan"))
            if not math.isfinite(mark) or mark <= 0:
                mark = arrays[s]["open"][i]
                counters["funding_mark_proxy"] += 1
            change = -pos["side"]*pos["q"]*mark*f["fundingRate"]
            cash += change; pos["funding_cashflow"] += change; pos["funding_settlements"] += 1
            counters["funding_settlements"] += 1
        pos["funding_applied_through_ms"] = int(until_ms)

    def close_position(i, raw_exit, reason):
        nonlocal cash, pos, pending_kill
        intraminute = reason in ("stop", "stop_both_touched", "target", "end_data")
        exit_stamp = int(ts[i]+MINUTE-1 if intraminute else ts[i])
        apply_funding(exit_stamp, i)
        side, q = pos["side"], pos["q"]
        actual = raw_exit*(1-side*cfg.slip)
        exec_gross = side*q*(actual-pos["entry_exec"])
        exit_fee = cfg.fee*q*actual
        raw_gross = side*q*(raw_exit-pos["entry_mid"])
        cash += exec_gross-exit_fee
        net = exec_gross-pos["entry_fee"]-exit_fee+pos["funding_cashflow"]
        item = dict(pos, exit_ix=i, exit_time=utc(exit_stamp), exit_time_ms=exit_stamp, exit_mid=raw_exit,
                    exit_exec=actual, reason=reason, duration_minutes=i-pos["entry_ix"],
                    raw_gross_usd=raw_gross, executed_gross_usd=exec_gross,
                    slippage_cost_usd=raw_gross-exec_gross, exit_fee_usd=exit_fee,
                    fees_usd=pos["entry_fee"]+exit_fee, net_usd=net,
                    net_R=net/pos["planned_risk_usd"], net_pct_entry_notional=net/(q*pos["entry_mid"])*100,
                    raw_entry_notional=q*pos["entry_mid"], turnover_usd=q*(pos["entry_exec"]+actual),
                    fixed_trajectory_allin4bps_net_usd=raw_gross-.0004*q*pos["entry_mid"],
                    equity_after_exit=cash)
        ledger.append(item); counters["exit_"+reason] += 1
        pos = None; pending_kill = False

    for i, stamp in enumerate(ts):
        day = int(stamp // DAY)
        if day != current_day:
            mark = arrays[pos["symbol"]]["open"][i] if pos else 0
            day_start = liquidation(cash, pos, mark, cfg)
            current_day, day_entries, day_killed = day, 0, False
        carried_into_open = pos is not None
        apply_funding(int(stamp), i)
        opening_equity = liquidation(cash, pos, arrays[pos["symbol"]]["open"][i] if pos else 0, cfg)
        if opening_equity <= day_start*(1-cfg.daily_loss_fraction):
            if not day_killed:
                incidents.append({"ts": int(stamp), "event": "daily_kill_open", "equity": opening_equity, "day_start_equity": day_start})
            day_killed = True; pending_kill = pending_kill or pos is not None
        group = by_time.get(i, [])
        if carried_into_open and group:
            counters["signal_skip_busy"] += len(group)
        if pos is not None:
            a = arrays[pos["symbol"]]
            if pending_kill:
                close_position(i, a["open"][i], "daily_kill")
            else:
                event = exit_event(pos, i, a["open"][i], a["high"][i], a["low"][i])
                if event is not None:
                    close_position(i, *event)
        if not carried_into_open and group:
            entered = False
            for signal in group:
                if entered:
                    counters["signal_skip_crosssymbol_priority"] += 1; continue
                if day_killed or pending_kill:
                    counters["signal_skip_daily_kill"] += 1; continue
                if day_entries >= cfg.max_entries_day:
                    counters["signal_skip_daily_entry_limit"] += 1; continue
                if signal.pivot_id in used:
                    counters["signal_skip_used_pivot"] += 1; continue
                a = arrays[signal.symbol]; entry = a["open"][i]
                sizing = size_position(cash, entry, signal.stop, signal.side, signal.symbol, cfg)
                if sizing is None:
                    counters["signal_skip_invalid_stop_or_size"] += 1; continue
                r = abs(sizing["entry_exec"]-signal.stop)
                target = sizing["entry_exec"]+signal.side*3*r
                if target <= 0:
                    counters["signal_skip_nonpositive_target"] += 1; continue
                fee = cfg.fee*sizing["q"]*sizing["entry_exec"]
                pos = {**sizing, "symbol": signal.symbol, "side": signal.side, "entry_ix": i,
                       "entry_time": utc(stamp), "entry_time_ms": int(stamp), "entry_mid": entry,
                       "stop": signal.stop, "target": target, "entry_fee": fee,
                       "deadline_ix": i+cfg.hold_minutes, "pivot_id": signal.pivot_id,
                       "pivot_time_ms": signal.pivot_time_ms, "signal_start_ms": signal.signal_start_ms,
                       "funding_cashflow": 0., "funding_settlements": 0, "entry_equity": cash,
                       "funding_applied_through_ms": int(stamp)}
                cash -= fee; used.add(signal.pivot_id); day_entries += 1; entered = True
                counters["entries"] += 1
                event = exit_event(pos, i, a["open"][i], a["high"][i], a["low"][i])
                if event is not None:
                    close_position(i, *event)
        apply_funding(int(stamp+MINUTE-1), i)
        mark = arrays[pos["symbol"]]["close"][i] if pos else 0
        equity = liquidation(cash, pos, mark, cfg)
        if equity <= day_start*(1-cfg.daily_loss_fraction):
            if not day_killed:
                incidents.append({"ts": int(stamp), "event": "daily_kill_close", "equity": equity, "day_start_equity": day_start})
            day_killed = True; pending_kill = pending_kill or pos is not None
        curve.append({"ts": int(stamp), "cash": cash, "liquidation_equity": equity,
                      "position_symbol": pos["symbol"] if pos else "", "position_qty": pos["q"] if pos else 0.,
                      "position_notional": abs(pos["q"]*mark) if pos else 0., "day_start_equity": day_start,
                      "day_entries": day_entries, "daily_kill_active": int(day_killed)})
    if pos is not None:
        close_position(len(ts)-1, arrays[pos["symbol"]]["close"][-1], "end_data")
        curve[-1].update(cash=cash, liquidation_equity=cash, position_symbol="", position_qty=0., position_notional=0.)
    assert math.isclose(cash-cfg.initial, math.fsum(row["net_usd"] for row in ledger), abs_tol=1e-7)
    return pd.DataFrame(ledger), pd.DataFrame(curve), dict(counters), incidents


def weekly_ci(frame, column):
    if not len(frame):
        return None
    groups = frame.groupby("iso_week")[column].agg(["sum", "size"]).to_numpy(float)
    rng = np.random.default_rng(SEED)
    selected = rng.integers(0, len(groups), size=(9999, len(groups)))
    blocks = groups[selected].sum(axis=1)
    return [float(x) for x in np.quantile(blocks[:, 0]/blocks[:, 1], [.025, .975])]


def trade_summary(frame):
    if not len(frame):
        return {"n": 0}
    net = frame.net_usd.to_numpy(float)
    negative = -net[net < 0].sum()
    return {"n": len(frame), "net_usd": float(net.sum()), "mean_net_R": float(frame.net_R.mean()),
            "mean_net_pct_entry_notional": float(frame.net_pct_entry_notional.mean()),
            "win_rate": float((net > 0).mean()), "profit_factor": float(net[net > 0].sum()/negative) if negative else None,
            "raw_gross_usd": float(frame.raw_gross_usd.sum()), "slippage_cost_usd": float(frame.slippage_cost_usd.sum()),
            "fees_usd": float(frame.fees_usd.sum()), "signed_funding_cashflow_usd": float(frame.funding_cashflow.sum()),
            "fixed_trajectory_allin4bps_net_usd": float(frame.fixed_trajectory_allin4bps_net_usd.sum()),
            "mean_duration_minutes": float(frame.duration_minutes.mean()), "weeks_with_trades": int(frame.iso_week.nunique()),
            "weekly_block95_mean_net_R": weekly_ci(frame, "net_R"),
            "weekly_block95_mean_net_pct_entry_notional": weekly_ci(frame, "net_pct_entry_notional"),
            "exit_reasons": {str(k): int(v) for k, v in frame.reason.value_counts().items()},
            "max_loss_trade_usd": float(-min(0., frame.net_usd.min())),
            "max_loss_trade_R": float(-min(0., frame.net_R.min())),
            "max_planned_risk_fraction_entry_equity": float((frame.planned_risk_usd/frame.entry_equity).max()),
            "max_entry_notional_fraction_equity": float((frame.entry_exec*frame.q/frame.entry_equity).max())}


def summarize_run(ledger, curve, config, start, end, counts, incidents):
    boundary = start + ((end-start)*7//10//MINUTE)*MINUTE
    if len(ledger):
        times = pd.to_datetime(ledger.entry_time_ms, unit="ms", utc=True)
        ledger["month"] = times.dt.strftime("%Y-%m")
        ledger["iso_week"] = times.dt.strftime("%G-W%V")
        ledger["calendar_segment"] = np.where(ledger.entry_time_ms < boundary, "first70", "last30")
    summary = {"full": trade_summary(ledger), "first70": trade_summary(ledger[ledger.entry_time_ms < boundary]) if len(ledger) else {"n": 0},
               "last30": trade_summary(ledger[ledger.entry_time_ms >= boundary]) if len(ledger) else {"n": 0},
               "symbols": {s: trade_summary(ledger[ledger.symbol == s]) if len(ledger) else {"n": 0} for s in SYMBOLS},
               "calendar_boundary_ms": boundary, "calendar_boundary_utc": utc(boundary),
               "config": config.__dict__, "simulation_counts": counts, "daily_kill_incidents": incidents}
    equities = np.r_[config.initial, curve.liquidation_equity.to_numpy(float)]
    peak = np.maximum.accumulate(equities)
    before = curve[curve.ts < boundary]
    eq_boundary = float(before.liquidation_equity.iloc[-1]) if len(before) else config.initial
    summary["equity"] = {"initial": config.initial, "terminal": float(equities[-1]),
                         "net_usd": float(equities[-1]-config.initial),
                         "max_drawdown_basis": "minute-close liquidation equity; intraminute worst equity is not proven",
                         "max_drawdown_usd": float(np.max(peak-equities)),
                         "max_drawdown_pct_running_peak": float(np.max((peak-equities)/peak)*100),
                         "equity_at_first70_end": eq_boundary,
                         "first70_mtm_change": eq_boundary-config.initial,
                         "last30_mtm_change": float(equities[-1]-eq_boundary),
                         "max_position_notional": float(curve.position_notional.max()),
                         "capital_breached": bool((equities <= 0).any())}
    if len(ledger):
        summary["months"] = {str(k): trade_summary(g) for k, g in ledger.groupby("month")}
        summary["weeks"] = {str(k): trade_summary(g) for k, g in ledger.groupby("iso_week")}
    else:
        summary.update(months={}, weeks={})
    mean_r = summary["full"].get("mean_net_R", 0.)
    summary["verdict"] = "negative_primary_filter" if mean_r <= 0 else "candidate_unconfirmed"
    return summary


def main():
    assert (OUT/"IMPLEMENTATION_ASSUMPTIONS.md").exists(), "Save assumptions BEFORE examining results"
    inputs, funding, manifests, funnels, signals = {}, {}, [], {}, []
    for symbol in SYMBOLS:
        source = PUBLIC/f"binance_futures_{symbol}_1m.csv"
        fsource = PUBLIC/f"binance_futures_{symbol}_funding.csv"
        d = pd.read_csv(source, usecols=["ts", "open", "high", "low", "close"])
        assert len(d) and d.ts.is_unique and d.ts.diff().iloc[1:].eq(MINUTE).all()
        assert (d.low > 0).all() and (d.low <= d[["open", "close"]].min(axis=1)).all() and (d.high >= d[["open", "close"]].max(axis=1)).all()
        assert np.isfinite(d[["open", "high", "low", "close"]]).all().all()
        inputs[symbol] = d
        f = pd.read_csv(fsource)
        assert f.fundingTime.is_unique and f.fundingTime.is_monotonic_increasing
        assert np.isfinite(f.fundingRate).all()
        slot = 8*60*MINUTE
        relevant = f[(f.fundingTime >= int(d.ts.iloc[0])) & (f.fundingTime < int(d.ts.iloc[-1]+MINUTE))]
        expected_slots = set(range(((int(d.ts.iloc[0])+slot-1)//slot)*slot, int(d.ts.iloc[-1]+MINUTE), slot))
        observed_slots = (relevant.fundingTime//slot*slot).astype("int64")
        assert observed_slots.is_unique and set(observed_slots) == expected_slots, "missing/duplicate nominal funding slot"
        jitter = relevant.fundingTime-observed_slots
        funding[symbol] = f.to_dict("records")
        manifests += [{"file": str(source.relative_to(OUT.parent)), "sha256": sha(source), "rows": len(d),
                       "start_utc": utc(d.ts.iloc[0]), "last_open_utc": utc(d.ts.iloc[-1])},
                      {"file": str(fsource.relative_to(OUT.parent)), "sha256": sha(fsource), "rows": len(f),
                       "funding_slots_in_price_window": len(relevant), "missing_nominal_slots": 0,
                       "timestamp_jitter_ms_min": int(jitter.min()), "timestamp_jitter_ms_max": int(jitter.max()),
                       "funding_timestamps_rounded": False}]
        found, funnel = build_signals(d, symbol)
        signals.extend(found); funnels[symbol] = funnel
        print(symbol, "signals", len(found), flush=True)
    start = int(inputs[SYMBOLS[0]].ts.iloc[0]); end = int(inputs[SYMBOLS[0]].ts.iloc[-1]+MINUTE)
    pd.DataFrame([s.__dict__ for s in signals]).sort_values(["entry_ix", "symbol"]).to_csv(OUT/"signals.csv", index=False)
    results = {"history_status": "previously_inspected_Binance_USDM_not_untouched_OOS_not_WEEX_fills",
               "start_utc": utc(start), "end_exclusive_utc": utc(end), "signal_funnels": funnels}
    for name, config in (("primary", Config()), ("stress", Config(slip=.0003))):
        ledger, curve, counters, incidents = simulate(inputs, signals, funding, config)
        results[name] = summarize_run(ledger, curve, config, start, end, counters, incidents)
        ledger.to_csv(OUT/f"{name}_ledger.csv", index=False)
        curve.to_csv(OUT/f"{name}_equity.csv.gz", index=False, compression="gzip")
        print(name, json.dumps(results[name]["full"], ensure_ascii=False), flush=True)
    (OUT/"summary.json").write_text(json.dumps(results, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    manifests += [{"file": "IMPLEMENTATION_ASSUMPTIONS.md", "sha256": sha(OUT/"IMPLEMENTATION_ASSUMPTIONS.md")},
                  {"file": "M15_SR1_FROZEN_SPEC_2026-10-15.md", "sha256": sha(SPEC_PATH)},
                  {"file": "run_m15_sr1.py", "sha256": sha(Path(__file__))}]
    (OUT/"manifest.json").write_text(json.dumps({"inputs": manifests, "parameters_fitted": False, "seed": SEED,
                                                "bootstrap_reps": 9999, "network_calls": 0}, indent=2)+"\n", encoding="utf-8")
    make_report(results)


def make_report(results):
    lines = ["# M15-SR1 v1: портфель BTC+ETH — 15.10.2026", "", "Локальный Python-расчёт Codex. История Binance USD-M уже просмотрена; это не OOS, не WEEX fills и не maker-модель.", "",
             "| Прогон | N | Net USDT | Средний net R | 95% weekly block CI | First70 R | Last30 R | DD minute-close liquidation USDT |",
             "|---|---:|---:|---:|---|---:|---:|---:|"]
    for name in ("primary", "stress"):
        r = results[name]; full = r["full"]
        lines.append(f"| {name} | {full['n']} | {full.get('net_usd',0):+.3f} | {full.get('mean_net_R',0):+.5f} | {full.get('weekly_block95_mean_net_R')} | {r['first70'].get('mean_net_R',0):+.5f} | {r['last30'].get('mean_net_R',0):+.5f} | {r['equity']['max_drawdown_usd']:.3f} |")
    p = results["primary"]; f = p["full"]
    lines += ["", f"**Вердикт: {p['verdict']}.** Положительный результат был бы только candidate unconfirmed: контроли и untouched/forward проверка здесь не выполнены. Параметры не подбирались.", "",
              "Один портфель, BTC приоритет; максимум3входа/UTCдень и один вход/pivot. Контекст1h/15m зафиксирован на начало сигнального15m-бара, pivots доступны сi+3; ATRprev Wilder. Следующий minute-open market, стоп активен с минуты входа, TP3R, предел4h. Риск0.25% liquidation equity, notional≤1×equity; в размере1bp funding reserve, не денежный расход. Daily kill0.75%cash+MTM с причинным выходом на следующем open после close-trigger. Гэпы/задержка могут превысить плановый риск.", "",
              "Primary: fee1bp+adverse slip1bp каждой стороны +signed funding. Stress: fee1bp+slip3bp каждой стороны, полный replay. Это гипотетические расходы, не подтверждённые WEEX API fee. Tick/step — constant proxy без исторической верификации.", "",
              f"Primary raw gross {f.get('raw_gross_usd',0):+.6f}; slippage cost {f.get('slippage_cost_usd',0):.6f}; fees {f.get('fees_usd',0):.6f}; signed funding cashflow {f.get('signed_funding_cashflow_usd',0):+.6f}; net {f.get('net_usd',0):+.6f}USDT.", "",
              f"Отдельная fixed-trajectory all-in4bps чувствительность: **{f.get('fixed_trajectory_allin4bps_net_usd',0):+.6f}USDT**. Raw-mid gross минус0.0004×raw entry notional, funding/fee/slippage повторно не вычитаются; исходные q/entry/exit/уровни сохранены. Это не новый cash/size replay.", "",
              f"Граница календарных70/30: {p['calendar_boundary_utc']}. Когорты ledger относятся по entry; отдельные MTM-изменения equity приведены в JSON, они могут отличаться из-за переноса позиции.", "", "## Раздельные инструменты в общем портфеле", "", "| Symbol | N | Net USDT | Средний net R |", "|---|---:|---:|---:|"]
    for symbol, row in p["symbols"].items():
        lines.append(f"| {symbol} | {row['n']} | {row.get('net_usd',0):+.4f} | {row.get('mean_net_R',0):+.5f} |")
    lines += ["", "Полные first70/last30, monthly/ISO-week cohorts, риск, CI, причины пропусков и kill incidents — summary.json. Ledger и непрерывная minute-close liquidation equity сохранены отдельно для обоих прогонов. Funding подписан положительным cashflow=получено.", "",
              "Воспроизведение: `python run_m15_sr1.py`; перед ним `python -m unittest test_m15_sr1 -v`. Источники/код/спека/доходные допущения зафиксированы SHA256 в manifest.json. Никаких исходных данных или боевых ботов этот скрипт не меняет."]
    (OUT/"REPORT.md").write_text("\n".join(lines)+"\n", encoding="utf-8")


if __name__ == "__main__":
    main()
