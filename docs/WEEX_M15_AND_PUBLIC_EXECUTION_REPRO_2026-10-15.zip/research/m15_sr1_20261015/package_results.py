"""Package only explicit public-research inputs and outputs; no account or image data."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parent
RESEARCH=ROOT.parent
OUT=RESEARCH/'weex_publish_20261010'/'docs'
NAME='WEEX_M15_AND_PUBLIC_EXECUTION_REPRO_2026-10-15.zip'

def main():
    files=[]
    m15=('IMPLEMENTATION_ASSUMPTIONS.md','run_m15_sr1.py','test_m15_sr1.py',
         'independent_qa.py','independent_qa.json','verify_numerics.py','numerical_qa.json',
         'manifest.json','summary.json','signals.csv','primary_ledger.csv',
         'stress_ledger.csv','primary_equity.csv.gz','stress_equity.csv.gz','REPORT.md',
         'package_results.py')
    files.extend(ROOT/name for name in m15)
    files.append(RESEARCH/'execution_focus_20261015/M15_SR1_FROZEN_SPEC_2026-10-15.md')
    files.append(RESEARCH/'execution_focus_20261015/ETH_EXECUTION_FROZEN_PROTOCOL_2026-10-15.md')
    for symbol in ('BTCUSDT','ETHUSDT'):
        for kind in ('1m','funding'):
            files.append(RESEARCH/f'expectancy_20261006/public_data/binance_futures_{symbol}_{kind}.csv')
    for name in ('capture_public.py','test_capture_public.py','recorder_snapshot.py',
                 'quality_report.md','quality_report.json','quality_preflight.json','audit_capture_quality.py'):
        files.append(RESEARCH/'weex_public_capture_20261015'/name)
    files.append(RESEARCH/'weex_public_capture_20261015/market_capture_001/capture_manifest.json')
    for name in ('preflight.py','test_preflight.py'):
        files.append(RESEARCH/'execution_focus_20261015/maker_preflight'/name)
    for path in files:
        assert path.is_file(),path
    index=[{'path':'research/'+p.relative_to(RESEARCH).as_posix(),
            'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    readme='''# Codex research: 15 October 2026

This archive contains only public market data, research source, simulated ledgers,
and aggregate diagnostics. No keys, account records, CoinGlass images or journal,
WEEX raw recording, Claude/Anthropic calls, or bot configuration are included.

Extract preserving the research/ directory layout. Python 3.12, numpy 2.3.5,
pandas 3.0.1 were used. From research/m15_sr1_20261015:

    python -m unittest test_m15_sr1 -v
    python run_m15_sr1.py
    python independent_qa.py
    python verify_numerics.py

Main output is summary.json, REPORT.md and both ledgers/equity files. The historical
inputs have been inspected previously: these runs are NOT untouched out of sample.
M15-SR1 failed its primary net-expectancy filter; no live trading is recommended.

The separate WEEX collector was limited to 300 seconds. Its raw market files stay
local. Aggregate QA and their original hashes are included. Consequently the raw
capture QA cannot be rerun from this archive; no maker-profit calculation exists.
For a NEW public capture, install websockets 15.0.1 into a chosen research Python
environment and run capture_public.py --seconds 300 --out NEW_EMPTY_DIRECTORY.
This calls the public WEEX websocket only. It does not read account configuration.
Use a NEW output folder and retain ordered_public.jsonl with the v2 CSV files.
The copy of recorder_snapshot.py is a reviewed public repository snapshot; it is
imported with retention deletions disabled. Clock offsets are not order latency.

Bundle SHA256 values for each explicit entry are in bundle_manifest.json.
'''
    OUT.mkdir(parents=True,exist_ok=True)
    target=OUT/NAME
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        archive.writestr('README.md',readme)
        archive.writestr('bundle_manifest.json',json.dumps(index,indent=2)+'\n')
        for path,item in zip(files,index):archive.write(path,item['path'])
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        for item in index:
            assert hashlib.sha256(archive.read(item['path'])).hexdigest()==item['sha256']
    print(json.dumps({'file':str(target),'bytes':target.stat().st_size,
                      'entries':len(index)+2,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))

if __name__=='__main__':main()
