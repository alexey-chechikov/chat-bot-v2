"""Independent indicator/signal reconstruction; no network or model calls.

Saved money paths are checked separately by verify_numerics.py.
"""
from pathlib import Path
from collections import Counter
import importlib.util
import hashlib
import json
import math
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
DATA=ROOT.parent/'expectancy_20261006/public_data'
MINUTE=60000
SYMS=('BTCUSDT','ETHUSDT')
TICK={'BTCUSDT':.1,'ETHUSDT':.01}

def aggregate(df,n):
    bucket=(df.ts//(n*MINUTE))*(n*MINUTE)
    b=df.groupby(bucket,sort=True).agg(open=('open','first'),high=('high','max'),
        low=('low','min'),close=('close','last'),count=('ts','size'))
    assert (b['count']==n).all()
    b.index.name='ts'
    return b

def pivots(b,field,step):
    series=b[field]
    comparison=series.lt if field=='low' else series.gt
    yes=np.logical_and.reduce([comparison(series.shift(offset)).to_numpy() for offset in (-2,-1,1,2)])
    return [(int(ts),int(ts+3*step*MINUTE),float(series.loc[ts])) for ts in b.index[yes]]

def expected_signals(df,sym):
    fifteen,hour=aggregate(df,15),aggregate(df,60)
    # Own scalar Wilder recursion, using only fully completed previous bars.
    atr=[];prev_close=None;state=None;seed=[]
    for row in fifteen.itertuples():
        tr=max(row.high-row.low,0 if prev_close is None else abs(row.high-prev_close),
               0 if prev_close is None else abs(row.low-prev_close))
        prev_close=row.close
        if state is None:
            seed.append(tr)
            if len(seed)==14:state=math.fsum(seed)/14
        else:state=(13*state+tr)/14
        atr.append(state)
    hp={k:pivots(hour,k,60) for k in ('high','low')}
    fp={k:pivots(fifteen,k,15) for k in ('high','low')}
    pointers={('h',k):0 for k in hp}|{('f',k):0 for k in fp}
    result=[];start=int(df.ts.iloc[0]);end=int(df.ts.iloc[-1])+MINUTE
    for i,(stamp,row) in enumerate(fifteen.iterrows()):
        if i==0 or atr[i-1] is None:continue
        available={}
        for label,sets in (('h',hp),('f',fp)):
            for kind,items in sets.items():
                j=pointers[(label,kind)]
                while j<len(items) and items[j][1]<=stamp:j+=1
                pointers[(label,kind)]=j
                available[(label,kind)]=items[max(0,j-2):j]
        highs,lows=available[('h','high')],available[('h','low')]
        if len(highs)<2 or len(lows)<2:continue
        side=1 if highs[-1][2]>highs[-2][2] and lows[-1][2]>lows[-2][2] else (
            -1 if highs[-1][2]<highs[-2][2] and lows[-1][2]<lows[-2][2] else 0)
        if not side:continue
        kind='low' if side==1 else 'high'
        levels=available[('f',kind)]
        if not levels:continue
        pivot_time,ready,level=levels[-1]
        if stamp-pivot_time>32*15*MINUTE:continue
        tick=TICK[sym]
        sweep=(row.low<=level-tick and row.close>=level+tick) if side==1 else (
               row.high>=level+tick and row.close<=level-tick)
        if not sweep or row.high-row.low<atr[i-1]:continue
        entry_time=int(stamp+15*MINUTE)
        if entry_time+240*MINUTE>=end:continue
        stop=(math.floor((row.low-2*tick)/tick+1e-9)*tick if side==1 else
              math.ceil((row.high+2*tick)/tick-1e-9)*tick)
        result.append((sym,(entry_time-start)//MINUTE,side,
                       f'{sym}:{kind}:{pivot_time}',round(stop,8)))
    return sorted(result)

def main():
    spec=importlib.util.spec_from_file_location('m15_subject',ROOT/'run_m15_sr1.py')
    module=importlib.util.module_from_spec(spec)
    import sys
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    checks={};source_hashes={};market={};funding={}
    for sym in SYMS:
        path=DATA/f'binance_futures_{sym}_1m.csv'
        source_hashes[sym]=hashlib.sha256(path.read_bytes()).hexdigest()
        df=pd.read_csv(path,usecols=['ts','open','high','low','close'])
        market[sym]=df
        funding[sym]=pd.read_csv(DATA/f'binance_futures_{sym}_funding.csv')
        expected=expected_signals(df,sym)
        actual,_=module.build_signals(df,sym)
        actual=sorted((x.symbol,x.entry_ix,x.side,x.pivot_id,round(x.stop,8)) for x in actual)
        assert expected==actual, f'{sym} independent signal mismatch'
        checks[sym]={'all_signal_tuples_match':True,'candidate_signals':len(expected)}
    result={'independent_signal_qa':'PASS','source_hashes':source_hashes,'checks':checks}
    (ROOT/'independent_qa.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':main()
