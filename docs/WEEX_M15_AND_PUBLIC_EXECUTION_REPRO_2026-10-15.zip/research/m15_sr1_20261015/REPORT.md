# M15-SR1 v1: портфель BTC+ETH — 15.10.2026

Локальный Python-расчёт Codex. История Binance USD-M уже просмотрена; это не OOS, не WEEX fills и не maker-модель.

| Прогон | N | Net USDT | Средний net R | 95% weekly block CI | First70 R | Last30 R | DD minute-close liquidation USDT |
|---|---:|---:|---:|---|---:|---:|---:|
| primary | 347 | -671.721 | -0.12771 | [-0.22978129319436114, -0.02093220296317012] | -0.13051 | -0.12142 | 694.228 |
| stress | 347 | -1399.059 | -0.22051 | [-0.31214936214366307, -0.12163739321504549] | -0.23109 | -0.19679 | 1417.190 |

**Вердикт: negative_primary_filter.** Положительный результат был бы только candidate unconfirmed: контроли и untouched/forward проверка здесь не выполнены. Параметры не подбирались.

Один портфель, BTC приоритет; максимум3входа/UTCдень и один вход/pivot. Контекст1h/15m зафиксирован на начало сигнального15m-бара, pivots доступны сi+3; ATRprev Wilder. Следующий minute-open market, стоп активен с минуты входа, TP3R, предел4h. Риск0.25% liquidation equity, notional≤1×equity; в размере1bp funding reserve, не денежный расход. Daily kill0.75%cash+MTM с причинным выходом на следующем open после close-trigger. Гэпы/задержка могут превысить плановый риск.

Primary: fee1bp+adverse slip1bp каждой стороны +signed funding. Stress: fee1bp+slip3bp каждой стороны, полный replay. Это гипотетические расходы, не подтверждённые WEEX API fee. Tick/step — constant proxy без исторической верификации.

Primary raw gross +396.650152; slippage cost 530.998141; fees 530.998137; signed funding cashflow -6.375284; net -671.721411USDT.

Отдельная fixed-trajectory all-in4bps чувствительность: **-665.429698USDT**. Raw-mid gross минус0.0004×raw entry notional, funding/fee/slippage повторно не вычитаются; исходные q/entry/exit/уровни сохранены. Это не новый cash/size replay.

Граница календарных70/30: 2026-08-21T09:36:00+00:00. Когорты ledger относятся по entry; отдельные MTM-изменения equity приведены в JSON, они могут отличаться из-за переноса позиции.

## Раздельные инструменты в общем портфеле

| Symbol | N | Net USDT | Средний net R |
|---|---:|---:|---:|
| BTCUSDT | 183 | -637.5096 | -0.20357 |
| ETHUSDT | 164 | -34.2119 | -0.04306 |

Полные first70/last30, monthly/ISO-week cohorts, риск, CI, причины пропусков и kill incidents — summary.json. Ledger и непрерывная minute-close liquidation equity сохранены отдельно для обоих прогонов. Funding подписан положительным cashflow=получено.

Воспроизведение: `python run_m15_sr1.py`; перед ним `python -m unittest test_m15_sr1 -v`. Источники/код/спека/доходные допущения зафиксированы SHA256 в manifest.json. Никаких исходных данных или боевых ботов этот скрипт не меняет.
