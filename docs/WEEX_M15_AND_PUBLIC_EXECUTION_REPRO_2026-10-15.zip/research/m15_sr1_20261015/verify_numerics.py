"""Independent arithmetic/source-path checks for saved M15-SR1 ledgers; no rerun/fit."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT.parent / "expectancy_20261006" / "public_data"
MINUTE = 60000


def main():
    summary = json.loads((ROOT/"summary.json").read_text())
    source, funds = {}, {}
    for symbol in ("BTCUSDT", "ETHUSDT"):
        source[symbol] = pd.read_csv(PUBLIC/f"binance_futures_{symbol}_1m.csv", usecols=["ts","open","high","low","close"])
        funds[symbol] = pd.read_csv(PUBLIC/f"binance_futures_{symbol}_funding.csv")
    checks = {}
    for mode in ("primary", "stress"):
        d = pd.read_csv(ROOT/f"{mode}_ledger.csv")
        eq = pd.read_csv(ROOT/f"{mode}_equity.csv.gz")
        fee, slip = .0001, .0001 if mode == "primary" else .0003
        max_errors = dict(net=0., funding=0., gross=0., fees=0., slippage=0., entry=0., stop=0.)
        for row in d.itertuples():
            minute = source[row.symbol]
            entry_mid = float(minute.open.iloc[row.entry_ix])
            entry_exec = entry_mid*(1+row.side*slip)
            exit_exec = row.exit_mid*(1-row.side*slip)
            raw_gross = row.side*row.q*(row.exit_mid-entry_mid)
            actual_gross = row.side*row.q*(exit_exec-entry_exec)
            fees = fee*row.q*(entry_exec+exit_exec)
            f = funds[row.symbol]
            f = f[(f.fundingTime > row.entry_time_ms) & (f.fundingTime <= row.exit_time_ms)]
            assert np.isfinite(f.markPrice).all() and (f.markPrice > 0).all(), "QA needs explicit fallback to verify missing marks"
            funding = math.fsum(-row.side*row.q*float(mark)*float(rate) for mark, rate in zip(f.markPrice, f.fundingRate))
            net = actual_gross-fees+funding
            signal_window = minute.iloc[row.entry_ix-15:row.entry_ix]
            tick = .1 if row.symbol == "BTCUSDT" else .01
            stop = math.floor((signal_window.low.min()-2*tick)/tick+1e-9)*tick if row.side == 1 else math.ceil((signal_window.high.max()+2*tick)/tick-1e-9)*tick
            max_errors["entry"] = max(max_errors["entry"],abs(entry_exec-row.entry_exec))
            max_errors["stop"] = max(max_errors["stop"],abs(stop-row.stop))
            for key, actual, stored in (("net",net,row.net_usd), ("funding",funding,row.funding_cashflow),
                                        ("gross",raw_gross,row.raw_gross_usd), ("fees",fees,row.fees_usd),
                                        ("slippage",raw_gross-actual_gross,row.slippage_cost_usd)):
                max_errors[key] = max(max_errors[key],abs(actual-stored))
            assert row.entry_ix*MINUTE == row.entry_time_ms-int(minute.ts.iloc[0])
            assert row.pivot_time_ms+3*15*MINUTE <= row.signal_start_ms
            assert (row.signal_start_ms-row.pivot_time_ms)//(15*MINUTE) <= 32
            assert row.planned_risk_usd <= .0025*row.entry_equity+1e-8
            assert row.q*row.entry_exec <= row.entry_equity+1e-8
            assert math.isclose(row.q/.001, round(row.q/.001), abs_tol=1e-8)
            assert math.isclose(row.fixed_trajectory_allin4bps_net_usd, raw_gross-.0004*row.q*entry_mid, abs_tol=1e-8)
        assert max(max_errors.values()) < 1e-8, max_errors
        assert d.pivot_id.is_unique
        assert (d.entry_time_ms.iloc[1:].to_numpy() > d.exit_time_ms.iloc[:-1].to_numpy()).all(), "portfolio overlap"
        assert d.groupby(d.entry_time_ms//86400000).size().max() <= 3
        total = math.fsum(d.net_usd)
        assert math.isclose(total, eq.liquidation_equity.iloc[-1]-10000, abs_tol=1e-7)
        assert len(eq) == len(source["BTCUSDT"]) and np.array_equal(eq.ts,source["BTCUSDT"].ts)
        peak = np.maximum.accumulate(np.r_[10000., eq.liquidation_equity.to_numpy()])
        draw = float(np.max(peak-np.r_[10000.,eq.liquidation_equity.to_numpy()]))
        assert math.isclose(draw, summary[mode]["equity"]["max_drawdown_usd"],abs_tol=1e-8)
        boundary = summary[mode]["calendar_boundary_ms"]
        assert (d.entry_time_ms<boundary).sum()==summary[mode]["first70"]["n"]
        assert (d.entry_time_ms>=boundary).sum()==summary[mode]["last30"]["n"]
        grouped = d.groupby("iso_week").net_R.agg(["sum","size"]).to_numpy()
        rng = np.random.default_rng(20261015)
        draws = grouped[rng.integers(0,len(grouped),(9999,len(grouped)))].sum(axis=1)
        interval = np.quantile(draws[:,0]/draws[:,1],[.025,.975])
        assert np.allclose(interval,summary[mode]["full"]["weekly_block95_mean_net_R"],atol=1e-12)
        checks[mode] = {"ledger_rows":len(d),"equity_rows":len(eq),"max_arithmetic_errors":max_errors,
                        "net_fsum":total,"funding_settlements_reconstructed":int(d.funding_settlements.sum()),
                        "no_portfolio_overlap":True,"unique_pivot_entries":True,"max_three_entries_per_day":True,
                        "risk_notional_rounding_within_proxy_limits":True,"weekly_ci_reproduced":True,
                        "max_dd_minute_close_liquidation":draw}
    for item in json.loads((ROOT/"manifest.json").read_text())["inputs"]:
        if item["file"].startswith("expectancy_"):
            relative = item["file"].replace("\\", "/")
            assert hashlib.sha256((ROOT.parent/relative).read_bytes()).hexdigest()==item["sha256"]
    result={"status":"PASS","checks":checks,"scope":"Arithmetic and saved path invariants; source signal review remains separately testable."}
    (ROOT/"numerical_qa.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    main()
