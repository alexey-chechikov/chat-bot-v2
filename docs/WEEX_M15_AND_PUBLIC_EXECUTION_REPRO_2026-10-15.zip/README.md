# Codex research: 15 October 2026

This archive contains only public market data, research source, simulated ledgers,
and aggregate diagnostics. No keys, account records, CoinGlass images or journal,
WEEX raw recording, Claude/Anthropic calls, or bot configuration are included.

Extract preserving the research/ directory layout. Python 3.12, numpy 2.3.5,
pandas 3.0.1 were used. From research/m15_sr1_20261015:

    python -m unittest test_m15_sr1 -v
    python run_m15_sr1.py
    python independent_qa.py
    python verify_numerics.py

Main output is summary.json, REPORT.md and both ledgers/equity files. The historical
inputs have been inspected previously: these runs are NOT untouched out of sample.
M15-SR1 failed its primary net-expectancy filter; no live trading is recommended.

The separate WEEX collector was limited to 300 seconds. Its raw market files stay
local. Aggregate QA and their original hashes are included. Consequently the raw
capture QA cannot be rerun from this archive; no maker-profit calculation exists.
For a NEW public capture, install websockets 15.0.1 into a chosen research Python
environment and run capture_public.py --seconds 300 --out NEW_EMPTY_DIRECTORY.
This calls the public WEEX websocket only. It does not read account configuration.
Use a NEW output folder and retain ordered_public.jsonl with the v2 CSV files.
The copy of recorder_snapshot.py is a reviewed public repository snapshot; it is
imported with retention deletions disabled. Clock offsets are not order latency.

Bundle SHA256 values for each explicit entry are in bundle_manifest.json.
