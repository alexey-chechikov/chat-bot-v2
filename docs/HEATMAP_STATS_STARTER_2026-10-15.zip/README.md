# Heatmap starter: phase1 journal, no calibrated forecast

See `HEATMAP_STATISTICS_SPEC_2026-10-15.md` for the user-visible Russian specification.
Only stdlib Python3.12 is required. Run from `prototype/`:

```text
python -m unittest -q test_journal test_labels test_collect_coinglass test_stats
python journal.py --db ../local/journal.sqlite status
python journal.py --db ../local/journal.sqlite summary
```

The local screenshot registration is not bundled. The public package contains no runtime DB or user image.
To register a local image as reference, use `python journal.py reference <image-path>`.

Normalized observations currently require operator-verified fresh metadata and preselected zones. Copy the
`sample()` function from `prototype/test_journal.py` only for a SYNTHETIC experiment in a separate test DB;
replace fake fields for real ingestion only after confirming the chart source/settings. Real source_sha256
must be the recorded source artifact's hash. Required fields are explicit in `validate_observation`; do
not use filename time as a provider timestamp. The numeric-adapter identifier is an external contract:
the starter collector validates raw shape but does NOT implement that adapter or calibrate unit/zeros.

`journal.py bars` reads closed UTC1m CSV `ts,open,high,low,close` in milliseconds. Extra columns are ignored.
Duplicates, nonascending/off-grid/invalid OHLC, forming candles and revisions to an existing row fail.
No candles are automatically fetched. Pass a new explicit source version for revised market history.

`evaluate` uses only candles closed by evaluation time. Future windows are PENDING; matured incomplete
windows CENSORED. Derived records are append-only, keyed by snapshot/code protocol/input+maturity hash;
the same key producing different content fails. Code changes create a new signature, not rewritten
labels. `summary` selects the earliest freeze per fixed UTC6h slot BEFORE examining outcomes, separates
settings/one-sided series, counts no-hit/ambiguous and never emits a calibrated future probability.

Raw collector: `prototype/COLLECTOR_README.md`. It sends no request at import, reads no .env, buys nothing,
uses only explicit one-shot config, and is not active in this task. Exact provider settings/API entitlement
remain prerequisites. No regular monitoring automation is installed. Existing actual-liquidation raw
archive is a different data source and cannot stand in for predicted CoinGlass heatmap snapshots.

Methodology notes include additional intended ATR/features/CI/controls; those are future work, not claims
about this code. Present labels use fixed0.15% reaction barriers and15/60/240min horizons. All bundled
fixtures/probes are artificial. Test success proves mechanics, not market predictability or profit.
