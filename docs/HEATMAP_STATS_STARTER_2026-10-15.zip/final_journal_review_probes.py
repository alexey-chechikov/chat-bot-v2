"""Independent final integration probes, synthetic DB only."""
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'prototype'))
from journal import Journal, MINUTE
from test_journal import sample, T
from stats import summarize, SLOT


def main():
    root = BASE / 'review_tmp'; root.mkdir(exist_ok=True)
    result = {'scope': 'isolated synthetic DB only; no user images or runtime DB read'}
    with tempfile.TemporaryDirectory(dir=root) as folder:
        path = Path(folder) / 'legacy.sqlite'
        db = sqlite3.connect(path)
        db.execute('CREATE TABLE evaluations(snapshot_id TEXT NOT NULL,protocol TEXT NOT NULL,price_sha256 TEXT NOT NULL,evaluated_ms INTEGER NOT NULL,payload TEXT NOT NULL,PRIMARY KEY(snapshot_id,protocol,price_sha256))')
        db.commit(); db.close()
        j = Journal(path)
        try:
            j.observation(sample(), T)
            try:
                j.evaluate(T)
                result['legacy_evaluation_schema_works'] = True
            except sqlite3.OperationalError as exc:
                result['legacy_evaluation_schema_works'] = False
                result['legacy_evaluation_error'] = str(exc)
        finally:
            j.close()

    with tempfile.TemporaryDirectory(dir=root) as folder:
        j = Journal(Path(folder) / 'current.sqlite')
        try:
            # An empty pending price series must become censored at maturity;
            # its raw price hash stays unchanged, its input maturity hash changes.
            anchor = T // SLOT * SLOT
            value = sample()
            for key in ('received_ms', 'observed_ms', 'spot_asof_ms'):
                value[key] = anchor
            j.observation(value, anchor)
            early = j.evaluate(anchor)[0]
            later = j.evaluate(anchor + 241 * MINUTE)[0]
            assert early['horizons']['240']['observation_status'] == 'PENDING'
            assert later['horizons']['240']['observation_status'] == 'CENSORED'
            assert early['price_sha256'] == later['price_sha256']
            assert early['input_sha256'] != later['input_sha256']
            assert j.status()['evaluations'] == 2
            summary = summarize([later])
            assert summary['forecast_status'] == 'not_calibrated'
            horizon = summary['series'][0]['cohorts']['primary_fixed_UTC6h']['horizons']['240']
            assert horizon['complete_denominator'] == 0
            assert horizon['counts'] == {'CENSORED': 1}
            assert horizon['historical_fractions_not_forecasts'] == {}
            result['empty_prices_async_maturity'] = 'PASS: pending/censored distinct immutable derivatives, not zero return'
            result['summary_missing_data_not_in_probability_denominator'] = 'PASS'
        finally:
            j.close()
    (BASE / 'final_journal_review_probe_results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
