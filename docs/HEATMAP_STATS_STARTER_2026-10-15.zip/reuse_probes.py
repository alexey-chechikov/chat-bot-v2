"""Read-only probes: compile only pure AST definitions, never import bot modules."""
from __future__ import annotations

import ast
import csv
import hashlib
import json
import subprocess
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

ROOT = Path('C:/bot7')
OUT = ROOT / 'research/liquidation_heatmap_20261015/reuse_probe_results.json'


def isolated(relative: str, names: set[str], extra: dict | None = None) -> dict:
    source = (ROOT / relative).read_text(encoding='utf-8-sig')
    tree = ast.parse(source, filename=relative)
    nodes = [node for node in tree.body if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in names]
    scope = {'Any': Any, 'Dict': Dict, 'Iterable': Iterable, 'List': List,
             'Optional': Optional, 'dataclass': dataclass, 'defaultdict': defaultdict,
             'time': time}
    if extra:
        scope.update(extra)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), relative, 'exec'), scope)
    return scope


def main() -> None:
    result = {'method': 'AST-isolated pure definitions; no bot imports/network/live state', 'synthetic': {}}
    cg = isolated('core/coinglass_client.py', {'_find_heatmap_levels'})
    result['synthetic']['matrix_is_not_parsed'] = cg['_find_heatmap_levels'](
        {'prices': [99, 101], 'liquidationLeverageData': [[0, 0, 20], [0, 1, 40]]}, 100)

    lm = isolated('core/liquidation_map.py', {'LiquidationSnapshot', 'build_liquidation_context'})
    result['synthetic']['near_price_has_no_sweep_history'] = lm['build_liquidation_context'](
        lm['LiquidationSnapshot'](nearest_long_liq_price=99, nearest_short_liq_price=100.1,
                                  current_price=100, long_cluster_strength=5, short_cluster_strength=10))

    lc = isolated('core/liquidation_character.py', {'_f', 'analyze_fast_move'})
    p = lc['analyze_fast_move']({'decision': {'fast_move_classification': 'POST_LIQUIDATION_EXHAUSTION',
                                            'confidence_pct': 80}})
    result['synthetic']['probability_is_heuristic'] = p
    result['synthetic']['probability_sum_pct'] = p['continuation_probability'] + p['exhaustion_probability']

    ex = isolated('core/exchange_liquidity_engine.py', {'_safe_float', '_safe_int', '_bucket_price', '_aggregate_events'},
                  {'PRICE_BUCKET_USD': 0, 'WINDOW_MINUTES': 180, '_now_ms': lambda: 1000000})
    events = [{'price': 101, 'notional': 1, 'side': 'SELL', 'ts': 1000000},
              {'price': 105, 'notional': 100, 'side': 'SELL', 'ts': 1000000}]
    a = ex['_aggregate_events'](events, 100)
    b = ex['_aggregate_events']([{**v, 'side': 'BUY'} for v in events], 100)
    result['synthetic']['strongest_is_called_nearest'] = a
    result['synthetic']['changing_liquidated_side_does_not_change_clusters'] = a == b
    assert result['synthetic']['matrix_is_not_parsed'] == {}
    assert result['synthetic']['near_price_has_no_sweep_history']['liquidity_state'] == 'BUY_SIDE_SWEEP_REJECTED'
    assert result['synthetic']['probability_sum_pct'] == 108
    assert a['nearest_above_price'] == 105
    assert result['synthetic']['changing_liquidated_side_does_not_change_clusters'] is True
    result['synthetic_assertions_passed'] = 5

    source_inventory = {}
    pin = 'e1fe76a50c226872de6831edaa23c2ef3f30f466'
    gitdir = ROOT / 'research/weex_publish_20261010'
    for relative in ('core/coinglass_client.py', 'core/liquidation_map.py',
                     'core/liquidation_reaction_engine.py', 'core/liquidation_character.py',
                     'core/exchange_liquidity_engine.py', 'services/analysis_service.py',
                     'market_collector/liquidations.py', 'tests/market_collector/test_liquidations_parsing.py'):
        public = subprocess.run(['git', '-C', str(gitdir), 'show', f'{pin}:{relative}'],
                                check=True, capture_output=True).stdout.decode('utf-8-sig').replace('\r\n', '\n')
        local = (ROOT / relative).read_text(encoding='utf-8-sig').replace('\r\n', '\n')
        source_inventory[relative] = {'matches_public_pin_after_newline_normalization': public == local,
                                      'local_normalized_sha256': hashlib.sha256(local.encode()).hexdigest()}
    result['public_source_pin'] = pin
    result['source_inventory'] = source_inventory

    inventory = {}
    for name in ('liquidations.csv', 'liquidations_ETHUSDT.csv', 'liquidations_XRPUSDT.csv'):
        path = ROOT / 'market_live' / name
        counts = Counter()
        first = last = None
        n = 0
        with path.open(encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            header = reader.fieldnames
            for row in reader:
                n += 1
                counts[row.get('exchange', '')] += 1
                ts = row.get('ts_utc')
                if ts:
                    first = ts if first is None or ts < first else first
                    last = ts if last is None or ts > last else last
        inventory[name] = {'header': header, 'rows': n, 'counts_by_exchange': dict(counts),
                           'first_recorded_utc': first, 'last_recorded_utc': last}
    result['market_csv_inventory'] = inventory
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
