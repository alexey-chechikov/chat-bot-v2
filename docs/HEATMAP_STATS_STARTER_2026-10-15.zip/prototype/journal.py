"""Prospective heatmap observation journal. No bot imports, trade calls, API or implicit credentials."""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import time
from urllib.parse import urlparse, parse_qsl
import uuid

MINUTE = 60_000
HORIZONS = (15, 60, 240)
PROTOCOL = 'heatmap-first-reach-v1-close-reaction-0.15pct-60min'
DEFAULT_DB = Path(__file__).resolve().parents[1] / 'local' / 'journal.sqlite'


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def utc_ms():
    return time.time_ns() // 1_000_000


def finite(value, name, positive=False):
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
        raise ValueError(f'{name}: finite number required')
    if positive and value <= 0:
        raise ValueError(f'{name}: positive number required')
    return float(value)


def timestamp(value, name):
    if isinstance(value, bool) or not isinstance(value, int) or value < 1_000_000_000_000:
        raise ValueError(f'{name}: UTC epoch milliseconds required, not seconds')
    return value


def validate_observation(data, now_ms):
    """Operator-verified normalized zones; historical reconstruction cannot become prospective."""
    if not isinstance(data, dict):
        raise ValueError('snapshot must be object')
    required = ('symbol', 'price_source', 'provider', 'model', 'map_range', 'scope', 'settings_id',
                'source_url', 'source_sha256', 'received_ms', 'observed_ms', 'spot_asof_ms',
                'spot_price', 'metadata_verified', 'zone_upper', 'zone_lower')
    for name in required:
        if name not in data:
            raise ValueError(f'missing {name}')
    allowed = set(required) | {'exchanges','intensity_unit','extraction_method','selection_rule_id'}
    if set(data) - allowed:
        raise ValueError('unexpected fields: normalized observations exclude secrets and arbitrary notes')
    for name in ('symbol', 'price_source', 'provider', 'model', 'map_range', 'scope', 'settings_id'):
        if not isinstance(data[name], str) or not data[name].strip():
            raise ValueError(f'{name}: nonempty string required')
    if data['provider'] != 'coinglass' or data['model'] not in ('model1', 'model2', 'model3'):
        raise ValueError('confirmed CoinGlass provider/model required')
    if data['scope'] not in ('pair', 'aggregated'):
        raise ValueError('scope must be pair or aggregated')
    if data['map_range'] not in ('12h', '24h', '3d', '7d', '30d', '90d', '180d', '1y'):
        raise ValueError('unsupported range')
    if data['metadata_verified'] is not True:
        raise ValueError('metadata not verified: save as reference instead')
    if not isinstance(data.get('exchanges'), list) or not data['exchanges']:
        raise ValueError('exchanges or explicit aggregated coverage identifier required')
    if not all(isinstance(v, str) and v.strip() for v in data['exchanges']):
        raise ValueError('invalid exchanges')
    url = urlparse(data['source_url'])
    if url.scheme != 'https' or not url.hostname or not (
        url.hostname == 'coinglass.com' or url.hostname.endswith('.coinglass.com')
    ) or url.username or url.password:
        raise ValueError('public CoinGlass HTTPS source URL required')
    auth_keys = {'apikey','secret','token','accesstoken','authorization','password','accesskey','jwt'}
    query_keys = {''.join(c for c in k.lower() if c.isalnum()) for k, _ in parse_qsl(url.query)}
    if query_keys & auth_keys or url.fragment:
        raise ValueError('do not store credential query parameters')
    fingerprint = data['source_sha256']
    if not isinstance(fingerprint, str) or len(fingerprint) != 64 or any(c not in '0123456789abcdef' for c in fingerprint):
        raise ValueError('source_sha256 required')
    received = timestamp(data['received_ms'], 'received_ms')
    observed = timestamp(data['observed_ms'], 'observed_ms')
    price_time = timestamp(data['spot_asof_ms'], 'spot_asof_ms')
    if received > now_ms or observed > received or price_time > received:
        raise ValueError('future source/price/receipt timestamps')
    if now_ms - min(received, observed, price_time) > 120_000:
        raise ValueError('older than two minutes: reference only, no prospective label')
    p = finite(data['spot_price'], 'spot_price', True)
    zone_count = 0
    for side in ('upper', 'lower'):
        zone = data[f'zone_{side}']
        if zone is None:
            continue
        if not isinstance(zone, dict):
            raise ValueError('zone must be object or null')
        if set(zone) - {'low','high','intensity'}:
            raise ValueError('unexpected zone fields')
        low, high = finite(zone.get('low'), 'zone low', True), finite(zone.get('high'), 'zone high', True)
        if low >= high:
            raise ValueError('zone low must be below high')
        if side == 'upper' and low <= p or side == 'lower' and high >= p:
            raise ValueError('zone must be strictly above/below capture price')
        if 'intensity' in zone and zone['intensity'] is not None:
            if finite(zone['intensity'], 'intensity') < 0 or not data.get('intensity_unit'):
                raise ValueError('nonnegative intensity and known unit required')
        zone_count += 1
    if not zone_count:
        raise ValueError('at least one preselected zone required')
    method = data.get('extraction_method')
    if method not in ('manual_frozen_zones', 'validated_numeric_adapter'):
        raise ValueError('explicit extraction_method required')
    if not isinstance(data.get('selection_rule_id'),str) or not data['selection_rule_id'].strip():
        raise ValueError('selection_rule_id required before outcomes')
    if 'intensity_unit' in data and (not isinstance(data['intensity_unit'],str) or not data['intensity_unit'].strip()):
        raise ValueError('intensity_unit must be a nonempty string')
    # Freeze at annotation/database admission, never backdate annotations to screenshot time.
    out = dict(data)
    out.update(schema_version=1, kind='observation', eligible=True, ingested_ms=now_ms,
               source_received_ms=received, received_ms=now_ms, decision_ms=(now_ms // MINUTE + 1) * MINUTE,
               quality='operator_verified_manual' if method == 'manual_frozen_zones' else 'validated_numeric')
    out['series_key'] = digest({k:out[k] for k in (
        'symbol','price_source','provider','model','map_range','scope','exchanges','settings_id',
        'selection_rule_id','extraction_method')})
    return out


def validate_bars(rows):
    output, previous = [], None
    for row in rows:
        ts = timestamp(row['ts'], 'bar ts')
        if ts % MINUTE or previous is not None and ts <= previous:
            raise ValueError('price bars must be unique, ascending, exact UTC minute starts')
        o, h, l, c = (finite(row[k], k, True) for k in ('open', 'high', 'low', 'close'))
        if not (l <= min(o, c) <= max(o, c) <= h):
            raise ValueError('invalid OHLC')
        output.append({'ts': ts, 'open': o, 'high': h, 'low': l, 'close': c})
        previous = ts
    if not output:
        raise ValueError('empty bars are not complete history')
    return output


class Journal:
    def __init__(self, path=DEFAULT_DB):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS snapshots(
            id TEXT PRIMARY KEY, received_ms INTEGER NOT NULL, kind TEXT NOT NULL,
            sha256 TEXT NOT NULL, payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS bars(
            source TEXT NOT NULL, symbol TEXT NOT NULL, ts INTEGER NOT NULL,
            payload TEXT NOT NULL, sha256 TEXT NOT NULL,
            PRIMARY KEY(source,symbol,ts));
        CREATE TABLE IF NOT EXISTS evaluations(
            snapshot_id TEXT NOT NULL, protocol TEXT NOT NULL, input_sha256 TEXT NOT NULL,
            evaluated_ms INTEGER NOT NULL, payload TEXT NOT NULL,
            PRIMARY KEY(snapshot_id,protocol,input_sha256));
        CREATE TRIGGER IF NOT EXISTS snapshots_no_update BEFORE UPDATE ON snapshots
            BEGIN SELECT RAISE(ABORT,'immutable snapshots'); END;
        CREATE TRIGGER IF NOT EXISTS snapshots_no_delete BEFORE DELETE ON snapshots
            BEGIN SELECT RAISE(ABORT,'immutable snapshots'); END;
        CREATE TRIGGER IF NOT EXISTS bars_no_update BEFORE UPDATE ON bars
            BEGIN SELECT RAISE(ABORT,'immutable bars'); END;
        CREATE TRIGGER IF NOT EXISTS bars_no_delete BEFORE DELETE ON bars
            BEGIN SELECT RAISE(ABORT,'immutable bars'); END;
        CREATE TRIGGER IF NOT EXISTS evaluations_no_update BEFORE UPDATE ON evaluations
            BEGIN SELECT RAISE(ABORT,'immutable evaluations'); END;
        CREATE TRIGGER IF NOT EXISTS evaluations_no_delete BEFORE DELETE ON evaluations
            BEGIN SELECT RAISE(ABORT,'immutable evaluations'); END;
        ''')
        columns={r[1] for r in self.db.execute('PRAGMA table_info(evaluations)')}
        if 'price_sha256' in columns:
            self.db.execute('ALTER TABLE evaluations RENAME COLUMN price_sha256 TO input_sha256')
            self.db.commit()

    def close(self):
        self.db.close()

    def store(self, payload, snapshot_id=None):
        ident = snapshot_id or str(uuid.uuid4())
        text, sha = canonical(payload), digest(payload)
        old = self.db.execute('SELECT sha256 FROM snapshots WHERE id=?', (ident,)).fetchone()
        if old:
            if old[0] != sha:
                raise ValueError('existing snapshot id with different content')
            return ident
        with self.db:
            self.db.execute('INSERT INTO snapshots VALUES(?,?,?,?,?)',
                            (ident, payload['received_ms'], payload['kind'], sha, text))
        return ident

    def reference(self, image_path, notes='', now_ms=None):
        path = Path(image_path).resolve(strict=True)
        payload = {'schema_version': 1, 'kind': 'reference', 'eligible': False,
                   'received_ms': utc_ms() if now_ms is None else now_ms,
                   'image_path_local': str(path), 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                   'filename_time_is_unverified': True, 'provider': 'coinglass', 'symbol': None,
                   'model': None, 'map_range': None, 'zone_upper': None, 'zone_lower': None,
                   'notes': notes, 'quality': 'cropped_metadata_missing', 'forecast_status': 'not_calibrated'}
        return self.store(payload)

    def observation(self, payload, now_ms=None, snapshot_id=None):
        clean = validate_observation(payload, utc_ms() if now_ms is None else now_ms)
        return self.store(clean, snapshot_id)

    def import_bars(self, source, symbol, rows, now_ms=None):
        if not source or not symbol:
            raise ValueError('source and symbol required')
        validated = validate_bars(rows)
        now = utc_ms() if now_ms is None else now_ms
        if any(r['ts'] + MINUTE > now for r in validated):
            raise ValueError('forming/future candle cannot be imported as closed')
        added = 0
        with self.db:
            for row in validated:
                sha = digest(row)
                previous = self.db.execute('SELECT sha256 FROM bars WHERE source=? AND symbol=? AND ts=?',
                                           (source, symbol, row['ts'])).fetchone()
                if previous:
                    if previous[0] != sha:
                        raise ValueError('price revision conflict: preserve versions in a new source dataset')
                    continue
                self.db.execute('INSERT INTO bars VALUES(?,?,?,?,?)',
                                (source, symbol, row['ts'], canonical(row), sha))
                added += 1
        return added

    def snapshots(self):
        return [(i, json.loads(p)) for i, p in self.db.execute(
            'SELECT id,payload FROM snapshots ORDER BY received_ms,id')]

    def evaluate(self, now_ms=None):
        import labels
        now = utc_ms() if now_ms is None else now_ms
        label_source_sha = hashlib.sha256(Path(labels.__file__).read_bytes()).hexdigest()
        journal_source_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        effective_protocol = f'{PROTOCOL}:{labels.LABEL_VERSION}:{label_source_sha}:{journal_source_sha}'
        results = []
        for ident, snapshot in self.snapshots():
            if not snapshot.get('eligible') or snapshot['received_ms'] > now:
                continue
            rows = [json.loads(v[0]) for v in self.db.execute(
                'SELECT payload FROM bars WHERE source=? AND symbol=? AND ts>=? AND ts<? AND ts+?<=? ORDER BY ts',
                (snapshot['price_source'], snapshot['symbol'], snapshot['decision_ms'],
                 snapshot['decision_ms'] + (max(HORIZONS) + 60) * MINUTE, MINUTE, now))]
            price_hash = digest(rows)
            response = labels.label_snapshot(dict(snapshot, snapshot_id=ident), rows)
            response.update(snapshot_id=ident, protocol=effective_protocol, price_sha256=price_hash,
                            settings_id=snapshot['settings_id'], model=snapshot['model'],
                            symbol=snapshot['symbol'], price_source=snapshot['price_source'],
                            received_ms=snapshot['received_ms'],series_key=snapshot['series_key'])
            mature_flags=[]
            for horizon in HORIZONS:
                result=response['horizons'][str(horizon)]
                mature=result['window_end_ms']<=now
                result['final']=mature
                result['observation_status']=result['status'] if mature else 'PENDING'
                mature_flags.append(mature)
                reaction=result.get('reaction')
                if reaction is not None:
                    hit=result['first_hit']['ts_ms']
                    reaction_mature=hit+60*MINUTE<=now
                    reaction['final']=reaction_mature
                    reaction['observation_status']=reaction['status'] if reaction_mature else 'PENDING'
                    mature_flags.append(reaction_mature)
            input_hash=digest({'price_sha256':price_hash,'mature_flags':mature_flags})
            response['input_sha256']=input_hash
            old = self.db.execute('SELECT payload,evaluated_ms FROM evaluations WHERE snapshot_id=? AND protocol=? AND input_sha256=?',
                                  (ident,effective_protocol,input_hash)).fetchone()
            if old and old[0] != canonical(response):
                raise ValueError('same evaluation inputs/code returned different output; preserve incident')
            with self.db:
                self.db.execute('INSERT OR IGNORE INTO evaluations VALUES(?,?,?,?,?)',
                                (ident, effective_protocol, input_hash, now, canonical(response)))
            results.append(dict(response,evaluated_ms=old[1] if old else now,data_asof_ms=now))
        return results

    def status(self):
        refs = self.db.execute("SELECT count(*) FROM snapshots WHERE kind='reference'").fetchone()[0]
        observations = self.db.execute("SELECT count(*) FROM snapshots WHERE kind='observation'").fetchone()[0]
        return {'reference_images': refs, 'eligible_observations': observations,
                'price_bars': self.db.execute('SELECT count(*) FROM bars').fetchone()[0],
                'evaluations': self.db.execute('SELECT count(*) FROM evaluations').fetchone()[0],
                'forecast_status': 'not_calibrated',
                'note': 'Descriptive outcomes only; no validated future probabilities or trading signals.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db', type=Path, default=DEFAULT_DB)
    sub = p.add_subparsers(dest='command', required=True)
    sub.add_parser('status')
    r = sub.add_parser('reference')
    r.add_argument('image', type=Path)
    r.add_argument('--notes', default='')
    s = sub.add_parser('snapshot')
    s.add_argument('json_file', type=Path)
    b = sub.add_parser('bars')
    b.add_argument('csv_file', type=Path)
    b.add_argument('--source', required=True)
    b.add_argument('--symbol', required=True)
    sub.add_parser('evaluate')
    sub.add_parser('summary')
    args = p.parse_args()
    j = Journal(args.db)
    try:
        if args.command == 'status':
            output = j.status()
        elif args.command == 'reference':
            output = {'reference_id': j.reference(args.image, args.notes), **j.status()}
        elif args.command == 'snapshot':
            payload = json.loads(args.json_file.read_text(encoding='utf-8-sig'))
            output = {'snapshot_id': j.observation(payload), **j.status()}
        elif args.command == 'bars':
            with args.csv_file.open(encoding='utf-8-sig', newline='') as f:
                rows = [{'ts': int(r['ts']), **{k: float(r[k]) for k in ('open','high','low','close')}} for r in csv.DictReader(f)]
            output = {'inserted_bars': j.import_bars(args.source, args.symbol, rows), **j.status()}
        elif args.command=='evaluate':
            output = {'evaluations': j.evaluate(), 'status': j.status()}
        else:
            from stats import summarize
            output={'statistics':summarize(j.evaluate()),'status':j.status()}
        print(json.dumps(output, ensure_ascii=False, indent=2))
    finally:
        j.close()


if __name__ == '__main__':
    main()
