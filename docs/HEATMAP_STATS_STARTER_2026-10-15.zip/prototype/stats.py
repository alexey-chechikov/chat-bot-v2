"""Descriptive frequencies only. No fitted market probabilities or trading recommendations."""
from collections import Counter, defaultdict

MINUTE=60_000
SLOT=360*MINUTE
SLOT_TOLERANCE=2*MINUTE
HORIZONS=('15','60','240')


def summarize(evaluations):
    """Primary selection before completeness/outcomes: earliest freeze per fixed UTC6h slot.

    Reaction can extend to5h; six-hour scheduled anchors avoid overlapping paths.
    Nonoverlap does NOT establish independent market observations.
    """
    ordered=sorted(evaluations,key=lambda r:(r['received_ms'],r['snapshot_id']))
    seen_ids=set();selected_slots=set();groups=defaultdict(list)
    for row in ordered:
        if row['snapshot_id'] in seen_ids:
            raise ValueError('duplicate evaluations: pass one latest result per snapshot')
        seen_ids.add(row['snapshot_id'])
        shape=('two_sided' if row['frozen_zone_upper'] and row['frozen_zone_lower'] else
               'upper_only' if row['frozen_zone_upper'] else 'lower_only')
        series=(row['series_key'],shape)
        primary=False
        if row['received_ms']%SLOT<SLOT_TOLERANCE:
            slot=(series,row['received_ms']//SLOT)
            if slot not in selected_slots:
                selected_slots.add(slot);primary=True
        groups[series].append((row,primary))
    output=[]
    for (key,shape),rows in sorted(groups.items()):
        sample=rows[0][0]
        cohorts={}
        for name in ('primary_fixed_UTC6h','secondary_all_frozen'):
            cohort=[row for row,primary in rows if primary or name=='secondary_all_frozen']
            windows={}
            for horizon in HORIZONS:
                counts=Counter(row['horizons'][horizon]['observation_status'] for row in cohort)
                completed=[row for row in cohort if row['horizons'][horizon]['final'] and
                           row['horizons'][horizon]['complete']]
                denominator=len(completed)
                frequencies={s:sum(row['horizons'][horizon]['status']==s for row in completed)/denominator
                             for s in ('UPPER_FIRST','LOWER_FIRST','NO_HIT','AMBIGUOUS')} if denominator else {}
                reactions=Counter()
                for row in cohort:
                    result=row['horizons'][horizon]
                    if result['final'] and result['complete'] and result.get('reaction') is not None:
                        reactions[result['reaction']['observation_status']]+=1
                windows[horizon]={'all_selected':len(cohort),'counts':dict(counts),
                                  'complete_denominator':denominator,
                                  'historical_fractions_not_forecasts':frequencies,
                                  'reaction_counts':dict(reactions)}
            cohorts[name]={'n_snapshots':len(cohort),'horizons':windows}
        output.append({'series_key':key,'shape':shape,'symbol':sample['symbol'],'model':sample['model'],
                       'settings_id':sample['settings_id'],'price_source':sample['price_source'],'cohorts':cohorts})
    return {'forecast_status':'not_calibrated','series':output,
            'primary_policy':'Earliest eligible freeze within00:00/06:00/12:00/18:00 UTC +2min, selected before outcomes.',
            'uncertainty':'No CI/model fitted yet. Secondary records overlap; even primary markets remain serially dependent.',
            'gates_missing':['matched price-only controls','day/week cluster uncertainty','untouched forward calibration']}
