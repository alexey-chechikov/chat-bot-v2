"""Pure prospective heatmap labels. No network, account or trading code.

Prices are UTC 1m OHLC bars, timestamps are minute opens in milliseconds.
The caller must establish source eligibility and freeze snapshot annotation
before passing ``eligible=True``. No fitted probability is produced here.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from math import isfinite
from typing import Any

MINUTE_MS = 60_000
LABEL_VERSION = "frozen-zone-first-hit-v1"


class LabelValidationError(ValueError):
    """A malformed frozen snapshot or price series cannot be labelled."""


def _number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise LabelValidationError(f"{field}: expected finite numeric value")
    value = float(value)
    if not isfinite(value):
        raise LabelValidationError(f"{field}: expected finite numeric value")
    return value


def _millisecond(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise LabelValidationError(f"{field}: expected nonnegative integer UTC milliseconds")
    return value


def _price(row: Mapping[str, Any], name: str, alias: str) -> float:
    if name not in row and alias not in row:
        raise LabelValidationError(f"candle missing {name}/{alias}")
    value = _number(row[name] if name in row else row[alias], name)
    if name in row and alias in row:
        other = _number(row[alias], alias)
        if other != value:
            raise LabelValidationError(f"conflicting {name}/{alias}")
    if value <= 0:
        raise LabelValidationError(f"{name}: price must be positive")
    return value


@dataclass(frozen=True)
class Candle:
    ts: int
    o: float
    h: float
    l: float
    c: float


def _candles(rows: Iterable[Mapping[str, Any]]) -> dict[int, Candle]:
    result: dict[int, Candle] = {}
    previous: int | None = None
    for row in rows:
        if not isinstance(row, Mapping):
            raise LabelValidationError("candle must be a mapping")
        if "ts" not in row:
            raise LabelValidationError("candle missing ts")
        ts = _millisecond(row["ts"], "candle.ts")
        if ts % MINUTE_MS:
            raise LabelValidationError("candle.ts must be a UTC minute open")
        if previous is not None and ts <= previous:
            raise LabelValidationError("candles must be strictly increasing; duplicates are invalid")
        o, h, l, c = (_price(row, name, alias) for name, alias in
                       (("open", "o"), ("high", "h"), ("low", "l"), ("close", "c")))
        if l > min(o, c) or h < max(o, c) or l > h:
            raise LabelValidationError("OHLC range is inconsistent")
        result[ts] = Candle(ts, o, h, l, c)
        previous = ts
    return result


def _zone(value: Any, side: str, spot: float) -> tuple[float, float] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping) or "low" not in value or "high" not in value:
        raise LabelValidationError(f"zone_{side}: expected low/high or null")
    low, high = _number(value["low"], f"zone_{side}.low"), _number(value["high"], f"zone_{side}.high")
    if low <= 0 or low >= high:
        raise LabelValidationError(f"zone_{side}: expected 0 < low < high")
    if side == "upper" and low <= spot:
        raise LabelValidationError("upper zone must lie strictly above frozen spot")
    if side == "lower" and high >= spot:
        raise LabelValidationError("lower zone must lie strictly below frozen spot")
    return low, high


def _window(prices: dict[int, Candle], start: int, minutes: int) -> tuple[list[Candle], list[int]]:
    expected = range(start, start + minutes * MINUTE_MS, MINUTE_MS)
    available, missing = [], []
    for ts in expected:
        if ts in prices:
            available.append(prices[ts])
        else:
            missing.append(ts)
    return available, missing


def _movement(prices: dict[int, Candle], start: int, minutes: int,
              direction: int = 1) -> dict[str, Any]:
    rows, missing = _window(prices, start, minutes)
    output: dict[str, Any] = {
        "start_ms": start, "end_ms": start + minutes * MINUTE_MS,
        "complete": not missing, "missing_minutes": len(missing),
        "return_fraction": None, "mfe_fraction": None, "mae_fraction": None,
        "reference_open": None,
    }
    # Never invent an entry, terminal close, or extrema across a missing minute.
    if missing or not rows:
        return output
    entry = rows[0].o
    output["reference_open"] = entry
    output["return_fraction"] = direction * (rows[-1].c / entry - 1)
    if direction == 1:
        output["mfe_fraction"] = max(0.0, max(row.h for row in rows) / entry - 1)
        output["mae_fraction"] = min(0.0, min(row.l for row in rows) / entry - 1)
    else:
        output["mfe_fraction"] = max(0.0, 1 - min(row.l for row in rows) / entry)
        output["mae_fraction"] = min(0.0, 1 - max(row.h for row in rows) / entry)
    return output


def _reaction(prices: dict[int, Candle], hit: dict[str, Any],
              zone: tuple[float, float], spot: float, minutes: int,
              fraction: float) -> dict[str, Any]:
    """First close-confirmed reaction; original hit minute's close is admissible.

    This is not an intraminute stop/limit simulator. The confirmation clock is
    the bar close (ts+60_000), not the start timestamp of its candle. Separate
    movement metrics start at the NEXT minute, excluding unorderable extrema
    from the hit minute.
    """
    start = hit["ts_ms"]
    end = start + minutes * MINUTE_MS
    missing = [ts for ts in range(start, end, MINUTE_MS) if ts not in prices]
    direction = 1 if hit["side"] == "UPPER" else -1
    low, high = zone
    if direction == 1:
        rejection_level, continuation_level = low - spot * fraction, high + spot * fraction
    else:
        rejection_level, continuation_level = high + spot * fraction, low - spot * fraction
    confirmation = None
    # A gap before confirmation makes its earliest type unknowable. Preserve
    # a known confirmation before a later gap, with complete=False.
    for ts in range(start, end, MINUTE_MS):
        if ts not in prices:
            break
        close = prices[ts].c
        rejection = close <= rejection_level if direction == 1 else close >= rejection_level
        continuation = close >= continuation_level if direction == 1 else close <= continuation_level
        if rejection or continuation:
            confirmation = {
                "type": "REJECTION" if rejection else "CONTINUATION",
                "confirmed_at_ms": ts + MINUTE_MS,
                "candle_ts_ms": ts, "close": close,
            }
            break
    return {
        "status": "CENSORED" if missing else (confirmation["type"] if confirmation else "UNRESOLVED"),
        "complete": not missing,
        "known_first_confirmation": confirmation,
        "window_start_ms": start, "window_end_ms": end,
        "reaction_fraction_of_frozen_spot": fraction,
        "rejection_level": rejection_level, "continuation_level": continuation_level,
        "missing_minutes": len(missing),
        "forward_movement": _movement(prices, start + MINUTE_MS, minutes, direction),
        "note": "close confirmation only; CONTINUATION is a zone break, not proof of tradable fill or further follow-through",
    }


def _horizon(prices: dict[int, Candle], start: int, minutes: int,
             upper: tuple[float, float] | None, lower: tuple[float, float] | None,
             spot: float, reaction_minutes: int, reaction_fraction: float) -> dict[str, Any]:
    end = start + minutes * MINUTE_MS
    missing = [ts for ts in range(start, end, MINUTE_MS) if ts not in prices]
    first_hit = None
    first_outcome = None
    prefix = 0
    for ts in range(start, end, MINUTE_MS):
        if ts not in prices:
            break
        prefix += 1
        bar = prices[ts]
        upper_hit = upper is not None and bar.h >= upper[0]
        lower_hit = lower is not None and bar.l <= lower[1]
        if upper_hit and lower_hit:
            first_hit = {"side": "BOTH", "ts_ms": ts, "gap_over": False}
            first_outcome = "AMBIGUOUS"
            break
        if upper_hit or lower_hit:
            side = "UPPER" if upper_hit else "LOWER"
            gap_over = bar.l > upper[1] if upper_hit else bar.h < lower[0]
            first_hit = {"side": side, "ts_ms": ts, "gap_over": gap_over}
            first_outcome = f"{side}_FIRST"
            break
    if upper is None and lower is None:
        first_outcome = "NO_ZONES"
    elif first_outcome is None and not missing:
        first_outcome = "NO_HIT"
    reaction = None
    if first_hit is not None and first_hit["side"] != "BOTH":
        zone = upper if first_hit["side"] == "UPPER" else lower
        assert zone is not None
        reaction = _reaction(prices, first_hit, zone, spot, reaction_minutes, reaction_fraction)
    return {
        "status": "CENSORED" if missing else first_outcome,
        "complete": not missing,
        "known_first_hit_outcome": first_outcome,
        "first_hit": first_hit,
        "one_sided": (upper is None) != (lower is None),
        "window_start_ms": start, "window_end_ms": end,
        "missing_minutes": len(missing), "first_missing_ms": missing[0] if missing else None,
        "known_prefix_minutes_scanned": prefix,
        "movement": _movement(prices, start, minutes),
        "reaction": reaction,
    }


def label_snapshot(snapshot: Mapping[str, Any], candles: Iterable[Mapping[str, Any]],
                   horizons: tuple[int, ...] = (15, 60, 240), *,
                   reaction_minutes: int = 60, reaction_fraction: float = 0.0015) -> dict[str, Any]:
    """Return deterministic descriptive labels for an immutable frozen snapshot.

    Required eligible fields: snapshot_id, received_ms, spot_price, eligible=True,
    zone_upper and zone_lower (each optional/null, otherwise numeric low/high).
    received_ms must be the EFFECTIVE freeze time if manual annotation finished
    after receiving the image. Passing the original historical screenshot time
    is causally invalid; the journal is responsible for enforcing that rule.

    Every H window contains exactly H expected minute-open timestamps, starting
    with the first UTC minute strictly after received_ms. All return values are
    fractions (0.001 = 0.1%), not probabilities and not backtested trade PnL.
    """
    if not isinstance(snapshot, Mapping):
        raise LabelValidationError("snapshot must be a mapping")
    snapshot_id = snapshot.get("snapshot_id")
    if not isinstance(snapshot_id, str) or not snapshot_id.strip():
        raise LabelValidationError("snapshot_id must be a nonempty string")
    if snapshot.get("eligible") is not True or snapshot.get("record_kind") in ("reference", "reference_only"):
        return {"snapshot_id": snapshot_id, "label_version": LABEL_VERSION,
                "status": "REFERENCE_ONLY", "eligible": False, "horizons": {},
                "forecast_status": "not_calibrated"}
    received_ms = _millisecond(snapshot.get("received_ms"), "received_ms")
    spot = _number(snapshot.get("spot_price"), "spot_price")
    if spot <= 0:
        raise LabelValidationError("spot_price must be positive")
    upper = _zone(snapshot.get("zone_upper"), "upper", spot)
    lower = _zone(snapshot.get("zone_lower"), "lower", spot)
    if not horizons or any(isinstance(h, bool) or not isinstance(h, int) or h <= 0 for h in horizons):
        raise LabelValidationError("horizons must contain positive integer minutes")
    if len(set(horizons)) != len(horizons):
        raise LabelValidationError("duplicate horizons")
    if isinstance(reaction_minutes, bool) or not isinstance(reaction_minutes, int) or reaction_minutes <= 0:
        raise LabelValidationError("reaction_minutes must be a positive integer")
    reaction_fraction = _number(reaction_fraction, "reaction_fraction")
    if not 0 < reaction_fraction < 1:
        raise LabelValidationError("reaction_fraction must be in (0,1)")
    prices = _candles(candles)
    start = (received_ms // MINUTE_MS + 1) * MINUTE_MS
    return {
        "snapshot_id": snapshot_id, "label_version": LABEL_VERSION, "eligible": True,
        "status": "LABELLED", "forecast_status": "not_calibrated",
        "effective_received_ms": received_ms, "decision_ms": start,
        "frozen_spot_price": spot,
        "frozen_zone_upper": {"low": upper[0], "high": upper[1]} if upper else None,
        "frozen_zone_lower": {"low": lower[0], "high": lower[1]} if lower else None,
        "horizons": {str(h): _horizon(prices, start, h, upper, lower, spot,
                                      reaction_minutes, reaction_fraction) for h in horizons},
    }
