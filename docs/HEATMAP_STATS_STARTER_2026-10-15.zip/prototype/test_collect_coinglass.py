"""Offline only: all transport operations use explicit fake openers."""

import base64
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.error import HTTPError, URLError

from collect_coinglass import Config, RejectRedirects, collect_once, validate_shape


def valid_payload():
    return {"code": "0", "msg": "success", "data": {
        "y_axis": [100, 101],
        "liquidation_leverage_data": [[0, 1, 12.5]],
        "price_candlesticks": [[1792022400, "100", "101", "99", "100", "12"],
                               [1792022700, "100", "101", "99", "100.5", "10"]],
    }}


class Response:
    def __init__(self, body, status=200):
        self.body, self.status = body, status

    def read(self, n):
        return self.body[:n]

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class CollectorTests(unittest.TestCase):
    def setUp(self):
        self.temp_root = Path(__file__).resolve().parent / "collector_test_tmp"
        self.temp_root.mkdir(parents=True, exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=self.temp_root)
        self.root = Path(self.temp.name)
        self.key = "fake-never-live-test-credential"
        self.config = Config("model2", "pair", "BTCUSDT", "24h", "Binance")
        self.body = json.dumps(valid_payload()).encode()

    def tearDown(self):
        # TemporaryDirectory.cleanup() recursively removes its directory.
        # Verify the resolved target remains inside the explicit test workspace.
        self.assertTrue(self.root.resolve().is_relative_to(self.temp_root.resolve()))
        self.temp.cleanup()

    def collect(self, opener, config=None):
        return collect_once(config or self.config, self.key, self.root, opener=opener)

    def test_exact_endpoint_headers_raw_hash_and_no_auth_persistence(self):
        calls = []

        def fake(request, timeout):
            calls.append((request, timeout))
            return Response(self.body)

        path = self.collect(fake)
        record = json.loads(path.read_text())
        self.assertEqual(record["outcome"], "captured_raw_only")
        self.assertEqual(path.parent.name, "snapshots")
        self.assertEqual(base64.b64decode(record["body_base64"]), self.body)
        self.assertEqual(record["captured_body_sha256"], hashlib.sha256(self.body).hexdigest())
        self.assertFalse(record["historical_point_in_time_guarantee"])
        self.assertFalse(record["validation"]["usable_as_profile"])
        self.assertEqual(record["validation"]["sparse_missing_cell_semantics"], "unknown")
        self.assertNotIn(self.key, path.read_text())
        self.assertNotIn("headers", record["request"])
        self.assertEqual(calls[0][0].get_header("Cg-api-key"), self.key)
        self.assertIn("/heatmap/model2?symbol=BTCUSDT&range=24h&exchange=Binance", calls[0][0].full_url)
        self.assertEqual(len(calls), 1)

    def test_all_six_endpoints_and_explicit_scopes(self):
        for model in ("model1", "model2", "model3"):
            self.assertEqual(Config(model, "pair", "ETHUSDT", "12h", "OKX").endpoint,
                             f"/api/futures/liquidation/heatmap/{model}")
            self.assertEqual(Config(model, "aggregated", "ETH", "1y").endpoint,
                             f"/api/futures/liquidation/aggregated-heatmap/{model}")
        with self.assertRaises(ValueError):
            Config("model1", "aggregated", "BTC", "24h", "Binance")
        with self.assertRaises(ValueError):
            Config("model1", "pair", "BTCUSDT", "24h")

    def test_authenticated_redirect_is_never_followed(self):
        self.assertIsNone(RejectRedirects().redirect_request(
            None, None, 302, "redirect", {}, "https://other.invalid/"))

    def test_latency_uses_monotonic_and_receipt_is_separate(self):
        times = iter(["2026-10-15T01:00:00+00:00", "2026-10-15T01:00:01+00:00"])
        monotonic_times = iter([23.0, 23.25])
        path = collect_once(self.config, self.key, self.root,
                            opener=lambda *a, **k: Response(self.body),
                            now=lambda: next(times), monotonic=lambda: next(monotonic_times))
        rec = json.loads(path.read_text())
        self.assertEqual(rec["monotonic_latency_seconds"], 0.25)
        self.assertNotEqual(rec["request_sent_at_utc"], rec["received_at_utc"])

    def test_append_only_and_exclusive_collision(self):
        a = self.collect(lambda *a, **k: Response(self.body))
        before = a.read_bytes()
        b = self.collect(lambda *a, **k: Response(self.body))
        self.assertNotEqual(a, b)
        self.assertEqual(a.read_bytes(), before)
        with patch("collect_coinglass.uuid.uuid4") as fake_uuid:
            fake_uuid.return_value.hex = a.stem.removeprefix("snapshot_")
            with self.assertRaises(FileExistsError):
                self.collect(lambda *a, **k: Response(self.body))
        self.assertEqual(a.read_bytes(), before)

    def test_provider_nonzero_http200_preserved_as_error(self):
        body = b'{"code":"401","msg":"bad credential","data":null}'
        path = self.collect(lambda *a, **k: Response(body))
        rec = json.loads(path.read_text())
        self.assertEqual(rec["outcome"], "schema_or_provider_error")
        self.assertEqual(path.parent.name, "errors")
        self.assertEqual(base64.b64decode(rec["body_base64"]), body)

    def test_429_is_recorded_without_retry(self):
        calls = []

        def fake(*args, **kwargs):
            calls.append(1)
            raise HTTPError("https://example.invalid", 429, "key=" + self.key, {}, io.BytesIO(b"quota exhausted"))

        path = self.collect(fake)
        rec = json.loads(path.read_text())
        self.assertEqual(rec["outcome"], "rate_limited")
        self.assertEqual(rec["http_status"], 429)
        self.assertEqual(len(calls), 1)
        self.assertNotIn(self.key, path.read_text())

    def test_timeout_and_arbitrary_exception_do_not_log_credentials(self):
        for error in (TimeoutError(self.key), URLError(self.key), RuntimeError(self.key)):
            def fake(*args, **kwargs):
                raise error
            path = self.collect(fake)
            rec = json.loads(path.read_text())
            self.assertEqual(path.parent.name, "errors")
            self.assertIsNone(rec["http_status"])
            self.assertNotIn(self.key, path.read_text())

    def test_capped_body_not_misreported_complete(self):
        path = self.collect(lambda *a, **k: Response(self.body),
                            Config("model2", "pair", "BTCUSDT", "24h", "Binance", max_bytes=8))
        rec = json.loads(path.read_text())
        self.assertFalse(rec["raw_body_complete"])
        self.assertEqual(rec["outcome"], "body_limit_exceeded")
        self.assertEqual(rec["captured_body_bytes"], 8)

    def test_authentication_echo_body_is_redacted_even_if_base64(self):
        body = ("error " + self.key).encode()
        path = self.collect(lambda *a, **k: Response(body, status=401))
        rec = json.loads(path.read_text())
        stored = base64.b64decode(rec["body_base64"])
        self.assertNotIn(self.key.encode(), stored)
        self.assertTrue(rec["body_redacted"])
        self.assertEqual(rec["outcome"], "authentication_echo_redacted")
        self.assertEqual(rec["captured_body_sha256"], hashlib.sha256(body).hexdigest())
        self.assertNotEqual(rec["captured_body_sha256"], rec["stored_body_sha256"])

    def test_invalid_structures_cannot_be_usable_profile(self):
        mutations = [
            lambda d: d.update(y_axis=[101, 100]),
            lambda d: d.update(y_axis=[100, float("nan")]),
            lambda d: d.update(liquidation_leverage_data=[[2, 0, 1]]),
            lambda d: d.update(liquidation_leverage_data=[[0, 2, 1]]),
            lambda d: d.update(liquidation_leverage_data=[[True, 0, 1]]),
            lambda d: d.update(liquidation_leverage_data=[[0, 0, -1]]),
            lambda d: d.update(liquidation_leverage_data=[[0, 0, 1], [0, 0, 2]]),
            lambda d: d["price_candlesticks"][0].__setitem__(0, 1792022400000),
            lambda d: d["price_candlesticks"][1].__setitem__(0, 1792022400),
            lambda d: d["price_candlesticks"][0].__setitem__(2, "99"),
            lambda d: d["price_candlesticks"][0].__setitem__(5, "-1"),
        ]
        for mutate in mutations:
            payload = deepcopy(valid_payload())
            mutate(payload["data"])
            result = validate_shape(json.dumps(payload).encode())
            self.assertFalse(result["usable_as_profile"])
            self.assertEqual(result["state"], "invalid_matrix_structure")
        self.assertEqual(validate_shape(b"garbage")["state"], "invalid_json")


if __name__ == "__main__":
    unittest.main()
