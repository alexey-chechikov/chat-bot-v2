"""Offline synthetic tests; no CoinGlass key, HTTP or bot imports."""
import copy
from pathlib import Path
import sqlite3
import tempfile
import unittest

from journal import Journal, validate_observation, validate_bars, MINUTE

T = 1_800_000_000_000


def sample():
    return {'symbol':'BTCUSDT','price_source':'synthetic','provider':'coinglass','model':'model1',
            'map_range':'24h','scope':'aggregated','settings_id':'synthetic-frozen-selection-v1',
            'exchanges':['aggregated-provider-coverage-unverified-for-this-synthetic-fixture'],
            'source_url':'https://www.coinglass.com/pro/futures/LiquidationHeatMap',
            'source_sha256':'a'*64,'received_ms':T,'observed_ms':T,'spot_asof_ms':T,
            'spot_price':100.,'metadata_verified':True,'extraction_method':'manual_frozen_zones',
            'selection_rule_id':'nearest-band-preselected-before-future',
            'zone_upper':{'low':101.,'high':102.,'intensity':None},
            'zone_lower':{'low':98.,'high':99.,'intensity':None}}


class JournalTests(unittest.TestCase):
    def setUp(self):
        self.temp_root = Path(__file__).resolve().parent / 'test_tmp'
        self.temp_root.mkdir(exist_ok=True)
        self.tmp = tempfile.TemporaryDirectory(dir=self.temp_root)
        self.j = Journal(Path(self.tmp.name)/'journal.sqlite')

    def tearDown(self):
        self.j.close()
        assert Path(self.tmp.name).resolve().is_relative_to(self.temp_root.resolve())
        self.tmp.cleanup()

    def test_initial_reference_cannot_become_prediction(self):
        path=Path(self.tmp.name)/'image.png'; path.write_bytes(b'synthetic-image-fixture')
        self.j.reference(path,now_ms=T)
        self.assertEqual(self.j.status()['reference_images'],1)
        self.assertEqual(self.j.status()['eligible_observations'],0)
        self.assertEqual(self.j.status()['forecast_status'],'not_calibrated')

    def test_frozen_time_is_annotation_admission_not_older_capture(self):
        clean=validate_observation(sample(),T+60_000)
        self.assertEqual(clean['source_received_ms'],T)
        self.assertEqual(clean['received_ms'],T+60_000)
        self.assertEqual(clean['decision_ms'],T+120_000)

    def test_future_or_stale_timestamp_rejected(self):
        for field in ('received_ms','observed_ms','spot_asof_ms'):
            value=sample();value[field]=T+1
            with self.assertRaises(ValueError):validate_observation(value,T)
        with self.assertRaises(ValueError):validate_observation(sample(),T+120_001)

    def test_symbol_model_settings_source_and_metadata_required(self):
        for field,value in [('symbol',''),('model','unknown'),('metadata_verified',False),
                            ('settings_id',''),('source_url','https://fake.invalid/map'),('source_sha256','bad')]:
            data=sample();data[field]=value
            with self.assertRaises(ValueError):validate_observation(data,T)

    def test_nested_metadata_not_allowed_in_text_fields(self):
        for name in ('selection_rule_id','intensity_unit'):
            data=sample();data[name]={'unexpected':'synthetic'}
            with self.assertRaises(ValueError):validate_observation(data,T)

    def test_credentials_never_part_of_source_url(self):
        for suffix in ('?token=synthetic','?api%5fkey=synthetic','#token=synthetic'):
            data=sample();data['source_url']+=suffix
            with self.assertRaises(ValueError):validate_observation(data,T)
        for extra in ('api_key','private_note'):
            data=sample();data[extra]='synthetic'
            with self.assertRaises(ValueError):validate_observation(data,T)

    def test_zones_and_intensity_fail_closed(self):
        for bad in [{'low':99,'high':101},{'low':102,'high':101},{'low':101,'high':102,'intensity':-1},
                    {'low':101,'high':102,'intensity':float('nan')}]:
            data=sample();data['zone_upper']=bad
            with self.assertRaises(ValueError):validate_observation(data,T)

    def test_no_snapshot_rewrite_and_idempotent_exact_store(self):
        data=validate_observation(sample(),T)
        self.j.store(data,'same');self.j.store(data,'same')
        self.assertEqual(self.j.status()['eligible_observations'],1)
        changed=copy.deepcopy(data);changed['spot_price']=100.1
        with self.assertRaises(ValueError):self.j.store(changed,'same')
        with self.assertRaises(sqlite3.IntegrityError):
            self.j.db.execute("UPDATE snapshots SET kind='reference' WHERE id='same'")
        with self.assertRaises(sqlite3.IntegrityError):self.j.db.execute('DELETE FROM snapshots')

    def test_duplicate_offgrid_bad_ohlc_rejected(self):
        good={'ts':T,'open':100,'high':101,'low':99,'close':100}
        for rows in [[good,good],[dict(good,ts=T+1)],[dict(good,high=99)]]:
            with self.assertRaises(ValueError):validate_bars(rows)

    def test_atomic_import_rejects_revision_and_preserves_history(self):
        a={'ts':T,'open':100,'high':101,'low':99,'close':100}
        self.assertEqual(self.j.import_bars('synthetic','BTCUSDT',[a],T+MINUTE),1)
        self.assertEqual(self.j.import_bars('synthetic','BTCUSDT',[a],T+MINUTE),0)
        b=dict(a,ts=T-MINUTE)
        revision=dict(a,close=100.5)
        with self.assertRaises(ValueError):self.j.import_bars('synthetic','BTCUSDT',[b,revision],T+MINUTE)
        self.assertEqual(self.j.status()['price_bars'],1)

    def test_forming_future_candles_rejected(self):
        a={'ts':T,'open':100,'high':101,'low':99,'close':100}
        with self.assertRaises(ValueError):self.j.import_bars('synthetic','BTCUSDT',[a],T+MINUTE-1)

    def test_evaluation_filters_already_imported_future_rows(self):
        self.j.observation(sample(),T)
        rows=[{'ts':T+(i+1)*MINUTE,'open':100,'high':100.1,'low':99.9,'close':100} for i in range(300)]
        self.j.import_bars('synthetic','BTCUSDT',rows,T+301*MINUTE)
        early=self.j.evaluate(T+MINUTE)[0]
        self.assertFalse(early['horizons']['240']['complete'])
        self.assertEqual(early['horizons']['240']['observation_status'],'PENDING')
        later=self.j.evaluate(T+301*MINUTE)[0]
        self.assertTrue(later['horizons']['240']['complete'])
        self.assertEqual(later['horizons']['240']['status'],'NO_HIT')

    def test_empty_price_input_matures_from_pending_to_censored(self):
        self.j.observation(sample(),T)
        pending=self.j.evaluate(T)[0]
        censored=self.j.evaluate(T+301*MINUTE)[0]
        self.assertEqual(pending['price_sha256'],censored['price_sha256'])
        self.assertNotEqual(pending['input_sha256'],censored['input_sha256'])
        self.assertEqual(pending['horizons']['240']['observation_status'],'PENDING')
        self.assertEqual(censored['horizons']['240']['observation_status'],'CENSORED')

    def test_evaluation_is_idempotent_and_conflict_fails(self):
        from unittest.mock import patch
        self.j.observation(sample(),T)
        original=self.j.evaluate(T)[0]
        second=self.j.evaluate(T+1)[0]
        self.assertEqual(original['evaluated_ms'],second['evaluated_ms'])
        changed=copy.deepcopy(original)
        changed.pop('evaluated_ms',None);changed.pop('data_asof_ms',None)
        changed['synthetic_conflicting']=True
        with patch('labels.label_snapshot',return_value=changed):
            with self.assertRaises(ValueError):self.j.evaluate(T)


if __name__=='__main__':unittest.main()
