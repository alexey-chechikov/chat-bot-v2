"""Synthetic specification tests. These contain no real market assertions."""

import copy
import math
import unittest

from labels import MINUTE_MS, LabelValidationError, label_snapshot


def snapshot(**changes):
    value = {"snapshot_id": "synthetic-1", "eligible": True, "received_ms": 0,
             "spot_price": 100.0, "zone_upper": {"low": 101.0, "high": 101.5},
             "zone_lower": {"low": 98.5, "high": 99.0}}
    value.update(changes)
    return value


def bars(minutes=310):
    return [{"ts": (i + 1) * MINUTE_MS, "o": 100.0, "h": 100.1,
             "l": 99.9, "c": 100.0} for i in range(minutes)]


class LabelTests(unittest.TestCase):
    def test_reference_does_not_validate_or_label_bad_prices(self):
        result = label_snapshot(snapshot(eligible=False), [{"bad": True}])
        self.assertEqual(result["status"], "REFERENCE_ONLY")
        self.assertEqual(result["horizons"], {})
        self.assertEqual(result["forecast_status"], "not_calibrated")

    def test_reference_kind_overrides_true_eligibility(self):
        self.assertFalse(label_snapshot(snapshot(record_kind="reference"), bars())["eligible"])

    def test_missing_eligibility_never_defaults_to_live(self):
        value = snapshot()
        del value["eligible"]
        self.assertEqual(label_snapshot(value, [])["status"], "REFERENCE_ONLY")

    def test_strict_next_minute_and_no_future_mutation(self):
        value, prices = snapshot(received_ms=MINUTE_MS), bars()
        originals = copy.deepcopy((value, prices))
        result = label_snapshot(value, prices)
        self.assertEqual(result["decision_ms"], 2 * MINUTE_MS)
        self.assertEqual((value, prices), originals)

    def test_no_hit_complete(self):
        result = label_snapshot(snapshot(), bars())
        self.assertEqual(result["horizons"]["240"]["status"], "NO_HIT")
        self.assertEqual(result["horizons"]["60"]["movement"]["return_fraction"], 0)

    def test_upper_touch_not_lookahead_lower_touch(self):
        prices = bars()
        prices[2].update(h=101.2)
        prices[5].update(l=98.9)
        horizon = label_snapshot(snapshot(), prices)["horizons"]["15"]
        self.assertEqual(horizon["status"], "UPPER_FIRST")
        self.assertEqual(horizon["first_hit"]["ts_ms"], 3 * MINUTE_MS)

    def test_lower_touch(self):
        prices = bars()
        prices[0].update(l=99.0)
        self.assertEqual(label_snapshot(snapshot(), prices)["horizons"]["15"]["status"], "LOWER_FIRST")

    def test_both_same_minute_ambiguous(self):
        prices = bars()
        prices[0].update(h=101.1, l=98.9, c=100.05)
        horizon = label_snapshot(snapshot(), prices)["horizons"]["15"]
        self.assertEqual(horizon["status"], "AMBIGUOUS")
        self.assertIsNone(horizon["reaction"])

    def test_missing_after_hit_preserves_known_hit_but_censors_full_path(self):
        prices = bars()
        prices[0].update(h=101.1)
        del prices[3]
        horizon = label_snapshot(snapshot(), prices)["horizons"]["15"]
        self.assertEqual(horizon["status"], "CENSORED")
        self.assertEqual(horizon["known_first_hit_outcome"], "UPPER_FIRST")
        self.assertFalse(horizon["complete"])
        self.assertIsNone(horizon["movement"]["return_fraction"])

    def test_missing_before_later_hit_does_not_establish_first(self):
        prices = bars()
        prices[4].update(h=101.2)
        del prices[0]
        horizon = label_snapshot(snapshot(), prices)["horizons"]["15"]
        self.assertEqual(horizon["status"], "CENSORED")
        self.assertIsNone(horizon["first_hit"])

    def test_end_censor_never_uses_last_available_close(self):
        horizon = label_snapshot(snapshot(), bars(14))["horizons"]["15"]
        self.assertEqual(horizon["status"], "CENSORED")
        self.assertIsNone(horizon["movement"]["return_fraction"])
        self.assertEqual(horizon["missing_minutes"], 1)

    def test_gap_over_flag_does_not_claim_inside_zone_fill(self):
        prices = bars()
        prices[0].update(o=102.0, h=102.2, l=101.9, c=102.0)
        hit = label_snapshot(snapshot(), prices)["horizons"]["15"]["first_hit"]
        self.assertTrue(hit["gap_over"])
        self.assertEqual(hit["side"], "UPPER")

    def test_hit_candle_close_can_confirm_rejection_causally(self):
        prices = bars()
        prices[0].update(h=101.2, c=100.1)
        reaction = label_snapshot(snapshot(), prices)["horizons"]["15"]["reaction"]
        self.assertEqual(reaction["known_first_confirmation"]["type"], "REJECTION")
        self.assertEqual(reaction["known_first_confirmation"]["confirmed_at_ms"], 2 * MINUTE_MS)

    def test_break_close_continuation_ignores_wick_only(self):
        prices = bars()
        prices[0].update(o=101.1, h=101.8, l=101.0, c=101.4)
        prices[1].update(o=101.4, h=101.8, l=101.3, c=101.7)
        reaction = label_snapshot(snapshot(), prices)["horizons"]["15"]["reaction"]
        self.assertEqual(reaction["status"], "CONTINUATION")
        self.assertEqual(reaction["known_first_confirmation"]["candle_ts_ms"], 2 * MINUTE_MS)

    def test_reaction_gap_preserves_pre_gap_confirmation(self):
        prices = bars()
        prices[0].update(h=101.2)
        del prices[20]
        reaction = label_snapshot(snapshot(), prices)["horizons"]["15"]["reaction"]
        self.assertEqual(reaction["status"], "CENSORED")
        self.assertEqual(reaction["known_first_confirmation"]["type"], "REJECTION")

    def test_reaction_gap_before_confirmation_does_not_search_later(self):
        prices = bars()
        prices[0].update(o=101.2, h=101.3, l=101.1, c=101.2)
        prices[2].update(o=101.5, h=101.8, l=101.4, c=101.7)
        del prices[1]
        reaction = label_snapshot(snapshot(), prices)["horizons"]["15"]["reaction"]
        self.assertEqual(reaction["status"], "CENSORED")
        self.assertIsNone(reaction["known_first_confirmation"])

    def test_hit_minute_extrema_excluded_from_forward_movement(self):
        prices = bars()
        prices[0].update(h=101.2, l=99.1)
        forward = label_snapshot(snapshot(), prices)["horizons"]["15"]["reaction"]["forward_movement"]
        self.assertAlmostEqual(forward["mfe_fraction"], 0.001)
        self.assertAlmostEqual(forward["mae_fraction"], -0.001)
        self.assertEqual(forward["start_ms"], 2 * MINUTE_MS)

    def test_one_sided_separate_marker(self):
        prices = bars()
        prices[0].update(h=101.1)
        horizon = label_snapshot(snapshot(zone_lower=None), prices)["horizons"]["15"]
        self.assertTrue(horizon["one_sided"])
        self.assertEqual(horizon["status"], "UPPER_FIRST")

    def test_long_ohlc_names(self):
        prices = [{"ts": row["ts"], "open": row["o"], "high": row["h"],
                   "low": row["l"], "close": row["c"]} for row in bars()]
        self.assertEqual(label_snapshot(snapshot(), prices)["horizons"]["15"]["status"], "NO_HIT")

    def test_invalid_series_and_snapshot_never_become_zero_prices(self):
        invalid_series = [
            [{"ts": MINUTE_MS, "o": 100, "h": 101, "l": 99}],
            [{"ts": MINUTE_MS, "o": 100, "h": 101, "l": 102, "c": 100}],
            [{"ts": MINUTE_MS, "o": 100, "h": math.nan, "l": 99, "c": 100}],
            [bars()[0], bars()[0]],
            [bars()[1], bars()[0]],
            [{"ts": MINUTE_MS + 1, "o": 100, "h": 101, "l": 99, "c": 100}],
            [{"ts": MINUTE_MS, "o": 0, "h": 101, "l": 0, "c": 100}],
            [{"ts": MINUTE_MS, "o": 100, "open": 101, "h": 102, "l": 99, "c": 100}],
        ]
        for prices in invalid_series:
            with self.subTest(prices=prices):
                with self.assertRaises(LabelValidationError):
                    label_snapshot(snapshot(), prices)
        for changes in (dict(spot_price=0), dict(received_ms=-1),
                        dict(zone_upper={"low": 99, "high": 102}),
                        dict(zone_lower={"low": 99, "high": 101}),
                        dict(zone_upper={"low": 101, "high": 101})):
            with self.subTest(changes=changes):
                with self.assertRaises(LabelValidationError):
                    label_snapshot(snapshot(**changes), bars())

    def test_horizon_exact_wallclock_boundary(self):
        prices = bars()
        prices[15].update(h=101.2)
        result = label_snapshot(snapshot(), prices)
        self.assertEqual(result["horizons"]["15"]["status"], "NO_HIT")
        self.assertEqual(result["horizons"]["60"]["status"], "UPPER_FIRST")

    def test_mirror_reaction_downside(self):
        prices = bars()
        prices[0].update(o=98.8, h=98.9, l=98.6, c=98.8)
        prices[1].update(o=98.6, h=98.7, l=98.1, c=98.2)
        reaction = label_snapshot(snapshot(), prices)["horizons"]["15"]["reaction"]
        self.assertEqual(reaction["known_first_confirmation"]["type"], "CONTINUATION")
        self.assertAlmostEqual(reaction["continuation_level"], 98.35)

    def test_no_calibrated_probability_or_trade_profit(self):
        result = label_snapshot(snapshot(), bars())
        self.assertEqual(result["forecast_status"], "not_calibrated")
        self.assertNotIn("probability", result)
        self.assertNotIn("pnl", result)


if __name__ == "__main__":
    unittest.main()
