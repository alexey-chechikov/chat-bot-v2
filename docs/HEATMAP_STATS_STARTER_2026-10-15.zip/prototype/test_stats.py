import copy
import unittest
from stats import summarize,MINUTE,SLOT


def record(ident,t,status='NO_HIT',final=True,complete=True,series='one'):
    return {'snapshot_id':ident,'received_ms':t,'series_key':series,'symbol':'SYNTHETIC',
            'model':'model1','settings_id':'fixture','price_source':'synthetic',
            'frozen_zone_upper':{'low':101,'high':102},'frozen_zone_lower':{'low':98,'high':99},
            'horizons':{h:{'observation_status':status,'status':status,'final':final,'complete':complete,
                            'reaction':None} for h in ('15','60','240')}}


class StatsTests(unittest.TestCase):
    def test_selection_is_before_outcome_and_no_pick_later_complete(self):
        rows=[record('early',SLOT,'PENDING',False,False),record('later',SLOT+MINUTE,'UPPER_FIRST')]
        primary=summarize(rows)['series'][0]['cohorts']['primary_fixed_UTC6h']
        self.assertEqual(primary['n_snapshots'],1)
        self.assertEqual(primary['horizons']['240']['counts'],{'PENDING':1})

    def test_no_hit_and_ambiguous_remain_in_denominator(self):
        rows=[record('u',SLOT,'UPPER_FIRST'),record('n',SLOT*2),record('a',SLOT*3,'AMBIGUOUS')]
        r=summarize(rows)['series'][0]['cohorts']['primary_fixed_UTC6h']['horizons']['240']
        self.assertEqual(r['complete_denominator'],3)
        self.assertEqual(r['historical_fractions_not_forecasts']['UPPER_FIRST'],1/3)

    def test_different_series_and_one_sided_never_mix(self):
        a=record('a',SLOT);b=record('b',SLOT,series='two');c=record('c',SLOT+MINUTE)
        c['frozen_zone_lower']=None
        self.assertEqual(len(summarize([a,b,c])['series']),3)

    def test_duplicate_derivatives_not_double_counted(self):
        a=record('a',SLOT)
        with self.assertRaises(ValueError):summarize([a,copy.deepcopy(a)])


if __name__=='__main__':unittest.main()
