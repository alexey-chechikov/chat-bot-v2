# CoinGlass raw collector prototype

This is an isolated stdlib prototype for the requested data collection, ready for a future API request once the exact chart and access entitlement are available. It is not connected to any bot, account, daemon, task scheduler, strategy, or forecast model. Development tests use offline fakes; no provider request is needed. The user's request already authorizes this collection; the remaining prerequisites are source identification and provider access, not a second confirmation.

Prerequisites before a real run: identify the exact chart/model and scope, verify supported exchange/pair, verify the account has authorized Professional/Enterprise API access and local-storage rights. Prime website access does not establish API entitlement. Read `../official_sources.md` for verified documentation and limits. No key should be sent through chat or committed to Git.

From this directory, run offline tests:

```powershell
python -m unittest -v test_collect_coinglass.py
```

Future one-shot command, after the prerequisites are satisfied and `COINGLASS_API_KEY` is already available in the execution environment:

```powershell
python collect_coinglass.py --mode collect-once --model model1 --scope pair --exchange Binance --symbol BTCUSDT --range 24h --output-dir C:\bot7\runtime\coinglass_private
```

The current user-linked page shows Model1/Binance/BTCUSDT/24h, recorded in `../source_config_confirmed.json`; however the user has WEBSITE ONLY access, so this API example is inactive. No new API subscription is requested. UI threshold0.85 is not a documented API parameter and its exact numerical filter is not assumed. Aggregated scope requires a coin such as BTC and forbids `--exchange`, because no exchange-selection query is documented for aggregated heatmaps.

Each call sends one official GET, with no retries or paging and no automatic recurrence. Redirects are rejected, so the authentication header cannot be forwarded to another host by a provider redirect. A maximum byte cap and timeout limit bound each response. HTTP429 is recorded and stops. The program does not calculate or assert account quota. The key is read only from `COINGLASS_API_KEY` in `main()` and is used only in the request authentication header. Authentication headers and exception messages are not persisted. A provider response echoing the literal key is redacted; stored/raw-body hashes differ explicitly in that case.

Records are uniquely named, opened with exclusive-create semantics, flushed and fsynced. Success-shape records go into `snapshots/`; all HTTP/transport/schema/body-cap failures go into `errors/`. Raw captured response bytes are base64 encoded inside each envelope, with SHA-256, completeness status, request metadata, UTC send/receive times and monotonic latency. There is no overwrite/update method. Error records are evidence of collection failure and never imply zero liquidation concentration.

The validator checks response code, required arrays, finite positive sorted price axis, strict UTC-seconds candles and valid OHLCV, sparse integer indexes and bounds, nonnegative finite intensity, and duplicate-point ambiguity. It intentionally labels even valid structures `shape_valid_raw_only`. Missing sparse points do not have a confirmed meaning; the prototype does not fill them with zero or extract a normalized final profile. Intensities do not have a confirmed USD unit. Future chart candles may be incomplete and old matrix values may revise.

This captures a response as received now. It does not provide point-in-time historical heatmap reconstruction. No `as_of`, `start_time`, or `end_time` is added to requests. Its own receive timestamp proves receipt only, not vendor first-publication time. Keep different models/ranges/scopes as separate series. Price-history outcome collection, closed-candle alignment, validity checks and causal labels are separate work.

Keep every real raw record local and excluded from public repositories/backups unless the provider licence permits those destinations. Only code and own aggregate research results are intended for publication. The collector cannot establish distribution/storage licence rights.
