"""One explicitly requested CoinGlass GET; preserve raw current-response evidence.

No import-time network, credentials, scheduling, normalization, or trading.
Stdlib only. Run offline tests before enabling a future authorized API request.
"""

from __future__ import annotations

import argparse
import base64
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import HTTPRedirectHandler, Request, build_opener
import uuid


BASE_URL = "https://open-api-v4.coinglass.com"
RANGES = ("12h", "24h", "3d", "7d", "30d", "90d", "180d", "1y")
MAX_CAP_BYTES = 64 * 1024 * 1024


class RejectRedirects(HTTPRedirectHandler):
    """Prevent an authenticated request from forwarding its key on any redirect."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


@dataclass(frozen=True)
class Config:
    model: str
    scope: str
    symbol: str
    range: str
    exchange: str | None = None
    timeout_seconds: float = 20.0
    max_bytes: int = 8 * 1024 * 1024

    def __post_init__(self) -> None:
        if self.model not in ("model1", "model2", "model3"):
            raise ValueError("unsupported model")
        if self.scope not in ("pair", "aggregated") or self.range not in RANGES:
            raise ValueError("unsupported scope or range")
        if not re.fullmatch(r"[A-Z0-9_-]{1,40}", self.symbol):
            raise ValueError("symbol must be an explicit supported market identifier")
        if self.scope == "pair":
            if not self.exchange or not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", self.exchange):
                raise ValueError("pair scope requires an explicit supported exchange")
        elif self.exchange is not None:
            raise ValueError("aggregated heatmap does not document exchange selection")
        if not math.isfinite(self.timeout_seconds) or not 0 < self.timeout_seconds <= 120:
            raise ValueError("timeout must be between 0 and 120 seconds")
        if type(self.max_bytes) is not int or not 0 < self.max_bytes <= MAX_CAP_BYTES:
            raise ValueError("max_bytes must be between 1 and 64 MiB")

    @property
    def endpoint(self) -> str:
        family = "heatmap" if self.scope == "pair" else "aggregated-heatmap"
        return f"/api/futures/liquidation/{family}/{self.model}"

    @property
    def params(self) -> dict[str, str]:
        result = {"symbol": self.symbol, "range": self.range}
        if self.exchange is not None:
            result["exchange"] = self.exchange
        return result


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def _number(value: Any) -> float:
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        raise ValueError("expected numeric value")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("nonfinite numeric value")
    return result


def validate_shape(body: bytes) -> dict[str, Any]:
    """Validate structure, never infer sparse zeros, dollars, or historical as-of."""
    try:
        obj = json.loads(body)
    except (ValueError, UnicodeError):
        return {"state": "invalid_json", "usable_as_profile": False}
    if not isinstance(obj, dict) or obj.get("code") != "0":
        return {"state": "provider_error_or_unknown_status", "usable_as_profile": False}
    data = obj.get("data")
    if not isinstance(data, dict):
        return {"state": "invalid_data_object", "usable_as_profile": False}
    levels, candles, points = (data.get(k) for k in (
        "y_axis", "price_candlesticks", "liquidation_leverage_data"))
    if not isinstance(levels, list) or not levels or not isinstance(candles, list) or not candles or not isinstance(points, list):
        return {"state": "missing_matrix_arrays", "usable_as_profile": False}
    try:
        y = [_number(x) for x in levels]
        if any(x <= 0 for x in y) or any(a >= b for a, b in zip(y, y[1:])):
            raise ValueError("invalid price axis")
        timestamps: list[int] = []
        for row in candles:
            if not isinstance(row, list) or len(row) != 6:
                raise ValueError("invalid candle shape")
            ts = row[0]
            # UTC epoch seconds in the crypto era, not milliseconds or an index.
            if type(ts) is not int or not 1230768000 <= ts < 4133980800:
                raise ValueError("invalid timestamp seconds")
            o, h, l, c, v = [_number(x) for x in row[1:]]
            if min(o, h, l, c) <= 0 or v < 0 or l > min(o, c) or h < max(o, c) or l > h:
                raise ValueError("invalid OHLCV")
            timestamps.append(ts)
        if any(a >= b for a, b in zip(timestamps, timestamps[1:])):
            raise ValueError("non-monotonic candle time")
        seen: set[tuple[int, int]] = set()
        for row in points:
            if not isinstance(row, list) or len(row) != 3:
                raise ValueError("invalid point shape")
            x, yi, intensity = row
            if type(x) is not int or type(yi) is not int or not 0 <= x < len(candles) or not 0 <= yi < len(y):
                raise ValueError("point index out of bounds")
            if _number(intensity) < 0 or (x, yi) in seen:
                raise ValueError("negative or duplicate point")
            seen.add((x, yi))
    except (ValueError, TypeError, OverflowError):
        return {"state": "invalid_matrix_structure", "usable_as_profile": False}
    return {
        "state": "shape_valid_raw_only", "usable_as_profile": False,
        "n_price_levels": len(y), "n_candles": len(candles), "n_sparse_points": len(points),
        "sparse_missing_cell_semantics": "unknown", "intensity_unit": "unconfirmed",
        "historical_point_in_time_guarantee": False,
    }


def _read_capped(response: Any, cap: int) -> tuple[bytes, bool]:
    body = response.read(cap + 1)
    if not isinstance(body, bytes):
        raise TypeError("response did not return bytes")
    return body[:cap], len(body) <= cap


def collect_once(
    config: Config, api_key: str, output_dir: Path, *,
    opener: Callable[..., Any] | None = None,
    now: Callable[[], str] = utc_now,
    monotonic: Callable[[], float] = time.monotonic,
) -> Path:
    """No retries; save one response or one failure with no authentication values."""
    if not isinstance(api_key, str) or not api_key or any(c in api_key for c in "\r\n"):
        raise ValueError("valid API credential required; do not put it in arguments or files")
    sent_at, started = now(), monotonic()
    envelope: dict[str, Any] = {
        "schema": "coinglass_raw_current_snapshot_v1",
        "request": {"method": "GET", "base_url": BASE_URL, "endpoint": config.endpoint,
                    "params": config.params, "model": config.model, "scope": config.scope},
        "request_sent_at_utc": sent_at, "http_status": None,
        "outcome": "unknown", "raw_body_complete": False,
        "historical_point_in_time_guarantee": False,
    }
    request = Request(f"{BASE_URL}{config.endpoint}?{urlencode(config.params)}",
                      headers={"CG-API-KEY": api_key, "Accept": "application/json"})
    if opener is None:
        opener = build_opener(RejectRedirects()).open
    body = b""
    try:
        with opener(request, timeout=config.timeout_seconds) as response:
            envelope["http_status"] = response.status
            body, complete = _read_capped(response, config.max_bytes)
        envelope["raw_body_complete"] = complete
        if not complete:
            envelope["outcome"] = "body_limit_exceeded"
        elif envelope["http_status"] != 200:
            envelope["outcome"] = "http_error"
        else:
            envelope["validation"] = validate_shape(body)
            envelope["outcome"] = ("captured_raw_only" if envelope["validation"]["state"] == "shape_valid_raw_only"
                                   else "schema_or_provider_error")
    except HTTPError as exc:
        envelope["http_status"] = exc.code
        envelope["outcome"] = "rate_limited" if exc.code == 429 else "http_error"
        try:
            body, complete = _read_capped(exc, config.max_bytes)
            envelope["raw_body_complete"] = complete
        except Exception:
            envelope["body_read_error"] = True
        finally:
            exc.close()
    except (TimeoutError, URLError):
        envelope["outcome"] = "transport_or_timeout_error"
    except Exception:
        # No exception messages/repr: a library or fake could include credentials.
        envelope["outcome"] = "response_read_error"
    envelope["received_at_utc"] = now()
    envelope["monotonic_latency_seconds"] = max(0.0, monotonic() - started)
    envelope["captured_body_sha256"] = hashlib.sha256(body).hexdigest()
    envelope["captured_body_bytes"] = len(body)
    if api_key.encode("utf-8") in body:
        body = body.replace(api_key.encode("utf-8"), b"[REDACTED_AUTH]")
        envelope["body_redacted"] = True
        envelope["outcome"] = "authentication_echo_redacted"
    else:
        envelope["body_redacted"] = False
    envelope["stored_body_sha256"] = hashlib.sha256(body).hexdigest()
    envelope["body_base64"] = base64.b64encode(body).decode("ascii")
    category = "snapshots" if envelope["outcome"] == "captured_raw_only" else "errors"
    folder = Path(output_dir) / category
    folder.mkdir(parents=True, exist_ok=True)
    # Unique immutable records. Exclusive create rejects any accidental collision.
    path = folder / f"snapshot_{uuid.uuid4().hex}.json"
    payload = json.dumps(envelope, ensure_ascii=False, allow_nan=False, indent=2).encode("utf-8")
    with path.open("xb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("collect-once",), required=True)
    parser.add_argument("--model", choices=("model1", "model2", "model3"), required=True)
    parser.add_argument("--scope", choices=("pair", "aggregated"), required=True)
    parser.add_argument("--exchange")
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--range", choices=RANGES, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--timeout-seconds", type=float, default=20.0)
    parser.add_argument("--max-bytes", type=int, default=8 * 1024 * 1024)
    args = parser.parse_args()
    try:
        config = Config(args.model, args.scope, args.symbol, args.range, args.exchange,
                        args.timeout_seconds, args.max_bytes)
        key = os.environ.get("COINGLASS_API_KEY")
        if not key:
            parser.error("COINGLASS_API_KEY is unavailable; no request sent")
        path = collect_once(config, key, args.output_dir)
    except ValueError as exc:
        parser.error(str(exc))
    record = json.loads(path.read_text(encoding="utf-8"))
    print(json.dumps({"record": str(path), "outcome": record["outcome"], "http_status": record["http_status"]}))
    return 0 if record["outcome"] == "captured_raw_only" else 2


if __name__ == "__main__":
    raise SystemExit(main())
