# Что можно использовать для журнала карты ликвидаций — аудит 15.10.2026

Проверка только чтением исходников и рыночных CSV, без импорта production-модулей, без HTTP/WebSocket, без чтения `.env`, торгового state, счёта и ключей. Не запускались боты и не менялась конфигурация. Найденных `AGENTS.md` в корне C:\bot7 и при поиске в рабочем дереве нет.

## Версии

Публичный источник: `e1fe76a50c226872de6831edaa23c2ef3f30f466` в `alexey-chechikov/chat-bot-v2`, `alexey/mac-2026-05-29`. Последняя уже локально доступная публикация — `dce860dc67c227d31be5b217847f8467b1190e68`; проверенные core/collector-файлы между этими коммитами не изменились. Нового network fetch не делал.

`core/coinglass_client.py`, `core/liquidation_map.py`, `core/liquidation_reaction_engine.py`, `core/liquidation_character.py`, `core/exchange_liquidity_engine.py`, `services/analysis_service.py` совпадают с локальными после нормализации переносов. **Локальный `market_collector/liquidations.py` старее публичного**: в публичной версии уже есть исправление стороны Bybit, heartbeat и сырой журнал. Поэтому наличие кода в репозитории не доказывает, что текущий локальный процесс исполняет эту версию. Деплой не проверялся.

## Три различных объекта данных

1. **CoinGlass estimated liquidation heatmap.** В `core/coinglass_client.py:111` предусмотрен платный API и запрос model1 Binance, затем fallback aggregate heatmap. Клиент оставляет только ближайшие две цены/силы и остальные краткие OI/funding-показатели. Он не сохраняет матрицу, время получения, окно карты, настройки модели, raw payload или последовательность снимков. Нет журналирования карты на диск. Используются имена переменных `COINGLASS_API_KEY`, `COINGLASS_BASE_URL`, `COINGLASS_TIMEOUT_SEC`, `COINGLASS_CACHE_TTL_SEC`; присутствие и значения ключа не проверялись. Права тарифа неизвестны. HTTP200 с телом ошибки не проверяется как application-level failure, поэтому `ok=True` может быть без полезной карты.

2. **Прошедшие liquidation events.** `core/exchange_liquidity_engine.py` хранит последние 180 минут/500 событий Binance и Bybit в одном изменяемом state. `_aggregate_events:253` группирует цены уже случившихся принудительных закрытий. Это не уровни будущих оценочных ликвидаций. Однако `:576` выставляет `heatmap_ready=True`. В `services/analysis_service.py:344–350` этот источник имеет приоритет; CoinGlass запрашивается лишь при `exchange_ctx.ok=False`. Даже наличие только OI делает `ok=True` и может вообще не допустить запроса карты. Для исследуемой карты нельзя переиспользовать эту метку как свидетельство CoinGlass.

3. **Публичный архив фактических ликвидаций.** `market_collector/liquidations.py` пишет BTC/ETH/XRP CSV и в публичном коде от 13.10 дополнительно daily JSONL `market_live/liq_raw/{exchange}_{YYYYMMDD}.jsonl`. Raw: `recv_ms`, `exchange_ts_ms`, `side_liquidated`, `symbol`, `qty`, `qty_unit`, `price`, `price_basis`, OKX ctVal/spec и исходное сообщение. Это полезная уже выполненная часть прежнего ТЗ. CSV по-прежнему имеет только `ts_utc,exchange,side,qty,price`, где время — приём с секундной точностью. Старые CSV не могут восстановить задержку, исходную схему и первоначальное время события.

В проверенных локальных CSV есть записи Bybit/OKX, **нет записей Binance**. BTC около 9,6 тыс., ETH 4,3 тыс., XRP 1,7 тыс.; диапазон первых/последних строк май–14.10. Это живые изменяемые файлы и грубая инвентаризация на момент чтения, **не свидетельство непрерывной работы за пять месяцев**. Плотность и интервалы отказа отдельно не проверены. Raw JSONL в локальном `market_live` поиском не найдены.

## Что нельзя выдавать за статистику рынка

- `core/liquidation_character.py:30–31` прибавляет константы к входной confidence. Это не частотная оценка: при искусственном входе `POST_LIQUIDATION_EXHAUSTION`, confidence=80 функция даёт continuation=78 и exhaustion=30, сумма 108%. Для двух конкурирующих исходов это не распределение вероятностей; в любом случае значения не калиброваны на журнале событий.
- `core/liquidation_map.py:50–53` маркирует `*_SWEEP_REJECTED` по единственной текущей цене, расстоянию и силе. В функции нет истории прохождения/возврата и времени существования уровня. Искусственный current=100, upper=100.1 уже даёт `BUY_SIDE_SWEEP_REJECTED` без какого-либо предыдущего выноса.
- `core/liquidation_reaction_engine.py` использует пять текущих свечей, однако не фиксирует, когда уровни стали известны. `reaction_strength` 66/70 плюс бонус объёма — тоже ручной score. `core/liquidity_block_engine.py` строит блоки из price range (ширина 34%), а не из матрицы CoinGlass. Это не автоматически совпадает с яркими линиями приложенной карты.
- `_aggregate_events` называет strongest кластер `nearest`: искусственные верхние уровни 101 с объёмом 1 и 105 с объёмом 100 выбирают «nearest» 105. Поле стороны события в группировке не используется; замена всех SELL на BUY оставляет результат прежним. Метку `liq_side_pressure` нельзя считать измеренной стороной ещё открытых позиций.
- `get_exchange_liquidity_context(symbol=...)` читает один глобальный state `SYMBOL`, но возвращает переданный symbol. В данных/фильтрах нет независимого состояния для аргумента. До reuse нужен отказ на несовпадение символов, иначе BTC-события можно представить как ETH-контекст.
- `_find_heatmap_levels` рекурсивно ищет словари price/value. Матрица с индексами времени/цены и величиной не разбирается. Синтетическая такая матрица дала `{}`. Это демонстрация ограниченности parser, **не проверка конкретного доступного API payload**. Нужны versioned fixtures по официальной схеме и source-aware adapter.

## Качество потоков и тестов

Публичная версия market_collector уже отдельно сохраняет bankruptcy/order price_basis, время биржи и приёма. Сторона Bybit allLiquidation в ней `S=Buy→long`, `S=Sell→short`; старый локальный модуль инвертирует её. Нельзя объединить обе истории без cutoff/version/сырого сообщения. Binance `q,p` в CSV не являются автоматически исполненным объёмом/средней ценой; raw оставляет `ap` для следующего нормализатора. Дубли, отсутствие event ID, disconnect coverage и sampling нужно учитывать при анализе сумм.

Есть отдельный `collectors/liquidations/` с Parquet-потоком. Его локальный Bybit `_parse` читает legacy `symbol/side/size/price/updateTime` при подписке на allLiquidation, а не `s/S/v/p/T` текущего payload. Поэтому эта реализация также требует schema fixture перед reuse. Нельзя считать все три pipeline эквивалентными.

`tests/market_collector/test_liquidations_parsing.py` в основном проверяет отдельные выражения и наличие функций, а не конечный parsing реального сообщения. Публичный `tests/services/weex_book/test_liq_raw.py` проверяет helper raw_record, units/time и failure path, но также вручную повторяет формулу стороны. Тесты статически прочитаны; полный pytest здесь не запускался. Пять безопасных AST-проверок выполнены без production imports; сохранены в `reuse_probes.py` и `reuse_probe_results.json`.

## Минимальное reuse-ТЗ

1. Отдельный immutable журнал **оценочной карты**, не подмена потоками исполненных ликвидаций. Сохранить source/vendor, symbol, venue scope, model/version, window, source timestamp, recv timestamp, валюту/единицу силы, price grid, raw/hash, covered-through/as-of и status. API permission/API error != пустая карта. Screenshot с неизвестными параметрами — отдельный ручной источник с uncertain metadata.
2. Снимки/выбор уровней записываются до будущего движения. Подход/касание/вынос/возврат/закрепление считаются по замороженным уровням и ценам того же символа с чёткими horizon/tolerance. Новые снимки не перезаписывают прошлый прогноз.
3. Фактические ликвидации из public raw stream — независимые поясняющие features и подтверждения. Сверять direction semantics, price_basis/qty_unit, source coverage, timestamp lag, dedup и разрывы. Расчёт карты не восстанавливается из CSV ликвидаций.
4. Отчёт сначала даёт counts/base rates/calibrated CI и сравнение с distance/trend-only controls. При отсутствии созревших событий вывод `недостаточно наблюдений`, без 70–80% heuristic confidence. Учитывать отсутствие касания и цензурирование, а не только красивые отработавшие линии.
5. Публичный экспорт — только protocol/code/synthetic fixtures/aggregate market outcomes. Не включать `.env`, state, raw account events/балансы, user transcript, полный путь пользователя или скриншот с персональными данными. Внутреннее локальное имя может храниться, публичный manifest — безопасное логическое имя и hash.

Это позволяет начать честный журнал наблюдений уже сейчас. Автоматическое получение самой CoinGlass-карты ещё требует проверки доступного тарифа/schema и разрешённого API; существующий код не доказывает работающий сбор этой карты.
