# CoinGlass: проверенные официальные источники для журнала heatmap

Проверено 15.10.2026. Только публичные документы CoinGlass; запросов с ключом, чтения секретов, покупки доступа и сбора закрытых данных не было. Ни наличие подписки у пользователя, ни соответствие скриншота конкретной модели не установлены.

## Что означает карта

CoinGlass описывает heatmap как расчёт потенциальных цен ликвидации на основе рыночных данных и структуры плеча. Жёлтый цвет означает большую модельную концентрацию, фиолетовый — меньшую. Это оценка, а не вероятностный прогноз направления. Из яркости нельзя получить вероятность «цена дойдёт с шансом 70%». [Официальное объяснение Prime, FAQ 6](https://www.coinglass.com/prime).

У CoinGlass отдельно существуют liquidation heatmap и orderbook heatmap. Первая не является наблюдаемым стаканом лимитных заявок. Фактические liquidation history/order также являются отдельными API. [Список endpoints](https://docs.coinglass.com/reference/endpoint-overview).

Точные формулы и различия Model1/Model2/Model3 не раскрыты на прочитанных страницах API. Не приписывать моделям выдуманные свойства «агрессивная/консервативная/все плечи». В документации третья компонента точки называется liquidation leverage, а в локализованной версии — интенсивностью. Подтверждения, что её можно безусловно трактовать как исполненный USD-объём, нет.

## Шесть heatmap endpoints v4

Base URL: `https://open-api-v4.coinglass.com`. Метод GET. Авторизация — заголовок `CG-API-KEY`. На каждой из шести страниц heatmap указаны Professional и Enterprise, а Hobbyist/Startup/Standard недоступны. Обновление заявлено real time, точная периодичность в секундах не обещана.

| Источник | Endpoint | Обязательные query params | Документация |
|---|---|---|---|
| Пара, Model1 | `/api/futures/liquidation/heatmap/model1` | `exchange`, `symbol`, `range` | [Model1](https://docs.coinglass.com/reference/liquidation-heatmap) |
| Пара, Model2 | `/api/futures/liquidation/heatmap/model2` | `exchange`, `symbol`, `range` | [Model2](https://docs.coinglass.com/reference/liquidation-heatmap-model2) |
| Пара, Model3 | `/api/futures/liquidation/heatmap/model3` | `exchange`, `symbol`, `range` | [Model3](https://docs.coinglass.com/reference/liquidation-heatmap-model3) |
| Монета агрегированно, Model1 | `/api/futures/liquidation/aggregated-heatmap/model1` | `symbol`, `range` | [Model1](https://docs.coinglass.com/reference/liquidation-aggregate-heatmap) |
| Монета агрегированно, Model2 | `/api/futures/liquidation/aggregated-heatmap/model2` | `symbol`, `range` | [Model2](https://docs.coinglass.com/reference/liquidation-aggregate-heatmap-model2) |
| Монета агрегированно, Model3 | `/api/futures/liquidation/aggregated-heatmap/model3` | `symbol`, `range` | [Model3](https://docs.coinglass.com/reference/liquidation-aggregated-heatmap-model3) |

Пара: пример `exchange=Binance`, `symbol=BTCUSDT`. Агрегированно: `symbol=BTC`, параметра `exchange_list` на этих heatmap страницах нет. Биржи и пары необходимо проверять через supported-exchange-pairs; нельзя считать, что WEEX обязательно включён.

У всех heatmap страниц документирован `range`: `12h`, `24h`, `3d`, `7d`, `30d`, `90d`, `180d`, `1y`; по умолчанию `3d`. `start_time`, `end_time`, `as_of`, `interval` и версия расчётной модели не документированы. Наличие длинного range не доказывает предоставление исторических снимков в том виде, в котором они были известны в прошлом.

## Общая heatmap схема ответа

Документирован объект с `code="0"`, `msg="success"`, `data`:

| Поле | Смысл из документации |
|---|---|
| `y_axis` | Массив ценовых уровней |
| `liquidation_leverage_data` | Разреженные тройки `[x_index, y_index, intensity]` |
| `price_candlesticks` | Массив `[timestamp_seconds, open, high, low, close, trading_volume_USD]` |

Цены OHLC в примере — строки. Время свечей — секунды, не миллисекунды. Индексы нужны для адресации сетки, а не являются временем/ценой напрямую. Сохранять исходный ответ до нормализации и проверять границы индексов, finite/nonnegative intensity и строгую временную монотонность. Пример не обещает, что последний столбец закрыт, что пропущенная точка равна нулю или что временное разрешение одинаково для разных range. Эти свойства следует проверять при реальном доступе.

## Цена и глубина доступа

На [API pricing](https://www.coinglass.com/pricing) Professional отображается как **$699/мес**, 1200 запросов/мин и коммерческое использование; Enterprise — договорные цена, лимиты, granularity/history и bulk export. Это проверенное состояние страницы, а не рекомендация покупать.

Общая таблица Professional history: 1m — 12 дней; 3m — 40; 5m — 60; 15m — 180; 30m — 360; 1h/2h/4h — 720; дневная — all time. **Не переносить автоматически эту общую таблицу на heatmap:** у heatmap собственный интерфейс range без запроса произвольной даты.

На [Prime](https://www.coinglass.com/prime) указаны $28/мес, модели 1/2/3 и auto refresh. В FAQ речь о веб-функциях, FAQ 3 даже говорит web only. Страница не утверждает, что Prime даёт ключ Professional API. Видимые долгие периоды Prime 24 months+ и документированный API range максимум 1y — разные продукты/интерфейсы, не противоречие, которое можно решить предположением.

## Отдельные фактические liquidation данные для контроля

| Endpoint | Что документировано | Ограничения |
|---|---|---|
| `/api/futures/liquidation/history` | Время ms, long/short liquidation USD для пары; `exchange,symbol,interval,start_time,end_time,limit` | limit максимум 1000; интервалы 1m..1w; Hobbyist минимум 4h, Startup минимум 30m, Standard+ без interval limit. [Документация](https://docs.coinglass.com/reference/liquidation-history) |
| `/api/futures/liquidation/aggregated-history` | Агрегированный long/short USD; `exchange_list,symbol,interval,start_time,end_time,limit` | те же limit/interval ограничения. [Документация](https://docs.coinglass.com/reference/aggregated-liquidation-history) |
| `/api/futures/liquidation/order` | События: exchange, symbol, base_asset, price, usd_value, side, time(ms) | последние 7 дней; до 200 записей; required min_liquidation_amount; Standard+; cache/update 1s. Side1 buy,2 sell — направление сделки ликвидации, а не знак прогноза. [Документация](https://docs.coinglass.com/reference/liquidation-order) |

Полноту покрытия конкретной биржи/пары и степень агрегации ленты нужно проверять отдельно. Карта оцениваемых уровней не заменяет журнал фактически наблюдаемых ликвидаций.

## Правило причинного исследования (наша спецификация)

Сохранять снимок append-only **в момент получения**, с `request_sent_at_utc`, `received_at_utc`, endpoint/model/scope/exchange/symbol/range, полным raw JSON, SHA-256, статусом/ошибкой, ссылкой источника и подтверждённым временем доступности. На момент решения использовать только последний снимок, фактически полученный до него. Свеча и снимок должны иметь отдельные event-time и receive-time. Историческое время на оси не равно времени доступности всей матрицы.

Не пересчитывать прошлые признаки из новой текущей карты. Если в новом ответе изменилась старая часть матрицы, хранить обе версии и отчёт об изменении. Для данных, скачанных задним числом без гарантии as-of, допустима только исследовательская ретроспектива, а не честный торговый backtest. Модель, биржа/aggregation, range, resolution, sensitivity/threshold и crop/scale скриншота нельзя смешивать как один ряд.

При отсутствии API начать журнал вручную с одинаковыми настройками и зафиксированными UTC timestamp, полным скриншотом, ссылкой и невыбранными постфактум наблюдениями. У cropped-скриншота пользователя нет модели, источника и настроек: этот снимок можно зарегистрировать как иллюстрацию, но нельзя создавать из него числовую обучающую матрицу или forecast percentages.

## Разрешённый сбор и публикация

[CoinGlass Terms](https://www.coinglass.com/terms) ограничивают копирование/перепродажу/распространение данных, коммерческое использование без разрешения и bulk scraping/crawling/extraction без разрешения. Использовать официальный разрешённый доступ в пределах тарифа. Не обходить тариф через скрытые браузерные endpoints. В публичном GitHub хранить код, схему и собственные агрегированные исследовательские выводы; сырьё CoinGlass и ключи не публиковать без соответствующего права.

[Errors/rate limits](https://docs.coinglass.com/reference/responses-error-codes): 429 означает превышение лимита; заголовки `API-KEY-MAX-LIMIT` и `API-KEY-USE-LIMIT` позволяют отслеживать бюджет запросов. Ошибка/пустой/устаревший ответ не должна незаметно превращаться в нулевую ликвидность.
