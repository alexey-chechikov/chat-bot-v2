"""Synthetic market-only scenarios. No trading modules, network, or account files."""
from __future__ import annotations

import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from contextlib import redirect_stderr
from unittest.mock import patch

from preflight import HEADERS, inspect, main, maker_flag

T = 1792022400000  # 2026-10-15 00:00:00 UTC
SYM = "ETHUSDT"
DAY = "20261015"


def fixture():
    dep = [dict(kind="snapshot", U="1", u="10", E=str(T), recv_ms=str(T+10), session="s1", applied="1", b='[["100","2"]]', a='[["101","3"]]'),
           dict(kind="delta", U="10", u="11", E=str(T+1000), recv_ms=str(T+1010), session="s1", applied="1", b='[["100","1"]]', a="[]"),
           dict(kind="delta", U="11", u="12", E=str(T+2000), recv_ms=str(T+2010), session="s1", applied="1", b="[]", a='[["101","2"]]')]
    tr = [dict(t="id1", T=str(T+100), E=str(T+101), recv_ms=str(T+111), session="s1", p="101", q="0.1", m_raw="False"),
          dict(t="id2", T=str(T+1500), E=str(T+1501), recv_ms=str(T+1511), session="s1", p="100", q="0.2", m_raw="True")]
    ev = [dict(recv_ms=str(T+1), session="s1", event="connect", detail="DO_NOT_EXPORT_THIS_DETAIL"),
          dict(recv_ms=str(T+10), session="s1", event="snapshot", detail="u=10")]
    return {"depth": dep, "trades2": tr, "events": ev}


class PreflightTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="synthetic_", dir=Path(__file__).resolve().parent)
        self.directory = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write(self, data=None):
        data = fixture() if data is None else data
        for kind, rows in data.items():
            with (self.directory / f"{SYM}_{DAY}_{kind}.csv").open("w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=HEADERS[kind])
                w.writeheader()
                w.writerows(rows)

    def codes(self, report):
        return {v["code"] for v in report["issue_counts"]}

    def test_clean_manifest_and_input_immutability(self):
        self.write()
        before = {p.name: p.read_bytes() for p in self.directory.iterdir()}
        r = inspect(self.directory)
        self.assertEqual(r["status"], "pass_with_limits")
        self.assertEqual(r["symbols"][SYM]["counts"]["unique_trades"], 2)
        self.assertEqual(r["symbols"][SYM]["counts"]["documented_seller_taker"], 1)
        for entry in r["files"]:
            self.assertEqual(entry["sha256"], hashlib.sha256(before[entry["file"]]).hexdigest())
        self.assertEqual(before, {p.name: p.read_bytes() for p in self.directory.iterdir()})
        serialized = json.dumps(r)
        self.assertNotIn(str(self.directory), serialized)
        self.assertNotIn("DO_NOT_EXPORT", serialized)
        self.assertNotIn("id1", serialized)
        self.assertNotIn('"s1"', serialized)

    def test_false_is_not_truthy_string(self):
        self.assertIs(maker_flag("False"), False)
        self.assertIs(maker_flag("false"), False)
        for invalid in ("", "0", "1", "None", "FALSE", "unknown"):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                maker_flag(invalid)

    def test_unknown_maker_flag_is_invalid_not_no_trades(self):
        data = fixture()
        data["trades2"][0]["m_raw"] = ""
        self.write(data)
        r = inspect(self.directory)
        self.assertEqual(r["status"], "invalid")
        self.assertIn("invalid_row_schema_or_value", self.codes(r))

    def test_exact_duplicate_is_deduplicated_and_conflict_is_invalid(self):
        data = fixture()
        data["trades2"].append(copy.deepcopy(data["trades2"][-1]))
        self.write(data)
        r = inspect(self.directory)
        self.assertEqual(r["symbols"][SYM]["counts"]["unique_trades"], 2)
        self.assertIn("exact_duplicate_trade_id", self.codes(r))
        data["trades2"][-1]["q"] = "0.3"
        self.write(data)
        r = inspect(self.directory)
        self.assertEqual(r["status"], "invalid")
        self.assertIn("conflicting_trade_id", self.codes(r))

    def test_gap_is_incomplete_then_new_snapshot_recovers_sequence(self):
        data = fixture()
        data["depth"][1].update(U="99", u="100", applied="0")
        data["depth"][2].update(kind="snapshot", U="100", u="105", b='[["100","1"]]', a='[["101","2"]]')
        data["events"].append(dict(recv_ms=str(T+1010), session="s1", event="gap", detail="sensitive-local-detail"))
        self.write(data)
        r = inspect(self.directory)
        self.assertEqual(r["status"], "incomplete")
        self.assertNotIn("applied_sequence_disagreement", self.codes(r))
        self.assertIn("event_gap", self.codes(r))
        self.assertEqual(r["symbols"][SYM]["counts"]["snapshots"], 2)

    def test_falsely_applied_gap_is_invalid(self):
        data = fixture()
        data["depth"][1]["U"] = "99"
        data["depth"][1]["u"] = "100"
        self.write(data)
        r = inspect(self.directory)
        self.assertEqual(r["status"], "invalid")
        self.assertIn("applied_sequence_disagreement", self.codes(r))

    def test_cross_stream_equal_receive_ms_is_ambiguous(self):
        data = fixture()
        data["trades2"][0]["recv_ms"] = data["depth"][1]["recv_ms"]
        self.write(data)
        r = inspect(self.directory)
        self.assertEqual(r["status"], "incomplete")
        self.assertIn("cross_stream_receive_order_ambiguous", self.codes(r))

    def test_receive_time_reversal(self):
        data = fixture()
        data["depth"][2]["recv_ms"] = str(T+9)
        self.write(data)
        self.assertIn("receive_time_reversal", self.codes(inspect(self.directory)))

    def test_silence_and_session_disconnect_are_not_continuous_coverage(self):
        data = fixture()
        data["depth"][2].update(E=str(T+7000), recv_ms=str(T+7010))
        data["events"].append(dict(recv_ms=str(T+3000), session="s1", event="disconnect", detail=""))
        self.write(data)
        r = inspect(self.directory)
        self.assertEqual(r["status"], "incomplete")
        self.assertIn("depth_silence_staleness_intervals", self.codes(r))
        self.assertIn("event_disconnect", self.codes(r))

    def test_missing_stream_and_empty_directory(self):
        self.assertEqual(inspect(self.directory)["status"], "invalid")
        data = fixture()
        data.pop("trades2")
        self.write(data)
        r = inspect(self.directory)
        self.assertEqual(r["status"], "incomplete")
        self.assertIn("missing_or_empty_trades2", self.codes(r))

    def test_disjoint_sessions_do_not_fake_coverage(self):
        data = fixture()
        for row in data["trades2"]:
            row["session"] = "s2"
        self.write(data)
        r = inspect(self.directory)
        self.assertEqual(r["status"], "incomplete")
        self.assertIn("session_missing_stream", self.codes(r))
        self.assertEqual(r["symbols"][SYM]["counts"].get("sessions_with_positive_depth_trade_overlap", 0), 0)

    def test_nan_negative_duplicate_levels_and_crossed_book(self):
        for field, value in (("b", '[["NaN","2"]]'), ("b", '[["100","-1"]]'),
                             ("b", '[["100","2"],["100","3"]]'), ("a", '[["99","3"]]')):
            with self.subTest(value=value):
                data = fixture()
                data["depth"][0][field] = value
                self.write(data)
                self.assertEqual(inspect(self.directory)["status"], "invalid")

    def test_filename_day_and_header_mismatch(self):
        self.write()
        p = self.directory / f"{SYM}_{DAY}_depth.csv"
        p.rename(self.directory / f"{SYM}_20261014_depth.csv")
        self.assertIn("filename_utc_day_disagreement", self.codes(inspect(self.directory)))
        p = self.directory / f"{SYM}_{DAY}_trades2.csv"
        p.write_text("wrong,columns\n1,2\n", encoding="utf-8")
        self.assertIn("header_mismatch", self.codes(inspect(self.directory)))

    def test_unrelated_files_are_not_opened_or_manifested(self):
        self.write()
        (self.directory / "private_account.json").write_text("never_read", encoding="utf-8")
        (self.directory / ".env").write_text("never_read", encoding="utf-8")
        r = inspect(self.directory)
        self.assertEqual(len(r["files"]), 3)
        self.assertNotIn("private_account", json.dumps(r))

    def test_one_level_is_schema_example_not_fifteen_level_eth_gate(self):
        self.write()
        self.assertEqual(inspect(self.directory)["status"], "pass_with_limits")
        r = inspect(self.directory, stale_ms=1000, min_levels=15)
        self.assertEqual(r["status"], "incomplete")
        self.assertIn("insufficient_depth", self.codes(r))
        self.assertEqual(r["min_levels_per_side"], 15)
        self.assertEqual(r["symbols"][SYM]["counts"]["min_observed_bid_levels"], 1)
        self.assertEqual(r["symbols"][SYM]["counts"]["min_observed_ask_levels"], 1)

    def test_depth_depletion_after_applied_delta_is_incomplete(self):
        data = fixture()
        data["depth"][0].update(b='[["100","2"],["99","3"]]', a='[["101","3"],["102","4"]]')
        data["depth"][1]["b"] = '[["99","0"]]'
        self.write(data)
        r = inspect(self.directory, min_levels=2)
        self.assertEqual(r["status"], "incomplete")
        self.assertIn("insufficient_depth", self.codes(r))
        counts = r["symbols"][SYM]["counts"]
        self.assertEqual(counts["min_observed_bid_levels"], 1)
        self.assertEqual(counts["min_observed_ask_levels"], 2)
        examples = [x for x in r["issues_sample"] if x["code"] == "insufficient_depth"]
        self.assertTrue(examples)
        self.assertTrue(all(x["row"] >= 3 for x in examples))

    def test_invalid_min_levels_rejected_by_library_and_cli(self):
        self.write()
        for value in (0, -1, 1.5, True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                inspect(self.directory, min_levels=value)
        for raw in ("0", "-1", "1.5", "true"):
            with self.subTest(raw=raw), patch("sys.argv", ["preflight.py", "--data", str(self.directory), "--min-levels", raw]), redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as raised:
                main()
            self.assertEqual(raised.exception.code, 2)


if __name__ == "__main__":
    unittest.main()
