"""Read-only quality gate for WEEX recorder v2 public-market CSV exports.

Standard library only. Does not import any project/trading modules or call a network.
The input directory is never modified. Temporary indices contain timestamps and hashes.
"""
from __future__ import annotations

import argparse
import csv
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import tempfile

FILE_RE = re.compile(r"^([A-Z0-9]+)_(\d{8})_(depth|trades2|events)\.csv$")
HEADERS = {
    "depth": ["kind", "U", "u", "E", "recv_ms", "session", "applied", "b", "a"],
    "trades2": ["t", "T", "E", "recv_ms", "session", "p", "q", "m_raw"],
    "events": ["recv_ms", "session", "event", "detail"],
}
EVENTS = {"connect", "snapshot", "gap", "resync", "disconnect"}
LIMIT = 100


def integer(value: str, positive: bool = False) -> int:
    if not isinstance(value, str) or not re.fullmatch(r"\d+", value):
        raise ValueError("invalid integer")
    n = int(value)
    if positive and n <= 0:
        raise ValueError("nonpositive timestamp")
    return n


def number(value: str, *, zero_ok: bool = False) -> Decimal:
    try:
        d = Decimal(value)
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError("invalid numeric value") from None
    if not d.is_finite() or d < 0 or (not zero_ok and d == 0):
        raise ValueError("invalid numeric value")
    return d


def levels(raw: str) -> dict[Decimal, Decimal]:
    try:
        rows = json.loads(raw)
    except (ValueError, TypeError):
        raise ValueError("invalid levels JSON") from None
    if not isinstance(rows, list):
        raise ValueError("levels not list")
    result = {}
    for row in rows:
        if not isinstance(row, list) or len(row) != 2:
            raise ValueError("invalid level shape")
        p, q = number(str(row[0])), number(str(row[1]), zero_ok=True)
        if p in result:
            raise ValueError("duplicate price in update")
        result[p] = q
    return result


def maker_flag(raw: str) -> bool:
    # csv.writer serializes a JSON boolean as True/False. Lowercase JSON spellings
    # are unambiguous too. Missing values, 0/1 and arbitrary strings are NOT inferred.
    if raw in ("True", "true"):
        return True
    if raw in ("False", "false"):
        return False
    raise ValueError("unknown maker flag")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def inspect(data_dir: Path, *, stale_ms: int = 2000, min_levels: int = 1) -> dict:
    """Return metadata/quality only; no prices, trade IDs, raw details or absolute paths."""
    if stale_ms <= 0:
        raise ValueError("stale_ms must be positive")
    if type(min_levels) is not int or min_levels <= 0:
        raise ValueError("min_levels must be a positive integer")
    if not data_dir.is_dir():
        raise ValueError("input directory does not exist")
    issues, issue_counts, manifest = [], Counter(), []
    statistics = defaultdict(lambda: Counter())
    coverage = defaultdict(dict)
    books = {}
    last_recv = {}
    file_names = {m.group(1) for p in data_dir.iterdir() if (m := FILE_RE.fullmatch(p.name))}
    selected = sorted((p for p in data_dir.iterdir() if FILE_RE.fullmatch(p.name)), key=lambda p: p.name)

    def issue(code: str, filename: str = "", row: int = 0, severity: str = "error"):
        issue_counts[(severity, code)] += 1
        if len(issues) < LIMIT:
            issues.append({"severity": severity, "code": code, "file": filename, "row": row})

    def cover(sym, kind, field, value):
        key = f"{kind}.{field}"
        c = coverage[sym].setdefault(key, [value, value])
        c[0], c[1] = min(c[0], value), max(c[1], value)

    if not selected:
        issue("no_v2_files")
    # Keep disposable metadata beside this utility, never in the input directory.
    with tempfile.TemporaryDirectory(prefix="weex_preflight_", dir=Path(__file__).resolve().parent) as tmp:
        db = sqlite3.connect(str(Path(tmp) / "index.sqlite"))
        db.execute("CREATE TABLE timing(sym TEXT, session TEXT, recv INTEGER, kind TEXT)")
        db.execute("CREATE TABLE trades(sym TEXT, tid TEXT, payload TEXT, PRIMARY KEY(sym,tid))")
        for p in selected:
            match = FILE_RE.fullmatch(p.name)
            sym, day, kind = match.groups()
            statistics[sym][f"files_{kind}"] += 1
            if p.is_symlink() or not p.is_file():
                issue("non_regular_or_symlink", p.name)
                continue
            try:
                datetime.strptime(day, "%Y%m%d")
            except ValueError:
                issue("invalid_filename_day", p.name)
                continue
            initial_stat = p.stat()
            record = {"file": p.name, "bytes": initial_stat.st_size, "sha256": sha256(p),
                      "kind": kind, "symbol": sym, "rows": 0, "valid_rows": 0}
            manifest.append(record)
            try:
                with p.open("r", newline="", encoding="utf-8-sig") as f:
                    reader = csv.DictReader(f)
                    if reader.fieldnames != HEADERS[kind]:
                        issue("header_mismatch", p.name, 1)
                        continue
                    for rownum, row in enumerate(reader, 2):
                        record["rows"] += 1
                        statistics[sym][f"rows_{kind}"] += 1
                        try:
                            if None in row or any(v is None for v in row.values()):
                                raise ValueError("row shape")
                            recv = integer(row["recv_ms"], positive=True)
                            day_clock = row["T"] if kind == "trades2" else (row["E"] if kind == "depth" else row["recv_ms"])
                            if datetime.fromtimestamp(integer(day_clock, positive=True) / 1000, timezone.utc).strftime("%Y%m%d") != day:
                                issue("filename_utc_day_disagreement", p.name, rownum)
                            session = row["session"]
                            if not session or len(session) > 128:
                                raise ValueError("session")
                            session_hash = hashlib.sha256(session.encode()).hexdigest()[:16]
                            for field in ("E", "T"):
                                if field in row:
                                    val = integer(row[field], positive=True)
                                    cover(sym, kind, field, val)
                                    if recv < val:
                                        statistics[sym]["negative_receive_minus_exchange"] += 1
                            cover(sym, kind, "recv_ms", recv)
                            previous = last_recv.get((sym, kind, session_hash))
                            if previous is not None and recv < previous:
                                issue("receive_time_reversal", p.name, rownum)
                            last_recv[(sym, kind, session_hash)] = recv
                            db.execute("INSERT INTO timing VALUES(?,?,?,?)", (sym, session_hash, recv, kind))
                            if kind == "depth":
                                typ = row["kind"]
                                if typ not in ("snapshot", "delta") or row["applied"] not in ("0", "1"):
                                    raise ValueError("depth flags")
                                u = integer(row["u"])
                                U = integer(row["U"]) if row["U"] else None
                                if U is not None and u < U:
                                    raise ValueError("reversed sequence range")
                                b, a = levels(row["b"]), levels(row["a"])
                                applied = row["applied"] == "1"
                                state = books.get((sym, session_hash))
                                if typ == "snapshot":
                                    if not applied:
                                        issue("snapshot_not_applied", p.name, rownum)
                                    state = {"u": u, "b": {}, "a": {}, "ok": applied}
                                    books[(sym, session_hash)] = state
                                    statistics[sym]["snapshots"] += 1
                                else:
                                    if U is None:
                                        raise ValueError("delta lacks U")
                                    contiguous = state is not None and state["ok"] and U == state["u"]
                                    if applied != contiguous:
                                        issue("applied_sequence_disagreement", p.name, rownum)
                                    if not applied:
                                        statistics[sym]["unapplied_depth"] += 1
                                        issue("unapplied_depth_interval", p.name, rownum, "incomplete")
                                        if state:
                                            state["ok"] = False
                                if applied:
                                    if state is None:
                                        issue("applied_without_snapshot", p.name, rownum)
                                    else:
                                        for side, updates in (("b", b), ("a", a)):
                                            for price, qty in updates.items():
                                                if qty:
                                                    state[side][price] = qty
                                                else:
                                                    state[side].pop(price, None)
                                        state["u"] = u
                                        for side, label in (("b", "bid"), ("a", "ask")):
                                            count = len(state[side])
                                            key = f"min_observed_{label}_levels"
                                            if key not in statistics[sym] or count < statistics[sym][key]:
                                                statistics[sym][key] = count
                                        if len(state["b"]) < min_levels or len(state["a"]) < min_levels:
                                            issue("insufficient_depth", p.name, rownum, "incomplete")
                                        if not state["b"] or not state["a"]:
                                            issue("empty_reconstructed_side", p.name, rownum)
                                        elif max(state["b"]) >= min(state["a"]):
                                            issue("crossed_reconstructed_book", p.name, rownum)
                                        statistics[sym]["applied_depth"] += 1
                            elif kind == "trades2":
                                tid = row["t"]
                                if not tid or tid in ("None", "null") or len(tid) > 256:
                                    raise ValueError("trade id")
                                price, qty = number(row["p"]), number(row["q"])
                                flag = maker_flag(row["m_raw"])
                                # Source mapping is documented in recorder.py; no independent
                                # external validation or own execution evidence is claimed.
                                payload = json.dumps([row["T"], str(price.normalize()), str(qty.normalize()), flag])
                                digest = hashlib.sha256(payload.encode()).hexdigest()
                                tid_hash = hashlib.sha256(tid.encode()).hexdigest()
                                prior = db.execute("SELECT payload FROM trades WHERE sym=? AND tid=?", (sym, tid_hash)).fetchone()
                                if prior:
                                    statistics[sym]["duplicate_trade_ids"] += 1
                                    if prior[0] != digest:
                                        issue("conflicting_trade_id", p.name, rownum)
                                    else:
                                        issue("exact_duplicate_trade_id", p.name, rownum, "warning")
                                else:
                                    db.execute("INSERT INTO trades VALUES(?,?,?)", (sym, tid_hash, digest))
                                    statistics[sym]["unique_trades"] += 1
                                    statistics[sym]["documented_seller_taker" if flag else "documented_buyer_taker"] += 1
                            else:
                                event = row["event"]
                                if event not in EVENTS:
                                    raise ValueError("unknown event")
                                statistics[sym][f"event_{event}"] += 1
                                if event in ("gap", "resync", "disconnect"):
                                    issue(f"event_{event}", p.name, rownum, "incomplete")
                            record["valid_rows"] += 1
                        except (ValueError, TypeError, OverflowError, InvalidOperation):
                            issue("invalid_row_schema_or_value", p.name, rownum)
            except (OSError, UnicodeError, csv.Error):
                issue("unreadable_or_invalid_csv", p.name)
            final_stat = p.stat()
            if (initial_stat.st_size, initial_stat.st_mtime_ns) != (final_stat.st_size, final_stat.st_mtime_ns):
                issue("input_changed_during_scan", p.name, severity="incomplete")
        db.commit()
        db.execute("CREATE INDEX timing_idx ON timing(sym,session,recv)")
        for sym in sorted(file_names):
            stats = statistics[sym]
            for kind in HEADERS:
                if not stats[f"files_{kind}"] or not stats[f"rows_{kind}"]:
                    issue(f"missing_or_empty_{kind}", severity="incomplete")
            ambiguous = db.execute("SELECT COUNT(*) FROM (SELECT recv FROM timing WHERE sym=? AND kind IN ('depth','trades2') GROUP BY session,recv HAVING COUNT(DISTINCT kind)>1)", (sym,)).fetchone()[0]
            stats["cross_stream_receive_tie_groups"] = ambiguous
            if ambiguous:
                issue("cross_stream_receive_order_ambiguous", severity="incomplete")
            stats["sessions"] = db.execute("SELECT COUNT(DISTINCT session) FROM timing WHERE sym=?", (sym,)).fetchone()[0]
            for session, kinds in db.execute("SELECT session,GROUP_CONCAT(DISTINCT kind) FROM timing WHERE sym=? GROUP BY session", (sym,)):
                if set(kinds.split(",")) != set(HEADERS):
                    issue("session_missing_stream", severity="incomplete")
                bounds = dict((k, (lo, hi)) for k, lo, hi in db.execute("SELECT kind,MIN(recv),MAX(recv) FROM timing WHERE sym=? AND session=? AND kind IN ('depth','trades2') GROUP BY kind", (sym, session)))
                if len(bounds) == 2:
                    overlap = min(v[1] for v in bounds.values()) - max(v[0] for v in bounds.values())
                    if overlap <= 0:
                        issue("session_no_positive_depth_trade_overlap", severity="incomplete")
                    else:
                        stats["sessions_with_positive_depth_trade_overlap"] += 1
            # Receive-time silence is a diagnostic, not proof of exchange packet loss.
            last = {}
            for session, recv in db.execute("SELECT session,recv FROM timing WHERE sym=? AND kind='depth' ORDER BY session,recv", (sym,)):
                if session in last and recv - last[session] > stale_ms:
                    stats["depth_silences_above_threshold"] += 1
                    stats["max_depth_silence_ms"] = max(stats["max_depth_silence_ms"], recv - last[session])
                last[session] = recv
            if stats["depth_silences_above_threshold"]:
                issue("depth_silence_staleness_intervals", severity="incomplete")
            ranges = [coverage[sym].get(f"{k}.recv_ms") for k in ("depth", "trades2")]
            if all(ranges):
                overlap = min(r[1] for r in ranges) - max(r[0] for r in ranges)
                stats["depth_trade_receive_overlap_ms"] = max(0, overlap)
                if overlap <= 0:
                    issue("no_positive_depth_trade_coverage_overlap", severity="incomplete")
        db.close()
    errors = sum(v for (severity, _), v in issue_counts.items() if severity == "error")
    incomplete = sum(v for (severity, _), v in issue_counts.items() if severity == "incomplete")
    return {
        "schema": "weex_market_preflight_v1", "source_format": "WEEX recorder v2 at public b91f292",
        "scope": "public_market_csv_quality_only",
        "status": "invalid" if errors else ("incomplete" if incomplete else "pass_with_limits"),
        "stale_threshold_ms": stale_ms,
        "min_levels_per_side": min_levels,
        "files": manifest,
        "symbols": {s: {"counts": dict(sorted(statistics[s].items())),
                        "coverage_ms_utc_epoch": dict(sorted(coverage[s].items()))} for s in sorted(file_names)},
        "issue_counts": [{"severity": sev, "code": code, "count": count}
                         for (sev, code), count in sorted(issue_counts.items())],
        "issues_sample": issues, "issue_sample_limit": LIMIT,
        "direction_semantics": {"mapping": "m_raw true => seller taker; false => buyer taker",
                                "basis": "documented by public recorder.py and its tests",
                                "independently_crosschecked_against_exchange_or_own_fills": False},
        "limitations": [
            "No exchange/account/order API is called; no fills or profitability are simulated.",
            "recv_ms is wall clock; global receive_seq and monotonic receive time are absent in v2.",
            "A depth silence is not proof of packet loss; timestamp differences are not measured order latency.",
            "Coverage endpoints do not establish continuous complete coverage; explicit gaps and silences are reported.",
            "No public trade feed completeness guarantee or exact FIFO queue is established.",
            "pass_with_limits permits bounded model research only; it does not authorize live trading.",
        ],
    }


def main() -> int:
    def positive_int(raw: str) -> int:
        try:
            return integer(raw, positive=True)
        except ValueError:
            raise argparse.ArgumentTypeError("must be a positive integer") from None

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, type=Path, help="Explicit frozen public-market CSV directory")
    parser.add_argument("--out", type=Path, help="JSON report; defaults to stdout, never modifies inputs")
    parser.add_argument("--stale-ms", type=int, default=2000)
    parser.add_argument("--min-levels", type=positive_int, default=1,
                        help="Required reconstructed positive-quantity levels on each side; ETH gate requires 15")
    args = parser.parse_args()
    try:
        result = inspect(args.data, stale_ms=args.stale_ms, min_levels=args.min_levels)
    except (ValueError, OSError, sqlite3.Error):
        result = {"schema": "weex_market_preflight_v1", "status": "invalid", "error": "invalid_or_unreadable_input_directory_or_options"}
    content = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.out:
        # Refuse to overwrite one of the recorder inputs, including via resolution.
        target = args.out.resolve()
        if target.parent == args.data.resolve() and FILE_RE.fullmatch(target.name):
            raise SystemExit("Refusing to overwrite recorder input")
        args.out.write_text(content, encoding="utf-8")
    else:
        print(content, end="")
    return 0 if result["status"] == "pass_with_limits" else (2 if result["status"] == "incomplete" else 1)


if __name__ == "__main__":
    raise SystemExit(main())
