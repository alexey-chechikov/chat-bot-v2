# Execution focus research bundle — 2026-10-15

Python 3.12+, standard library only. Extract preserving the three neighbouring
directories `execution_focus_20261015`, `expectancy_20261006`, and
`liquidation_heatmap_20261015`.

This bundle contains own analysis, one **simulated** public-market ETH trade
ledger, offline schema checks with artificial fixtures, and a public closed-price
refresh helper. It contains no WEEX market recording, real account executions,
CoinGlass images/matrices, local journal DB, credentials, or copied video transcript.

Reproduce the ETH diagnostic from the extraction root:

```text
python execution_focus_20261015/eth_diagnostic.py
```

The script reads only the included simulated CSV and writes its two generated
outputs beside itself. It does not change the CSV. These old market-entry
trajectories do not establish post-only fills or WEEX returns.

Test the limited v2 market-export preflight:

```text
python -m unittest discover -s execution_focus_20261015/maker_preflight -p test_preflight.py
python execution_focus_20261015/maker_preflight/preflight.py --data execution_focus_20261015/maker_preflight/synthetic_example --out synthetic_preflight_reproduced.json
```

The synthetic example has one level per side. For an actual separate export used
by the ETH protocol, add **`--stale-ms 1000 --min-levels 15`**. The example should
fail that stricter depth gate; a format check is not a complete replay admission.
Never pass an account/state directory: pass only the explicitly exported public
depth/trades2/events files. See the included README and protocol for output status,
incomplete intervals and remaining queue-model limitations.

For the optional closed-Binance-price refresh helper, run its synthetic tests:

```text
python -m unittest discover -s liquidation_heatmap_20261015 -p test_refresh_public_bars.py
```

The helper requires an **existing explicitly supplied** manual-pilot journal and
an explicit output directory. Its public GET mode updates price bars and evaluations;
it does not take CoinGlass snapshots or create observations. The journal and
first real pilot observation are intentionally not bundled. See `--help`.

Detailed specifications and evidence are inside `execution_focus_20261015/`:

- `video_M6_audit.md`: own analysis of the newly read first webinar, with timestamps.
- `M15_SR1_FROZEN_SPEC_2026-10-15.md`: unchanged earlier hypothesis; not calculated.
- `ETH_EXECUTION_FROZEN_PROTOCOL_2026-10-15.md`: one frozen prospective execution test.
- `maker_preflight/protocol.md`: exact market-data handoff and paper-replay requirements.

All source files in the archive have SHA256 entries in `MANIFEST.json`.
Passing tests demonstrates mechanics on artificial inputs. Market profitability
and a calibrated map forecast remain separate uncompleted research questions.
