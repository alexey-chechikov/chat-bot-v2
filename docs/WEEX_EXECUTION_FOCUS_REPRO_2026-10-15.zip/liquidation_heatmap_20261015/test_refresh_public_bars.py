"""Synthetic offline tests. No HTTP, CoinGlass images, live journal or account data."""
from __future__ import annotations

import contextlib
import copy
import hashlib
import io
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

import refresh_public_bars as helper
from journal import Journal, MINUTE

T = 1_800_000_000_000


def sample():
    return {"symbol": helper.SYMBOL, "price_source": helper.SOURCE, "provider": "coinglass", "model": "model1",
            "map_range": "24h", "scope": "pair", "settings_id": "synthetic-manualpilot-v1", "exchanges": ["Binance"],
            "source_url": "https://www.coinglass.com/pro/futures/LiquidationHeatMap", "source_sha256": "a" * 64,
            "received_ms": T, "observed_ms": T, "spot_asof_ms": T, "spot_price": 100.,
            "metadata_verified": True, "extraction_method": "manual_frozen_zones",
            "selection_rule_id": "synthetic-preselected-bands", "zone_upper": {"low": 101., "high": 102.},
            "zone_lower": {"low": 98., "high": 99.}}


def kline(ts, close="100"):
    return [ts, "100", "100", "100", close, "10", ts + MINUTE - 1, "1000", 10, "5", "500", "0"]


class FakePublic:
    def __init__(self, now, transform=None):
        self.now, self.transform, self.calls = now, transform, []

    def __call__(self, path, params):
        self.calls.append((path, copy.deepcopy(params)))
        if path == "/fapi/v1/time":
            return {"serverTime": self.now}
        assert path == "/fapi/v1/klines"
        assert params["symbol"] == "BTCUSDT" and params["interval"] == "1m" and params["limit"] == 1000
        rows = [kline(t) for t in range(params["startTime"], params["endTime"] + 1, MINUTE)][:1000]
        return self.transform(rows, params, len(self.calls)) if self.transform else rows


class RefreshTests(unittest.TestCase):
    def setUp(self):
        self.temp_root = Path(__file__).resolve().parent / "test_refresh_tmp"
        self.temp_root.mkdir(exist_ok=True)
        self.tmp = tempfile.TemporaryDirectory(dir=self.temp_root)
        self.base = Path(self.tmp.name)
        self.db, self.out = self.base / "journal.sqlite", self.base / "output"
        journal = Journal(self.db)
        self.ident = journal.observation(sample(), now_ms=T, snapshot_id="synthetic-first")
        journal.close()

    def tearDown(self):
        assert self.base.resolve().is_relative_to(self.temp_root.resolve())
        self.tmp.cleanup()

    def query(self, sql):
        with contextlib.closing(sqlite3.connect(self.db)) as db:
            return db.execute(sql).fetchall()

    def run_refresh(self, now, fake=None, local=None):
        api = fake or FakePublic(now)
        return helper.refresh(self.db, self.out, get_json=api, clock_ms=lambda: now if local is None else local)

    def test_closed_window_maturity_and_idempotence_preserve_snapshot(self):
        before = self.query("SELECT id,sha256,payload FROM snapshots")
        now = T + 301 * MINUTE
        first = self.run_refresh(now)
        second = self.run_refresh(now)
        self.assertEqual(first["inserted_bars"], 300)
        self.assertEqual(second["inserted_bars"], 0)
        self.assertFalse(second["has_missing_minutes"])
        self.assertEqual(self.query("SELECT count(*) FROM bars")[0][0], 300)
        self.assertEqual(self.query("SELECT count(*) FROM evaluations")[0][0], 1)
        self.assertEqual(before, self.query("SELECT id,sha256,payload FROM snapshots"))
        self.assertEqual(second["evaluations"][0]["horizons"]["240"]["observation_status"], "NO_HIT")
        self.assertTrue(second["observation_coverage"][0]["fully_mature_by_clock"])
        self.assertEqual(second["forecast_status"], "not_calibrated")
        payload = (self.out / "fresh_closed_1m.csv").read_bytes()
        self.assertEqual(hashlib.sha256(payload).hexdigest(), second["closed_csv_sha256"])
        self.assertEqual(json.loads((self.out / "refresh_result.json").read_text())["status"], "ok")
        self.assertFalse(list(self.out.glob(".refresh-*.tmp")))

    def test_pagination_bounded_to_two_1000_bar_pages(self):
        now = T + 24 * 60 * MINUTE
        journal = Journal(self.db)
        newer = sample()
        newer.update(received_ms=now - 2 * MINUTE, observed_ms=now - 2 * MINUTE, spot_asof_ms=now - 2 * MINUTE)
        journal.observation(newer, now_ms=now - 2 * MINUTE, snapshot_id="synthetic-latest")
        journal.close()
        api = FakePublic(now)
        result = self.run_refresh(now, api)
        self.assertEqual(result["fetched_closed_rows"], 1439)
        self.assertEqual(result["kline_requests"], 2)
        self.assertEqual(result["total_http_requests"], 3)
        self.assertEqual(len(api.calls), 3)
        self.assertEqual(api.calls[2][1]["startTime"], T + 1001 * MINUTE)
        self.assertLessEqual(result["request_end_exclusive_ms"] - result["request_start_ms"], helper.LOOKBACK_MS)

    def test_forming_candle_from_provider_is_excluded(self):
        now = T + 16 * MINUTE + 30_000
        def extra(rows, params, call):
            return rows + [kline(T + 16 * MINUTE)]
        result = self.run_refresh(now, FakePublic(now, extra))
        self.assertEqual(result["fetched_closed_rows"], 15)
        self.assertEqual(result["forming_rows_excluded"], 1)
        self.assertEqual(self.query("SELECT max(ts) FROM bars")[0][0], T + 15 * MINUTE)
        self.assertEqual(result["evaluations"][0]["horizons"]["240"]["observation_status"], "PENDING")

    def test_clock_skew_uses_the_earlier_clock_both_directions(self):
        for server, local in ((T + 20 * MINUTE, T + 16 * MINUTE), (T + 16 * MINUTE, T + 20 * MINUTE)):
            result = self.run_refresh(server, local=local)
            self.assertEqual(result["cutoff_ms"], T + 16 * MINUTE)
            self.assertEqual(result["fetched_closed_rows"], 15)
            self.assertEqual(result["observation_coverage"][0]["closed_minutes_expected_so_far"], 15)

    def test_only_exact_observation_series_no_reference_payload_reads(self):
        journal = Journal(self.db)
        other = sample(); other["price_source"] = "different-synthetic-source"
        journal.observation(other, now_ms=T, snapshot_id="other-source")
        other = sample(); other["symbol"] = "ETHUSDT"
        journal.observation(other, now_ms=T, snapshot_id="other-symbol")
        # Invalid JSON on a reference proves the helper/evaluator does not even parse references.
        with journal.db:
            journal.db.execute("INSERT INTO snapshots VALUES(?,?,?,?,?)", ("reference-unread", T, "reference", "b"*64, "invalid-reference-json"))
        journal.close()
        result = self.run_refresh(T + 16 * MINUTE)
        self.assertEqual(result["observations_in_scope"], 1)
        self.assertEqual([r["snapshot_id"] for r in result["evaluations"]], [self.ident])
        self.assertEqual(self.query("SELECT DISTINCT source,symbol FROM bars"), [(helper.SOURCE, helper.SYMBOL)])
        self.assertEqual(self.query("SELECT DISTINCT snapshot_id FROM evaluations"), [(self.ident,)])

    def test_future_decision_is_deferred_without_kline_request(self):
        api = FakePublic(T + 30_000)
        result = self.run_refresh(T + 30_000, api)
        self.assertEqual(result["observations_in_scope"], 0)
        self.assertEqual(result["observations_deferred_by_clock"], 1)
        self.assertEqual(result["total_http_requests"], 1)
        self.assertEqual(result["evaluations"], [])

    def test_older_than_24h_missing_history_is_reported_not_backfilled(self):
        api = FakePublic(T + 2 * helper.LOOKBACK_MS)
        result = self.run_refresh(api.now, api)
        self.assertEqual(len(api.calls), 1)
        self.assertTrue(result["has_missing_minutes"])
        cov = result["observation_coverage"][0]
        self.assertTrue(cov["lookback_truncated"])
        self.assertEqual(cov["missing_minutes_so_far"], 300)
        self.assertEqual(result["evaluations"][0]["horizons"]["240"]["observation_status"], "CENSORED")

    def test_gap_is_explicit_not_forward_filled(self):
        now = T + 16 * MINUTE
        def gap(rows, params, call):
            return [row for row in rows if row[0] != T + 8 * MINUTE]
        result = self.run_refresh(now, FakePublic(now, gap))
        self.assertTrue(result["has_missing_minutes"])
        self.assertEqual(result["observation_coverage"][0]["missing_minute_starts_ms"], [T + 8 * MINUTE])
        self.assertEqual(result["evaluations"][0]["horizons"]["15"]["observation_status"], "CENSORED")

    def test_api_error_or_bad_time_never_imports_bars(self):
        for bad_reply in ({"code": -1003, "msg": "rate limited"}, {"serverTime": True}, {"serverTime": 123}, []):
            with self.subTest(reply=bad_reply):
                with self.assertRaises(helper.RefreshError):
                    self.run_refresh(T + 16 * MINUTE, lambda path, params: bad_reply)
                self.assertEqual(self.query("SELECT count(*) FROM bars")[0][0], 0)
                self.assertEqual(json.loads((self.out / "refresh_result.json").read_text())["status"], "error")

    def test_schema_ohlc_duplicate_and_unbounded_future_are_rejected_before_import(self):
        now = T + 16 * MINUTE
        def short(rows, params, call): return [rows[0][:-1]]
        def invalid_ohlc(rows, params, call):
            rows[0][2] = "99"; return rows
        def duplicate(rows, params, call): return [rows[0], rows[0]]
        def nonfinite(rows, params, call):
            rows[0][4] = "NaN"; return rows
        def wrong_close(rows, params, call):
            rows[0][6] += 1; return rows
        def far_future(rows, params, call): return rows + [kline(now + 100 * MINUTE)]
        for transform in (short, invalid_ohlc, duplicate, nonfinite, wrong_close, far_future):
            with self.subTest(transform=transform.__name__):
                with self.assertRaises(ValueError):
                    self.run_refresh(now, FakePublic(now, transform))
                self.assertEqual(self.query("SELECT count(*) FROM bars")[0][0], 0)

    def test_immutable_revision_rolls_back_new_rows_from_same_import(self):
        journal = Journal(self.db)
        original = {"ts": T + 2 * MINUTE, "open": 100., "high": 100., "low": 100., "close": 100.}
        journal.import_bars(helper.SOURCE, helper.SYMBOL, [original], now_ms=T + 3 * MINUTE)
        journal.close()
        before = self.query("SELECT ts,payload,sha256 FROM bars")
        def revised(rows, params, call):
            rows[1][2] = "101"; rows[1][4] = "101"; return rows
        with self.assertRaisesRegex(ValueError, "revision conflict"):
            self.run_refresh(T + 16 * MINUTE, FakePublic(T + 16 * MINUTE, revised))
        self.assertEqual(before, self.query("SELECT ts,payload,sha256 FROM bars"))
        self.assertFalse((self.out / "fresh_closed_1m.csv").exists())

    def test_second_page_network_failure_has_no_partial_import(self):
        now = T + helper.LOOKBACK_MS
        journal = Journal(self.db)
        other = sample(); other.update(received_ms=now - 2 * MINUTE, observed_ms=now - 2 * MINUTE, spot_asof_ms=now - 2 * MINUTE)
        journal.observation(other, now_ms=now - 2 * MINUTE, snapshot_id="latest")
        journal.close()
        api = FakePublic(now)
        def broken(path, params):
            if path == "/fapi/v1/klines" and params["startTime"] > T + MINUTE:
                raise OSError("synthetic public network failure")
            return api(path, params)
        with self.assertRaises(OSError): self.run_refresh(now, broken)
        self.assertEqual(self.query("SELECT count(*) FROM bars")[0][0], 0)

    def test_pagination_does_not_exceed_request_cap_when_provider_underfills(self):
        now = T + 301 * MINUTE
        api = FakePublic(now, lambda rows, params, call: rows[:1])
        result = self.run_refresh(now, api)
        self.assertEqual(len(api.calls), 3)
        self.assertTrue(result["pagination_cap_reached"])
        self.assertTrue(result["has_missing_minutes"])
        self.assertEqual(result["fetched_closed_rows"], 2)

    def test_missing_db_and_required_cli_options_fail_without_creating_database(self):
        missing = self.base / "not-existing.sqlite"
        with self.assertRaises(FileNotFoundError):
            helper.refresh(missing, self.out, get_json=lambda *a: self.fail("unexpected HTTP"))
        self.assertFalse(missing.exists())
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit): helper.main([])

    def test_non_allowlisted_http_path_is_rejected_without_network(self):
        with self.assertRaises(helper.RefreshError): helper.public_get_json("/fapi/v1/order")


if __name__ == "__main__":
    unittest.main()
