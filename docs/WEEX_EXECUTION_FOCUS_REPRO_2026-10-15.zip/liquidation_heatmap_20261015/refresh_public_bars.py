"""One-shot public closed-BTC-minute refresh for already frozen manual heatmap observations.

No credentials, bot/order clients, scheduler or observation creation. At most one public
time GET and two public kline GETs per invocation; only an explicitly selected existing
journal and output directory can be written. Run offline tests before actual use.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import time
from urllib.parse import urlencode
from urllib.request import HTTPRedirectHandler, Request, build_opener

ROOT = Path(__file__).resolve().parent
if str(ROOT / "prototype") not in sys.path:
    sys.path.insert(0, str(ROOT / "prototype"))
from journal import Journal, MINUTE, validate_bars
from stats import summarize

SYMBOL = "BTCUSDT"
SOURCE = "binance-usdm-rest-closed1m-manualpilot-v1"
BASE = "https://fapi.binance.com"
LOOKBACK_MS = 24 * 60 * MINUTE
MATURITY_MS = (240 + 60) * MINUTE
PAGE_LIMIT = 1000
MAX_KLINE_REQUESTS = 2
MAX_RESPONSE_BYTES = 2_000_000


class RefreshError(ValueError):
    pass


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RefreshError("public endpoint redirect rejected")


def public_get_json(path: str, params: dict | None = None):
    """Exactly two allowlisted public GET paths; no user URL or auth headers."""
    if path not in ("/fapi/v1/time", "/fapi/v1/klines"):
        raise RefreshError("non-allowlisted public endpoint")
    url = BASE + path + ("?" + urlencode(params) if params else "")
    request = Request(url, headers={"User-Agent": "heatmap-manual-pilot-closed-bars-v1"}, method="GET")
    with build_opener(NoRedirect()).open(request, timeout=15) as response:
        if response.status != 200:
            raise RefreshError("non-200 public endpoint response")
        raw = response.read(MAX_RESPONSE_BYTES + 1)
    if len(raw) > MAX_RESPONSE_BYTES:
        raise RefreshError("public endpoint response exceeds byte cap")
    return json.loads(raw, parse_constant=lambda _: (_ for _ in ()).throw(RefreshError("non-finite JSON constant")))


def epoch_ms(value, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1_000_000_000_000:
        raise RefreshError(f"{field}: UTC epoch millisecond integer required")
    return value


def number(value, field: str, *, positive: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        raise RefreshError(f"{field}: numeric value required")
    try:
        result = float(value)
    except (ValueError, OverflowError) as exc:
        raise RefreshError(f"{field}: invalid numeric value") from exc
    if not math.isfinite(result) or (result <= 0 if positive else result < 0):
        raise RefreshError(f"{field}: invalid finite value")
    return result


def atomic_text(path: Path, text: str) -> None:
    """Only replace a named output artifact after writing/flushing its complete bytes."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="", dir=path.parent,
                                         prefix=".refresh-", suffix=".tmp", delete=False) as handle:
            temp = Path(handle.name)
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        if temp is not None and temp.exists():
            temp.unlink()


class ManualPilotJournal(Journal):
    """Scope Journal.evaluate to observation rows and this exact public price series.

    Reading reference payloads (including local image paths) is unnecessary. This
    override also prevents evaluate() from writing results for unrelated series.
    """
    def snapshots(self):
        selected = []
        for ident, payload in self.db.execute(
            "SELECT id,payload FROM snapshots WHERE kind='observation' ORDER BY received_ms,id"
        ):
            item = json.loads(payload)
            if (item.get("kind") == "observation" and item.get("eligible") is True
                    and item.get("symbol") == SYMBOL and item.get("price_source") == SOURCE
                    and (getattr(self, "allowed_ids", None) is None or ident in self.allowed_ids)):
                selected.append((ident, item))
        return selected


def fetch_bars(start_ms: int, end_ms: int, cutoff_ms: int, get_json) -> tuple[list[dict], dict]:
    """[start,end) aligned minute window; every returned candle must already be closed."""
    if start_ms % MINUTE or end_ms % MINUTE or end_ms < start_ms:
        raise RefreshError("invalid aligned request window")
    if end_ms - start_ms > LOOKBACK_MS:
        raise RefreshError("requested lookback exceeds 24h")
    collected, cursor, previous = [], start_ms, None
    audit = {"kline_requests": 0, "forming_rows_excluded": 0, "request_window_complete": True}
    while cursor < end_ms and audit["kline_requests"] < MAX_KLINE_REQUESTS:
        page = get_json("/fapi/v1/klines", {"symbol": SYMBOL, "interval": "1m", "startTime": cursor,
                                            "endTime": end_ms - 1, "limit": PAGE_LIMIT})
        audit["kline_requests"] += 1
        if not isinstance(page, list) or len(page) > PAGE_LIMIT:
            raise RefreshError("klines must be an array containing at most 1000 rows")
        if not page:
            break
        last_open = None
        for raw in page:
            if not isinstance(raw, list) or len(raw) != 12:
                raise RefreshError("kline schema must have exactly 12 fields")
            ts = epoch_ms(raw[0], "kline open time")
            close_ms = epoch_ms(raw[6], "kline close time")
            if ts % MINUTE or close_ms != ts + MINUTE - 1:
                raise RefreshError("kline is not an exact one-minute interval")
            if ts < cursor or previous is not None and ts <= previous:
                raise RefreshError("duplicate, out-of-order or out-of-window kline")
            # A provider unexpectedly including an in-flight candle must not import it.
            if ts >= end_ms and not (ts == end_ms == cutoff_ms // MINUTE * MINUTE
                                     and ts + MINUTE > cutoff_ms):
                raise RefreshError("kline exceeds requested endTime beyond the current forming candle")
            prices = {key: number(raw[index], key, positive=True) for key, index in
                      (("open", 1), ("high", 2), ("low", 3), ("close", 4))}
            for index in (5, 7, 9, 10):
                number(raw[index], f"kline field {index}")
            if isinstance(raw[8], bool) or not isinstance(raw[8], int) or raw[8] < 0:
                raise RefreshError("kline trade count must be a nonnegative integer")
            item = validate_bars([{"ts": ts, **prices}])[0]
            if close_ms + 1 > cutoff_ms:
                audit["forming_rows_excluded"] += 1
            elif ts < end_ms:
                collected.append(item)
            previous = last_open = ts
        assert last_open is not None
        cursor = last_open + MINUTE
    audit["request_window_complete"] = cursor >= end_ms
    audit["pagination_cap_reached"] = cursor < end_ms and audit["kline_requests"] == MAX_KLINE_REQUESTS
    # Missing minutes are not fabricated. The caller reports coverage from imported immutable bars.
    return collected, audit


def coverage(journal: Journal, snapshots: list[tuple], cutoff_ms: int) -> list[dict]:
    output = []
    floor = cutoff_ms // MINUTE * MINUTE
    for ident, snapshot in snapshots:
        start = snapshot["decision_ms"]
        full_end = start + MATURITY_MS
        end = max(start, min(floor, full_end))
        present = {r[0] for r in journal.db.execute(
            "SELECT ts FROM bars WHERE source=? AND symbol=? AND ts>=? AND ts<?",
            (SOURCE, SYMBOL, start, end))}
        expected = set(range(start, end, MINUTE))
        missing = sorted(expected - present)
        output.append({"snapshot_id": ident, "decision_ms": start, "full_maturity_ms": full_end,
                       "fully_mature_by_clock": full_end <= cutoff_ms,
                       "closed_minutes_expected_so_far": len(expected),
                       "closed_minutes_available_so_far": len(expected & present),
                       "missing_minutes_so_far": len(missing), "missing_minute_starts_ms": missing,
                       "lookback_truncated": start < cutoff_ms - LOOKBACK_MS})
    return output


def refresh(db_path: Path, out_dir: Path, *, get_json=public_get_json, clock_ms=None) -> dict:
    """One finite refresh. Injectable GET/clock make all tests offline and deterministic."""
    db_path, out_dir = Path(db_path).resolve(strict=True), Path(out_dir).resolve()
    if not db_path.is_file():
        raise RefreshError("--db must select an existing journal file")
    if out_dir == db_path or (out_dir.exists() and not out_dir.is_dir()):
        raise RefreshError("--out must be an output directory")
    out_dir.mkdir(parents=True, exist_ok=True)
    report = {"helper_version": "public-closed1m-manualpilot-refresh-v1", "symbol": SYMBOL, "price_source": SOURCE,
              "forecast_status": "not_calibrated", "schedule_created": False,
              "max_http_requests": 3, "max_lookback_hours": 24, "max_observation_minutes": 300}
    clock = clock_ms or (lambda: time.time_ns() // 1_000_000)
    journal = None
    try:
        reply = get_json("/fapi/v1/time", None)
        if not isinstance(reply, dict):
            raise RefreshError("time endpoint must return an object")
        server = epoch_ms(reply.get("serverTime"), "serverTime")
        local = epoch_ms(clock(), "local clock")
        cutoff = min(local, server)
        floor = cutoff // MINUTE * MINUTE
        report.update(server_time_ms=server, local_time_ms=local, cutoff_ms=cutoff,
                      clock_skew_local_minus_server_ms=local - server, time_requests=1)
        journal = ManualPilotJournal(db_path)
        scoped_observations = journal.snapshots()
        observations = [(ident, snap) for ident, snap in scoped_observations
                        if snap["received_ms"] <= cutoff and snap["decision_ms"] <= cutoff]
        report["observations_in_scope"] = len(observations)
        report["observations_deferred_by_clock"] = len(scoped_observations) - len(observations)
        journal.allowed_ids = {ident for ident, _ in observations}
        wanted = [(max(snap["decision_ms"], ((cutoff - LOOKBACK_MS + MINUTE - 1) // MINUTE) * MINUTE),
                   min(snap["decision_ms"] + MATURITY_MS, floor)) for _, snap in observations]
        wanted = [(a, b) for a, b in wanted if a < b]
        rows, fetch_audit = [], {"kline_requests": 0, "forming_rows_excluded": 0,
                                "request_window_complete": True, "pagination_cap_reached": False}
        if wanted:
            start, end = min(a for a, _ in wanted), max(b for _, b in wanted)
            report.update(request_start_ms=start, request_end_exclusive_ms=end)
            rows, fetch_audit = fetch_bars(start, end, cutoff, get_json)
        report.update(fetch_audit)
        report["total_http_requests"] = 1 + fetch_audit["kline_requests"]
        # Fetch/validate the entire bounded response before a single journal import.
        if rows:
            stream = io.StringIO(newline="")
            writer = csv.DictWriter(stream, fieldnames=("ts", "open", "high", "low", "close"), lineterminator="\n")
            writer.writeheader(); writer.writerows(rows)
            csv_text = stream.getvalue()
            report["closed_csv_sha256"] = hashlib.sha256(csv_text.encode("utf-8")).hexdigest()
            report["closed_csv_file"] = "fresh_closed_1m.csv"
            # Journal enforces immutable revisions and rolls the whole import transaction back on conflict.
            inserted = journal.import_bars(SOURCE, SYMBOL, rows, now_ms=cutoff)
            atomic_text(out_dir / "fresh_closed_1m.csv", csv_text)
        else:
            inserted = 0
        results = journal.evaluate(now_ms=cutoff)
        report.update(status="ok", fetched_closed_rows=len(rows), inserted_bars=inserted,
                      observation_coverage=coverage(journal, observations, cutoff),
                      evaluations=results, summary=summarize(results))
        report["has_missing_minutes"] = any(r["missing_minutes_so_far"] for r in report["observation_coverage"])
        atomic_text(out_dir / "refresh_result.json", json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
        return report
    except Exception as exc:
        report.update(status="error", error_type=type(exc).__name__, error=str(exc),
                      note="No snapshots are created/backdated. Existing bar revisions are never overwritten; inspect before retry.")
        atomic_text(out_dir / "refresh_result.json", json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
        raise
    finally:
        if journal is not None:
            journal.close()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", type=Path, required=True, help="Existing manual-pilot journal SQLite file")
    parser.add_argument("--out", type=Path, required=True, help="Directory for atomically replaced JSON and closed-bars CSV")
    args = parser.parse_args(argv)
    try:
        result = refresh(args.db, args.out)
    except Exception as exc:
        print(json.dumps({"status": "error", "error_type": type(exc).__name__, "error": str(exc)}))
        return 1
    print(json.dumps({key: result[key] for key in
                      ("status", "observations_in_scope", "fetched_closed_rows", "inserted_bars",
                       "total_http_requests", "has_missing_minutes", "forecast_status")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
