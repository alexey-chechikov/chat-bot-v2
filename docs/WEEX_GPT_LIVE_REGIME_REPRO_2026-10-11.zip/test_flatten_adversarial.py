"""Read-only production-source tests; all exchanges/state below are synthetic."""
from __future__ import annotations
import json
import sys
import time
from pathlib import Path
import pytest

HERE = Path(__file__).resolve().parent
SNAP = HERE / "snapshot"
sys.path.insert(0, str(SNAP))
from services.weex_grid import engine as eg

@pytest.fixture(autouse=True)
def retry_windows_replace_permission_noise(monkeypatch):
    """Retain real fsync+replace; retry only observed Windows watcher WinError5."""
    real = eg.os.replace
    def retry(src, dst):
        for attempt in range(20):
            try:
                return real(src, dst)
            except PermissionError as exc:
                if getattr(exc, "winerror", None) != 5 or attempt == 19:
                    raise
                time.sleep(.005)
    monkeypatch.setattr(eg.os, "replace", retry)

class Px:
    def __init__(self, mid=100000.): self.mid = mid
    def __call__(self): return self.mid - .05, self.mid + .05

class PartialLiveExchange(eg.DryExchange):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.first_market_partial = True
    def place_market(self, symbol, side, position_side, qty, cid, reduce_only=False):
        r = super().place_market(symbol, side, position_side, qty, cid, reduce_only)
        if r.get("success") and reduce_only and self.first_market_partial:
            self.first_market_partial = False
            oid = r["orderId"]
            half = float(self.orders[oid]["origQty"]) / 2
            self.orders[oid].update(status="PARTIALLY_FILLED", executedQty=f"{half:.4f}")
            self.trades[oid][0].update(qty=f"{half:.4f}", commission=str(half * float(self.orders[oid]["price"]) * .00048))
        return r
    def open_orders(self, symbol):
        return [{"orderId": k, **v} for k,v in self.orders.items() if v["status"] in eg.LIVE]
    def cancel(self, oid):
        o = self.orders.get(str(oid))
        if o and o["status"] in ("NEW", "PARTIALLY_FILLED"):
            o["status"] = "CANCELED"
        return {"success": True, "orderId": oid}

def fixture(p: Path, cls=eg.DryExchange):
    px = Px()
    clock = {"t": 1800000000.}
    regime = {"up": True}
    ex = cls(px, now_fn=lambda: clock["t"])
    cfg = {**eg.DEFAULT, "enabled": True, "dry_run": True, "sides": ["LONG"], "order_qty": ".0012",
           "regime_sma": 100, "stress_budget_frac": 0., "daily_loss_stop_usd": 0., "max_notional_usd": 4000.}
    def build():
        return eg.Grid(ex, cfg, state_path=p / "st.json", journal_path=p / "journal.jsonl",
                       now_fn=lambda: clock["t"], regime_fn=lambda *a: regime["up"])
    g = build()
    def tick(g):
        clock["t"] += 10
        g.tick()
    tick(g)
    px.mid = 99790.
    tick(g)
    assert sum(float(l["qty"]) for l in g.st["LONG"]["lots"]) == pytest.approx(.0012)
    return g, ex, px, clock, regime, build, tick

def bot_markets(ex):
    return [dict(orderId=oid, **o) for oid,o in ex.orders.items()
            if o.get("type") == "MARKET" and str(o.get("clientOrderId", "")).startswith(eg.PREFIX)]

def actual_long(ex):
    return next(float(p["size"]) for p in ex.futures_positions() if p["side"] == "LONG")

def snapshot(g, ex):
    s = g.st["LONG"]
    return {"exchange_long": actual_long(ex), "book_long": sum(float(l["qty"]) for l in s["lots"]),
            "flatten": s.get("flatten"), "strays": list(s["strays"]), "realized": s["realized"],
            "fees": s["fees"], "turnover": s["turnover"], "bot_markets": bot_markets(ex)}

def partial_orphan_case(p):
    g, ex, px, clock, regime, build, tick = fixture(p, PartialLiveExchange)
    regime["up"] = False
    stages = []
    for _ in range(3):
        tick(g)
        # Deep copy because the next pass changes dictionaries in-place.
        stages.append(json.loads(json.dumps(snapshot(g, ex))))
    return {"stages": stages, "final": snapshot(g, ex)}

def timeout_retry_case(p):
    g, ex, px, clock, regime, build, tick = fixture(p)
    ex.place_market("BTCUSDT", "BUY", "LONG", ".0020", "manual_open", reduce_only=False)
    real = ex.place_market
    def lost(*a, **kw):
        real(*a, **kw)
        raise TimeoutError("accepted and filled, response lost")
    ex.place_market = lost
    regime["up"] = False
    tick(g)
    stages = [json.loads(json.dumps(snapshot(g, ex)))]
    # The market order is terminal (not in open orders); its history visibility
    # lags behind. A short page is treated as proof of nonexistence after TTL.
    ex.order_history = lambda *a, **kw: []
    ex.place_market = real
    g = build()                    # same persisted intent, simulated restart
    clock["t"] += eg.PENDING_TTL + 1
    tick(g)                        # clears the old unresolved flatten intent
    stages.append(json.loads(json.dumps(snapshot(g, ex))))
    tick(g)                        # sends a new cid, consuming manual position
    tick(g)                        # records the second response
    return {"manual_expected_remaining": .002, "stages": stages, "final": snapshot(g, ex)}

def mixed_manual_case(p):
    g, ex, px, clock, regime, build, tick = fixture(p)
    ex.place_market("BTCUSDT", "BUY", "LONG", ".0020", "manual_open", reduce_only=False)
    ex.place_market("BTCUSDT", "SELL", "LONG", ".0006", "manual_reduce", reduce_only=True)
    regime["up"] = False
    tick(g)
    tick(g)
    return {"expected_bot_remainder_before_exit": .0006, "manual_expected_remaining": .002,
            "final": snapshot(g, ex),
            "scope": "Ownership of same-side exchange quantity is fungible; this is an attribution limitation."}

def timeout_retry_bot_only_case(p):
    g, ex, px, clock, regime, build, tick = fixture(p)
    real = ex.place_market
    first = {}
    def lost(*a, **kw):
        r = real(*a, **kw)
        first.update(ex.orders[r["orderId"]])
        raise TimeoutError("accepted and filled, response lost")
    ex.place_market = lost
    regime["up"] = False
    tick(g)
    ex.order_history = lambda *a, **kw: []
    ex.place_market = real
    g = build()
    clock["t"] += eg.PENDING_TTL + 1
    tick(g)
    px.mid = 99000.                 # actual exit already happened at99789.95
    tick(g)                        # retry rejected; reconciles old lots at99000
    q, entry, exit_px = .0012, 99800., float(first["avgPrice"])
    true_realized = q * (exit_px-entry)
    true_fees = q * entry * .00016 + q * exit_px * .00048
    return {"final": snapshot(g, ex), "correct_realized": true_realized, "correct_fees": true_fees,
            "correct_turnover": q * (entry+exit_px), "correct_net": true_realized - true_fees,
            "accounted_net": g.st["LONG"]["realized"] - g.st["LONG"]["fees"]}

def fee_reference_case(p):
    g, ex, px, clock, regime, build, tick = fixture(p, PartialLiveExchange)
    regime["up"] = False
    b,a = px()
    g._flatten_side("LONG", b,a,px.mid)      # sends partial market
    oid = g.st["LONG"]["flatten"]["id"]
    g._flatten_side("LONG", b,a,px.mid)      # records initial partial, no orphan scan
    before = g.st["LONG"]["fees"]
    refs = sorted(g._referenced("LONG"))
    clock["t"] += eg.FEE_WINDOW + 10
    g._settle_fees()                        # drops cursor despite live flatten
    cursor_removed = oid not in g.st["LONG"]["fee_book"]
    o = ex.orders[oid]
    o.update(status="FILLED", executedQty=o["origQty"])
    market_fee = float(o["origQty"]) * float(o["price"]) * .00048
    ex.trades[oid][0].update(qty=o["origQty"], commission=str(market_fee))
    g._flatten_side("LONG", b,a,px.mid)
    entry_fee = .0012 * 99800. * .00016
    return {"id": oid, "referenced_after_partial": refs, "cursor_removed_while_flatten_live": cursor_removed,
            "fees_before": before, "fees_final": g.st["LONG"]["fees"],
            "correct_fee_total": entry_fee + market_fee, "overcount": g.st["LONG"]["fees"] - entry_fee - market_fee}

# These safety properties intentionally fail on the pinned source. They are
# ordinary regression tests, not tests mirroring its faulty implementation.
def test_partial_live_flatten_is_not_double_counted_as_orphan(tmp_path):
    r = partial_orphan_case(tmp_path)
    assert r["final"]["exchange_long"] == pytest.approx(r["final"]["book_long"])

def test_unknown_filled_market_is_not_retried_against_manual_position(tmp_path):
    r = timeout_retry_case(tmp_path)
    assert len(r["final"]["bot_markets"]) == 1
    assert r["final"]["exchange_long"] == pytest.approx(r["manual_expected_remaining"])

def test_active_flatten_keeps_fee_cursor(tmp_path):
    r = fee_reference_case(tmp_path)
    assert not r["cursor_removed_while_flatten_live"]
    assert r["fees_final"] == pytest.approx(r["correct_fee_total"])

def test_normal_full_flatten_survives_restart(tmp_path):
    g,ex,px,clock,regime,build,tick = fixture(tmp_path)
    regime["up"] = False
    tick(g)
    g = build()
    tick(g)
    tick(g)
    assert actual_long(ex) == 0. and not g.st["LONG"]["lots"]
    assert len(bot_markets(ex)) == 1

def test_known_partial_cumulative_fill_is_idempotent_without_orphan_handler(tmp_path):
    g,ex,px,clock,regime,build,tick = fixture(tmp_path, PartialLiveExchange)
    regime["up"] = False
    b,a = px()
    g._flatten_side("LONG", b,a,px.mid)
    oid = g.st["LONG"]["flatten"]["id"]
    g._flatten_side("LONG", b,a,px.mid)
    first = snapshot(g, ex)
    g._flatten_side("LONG", b,a,px.mid)
    assert snapshot(g, ex) == first
    o = ex.orders[oid]
    o.update(status="FILLED", executedQty=o["origQty"])
    full_fee = float(o["origQty"]) * float(o["price"]) * .00048
    ex.trades[oid][0].update(qty=o["origQty"], commission=str(full_fee))
    g._flatten_side("LONG", b,a,px.mid)
    assert actual_long(ex) == 0. and not g.st["LONG"]["lots"]
    assert g.st["LONG"]["fees"] == pytest.approx(.0012*99800*.00016+full_fee)
    assert len(bot_markets(ex)) == 1

def test_unknown_filled_market_is_not_rewritten_as_estimated_manual_close(tmp_path):
    r = timeout_retry_bot_only_case(tmp_path)
    assert r["final"]["realized"] == pytest.approx(r["correct_realized"])
    assert r["final"]["fees"] == pytest.approx(r["correct_fees"])

def test_crash_before_accounting_save_replays_known_exit_once(tmp_path):
    g,ex,px,clock,regime,build,tick = fixture(tmp_path)
    regime["up"] = False
    tick(g)
    original_journal = g._journal
    def crash(rec):
        if rec.get("kind") == "закрытие по режиму":
            raise RuntimeError("simulated crash after in-memory fill accounting, before durable save")
        return original_journal(rec)
    g._journal = crash
    with pytest.raises(RuntimeError, match="simulated crash"):
        tick(g)
    # The source's atomic state still holds the old cumulative cursor and known id.
    g = build()
    tick(g)
    assert actual_long(ex) == 0. and not g.st["LONG"]["lots"]
    assert len(bot_markets(ex)) == 1
    assert g.st["LONG"]["realized"] == pytest.approx(.0012*(99789.95-99800))
    assert g.st["LONG"]["fees"] == pytest.approx(.0012*(99800*.00016+99789.95*.00048))
