"""Pinned-code probes using synthetic public data only; no private state or network."""
import ast
import importlib.util
import json
import logging
from decimal import Decimal
from datetime import datetime, timedelta, timezone
from pathlib import Path
import time
import urllib.request

import numpy as np

HERE=Path(__file__).resolve().parent
SNAP=HERE/"snapshot"
source=SNAP/"services/weex_grid/engine.py"
tree=ast.parse(source.read_text(encoding="utf-8-sig"))
fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=="regime_up")
ns={"json":json,"time":time,"logger":logging.getLogger("probe"),"_REGIME_CACHE":{}}
ns["logger"].addHandler(logging.NullHandler())
ns["logger"].propagate=False
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(source),"exec"),ns)
regime=ns["regime_up"]
NOW=datetime(2026,10,11,0,5,tzinfo=timezone.utc).timestamp()


def bars(ending_day, last_close=99.0):
    start=ending_day-timedelta(days=99)
    return [[int((start+timedelta(days=i)).timestamp()*1000),"100","101","98",
             str(last_close if i==99 else 100.0),"10",
             int((start+timedelta(days=i+1)).timestamp()*1000)-1] for i in range(100)]


new_rows=bars(datetime(2026,10,10,tzinfo=timezone.utc))
requests=[]
payload={"rows":new_rows,"failure":False}
class Response:
    def read(self):
        return json.dumps(payload["rows"]).encode()
def fake_urlopen(req, timeout=15):
    requests.append(req.full_url)
    if payload["failure"]:
        raise TimeoutError("synthetic public data outage")
    return Response()
original=urllib.request.urlopen
urllib.request.urlopen=fake_urlopen
out={}
try:
    cache=ns["_REGIME_CACHE"]
    out["current_valid_payload"]={"decision":regime("BTCUSDT",100,now=NOW)}
    assert out["current_valid_payload"]["decision"] is False
    cache.clear()
    cache[("BTCUSDT",100)]=(NOW-600,True) # cached23:55 previousUTCday
    before=len(requests)
    result=regime("BTCUSDT",100,now=NOW)
    out["cache_crosses_UTC_day"]={"decision":result,"fresh_decision_same_payload":False,
        "HTTP_requests_made":len(requests)-before,"cached_at":"2026-10-10T23:55Z","now":"2026-10-11T00:05Z"}
    assert result is True and len(requests)==before

    cache.clear();cache[("BTCUSDT",100)]=(NOW-3600,True)
    payload["failure"]=True
    out["outage_reuses_previous_side"]={"decision":regime("BTCUSDT",100,now=NOW),
        "cache_age_seconds":3600,"expected_current_side_known_from_fixture":False}
    assert out["outage_reuses_previous_side"]["decision"] is True
    payload["failure"]=False
    cache.clear()
    payload["rows"]=bars(datetime(2026,10,8,tzinfo=timezone.utc),last_close=101.0)
    stale=regime("BTCUSDT",100,now=NOW)
    out["stale_successful_payload_renews_cache"]={"decision":stale,
        "latest_closed_day_in_payload":"2026-10-08","expected_latest_closed_day":"2026-10-10",
        "new_cache_time_seconds":cache[("BTCUSDT",100)][0],"query_time_seconds":NOW}
    assert stale is True and cache[("BTCUSDT",100)][0]==NOW

    cache.clear();payload["rows"]=list(reversed(new_rows))
    out["reverse_rows_change_decision"]={"decision":regime("BTCUSDT",100,now=NOW),"sorted_valid_decision":False}
    assert out["reverse_rows_change_decision"]["decision"] is True

    cache.clear();payload["rows"]=bars(datetime(2026,10,10,tzinfo=timezone.utc),last_close=float("nan"))
    out["NaN_generates_short_not_unknown"]={"decision":regime("BTCUSDT",100,now=NOW)}
    assert out["NaN_generates_short_not_unknown"]["decision"] is False

    cache.clear();payload["rows"]=bars(datetime(2026,10,10,tzinfo=timezone.utc))[:99]
    out["insufficient_rows_failclosed_without_cache"]={"decision":regime("BTCUSDT",100,now=NOW)}
    assert out["insufficient_rows_failclosed_without_cache"]["decision"] is None
finally:
    urllib.request.urlopen=original

spec=importlib.util.spec_from_file_location("maker_pinned",SNAP/"research/weex/maker_paper.py")
maker=importlib.util.module_from_spec(spec);spec.loader.exec_module(maker)
maker.MAKER=maker.TAKER=0.0001
# Quote created at t0; an aggressive event arrives after its5s life, but source fills before expiry.
ev=[(0,0,100.0,1.0,100.01,1.0),
    (6000,1,99.9,0.01,1,0.0),
    (6001,0,100.0,1.0,100.01,1.0)]
r=maker.simulate(ev,1,1,0.01)
out["maker_expired_quote_filled"]={"quote_created_ms":0,"life_ms":5000,
    "source_entry_fills":[list(x) for x in r["fills"]],"source_volume":r["vol"],
    "note":"Trade6000ms processed before expired quote is removed; small trade-through also gives full synthetic fill"}
assert len(r["fills"])==1 and r["fills"][0][0]==6000

# Forced finalmarket liquidation uses mid rather than crossing spread.
ev=[(0,0,100.0,1.0,100.02,1.0),
    (1,1,99.9,0.01,1,0.0),
    (1000,0,99.99,1.0,100.01,1.0)]
r=maker.simulate(ev,1,1,0.01)
out["maker_final_exit_mid_credit"]={"entry":100.0,"quantity":0.3,"end_bid":99.99,"end_ask":100.01,
    "source_gross":r["gross"],"executable_bid_gross":0.3*(99.99-100.0),
    "synthetic_full_return_volume":r["vol"]}
assert abs(r["gross"])<1e-12

# Quote already best at placement, but ahead is initialized only on a later post-trade snapshot.
# EqualE sorting puts that snapshot before the trade that already reduced its queue.
ev=[(0,0,100.0,1.0,100.01,1.0),
    (1000,0,100.0,0.2,100.01,1.0),
    (1000,1,100.0,0.8,1,0.0),
    (1001,0,100.0,0.2,100.01,1.0)]
r=maker.simulate(ev,1,1,0.01)
out["maker_post_trade_queue_double_count"]={"initial_ahead_at_placement":1.0,
    "same_timestamp_trade_quantity":0.8,"post_trade_visible_ahead":0.2,
    "own_quantity":0.3,"source_entry_fills":[list(x) for x in r["fills"]],
    "strict_queue_expected_filled_quantity":0.0,
    "note":"Own quote placed at t0 behind1.0; trade0.8 leaves0.2 ahead, but source captures post-trade0.2 then subtracts0.8 again"}
assert len(r["fills"])==1

# Scheme2 promised original-mid target; source anchor is fill-time midpoint, then unused.
out["scheme2_target_definition"]={"quote_initial_mid":100.0,"long_quote":99.92,
    "promised_exit_target":100.0,"source_entry_relative_target":99.92*(1+0.0008),
    "difference":99.92*(1+0.0008)-100.0,
    "anchor_field":"computed at fill-time and never used for target"}

actual=[Decimal(x) for x in ("-18.20","-34.68","544.83","-13.17","-4.02","-73.18","-15.12","118.58")]
opposite=[Decimal(x) for x in ("10.31","-12.17","-864.99","8.12","2.56","70.82","155.18","-122.51")]
out["ginarea_table_arithmetic"]={"regime_sum":str(sum(actual)),"opposite_sum":str(sum(opposite)),
    "regime_excluding_big_segment":str(sum(actual)-actual[2]),
    "opposite_excluding_big_segment":str(sum(opposite)-opposite[2]),
    "long_segments_sum":str(sum(actual[i] for i in (1,3,5,7))),
    "not_API_reproduced":True}
out["onebps_allfills_cost_identity"]={"gross_maker_taker1bps_fee_USD_per_million":100,
    "BTC_published_net_cost106_implies_zero_fee_cost":6,
    "ETH_published_net_cost91_implies_zero_fee_cost":-9,
    "BTC44_rounds30USD_each_leg_nominal_volume":2640,
    "BTC_nominal_net_loss_USD_at106_permillion":0.27984,
    "BTC_nominal_gross_loss_USD_at6_permillion":0.01584,
    "published_fills_not_reproduced_without_raw_book":True}
(HERE/"regime_metrics_probe.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(out,ensure_ascii=True,indent=2))
