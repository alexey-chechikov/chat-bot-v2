"""Package public pinned files and offline reproductions; no account state."""
from pathlib import Path
import hashlib, json, zipfile

HERE = Path(__file__).resolve().parent
manifest = json.loads((HERE / 'source_manifest.json').read_text(encoding='utf-8'))
extras = [
    'REPRO_README.md', 'source_manifest.json', 'run_tests.py',
    'test_flatten_adversarial.py', 'probe_flatten.py', 'probe_flatten_results.json',
    'release_probes.py', 'release_probe_results.json',
    'root_probes.py', 'root_probe_results.json',
    'regime_metrics_probe.py', 'regime_metrics_probe.json',
    'baseline_io_retry.json', 'audit_flatten.md', 'release_audit.md',
    'audit_regime_metrics.md', 'package_repro.py', 'verify_repro.py',
    'package_verification.json',
    'WEEX_GPT_LIVE_REGIME_REVIEW_2026-10-11.md',
]
target = HERE / 'WEEX_GPT_LIVE_REGIME_REPRO_2026-10-11.zip'
entries = []
for item in manifest['files']:
    rel = item['path']
    assert not rel.startswith('state/') and '..' not in Path(rel).parts
    p = HERE / 'snapshot' / rel
    assert hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256'], rel
    entries.append((p, 'snapshot/' + rel))
for rel in extras:
    entries.append((HERE / rel, rel))
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p, rel in entries:
        z.write(p, rel)
with zipfile.ZipFile(target, 'r') as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist()))
print(json.dumps({'zip': str(target), 'files': len(entries),
    'bytes': target.stat().st_size,
    'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
    'source_commit': manifest['commit']}, indent=2))
