"""Run confirmed offline counterexamples without modifying snapshot source."""
import json
import hashlib
import os
import time
from pathlib import Path
from test_flatten_adversarial import partial_orphan_case, timeout_retry_case, mixed_manual_case, fee_reference_case, timeout_retry_bot_only_case

HERE = Path(__file__).resolve().parent
_real_replace = os.replace
def _replace_with_retry(src, dst):
    for attempt in range(20):
        try:
            return _real_replace(src, dst)
        except PermissionError as exc:
            if getattr(exc, "winerror", None) != 5 or attempt == 19:
                raise
            time.sleep(.005)
# Narrow environment workaround; fsync and actual atomic replacement retained.
os.replace = _replace_with_retry
base = HERE / "flatten_probe_files"
base.mkdir(exist_ok=True)
out = {"commit": "5dc2d7eee1897b1fd83906128c20b38d7604df07", "cases": {}}
out["source_sha256"] = {
    str(p.relative_to(HERE / "snapshot")).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in (HERE / "snapshot/services/weex_grid/engine.py", HERE / "snapshot/services/weex_api/client.py",
              HERE / "snapshot/tests/services/weex_grid/test_weex_regime.py",
              HERE / "snapshot/tests/services/weex_grid/test_weex_release.py")}
for name, fn in (("partial_flatten_orphan", partial_orphan_case), ("timeout_retry_manual", timeout_retry_case),
                 ("mixed_manual_close", mixed_manual_case), ("flatten_fee_reference", fee_reference_case),
                 ("timeout_retry_bot_only", timeout_retry_bot_only_case)):
    p = base / name
    p.mkdir(exist_ok=True)
    for f in p.glob("*.json*"):
        f.unlink()              # task-created synthetic files only, no recursive delete
    out["cases"][name] = fn(p)
assert out["cases"]["partial_flatten_orphan"]["final"]["exchange_long"] == .0006
assert out["cases"]["partial_flatten_orphan"]["final"]["book_long"] == 0.
assert len(out["cases"]["timeout_retry_manual"]["final"]["bot_markets"]) == 2
assert out["cases"]["timeout_retry_manual"]["final"]["exchange_long"] == .0008
assert out["cases"]["flatten_fee_reference"]["overcount"] > 0
(HERE / "probe_flatten_results.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(out, ensure_ascii=False, indent=2))
