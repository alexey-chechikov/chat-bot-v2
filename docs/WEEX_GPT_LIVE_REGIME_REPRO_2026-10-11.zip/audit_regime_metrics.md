# Regime-provider и исследовательские цифры: независимый аудит

Коммит `5dc2d7eee1897b1fd83906128c20b38d7604df07`. Прочитаны brief, `regime_up`/tick, новые tests, maker_paper, GinArea runner и corrected regime_grid. Приватные state/book/journals, аккаунты и API GinArea/WEEX не использованы. Pinned public Git tree прочитан GET-only: содержит код recorder/maker/GinArea, но не raw `state/weex_book` и не `state/ginarea_regime_check.jsonl`. Поэтому опубликованные циклы/markout/GinArea/PAXG итоги независимо не повторены. Их арифметика проверяется отдельно от подтверждения фактического исполнения.

Probe: `python research/weex_live_regime_review_20261011/regime_metrics_probe.py`. Все assertions проходят, JSON содержит результаты. `regime_up` извлечён AST без импорта production модуля; сеть заменена FAKE и восстановлена; maker.simulate получает синтетические public events. Source/snapshot не менялся.

## 1. Regime cache задерживает смену UTC-дня

`engine.py:169–172`: ключ(symbol,sma_days), валидность определяется только now−cache_time<1800, а не датой последнего закрытого бара. Контрпример: cachedLONG23:55 10октября, теперь00:05 11октября; правильный новый100-day payload даётSHORT. Функция возвращает **LONG без HTTP-запроса**. В `tick:693–705` это допускает старуюLONG-сторону и не запускает нужный flatten. Смена на открытии нового дня из бэктеста не совпадает с такой моделью live; максимальная обычная задержка30мин плюс цикл/сетевые задержки.

Требование: cache принадлежит closed_day, последняя ожидаемая дата=yesterdayUTC; переход UTC-дня инвалидирует admission по старому решению. Запросить вчерашнюю закрытую свечу после её доступности; если она неизвестна, EXIT/owned-order lifecycle сохраняется, новые увеличивающие риск входы закрыты. Отдельный тест23:55→00:05 с противоположным новым regime.

## 2. Fallback не fail-closed для новых входов; stale-success renews cache

`engine:180–182` при ошибке возвращает старыйbool до24ч. Это прямо описано в brief, но не даёт гарантии «сбой→новых входов нет»: режимNone получается лишь безcache либо после суток. Probe cache age1ч LONG + Timeout → **LONG**, при fixture новой стороныSHORT.

Сильнее: успешный payload100 дневок, последняя08октября, запрошен11октября00:05. Длина достаточна, data freshness не проверена; возвращаетсяLONG и времяcache обновлено наnow. Повтор таких stale responses может продлевать admission бесконечно;24ч fallback здесь не ограничивает stale-data age.

Требование: сохранять source_last_closed_day/time отдельно от fetch_time; stale/error решение может показываться информационно, но не разрешать новые входы после истечения дневной source validity. Не принимать stale successful ответ как свежий. Управление уже открытыми ордерами продолжается, неизвестные данные сами не должны вызывать неподтверждённый market-close. При отказах — bounded retry/backoff вне критического lifecycle прохода, чтобы15sec quote request не скрывал задержку сопровождения.

## 3. Нет контроля календаря/порядка/finite closes

`engine:177–179` принимает любые100 rows c close_time<now, не проверяя100 уникальных последовательных дневных open/close timestamps, правильность последней даты и положительные finite closes.

- Перевёрнутый порядок того же valid payload меняетSHORT наLONG: берётся closed[-1], но не последняя по времени свеча.
- Последний close='NaN' проходитfloat conversion, сравнение даёт **False**, сохраняетсяSHORT, а неUNKNOWN. Это способно запускать flatten из malformed data.
- Без предыдущегоcache99 закрытых rows корректно даютNone; этот позитивный случай подтверждён.

Требование: explicit schema, sort/unique или отказ на нештатный порядок, expected contiguous daily calendar, last close=yesterday, finite positive close. Тесты настоящего provider с FAKE HTTP; нынешние5 regime tests подменяют provider lambda и эти сценарии не проверяют. Эти malformed-payload probes не утверждают, что Binance уже прислал такие ответы.

## 4. Maker-paper цифры не воспроизводятся без raw; есть ошибки симуляции

1. **Quote expiry применяется после fill.** `maker_paper.py:91–113` сначала пропускает event через старые quotes; очистка поlife только134. Quote создан0ms/life5000, trade6000ms → источник считает entry fill6000ms. Требуется обработать timer/cancel intent до event с учётом cancel-ACK latency; expired/UNKNOWN не должны исчезать без анализа возможных поздних fills. Это ошибка declared5sec-paper-rule, не доказательство частоты её возникновения в8.2ч записи.
2. **Финальный market-close поmid** (`143–145`) даёт ценовой кредит. Probe long entry100/q0.3, endbid99.99/ask100.01: source gross0, marketпоbid gross−$0.003. Финальный остаток должен либо оставаться marked/срез отдельно, либо ликвидироваться по executable стороне+slippage/depth. Оплата taker fee не делаетmid рыночной ценой.
3. **Нет partial-fill state/latency/actual queue replay.** Trade-through даже с q0.01 при собственном q0.3 даёт сразу full synthetic fill. Это strong infinitesimal-no-impact допущение, не доказанная консервативная очередь для любого размера. Более сильный подтверждённый probe: quote уже best при размещении, впереди1.0; агрессивный trade0.8 оставляет впереди0.2 и не касается наших0.3. При одинаковомE load ставит post-trade book раньше trade; on_book впервые записываетahead0.2, затем on_trade ещё раз вычитает0.8. Код считает весь наш fill0.3, хотя строгая очередь даёт0.0. Причина — поздняя инициализация ahead и отсутствие причинного порядка book/trade. Нужны initial queue at placement, отдельные snapshots/arrival/order-ACK timestamps, partial quantities, received-event order и stress cancel lag; не переносить$30 результат линейно на$100/несколько ботов.
4. Scheme2 promise — target исходной середины; код120 используетentry*(1±.0008), anchor записывает вмоментfill и не читает. При idealquote99.92 исходныйmid100, rawtarget99.999936; tick-rounding часто скроет такую небольшую разницу. Это несогласованность спецификации, не крупный доказанный источник прибыли. Зафиксировать выбранныйtarget rule до пересчёта.

**Стоимость оборота посчитана по правильному знаменателю:** `vol` прибавляет каждуюentry/exit fill value, perM=−net/vol·1e6. Приmaker=taker=.0001 всегда `fee/V·1e6=100USD`. Поэтому reportedBTC106USD/M vszero-fee6 иETH91 vs−9 арифметически согласованы.44 завершённых цикла по$30 на каждой ноге дают около$2640 оборота;106USD/M ≈ **−$0.27984 за8.2ч**, а6USD/M ≈−$0.01584 доfees. Это расходы, не доход. ETH91USD/M тоже чистый убыток; небольшая grossprice прибыль появляется только в сценарии фактически полученного полногоrefund. Не считать100%-refund доступной маржой доcredited event.

Эффективнаяmaker1bp в раннем партнёрском сообщении отдельно не установлена: там определёнtaker1bp. Параmaker/taker1/1 в paper — сценарий параметров, пока нет подтверждения обеих API-ставок. Markout диагностический и уже участвует в pricePnL; повторно вычитать его изnet нельзя. Funding/slippage/API/minimumqty/depth costs в paper могут дополнительно менятьnet. Цифры$91–106 не являются измеренной стоимостью будущегоmillion-volume.

## 5. GinArea восемь отрезков: арифметика правильна, continuous-live доказательства нет

Сумма опубликованной таблицы:

- по режиму **+$505.04** →+505;
- наоборот **−$752.68** →−753;
- без одного большогоOctober–April отрезка **−$39.79 vs+$112.31** →−40 vs+112;
- толькоLONG-отрезки **−$2.45** →−2.

Это проверенная арифметика текста; remote GinArea API не вызван и raw JSONL в pinned tree нет. Каждый отрезок по runner стартует отдельным тестом; конечный current_profit маркирует bag без комиссии/cost фактической liquidation. Сумма не даёт continuous portfolio DD, исполнение нового mode-boundary или риск согласованного WEEX бота. Положительный общий эффект сосредоточен в одном большом SHORT-тренде; это не преимущество на каждом отрезке и не проверка только LONG→FLAT правила.

`ginarea_regime_check.py:59–70` dedup key=(from_date,side), **безto_date/spec/data version**. Тот же текущийрежимныйотрезок со свежим концом илиизменённымspec может быть пропущен какужеdone. При future rerun нужен run_id поfrom/to/side/spec/source; params restoration не исправляет reuse старого результата. Здесь не утверждаю, что опубликованные8 строк уже stale: privateOUT не читался.

## 6. Исправленный режимный контроль: конкретная правка верна, этого мало

`regime_grid.py:48–86`: bound берётся из исходногоregime **до**random assignment; на каждомисходномboundary все ранееactive стороны закрываются, даже если два случайных соседних отрезка получили однусторону. Старый merge-bias действительно устранён. longflat/shuffle_lf соответствуютLONG/OFF actions, анеLONG/SHORT сравнению.

Однако случайноеBernoulli0.5 поотрезкам нефиксируетвремяLONG/SHORT илиON/OFF, распределениеусловногоrisk/notional ичислоactive exit events дляLONG/OFF. Большиеотрезки дают большойразбросexposure; нужны exposure-matched controls/отдельныйconstant-size/lifecycle контроль иноваяsample послеисторическогопоиска. Main сокращаетконтроли до12; tail probabilities оченьгрубые. Если сообщаетсяk/n «нехуже» какp, MonteCarlo correction=(k+1)/(n+1), например3/12→4/13≈0.3077,7/12→8/13≈0.6154. Бриф корректно сообщаетraw counts, не нужнообъявлятьэтоошибкой арифметики.

НовыхPAXG rawdata/results впубличномtree нет. Его опубликованные+309/+134/control counts независимо не воспроизведены. Регime code по-прежнему безfunding ибезcashfinal-liquidation; bound-midpoint маркировка половины послеforcedexit требуеттого жепорядкаevents вmatched контроле. ДляPAXG proxy отдельнопроверятьtargetvenue, tick/contract specs иrisk account; золото не сталоapprovedза счётданнойтаблицы.

