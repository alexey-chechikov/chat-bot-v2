# Offline reproductions for WEEX live-regime review

Pinned public commit: `5dc2d7eee1897b1fd83906128c20b38d7604df07`.
No credentials, private account data or production state are included.
`snapshot/` contains public source only. SHA256 are in `source_manifest.json`.

Requirements: Python 3.10+, pytest, numpy, pandas. Tested on Python 3.10,
pytest 9.0.3; standalone regime metrics also used Python 3.12/numpy 2.3.5.
Extract into a new writable directory. All generated files are synthetic and
confined to this extracted directory. Do not extract over production files.

From the archive root in PowerShell:

```powershell
$env:PYTHONUTF8='1'
New-Item -ItemType Directory -Path 'snapshot/state' -Force | Out-Null
python run_tests.py
python run_tests.py ../test_flatten_adversarial.py -q --basetemp=../pytest_safety
python probe_flatten.py
python release_probes.py
python root_probes.py
python regime_metrics_probe.py
```

The default test runner changes cwd to snapshot, hence the safety-test path in
that command uses ../ to select the test in the archive root. It imports source
and fixtures from snapshot; no added test file changes the public snapshot.
Alternatively run `python -m pytest test_flatten_adversarial.py -q` from the
archive root. That file includes its own narrow Windows replace retry.

Expected baseline: 84 passed. Expected adversarial safety tests: 4 fail, 3 pass
on the pinned faulty source. Each failing test asserts desired safe behavior.
The standalone probe scripts instead assert reproduced bad states, return zero,
and write their result JSON. Do not interpret a zero probe exit as a safe bot.

`run_tests.py`, `root_probes.py`, `probe_flatten.py` and adversarial tests retry
actual os.replace only for transient Windows WinError5 (up to 20 short retries).
Other I/O errors propagate. This does not change pinned source or atomic replace.
`release_probes.py` replaces atomic_write locally with plain file writes: those
tests cover ownership transitions, not operating-system crash durability.
`regime_metrics_probe.py` extracts regime_up by AST and mocks public responses;
its maker-paper tests use synthetic events. No exchange orders or network calls.

Results JSON included are the recorded run on 2026-10-11. Public source is
unmodified; synthetic order fees use DryExchange defaults, not operator pricing.
Raw live book/trades, GinArea outputs and account journals were not available,
so claimed 44/67 cycles and $91–106/M were not independently reproduced.
