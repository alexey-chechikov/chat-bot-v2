"""Verify packaged sources and run offline scripts in a fresh extraction."""
from pathlib import Path
import hashlib, json, os, subprocess, sys, uuid, zipfile

HERE=Path(__file__).resolve().parent
dest=HERE / ('package_verify_' + uuid.uuid4().hex[:8])
dest.mkdir()
with zipfile.ZipFile(HERE/'WEEX_GPT_LIVE_REGIME_REPRO_2026-10-11.zip') as z:
    for name in z.namelist():
        assert (dest/name).resolve().is_relative_to(dest.resolve()), name
    z.extractall(dest)
manifest=json.loads((dest/'source_manifest.json').read_text(encoding='utf-8'))
for f in manifest['files']:
    assert hashlib.sha256((dest/'snapshot'/f['path']).read_bytes()).hexdigest()==f['sha256']
(dest/'snapshot'/'state').mkdir(exist_ok=True)
env={**os.environ,'PYTHONUTF8':'1'}
runs=[]
for args, expected in [
    (['run_tests.py'],0),
    (['run_tests.py','../test_flatten_adversarial.py','-q','--basetemp=../pytest_safety'],1),
    (['probe_flatten.py'],0), (['release_probes.py'],0),
    (['root_probes.py'],0), (['regime_metrics_probe.py'],0)]:
    r=subprocess.run([sys.executable,*args],cwd=dest,env=env,text=True,
                     stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (dest/(Path(args[0]).stem+'_verification.log')).write_text(r.stdout,encoding='utf-8')
    runs.append({'args':args,'expected':expected,'actual':r.returncode,
                 'tail':r.stdout[-1000:]})
    assert r.returncode==expected, r.stdout
    if args[0]=='run_tests.py':
        assert ('84 passed' if expected==0 else '4 failed, 3 passed') in r.stdout
out={'source_commit':manifest['commit'],'verified_sources':len(manifest['files']),
     'extraction':str(dest),'runs':runs}
(HERE/'package_verification.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
