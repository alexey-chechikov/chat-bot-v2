"""Additional offline live-engine scenarios. No production files or API clients."""
from pathlib import Path
import json,os,sys,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'snapshot'))
from services.weex_grid import engine as eg
from services.weex_grid import loop as lp
from tests.services.weex_grid.test_weex_grid_engine import Px,make

native=os.replace
def replace(src,dst,*args,**kw):
    for i in range(20):
        try:return native(src,dst,*args,**kw)
        except PermissionError as e:
            if getattr(e,'winerror',None)!=5 or i==19:raise
            time.sleep(.025)
os.replace=replace

def setup(label):
    folder=HERE/'root_cases'/label;folder.mkdir(parents=True,exist_ok=True)
    for p in [folder/'st.json',folder/'j.jsonl']:p.unlink(missing_ok=True)
    px=Px();reg={'up':True}
    g,ex=make(folder,px,sides=['LONG'],order_qty='0.0012',regime_sma=100,stress_budget_frac=0.)
    g.regime_fn=lambda *_:reg['up']
    g.tick();px.mid=99790.;g.tick()
    assert float(g.st['LONG']['lots'][0]['qty'])==.0012
    return folder,g,ex,px,reg

out={}
folder,g,ex,px,reg=setup('terminal_reject_loop')
market=ex.place_market
def rejected_after_ack(*args,**kw):
    r=market(*args,**kw);o=ex.orders[r['orderId']]
    o.update(status='REJECTED',executedQty='0',avgPrice='0')
    ex.trades[r['orderId']]=[]
    return r
ex.place_market=rejected_after_ack;reg['up']=False
for _ in range(12):g.tick()
markets=[o for o in ex.orders.values() if o.get('type')=='MARKET']
case={'accepted_but_terminal_rejected_markets':len(markets),'flatten_rejects':g.st['LONG'].get('flatten_rejects'),
      'halted':g.st['halted'],'book_qty':sum(float(l['qty']) for l in g.st['LONG']['lots']),
      'position':ex.futures_positions(),'remaining_tp_orders':[l.get('tp_order') for l in g.st['LONG']['lots']]}
assert len(markets)==6 and case['flatten_rejects']==0 and not case['halted'] and case['book_qty']==.0012
assert case['remaining_tp_orders']==[None]
out['terminal_reject_loop']=case

# /stop's enabled=False does not inhibit mode exits. /dry cleanup likewise uses
# the real client for live leftovers and retains regime_sma.
folder,g,ex,px,reg=setup('disabled_still_market')
g.cfg['enabled']=False;reg['up']=False;g.tick()
case={'enabled':g.cfg['enabled'],'market_count':len([o for o in ex.orders.values() if o.get('type')=='MARKET']),
      'flatten':g.st['LONG'].get('flatten')}
assert case['market_count']==1
out['disabled_still_market']=case

folder,g,ex,px,reg=setup('dry_cleanup_still_market')
cfg={**g.cfg,'dry_run':True,'enabled':True}
old_config,old_files,old_regime=lp.grid_config,lp.run_files,eg.regime_up
try:
    lp.grid_config=lambda *_:cfg
    lp.run_files=lambda name,dry:(folder/('dry_st.json' if dry else 'st.json'),folder/('dry_j.jsonl' if dry else 'j.jsonl'))
    eg.regime_up=lambda *_:False
    runner=lp.Runner();runner._client=lambda:ex
    runner.tick_one('BTC')
finally:lp.grid_config,lp.run_files,eg.regime_up=old_config,old_files,old_regime
case={'display_cfg_dry':cfg['dry_run'],'real_client_market_count':len([o for o in ex.orders.values() if o.get('type')=='MARKET']),
      'live_state_flatten':json.loads((folder/'st.json').read_text(encoding='utf-8'))['LONG'].get('flatten')}
assert case['real_client_market_count']==1
out['dry_cleanup_still_market']=case

# R5 remains relevant even with only LONG: replacement of a newly discovered
# orphan gives reservation credit absent from the initial portfolio snapshot.
folder=HERE/'root_cases'/'one_side_R5';folder.mkdir(parents=True,exist_ok=True)
for p in [folder/'st.json',folder/'j.jsonl']:p.unlink(missing_ok=True)
px=Px();g,ex=make(folder,px,sides=['LONG'],order_qty='0.0002',step_pct=.6,
                portfolio_free_usd=15.,stress_budget_frac=0.,regime_sma=100)
g.regime_fn=lambda *_:True
ex.place_limit('BTCUSDT','BUY','LONG','0.0001','99800','b7gBLeR5orphan')
g.tick()
active=[o for o in ex.orders.values() if o.get('status')=='NEW' and not o.get('reduceOnly')]
used=sum(float(o['origQty'])*float(o['price']) for o in active)
case={'sides':g.cfg['sides'],'initial_portfolio_free':15.,'active_entry_notional_after_tick':used,
      'entry_quantity':g.st['LONG']['entry']['qty'],'entry_price':g.st['LONG']['entry']['price'],
      'room_used':g._room_used,'old_orphan_status':ex.orders['dry1']['status']}
assert used>15. and len(active)==1 and case['old_orphan_status']=='CANCELED'
out['R5_single_long_replacement']=case

# Logical money is recovered, but a successful journal append before failed
# state commit is appended again on recovery without an execution event key.
folder,g,ex,px,reg=setup('journal_replay_duplicate')
reg['up']=False;g.tick()
journal=g._journal
def crash_after_append(rec):
    journal(rec)
    if rec.get('kind')=='закрытие по режиму':raise RuntimeError('crash after journal append before state save')
g._journal=crash_after_append
try:g.tick()
except RuntimeError:pass
else:raise AssertionError('Expected simulated crash')
restart=eg.Grid(ex,g.cfg,state_path=folder/'st.json',journal_path=folder/'j.jsonl',now_fn=g.now,
                regime_fn=lambda *_:False)
restart.tick()
records=[json.loads(x) for x in (folder/'j.jsonl').read_text(encoding='utf-8').splitlines()]
closed=[r for r in records if r.get('kind')=='закрытие по режиму']
market_count=len([o for o in ex.orders.values() if o.get('type')=='MARKET'])
case={'market_orders':market_count,'closing_journal_rows':len(closed),
      'journal_close_qty_sum':sum(float(r['qty']) for r in closed),'actual_close_qty':.0012,
      'state_book_qty':sum(float(l['qty']) for l in restart.st['LONG']['lots']),
      'closing_event_ids':[r['order_id'] for r in closed]}
assert market_count==1 and len(closed)==2 and case['state_book_qty']==0.
out['journal_replay_duplicate']=case

# Arithmetic of operator-facing quote/target values. No private state inferred.
e=2522.17;tp=2557.49;next_buy=2507.03
out['display_math']={'ETH_intended_tp':eg.round_tick(e*1.014,.01,up=True),'ETH_intended_next_buy':eg.round_tick(e*.994,.01,up=False),
      'BTC_83127_to_84799_pct':(84799.9/83127.2-1)*100,'BTC_old_lot_implied_entry_from_tp':84799.9/1.014,
      'BTC_old_lot_implied_entry_from_next_buy':83127.2/.994}
assert out['display_math']['ETH_intended_tp']==tp and out['display_math']['ETH_intended_next_buy']==next_buy
(HERE/'root_probe_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
