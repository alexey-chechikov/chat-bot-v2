"""Test-only mitigation for Windows file watcher sharing violations.
Retries actual os.replace on WinError5, preserving the pinned source and atomicity.
Other errors are not intercepted. Fake clients only; no credentials or network.
"""
import json, os, sys, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'snapshot'))
os.chdir(HERE/'snapshot')
native=os.replace
retries=[]
def replace(src,dst,*a,**kw):
    for attempt in range(20):
        try:return native(src,dst,*a,**kw)
        except PermissionError as e:
            if getattr(e,'winerror',None)!=5 or attempt==19:raise
            retries.append({'src':str(src),'dst':str(dst),'attempt':attempt+1})
            time.sleep(.025)
os.replace=replace
import pytest
args=sys.argv[1:] or ['tests/services/weex_grid','-q',f'--basetemp={HERE / "pytest_baseline_retry"}']
rc=pytest.main(args)
(HERE/'baseline_io_retry.json').write_text(json.dumps({'return_code':int(rc),'arguments':args,'os_replace_retries':retries,'scope':'Windows test I/O workaround only. No pinned source edits.'},indent=2),encoding='utf-8')
sys.exit(rc)
