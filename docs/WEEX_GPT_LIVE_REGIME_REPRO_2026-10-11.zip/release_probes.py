"""Offline release/tick counterexamples against the frozen snapshot. No real API.

Writes only into this review directory. Source is imported unmodified. The
atomic_write replacement is harness-local so this tests state transitions, not
the OS atomic-rename guarantee. DelayedMarket models an accepted market whose
execution/detail is queryable while open-order enumeration has not exposed it.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
SNAPSHOT = BASE / "snapshot"
sys.path.insert(0, str(SNAPSHOT))
from services.weex_grid import engine as eg

eg.atomic_write = lambda p, s: Path(p).write_text(s, encoding="utf-8")


class Px:
    mid = 100000.0
    def __call__(self):
        return self.mid - .05, self.mid + .05


def make(name, exchange_cls=eg.DryExchange):
    folder = BASE / "release_cases" / name
    folder.mkdir(parents=True, exist_ok=True)
    for p in (folder / "st.json", folder / "j.jsonl"):
        p.unlink(missing_ok=True)
    clock = {"t": 1800000000.0}
    def now():
        clock["t"] += 10
        return clock["t"]
    px = Px()
    ex = exchange_cls(px, now_fn=lambda: clock["t"])
    regime = {"up": False}
    notifications = []
    cfg = {**eg.DEFAULT, "enabled": True, "dry_run": False,
           "sides": ["SHORT"], "order_qty": "0.0084", "regime_sma": 100,
           "daily_loss_stop_usd": 0, "stress_budget_frac": 0}
    g = eg.Grid(ex, cfg, state_path=folder / "st.json", journal_path=folder / "j.jsonl",
                now_fn=now, regime_fn=lambda *_: regime["up"], send_fn=notifications.append)
    g.tick()
    px.mid = 100260.0
    g.tick()
    assert sum(float(l["qty"]) for l in g.st["SHORT"]["lots"]) == .0084
    # Genuine foreign same-side trade and its manual TP. These must survive release.
    ex.orders["manual_entry"] = {"clientOrderId": "human-open", "side": "SELL", "positionSide": "SHORT",
        "price": "100200", "origQty": "0.0061", "status": "FILLED", "executedQty": "0.0061",
        "avgPrice": "100200", "reduceOnly": False}
    ex.orders["manual_tp"] = {"clientOrderId": "human-tp", "side": "BUY", "positionSide": "SHORT",
        "price": "90000", "origQty": "0.0061", "status": "NEW", "executedQty": "0",
        "avgPrice": "0", "reduceOnly": True}
    return g, ex, px, regime, notifications, folder


def qty(ex, side="SHORT"):
    return next(float(p["size"]) for p in ex.futures_positions() if p["side"] == side)


def rows(folder):
    return [json.loads(x) for x in (folder / "j.jsonl").read_text(encoding="utf-8").splitlines()]


def filled_before_release(lost=False):
    name = "filled_lost" if lost else "filled_ack"
    g, ex, px, regime, notices, folder = make(name)
    real_market = ex.place_market
    if lost:
        def market(*a, **kw):
            real_market(*a, **kw)
            raise TimeoutError("exchange executed; response lost")
        ex.place_market = market
    regime["up"] = True
    g.tick()  # Exchange has filled; intent durably exists; fill is not yet reconciled.
    market_id = next(k for k, o in ex.orders.items() if o.get("type") == "MARKET")
    flatten_before = dict(g.st["SHORT"]["flatten"])
    assert qty(ex) == .0061
    g.cfg.update(sides=["LONG"], release_sides=["SHORT"])
    g.tick()
    # Restart and several ticks: released side remains skipped, including its market intent.
    g2 = eg.Grid(ex, g.cfg, state_path=folder / "st.json", journal_path=folder / "j.jsonl",
                 now_fn=g.now, regime_fn=g.regime_fn, send_fn=notices.append)
    for _ in range(5):
        g2.tick()
    hands = [r for r in rows(folder) if r.get("kind") == "передано оператору"]
    assert len(hands) == 1 and float(hands[0]["qty"]) == .0084
    assert g2.st["SHORT"]["lots"] == [] and g2.st["SHORT"].get("flatten")
    assert g2.st["SHORT"]["realized"] == 0
    expected_close_pnl = -.0084 * (float(ex.orders[market_id]["avgPrice"]) - 100200)
    missed_fee = float(ex.trades[market_id][0]["commission"])
    assert market_id not in g2.st["SHORT"]["fee_book"]
    assert ex.orders["manual_tp"]["status"] == "NEW"
    return {"flatten_before": flatten_before, "actual_remaining_short": qty(ex),
            "handoff_announced_qty": float(hands[0]["qty"]), "manual_existing_qty": .0061,
            "actual_bot_qty_remaining": 0, "missed_market_pnl_usd": expected_close_pnl,
            "missed_market_fee_usd": missed_fee, "flatten_survives_restart": True,
            "manual_tp_untouched": True, "market_close_journal_rows":
            len([r for r in rows(folder) if r.get("kind") == "закрытие по режиму"])}


class DelayedMarket(eg.DryExchange):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.delayed = {}

    def place_market(self, symbol, side, position_side, qty, cid, reduce_only=False):
        self.n += 1
        oid = f"accepted{self.n}"
        self.delayed[oid] = {"clientOrderId": cid, "side": side, "positionSide": position_side,
            "price": "0", "origQty": qty, "status": "PENDING", "executedQty": "0", "avgPrice": "0",
            "reduceOnly": reduce_only, "type": "MARKET"}
        return {"success": True, "orderId": oid, "clientOrderId": cid}

    def order_info(self, oid):
        if str(oid) in self.delayed:
            return {"orderId": str(oid), **self.delayed[str(oid)]}
        return super().order_info(oid)

    def execute(self, oid):
        o = self.delayed.pop(oid)
        bid, ask = self.book_fn()
        px = ask if o["side"] == "BUY" else bid
        q = min(float(o["origQty"]), qty(self, o["positionSide"]))
        o.update(price=str(px), status="FILLED", executedQty=f"{q:.4f}", avgPrice=str(px))
        self.orders[oid] = o
        self.trades[oid] = [{"id": f"t{oid}", "orderId": oid, "commission": str(q * px * .00048),
                            "maker": False, "price": str(px), "qty": str(q), "time": int(self.now_fn()*1000)}]


def delayed_release():
    g, ex, px, regime, notices, folder = make("delayed", DelayedMarket)
    regime["up"] = True
    g.tick()
    oid = g.st["SHORT"]["flatten"]["id"]
    assert ex.order_info(oid)["status"] == "PENDING"
    assert qty(ex) == .0145
    g.cfg.update(sides=["LONG"], release_sides=["SHORT"])
    g.tick()
    hand = next(r for r in rows(folder) if r.get("kind") == "передано оператору")
    before = qty(ex)
    assert float(hand["qty"]) == .0084
    # Market is already accepted and never cancelled/resolved by release; later executes.
    ex.execute(oid)
    g.tick()
    assert qty(ex) == .0061 and g.st["SHORT"].get("flatten")
    return {"assumption": "accepted MARKET detail queryable, not yet in open_orders/history",
            "short_at_handoff": before, "announced_handoff_qty": float(hand["qty"]),
            "short_after_prior_bot_market_fills": qty(ex), "transferred_qty_later_closed": .0084,
            "manual_tp_untouched": ex.orders["manual_tp"]["status"] == "NEW"}


def normal_restart_pending_fee():
    g, ex, px, regime, notices, folder = make("normal")
    tp_id = g.st["SHORT"]["lots"][0]["tp_order"]["id"]
    ex.orders[tp_id].update(status="PARTIALLY_FILLED", executedQty="0.0004", avgPrice=ex.orders[tp_id]["price"])
    # Exchange cancellation confirms the partial remainder is cancelled; trade rows initially lag.
    real_cancel = ex.cancel
    def cancel(oid):
        if str(oid) == tp_id:
            ex.orders[tp_id]["status"] = "CANCELED"
            return {"success": True, "orderId": oid}
        return real_cancel(oid)
    ex.cancel = cancel
    g.cfg.update(sides=["LONG"], release_sides=["SHORT"])
    g.tick()
    hands = [r for r in rows(folder) if r.get("kind") == "передано оператору"]
    assert len(hands) == 1 and float(hands[0]["qty"]) == .008
    fees_before = g.st["SHORT"]["fees"]
    late_fee = .0004 * float(ex.orders[tp_id]["price"]) * .00016
    ex.trades[tp_id] = [{"commission": str(late_fee), "maker": True}]
    g2 = eg.Grid(ex, g.cfg, state_path=folder / "st.json", journal_path=folder / "j.jsonl",
                 now_fn=g.now, regime_fn=g.regime_fn, send_fn=notices.append)
    for _ in range(5):
        g2.tick()
    assert abs((g2.st["SHORT"]["fees"] - fees_before) - late_fee) < 1e-12
    assert not g2.st["SHORT"]["lots"] and not g2.st["SHORT"]["entry"]
    assert ex.orders["manual_tp"]["status"] == "NEW"
    assert len([r for r in rows(folder) if r.get("kind") == "передано оператору"]) == 1
    return {"announced_qty_after_partial_tp": .008, "late_fee_settled_after_restart": late_fee,
            "duplicate_handoffs": 0, "manual_tp_untouched": True, "new_short_entries": 0}


def empty_detail_release():
    g, ex, px, regime, notices, folder = make("empty_detail")
    tp_id = g.st["SHORT"]["lots"][0]["tp_order"]["id"]
    real_info, real_cancel = ex.order_info, ex.cancel
    def cancel(oid):
        if str(oid) == tp_id:
            # Failed DELETE, returned JSON rather than raised exception, is ignored by _cancel.
            return {"success": False, "errorCode": "TEMPORARILY_UNAVAILABLE"}
        return real_cancel(oid)
    def detail(oid):
        if str(oid) == tp_id:
            # HTTP 200 empty/error payload: client.order_info does no schema validation.
            return {}
        return real_info(oid)
    ex.cancel, ex.order_info = cancel, detail
    g.cfg.update(sides=["LONG"], release_sides=["SHORT"])
    g.tick()
    hand = next(r for r in rows(folder) if r.get("kind") == "передано оператору")
    assert float(hand["qty"]) == .0084 and ex.orders[tp_id]["status"] == "NEW"
    assert not g.st["SHORT"]["lots"]
    # Operator trusts "bot orders removed" and closes then reopens the handed position.
    # Now every SHORT unit is manual, but the old bot TP is still live.
    for oid, side, red in (("human_close_transferred", "BUY", True), ("human_new_short", "SELL", False)):
        ex.orders[oid] = {"clientOrderId": oid, "side": side, "positionSide": "SHORT", "price": "100260",
            "origQty": "0.0084", "status": "FILLED", "executedQty": "0.0084", "avgPrice": "100260",
            "reduceOnly": red}
    before = qty(ex)
    px.mid = float(ex.orders[tp_id]["price"]) - 1
    g.tick()
    after = qty(ex)
    assert ex.orders[tp_id]["status"] == "FILLED" and abs(before-after-.0084) < 1e-12
    assert not any(r.get("order_id") == tp_id for r in rows(folder))
    return {"assumption": "cancel returns rejection, order_info returns HTTP-200 empty/error JSON",
            "handoff_announced_qty": float(hand["qty"]), "bot_tp_still_live_after_handoff": True,
            "manual_short_before_old_bot_tp": before, "manual_short_after_old_bot_tp": after,
            "old_bot_tp_closed_manual_qty": before-after, "tp_fill_never_journaled": True}


def standard_pending_guards():
    g, ex, px, regime, notices, folder = make("pending_adopted")
    cid = "b7gBSe_pending_entry"
    r = ex.place_limit("BTCUSDT", "SELL", "SHORT", "0.0012", "102000", cid)
    oid = r["orderId"]
    ex.orders[oid].update(status="FILLED", executedQty="0.0012", avgPrice="102000")
    now = g.now()
    g.st["SHORT"]["pending"] = {"cid": cid, "kind": "e", "qty": "0.0012", "price": 102000,
                                  "t": now, "srv": now}
    g.cfg.update(sides=["LONG"], release_sides=["SHORT"])
    g.tick()
    hand = next(r for r in rows(folder) if r.get("kind") == "передано оператору")
    assert float(hand["qty"]) == .0096
    assert not g.st["SHORT"]["pending"] and not g.st["SHORT"]["entry"]

    g, ex, px, regime, notices, folder = make("pending_incomplete")
    now = g.now() - 1000
    g.st["SHORT"]["pending"] = {"cid": "b7gBSe_not_found", "kind": "e", "qty": "0.0012",
                                  "price": 102000, "t": now, "srv": now}
    ex.order_history = lambda *a, **k: [{"orderId": f"dummy{i}", "clientOrderId": f"human{i}"}
                                       for i in range(100)]
    g.cfg.update(sides=["LONG"], release_sides=["SHORT"])
    for _ in range(3):
        g.tick()
    assert g.st["SHORT"]["pending"] and g.st["SHORT"]["lots"]
    assert not any(r.get("kind") == "передано оператору" for r in rows(folder))
    assert len([n for n in notices if "история слишком плотная" in n]) == 1
    return {"found_filled_entry_included_in_handoff_qty": .0096,
            "incomplete_history_pending_retained": True, "handoff_blocked_while_unknown": True,
            "incomplete_history_warnings": 1}


if __name__ == "__main__":
    out = {"source_sha": "5dc2d7eee1897b1fd83906128c20b38d7604df07",
           "filled_ack_before_release": filled_before_release(False),
           "filled_lost_reply_before_release": filled_before_release(True),
           "delayed_market_at_release": delayed_release(),
           "normal_release_restart_late_fee": normal_restart_pending_fee(),
           "empty_order_detail_at_release": empty_detail_release(),
           "standard_pending_guards": standard_pending_guards()}
    (BASE / "release_probe_results.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=2))
