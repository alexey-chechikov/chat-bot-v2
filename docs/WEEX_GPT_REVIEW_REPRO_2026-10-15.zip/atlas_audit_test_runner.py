"""Run pinned offline Atlas unit tests with networking prohibited; no live code imports."""
import os,socket,sys,types,urllib.request
from pathlib import Path
HERE=Path(__file__).resolve().parent
SNAP=HERE/'snapshot'
sys.dont_write_bytecode=True
sys.path.insert(0,str(SNAP))
tests=types.ModuleType('tests');tests.__path__=[str(SNAP/'tests')];sys.modules['tests']=tests
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
def denied(*a,**k):raise AssertionError('Network prohibited in audit')
socket.create_connection=denied
urllib.request.urlopen=denied
import pytest
raise SystemExit(pytest.main([str(SNAP/'tests/research_atlas'),'-q','-p','no:cacheprovider',
                             '--basetemp',str(HERE/'atlas_pytest_temp')]))
