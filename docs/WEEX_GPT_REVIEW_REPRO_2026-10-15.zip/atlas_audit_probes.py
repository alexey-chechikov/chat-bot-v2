"""Offline counterexamples against pinned public Atlas functions. Synthetic, no market/API calls."""
from pathlib import Path
import contextlib,io
from types import SimpleNamespace
import json,sys
import numpy as np
import pandas as pd

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
SNAP=HERE/'snapshot'
sys.path[:0]=[str(SNAP/'research/atlas_data'),str(SNAP/'research/gold')]
import delta_test1 as d1
import delta_test2 as d2
import footprint_bars as fb
import footprint_test as ft
import sweep_backtest as sb
import fetch_aggtrades_daily as fetch_agg


def duplicate_minute_probe():
    t=np.arange(1440,dtype=np.int64)*sb.MIN
    t[17]=t[16]  # one duplicate plus one missing minute in the same 15m group
    a={k:np.full(1440,100.) for k in ('open','high','low','close')}
    a.update(ts=t,volume=np.ones(1440),taker_buy=np.full(1440,.5))
    m=sb.Market(a,'BTCUSDT_UM',False)
    return {'data':'synthetic','unique_minutes':int(len(np.unique(t))), 'rows':len(t),
            'missing_minutes_report_formula':int((t[-1]-t[0])//sb.MIN+1-len(t)),
            'complete_days_accepted':len(m.complete_days),'full_15m_bars_accepted':len(m.b_id),
            'invalid_15m_group_accepted':bool(1 in m.b_id)}


def random_control_overlap_probe():
    original=np.random.default_rng
    draws=[]
    class Recorder:
        def __init__(self):self.rng=original(21)
        def choice(self,*args,**kwargs):
            out=self.rng.choice(*args,**kwargs);draws.append(np.array(out,copy=True));return out
    try:
        np.random.default_rng=lambda seed:Recorder()
        # Same three physical bars offered separately LONG/SHORT, as run_rule/evaluate do.
        keys=np.array([-100]*3+[100]*3)
        values=np.array([-.01,0,.01,.01,0,-.01])
        means,_=d1.matched_means(keys,values,np.array([-100,100]),999,21)
    finally:np.random.default_rng=original
    short=np.array([int(x[0]) for x in draws[:999]])
    long=np.array([int(x[0]) for x in draws[999:]])
    return {'data':'synthetic; actual matched_means draw calls recorded',
            'draws':999,'same_physical_bar_long_and_short':int((short==long).sum()),
            'expected_probability':1/3,
            'model_constraint':'one position per symbol cannot execute simultaneous opposite trades',
            'rank_calculated_despite_unexecutable_controls':d1.ctl_rank(.005,means)[0]}


def body_open_sensitivity():
    # Tiny open mismatch flips F's candle-color predicate while delta, close and wick remain fixed.
    common={'wl':np.array([-.11]),'wu':np.array([0.]),'p10':np.array([-.10]),'p90':np.array([.10]),
            'b_c':np.array([100.])}
    one=ft.f_signal(SimpleNamespace(**common,b_o=np.array([99.99])))[0]
    two=ft.f_signal(SimpleNamespace(**common,b_o=np.array([100.01])))[0]
    return {'data':'synthetic; fixed close and all delta features',
            'open_A':99.99,'open_B':100.01,'close':100.,'F_signal_A':int(one[0]),'F_signal_B':int(two[0]),
            'meaning':'Small open discrepancy is not sufficient evidence that the threshold/color signal is unchanged'}


def aggregate_correlation_not_incremental_edge():
    # Distinct feature / limited overlap cannot measure returns of exclusive new signals without that ledger.
    f=np.array([1,1,0,0,1,0,-1,-1,0,0])
    t=np.array([1,0,1,0,0,0,-1,0,-1,0])
    return ft.overlap(f,t,np.array([1]*6+[0]*4,dtype=bool),np.array([0]*6+[1]*4,dtype=bool))


def controls_price_only_confounder():
    # A toy price-only red/green-bar reversal explains all return differences; delta adds nothing.
    price_down=np.r_[np.ones(100,dtype=bool),np.zeros(100,dtype=bool)]
    next_return=np.where(price_down,.001,-.001)
    key=np.zeros(200,dtype=int)
    selected=next_return[:20]    # all selected LONGs are red bars, as real 'same' LONGs necessarily are
    unmatched,_=d1.matched_means(key,next_return,np.zeros(20,dtype=int),999,21)
    price_matched,_=d1.matched_means(key[price_down],next_return[price_down],np.zeros(20,dtype=int),999,21)
    return {'data':'synthetic; returns depend only on candle color, not delta',
            'selected_mean':float(selected.mean()),
            'current_control_rank':d1.ctl_rank(float(selected.mean()),unmatched)[0],
            'color_matched_control_rank':d1.ctl_rank(float(selected.mean()),price_matched)[0],
            'meaning':'Low current control rank cannot isolate incremental information of delta from price-bar reversal'}


def cached_zip_validation_probe():
    root=HERE/'atlas_cached_zip_probe'
    path=root/'backtests/aggtrades/TESTUSDT/TESTUSDT-aggTrades-2026-01-01.zip'
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b'not a valid zip')
    old_root,old_get,old_args=fetch_agg.ROOT,fetch_agg.get,sys.argv
    calls=[]
    def denied(url):calls.append(url);raise AssertionError('No network allowed')
    try:
        fetch_agg.ROOT=root;fetch_agg.get=denied;sys.argv=['fetch','TESTUSDT','2026-01-01','2026-01-01']
        buf=io.StringIO()
        with contextlib.redirect_stdout(buf):fetch_agg.main()
    finally:fetch_agg.ROOT,fetch_agg.get,sys.argv=old_root,old_get,old_args
    return {'data':'synthetic existing invalid archive','network_calls':len(calls),
            'actual_main_output':buf.getvalue(),
            'cached_file_checksum_revalidated':False}


def exclusive_subset_mean_probe():
    n,n_overlap,n_new=190,36,154
    overall=-.00007;new=.0005
    shared=(n*overall-n_new*new)/n_overlap
    return {'data':'synthetic mixture, not an identified real exclusive F ledger',
            'n':n,'n_overlap':n_overlap,'n_new':n_new,'overall_gross_pct':100*overall,
            'new_subset_gross_pct':100*new,'overlap_subset_gross_pct':100*shared,
            'weighted_mean_pct':100*(n_new*new+n_overlap*shared)/n,
            'meaning':'The overall F mean and overlap rate do not identify the mean of exclusive new signals'}


def published_arithmetic():
    # Values as printed in documents. Tolerances include rounding each component.
    rows=[('BTC div',927,-.150,587,-.152,340,-.146),('ETH div',929,-.151,569,-.133,360,-.180),
          ('BTC same',8430,-.126,5831,-.130,2599,-.117),('ETH same',8528,-.124,5944,-.121,2584,-.131),
          ('BTC A',409,-.145,291,-.147,118,-.142),('BTC B',224,-.070,163,-.084,61,-.034),
          ('BTC Cn',4,.046,3,.389,1,-.983),('BTC En',13,.480,8,.520,5,.415),
          ('ETH A',398,-.123,280,-.150,118,-.059),('ETH B',208,-.060,149,-.041,59,-.109),
          ('ETH Cn',6,.130,2,.225,4,.082),('ETH En',7,.104,6,.287,1,-.998),
          ('BTC F',190,-.143,125,-.099,65,-.228),('ETH F',169,-.122,121,-.095,48,-.189)]
    checks=[{'name':name,'n':n,'split_count_ok':na+nb==n,'weighted_mean_delta':(na*a+nb*b)/n-mean,
             'within_rounding':abs((na*a+nb*b)/n-mean)<=.0010000001}
            for name,n,mean,na,a,nb,b in rows]
    return {'split_rows':checks,'all_splits_pass':all(x['within_rounding'] and x['split_count_ok'] for x in checks),
            'footprint_half_cost':.136/2,'BTC_F_gross_upper':.063,'ETH_F_gross_upper':.069,
            'ETH_upper_less_than_half_cost':.069<.136/2,
            'ETH_upper_fraction_of_roundtrip_cost':.069/.136,
            'Cn_rank_BTC':(359+1)/(999+1),'Cn_rank_ETH':(337+1)/(999+1),
            'F_rank_BTC':(608+1)/(999+1),'F_rank_ETH':(340+1)/(999+1),
            'F_overlap_BTC':36/234,'F_overlap_ETH':41/214}


def main():
    out={'pin':'e1fe76a50c226872de6831edaa23c2ef3f30f466','data':'synthetic / published arithmetic only; no empirical replay',
         'duplicate_minutes':duplicate_minute_probe(),'random_control_overlap':random_control_overlap_probe(),
         'open_sensitivity':body_open_sensitivity(),'published_arithmetic':published_arithmetic(),
         'delta_incremental_control':controls_price_only_confounder(),
         'cached_archive_validation':cached_zip_validation_probe(),
         'exclusive_subset_mean':exclusive_subset_mean_probe(),
         'baseline_candidate_rank_gap':d1.atlas_status(200,.01,.01,.005,.008,None),
         'flat_price_roundtrip_cost':float(d1.trade_return(100.,100.,1.,d1.SLIP,d1.TAKER)),
         'funding_policy':{sym:sb.INST[sym]['funding_file'] for sym in d1.SYMS.values()}}
    assert out['duplicate_minutes']['complete_days_accepted']==1
    assert out['duplicate_minutes']['full_15m_bars_accepted']==96
    assert out['random_control_overlap']['same_physical_bar_long_and_short']>0
    assert out['open_sensitivity']['F_signal_A']!=out['open_sensitivity']['F_signal_B']
    assert out['published_arithmetic']['all_splits_pass']
    path=HERE/'atlas_audit_probe_results.json'
    path.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(out,ensure_ascii=True,indent=2))


if __name__=='__main__':main()
