"""Reconcile every saved ledger and produce a readable fixed-protocol report."""
from datetime import datetime, timezone
import json
from pathlib import Path

import numpy as np
import pandas as pd

from replay import ROOT, B15, H4, PROTOCOL, SCENARIOS, iso, save_json, session_key, sha


def fmt(x, digits=3, percent=False):
    if x is None:
        return "—"
    return f"{x * (100 if percent else 1):.{digits}f}" + ("%" if percent else "")


def ci(x, percent=False):
    return "—" if x is None else f"[{fmt(x[0], percent=percent)}; {fmt(x[1], percent=percent)}]"


def main():
    summary = json.loads((ROOT / "summary.json").read_text(encoding="utf-8"))
    manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
    tests = json.loads((ROOT / "test_results.json").read_text(encoding="utf-8"))
    checks = []
    loaded = {}
    for key, result in summary["results"].items():
        d = pd.read_csv(ROOT / f"ledger_{key}.csv")
        loaded[key] = d
        if len(d):
            side = d.side.to_numpy(float)
            e, x, sl, tp = (d[k].to_numpy(float) for k in ("entry_actual", "exit_actual", "stop", "tp"))
            w = d.stop_fraction.to_numpy(float)
            f = d.fee_rate.to_numpy(float)
            net = side * (x - e) / e - f * (1 + x / e) - d.funding_signed_cost.to_numpy(float)
            assert np.max(abs(net - d.net_return)) < 1e-12, key
            assert np.max(abs(net / w - d.net_R)) < 1e-12, key
            assert np.max(abs(side * (e - sl) / e - w)) < 1e-12, key
            assert np.max(abs(tp - (e + side * 2 * abs(e - sl)))) < 1e-8, key
            assert np.all((w >= .005 - 1e-12) & (w <= .015 + 1e-12)), key
            assert np.all(d.entry_ts == d.confirm_ts + B15), key
            assert np.all((d.confirm_ts - d.signal_ts >= B15) & (d.confirm_ts - d.signal_ts <= 3 * B15)), key
            assert np.all(d.exit_ts <= d.entry_ts + H4), key
            assert np.all(abs(d.entry_raw - d.confirm_close) <= .1 * d.atr + 1e-10), key
            assert d.episode_id.is_unique, key
            ordered = d.sort_values("entry_ts")
            assert np.all(ordered.entry_ts.to_numpy()[1:] >= ordered.exit_ts.to_numpy()[:-1]), key
            if key.startswith("P1"):
                assert np.all(d.trend_bar_end <= d.signal_ts + B15), key
            else:
                days = []
                for r in d.itertuples():
                    day, wd, minute = session_key(r.signal_ts)
                    _, _, cminute = session_key(r.confirm_ts + B15)
                    assert wd < 5 and 600 <= minute < 690 and cminute <= 690
                    assert r.side * ((r.or_high if r.side == 1 else r.or_low) - r.tp) >= -1e-8
                    days.append(day)
                assert len(set(days)) == len(days)
            for r in d.itertuples():
                events = json.loads(r.funding_details)
                assert len(events) == r.funding_count
                assert all(r.entry_ts < z["ts"] <= r.exit_ts for z in events)
                assert abs(sum(z["signed_cost"] for z in events) - r.funding_signed_cost) < 1e-12
                for z in events:
                    assert abs(z["signed_cost"] - r.side / r.entry_actual * z["mark"] * z["rate"]) < 1e-12
                if r.reason == "TP":
                    assert abs(r.exit_raw - r.tp) < 1e-8
                if r.reason == "SL":
                    assert abs(r.exit_raw - r.stop) < 1e-8
            assert abs(float(d.net_return.mean()) - result["all"]["mean_net_return"]) < 1e-12
            assert abs(float(d.net_R.mean()) - result["all"]["mean_net_R"]) < 1e-12
            positives = d.loc[d.net_return > 0, "net_return"].sum()
            negatives = -d.loc[d.net_return < 0, "net_return"].sum()
            assert abs(float(positives / negatives) - result["all"]["PF"]) < 1e-12
            assert len(d) == result["all"]["n"] + result["all"]["censored"]
        else:
            assert result["all"]["n"] == 0 and result["all"]["mean_net_R"] is None
        assert result["first70"]["n"] + result["last30_diagnostic_not_OOS"]["n"] == result["all"]["n"]
        assert sum(m["n"] for m in result["monthly"].values()) == result["all"]["n"]
        assert sum(w["n"] for w in result["weekly_block_CI"]["weekly"]) == result["all"]["n"]
        checks.append({"key": key, "ledger_rows": len(d), "reconciled": True})
    unchanged = []
    for source in manifest["inputs"]:
        for kind in ("minute", "funding"):
            assert sha(Path(source[f"{kind}_path"])) == source[f"{kind}_sha256"]
            unchanged.append(source[f"{kind}_path"])
    assert sha(PROTOCOL) == summary["protocol_sha256"] == manifest["protocol_sha256"]
    assert sha(ROOT / "replay.py") == manifest["implementation_sha256"]
    assert tests["successful"]
    matched = {}
    for strategy in ("P1", "P2"):
        for symbol in ("BTCUSDT", "ETHUSDT"):
            b = loaded[f"{strategy}_{symbol}_base"]
            s = loaded[f"{strategy}_{symbol}_stress"]
            ids = set(b.episode_id) & set(s.episode_id)
            br, sr = b[b.episode_id.isin(ids)], s[s.episode_id.isin(ids)]
            matched[f"{strategy}_{symbol}"] = {"n_matched": len(ids),
                "base_matched_mean_net_return": float(br.net_return.mean()) if len(br) else None,
                "stress_matched_mean_net_return": float(sr.net_return.mean()) if len(sr) else None,
                "base_matched_mean_net_R": float(br.net_R.mean()) if len(br) else None,
                "stress_matched_mean_net_R": float(sr.net_R.mean()) if len(sr) else None}
    summary["matched_stress_diagnostic"] = matched
    save_json(ROOT / "summary.json", summary)
    reconciliation = {"all_passed": True, "ledger_checks": checks, "input_files_unchanged": unchanged,
                      "protocol_and_replay_hashes_match": True, "synthetic_tests": tests["tests_run"]}
    save_json(ROOT / "reconciliation.json", reconciliation)
    # Refresh the preflight provenance from the authoritative finished manifest.
    save_json(ROOT / "preflight.json", manifest["inputs"])

    lines = ["# P1/P2 — фиксированный офлайн-пилот 15m", "",
        "P1 в этом screening дал отрицательное среднее на BTC и ETH во всех трёх сценариях расходов. P2 не создал ни одной сделки после всех заданных фильтров. Положительного ожидания не установлено. Параметры не менялись и прибыльные варианты не подбирались.", "",
        "Это два отдельных прогона по каждому символу с единичным начальным номиналом сделки. Здесь **не** симулировались капитализация equity, qtyStep/minQty, размер риска 0,25%, дневной equity-бюджет 0,75% и общий запрет одновременного BTC/ETH. Результат не является доходностью счёта, проверкой ручного RM или разрешением на живого бота.", "",
        "## Источники и проверка", "",
        "Native Binance USD-M futures: 07.05.2026 00:00 — 06.10.2026 00:00 UTC (последняя минута 05.10 23:59), 152 дня. На каждом символе 218 880 уникальных минут, 14 592 полных 15m и 912 полных 4h. Пропусков, дублей и повреждённых OHLC нет. Funding проверен по номинальной 8h-сетке, пропусков нет; сохранены точные timestamps с миллисекундным джиттером и markPrice источника.", "",
        f"Все {tests['tests_run']} синтетических тестов прошли. Все 12 ledger сверены по fills, next open, drift/width, TP2R, fees/funding/net/R, отсутствию пересечения позиций и суммам split/month/week. Четыре исходных CSV и протокол после расчёта имеют исходные SHA256. SHA, runtime и provenance — в manifest.json; результаты сверки — в reconciliation.json.", "",
        "Разрез календаря 70/30 — 21.08.2026 09:36 UTC. Эти данные проект уже использовал: это диагностический split, **не новая непросмотренная OOS-проверка**. Цены Binance — proxy для WEEX; реального WEEX execution и basis здесь нет.", "",
        "## Все четыре проверки и все сценарии", "",
        "Средний net % — доля единичного начального номинала сделки. R = net return / (расстояние actual entry→фиксированный SL / actual entry). PF считается по net P&L. Стресс меняет slipped entry, width-gate и target; низкая комиссия 0,01% — неподтверждённая гипотеза тарифа.", "",
        "| Стратегия | Символ | Сценарий | n | Средний net | Средний R | WR | PF | SL / TP / TIME |",
        "|---|---|---|---:|---:|---:|---:|---:|---|"
    ]
    for strategy in ("P1", "P2"):
        for symbol in ("BTCUSDT", "ETHUSDT"):
            for costs in SCENARIOS:
                a = summary["results"][f"{strategy}_{symbol}_{costs.name}"]["all"]
                reasons = a.get("reasons", {})
                labels = {"base": "fee 0,048%, slip 0,02%", "stress": "fee 0,048%, slip 0,04%", "manual_lowfee_unverified": "fee 0,01%*, slip 0,02%"}
                lines.append(f"| {strategy} | {symbol} | {labels[costs.name]} | {a['n']} | {fmt(a['mean_net_return'], percent=True)} | {fmt(a['mean_net_R'])} | {fmt(a['WR'], digits=1, percent=True)} | {fmt(a['PF'])} | {reasons.get('SL', 0)+reasons.get('SL_GAP', 0)} / {reasons.get('TP', 0)} / {reasons.get('TIME', 0)} |")
    lines += ["", "*Fee и slip указаны на каждую ногу. Во всех 12 прогонах цензурированных сделок и неоднозначных минут SL/TP — 0. Для P2 n=0 означает отсутствие измерения expectancy, а не нулевую доходность стратегии.", "",
        "## Почему P2 не торговал", "",
        "| Символ | Sweep-события | Подтверждения | Отмена новым экстремумом | Истёк срок | Width skip | Нет пространства 2R | Сделки |",
        "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for symbol in ("BTCUSDT", "ETHUSDT"):
        c = summary["results"][f"P2_{symbol}_base"]["counts"]
        lines.append(f"| {symbol} | {c.get('signal',0)} | {c.get('confirm',0)} | {c.get('cancel_new_extreme',0)} | {c.get('expire',0)} | {c.get('skip_stop_width',0)} | {c.get('skip_or_space',0)} | {c.get('entered',0)} |")
    lines += ["", "Эти причины одинаковы в трёх сценариях P2. Условия пространства до противоположной OR-границы и минимального stop-width 0,5% вместе отсеяли все подтверждения. Ослаблять фильтры после этого результата означало бы новую гипотезу; в пилоте этого не делали.", "",
        "## P1: частота и влияние сценария", "",
        "| Символ | Breakout-события | Ретесты | Width skip | Исполнено | Funding-события | Медиана width |",
        "|---|---:|---:|---:|---:|---:|---:|"]
    for symbol in ("BTCUSDT", "ETHUSDT"):
        r = summary["results"][f"P1_{symbol}_base"]
        a, c = r["all"], r["counts"]
        lines.append(f"| {symbol} | {c.get('signal',0)} | {c.get('confirm',0)} | {c.get('skip_stop_width',0)} | {a['n']} | {a['funding_events']} | {fmt(a['median_stop_fraction'], percent=True)} |")
    lines += ["", "В stress прошёл один дополнительный width-gate event на каждом символе. Поэтому общий stress-mean нельзя трактовать как чистое влияние издержек на неизменный набор сделок. На общих episode IDs:", "",
        "| Символ | Совпавшие сделки | Base mean net | Stress mean net | Base mean R | Stress mean R |",
        "|---|---:|---:|---:|---:|---:|"]
    for symbol in ("BTCUSDT", "ETHUSDT"):
        m = matched[f"P1_{symbol}"]
        lines.append(f"| {symbol} | {m['n_matched']} | {fmt(m['base_matched_mean_net_return'],percent=True)} | {fmt(m['stress_matched_mean_net_return'],percent=True)} | {fmt(m['base_matched_mean_net_R'])} | {fmt(m['stress_matched_mean_net_R'])} |")
    lines += ["", "Low-fee имеет те же entry/exit prices и episode IDs, что base. Все его полные средние остаются отрицательными. Партнёрская комиссия не подтверждена фактическими fills/зачислениями.", "",
        "## Диагностический 70/30 split", "",
        "| Стратегия | Символ | Сценарий | 70%: n / mean net / R | 30%: n / mean net / R |",
        "|---|---|---|---|---|"]
    for strategy in ("P1", "P2"):
        for symbol in ("BTCUSDT", "ETHUSDT"):
            for costs in SCENARIOS:
                r = summary["results"][f"{strategy}_{symbol}_{costs.name}"]
                parts = []
                for p in (r["first70"], r["last30_diagnostic_not_OOS"]):
                    parts.append(f"{p['n']} / {fmt(p['mean_net_return'],percent=True)} / {fmt(p['mean_net_R'])}")
                lines.append(f"| {strategy} | {symbol} | {costs.name} | {parts[0]} | {parts[1]} |")
    lines += ["", "## Weekly block CI", "",
        "9 999 bootstrap draws, seed 20261014. 23 календарные ISO-недели; пустые недели сохраняются отдельно от непустых clusters. Интервалы — диагностика на небольшой выборке, не свидетельство готовности торговать.", "",
        "| Стратегия | Символ | Сценарий | Непустых недель | 95% CI mean net, все недели | 95% CI mean R, все недели | CI mean R, непустые недели |",
        "|---|---|---|---:|---|---|---|"]
    for strategy in ("P1", "P2"):
        for symbol in ("BTCUSDT", "ETHUSDT"):
            for costs in SCENARIOS:
                w = summary["results"][f"{strategy}_{symbol}_{costs.name}"]["weekly_block_CI"]
                a, n = w["all_calendar_weeks"], w["nonempty_weeks"]
                lines.append(f"| {strategy} | {symbol} | {costs.name} | {w['nonempty_clusters']} | {ci(a['net_return_CI95'], True)} | {ci(a['net_R_CI95'])} | {ci(n['net_R_CI95'])} |")
    lines += ["", "При n=0 CI недоступен. При 7–10 непустых неделях и 11–13 сделках нельзя считать будущий средний результат точно установленным. P1 отрицателен в самом пилоте; оснований продвигать его в live нет.", "",
        "## Месяцы", "",
        "Все месяцы P1 приведены для всех сценариев. У P2 на обоих символах во всех сценариях и каждом месяце n=0; среднее/WR/PF недоступны. Май начинается 7-го числа, октябрь заканчивается 5-го.", "",
        "| Символ | Сценарий | Месяц | n | Mean net | Mean R | WR | PF |",
        "|---|---|---|---:|---:|---:|---:|---:|"]
    for symbol in ("BTCUSDT", "ETHUSDT"):
        for costs in SCENARIOS:
            for month, a in summary["results"][f"P1_{symbol}_{costs.name}"]["monthly"].items():
                lines.append(f"| {symbol} | {costs.name} | {month} | {a['n']} | {fmt(a['mean_net_return'],percent=True)} | {fmt(a['mean_net_R'])} | {fmt(a['WR'],digits=1,percent=True)} | {fmt(a['PF'])} |")
    lines += ["", "PF недоступен при отсутствии сделок или потерь, а не заменён искусственным большим числом. Единственный положительный месячный показатель/единичная stress-сделка не используется для отбора кандидата.", "",
        "## Просадка и материальные ограничения", "",
        "| Стратегия | Символ | Сценарий | Closed DD, п.п. | Closed+floating envelope DD, п.п. |",
        "|---|---|---|---:|---:|"]
    for strategy in ("P1", "P2"):
        for symbol in ("BTCUSDT", "ETHUSDT"):
            for costs in SCENARIOS:
                r = summary["results"][f"{strategy}_{symbol}_{costs.name}"]
                lines.append(f"| {strategy} | {symbol} | {costs.name} | {fmt(r['max_closed_dd_fixed_notional']*100)} | {fmt(r['max_closed_floating_dd_fixed_notional']*100)} |")
    lines += ["", "DD — процентные пункты накопленной fixed-notional кривой, **не процент реального счёта**. Floating использует консервативный intraminute envelope с границами SL/TP; OHLC не задаёт точный порядок всех промежуточных цен. На этих данных цензуры нет, но модель не превращается от этого в account replay.", "",
        "- Вход по next-minute open после закрытия подтверждения идеализирует доступность цены и задержку ручного решения. Slippage — сценарная константа, не измеренная очередь/ликвидность WEEX.",
        "- Millisecond fundingTime источника сохранён. Сам stop/TP известен только по минуте, поэтому точный порядок funding и intraminute exit внутри той же минуты требует сделок/исполнений. Boundary-конвенция и regression tests указаны в IMPLEMENTATION_ASSUMPTIONS.md.",
        "- EMA/ATR seed, политика отмены pending, окно P2, gap censorship и приоритет защитных ордеров документированы до расчёта. Это прозрачные разрешения неоднозначности протокола, а не адаптация к найденному плюсу.",
        "- Короткая ранее использованная история, малое n, корреляция BTC/ETH и четыре объявленные проверки ограничивают вывод. Не проводились перебор параметров, выбор прибыльной монеты или пересиживание убытков.",
        "- Только полноценная отдельная portfolio/WEEX execution проверка могла бы измерить заявленный manual risk-budget/qtyStep. Этот отрицательный screen её не заменяет и не даёт оснований менять работающий бот.", "",
        "Артефакты: summary.json (все 12 прогонов, месяцы, split, weekly counts/CI и причины), manifest.json (SHA/provenance), ledger_P1/P2_<symbol>_<scenario>.csv (включая пустые P2), events.csv, test_results.json, reconciliation.json. Код replay.py и test_replay.py воспроизводит этот screening только локально.", ""]
    (ROOT / "notes.md").write_text("\n".join(lines), encoding="utf-8")
    outputs = [p for p in ROOT.iterdir() if p.is_file() and p.name != "manifest.json"]
    manifest["outputs_sha256"] = {p.name: sha(p) for p in sorted(outputs)}
    manifest["finalized_utc"] = datetime.now(timezone.utc).isoformat()
    save_json(ROOT / "manifest.json", manifest)
    print(json.dumps({"reconciled_ledgers": len(checks), "synthetic_tests": tests["tests_run"], "notes": str(ROOT / "notes.md"),
                      "matched_stress": matched}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
