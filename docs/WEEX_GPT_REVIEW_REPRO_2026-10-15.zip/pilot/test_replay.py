"""Meaningful synthetic acceptance tests for the frozen P1/P2 pilot."""
from datetime import datetime, timezone
import json
import unittest

import numpy as np
import pandas as pd

from replay import (B15, H4, MIN, ROOT, Costs, Machine, aggregate_full, exit_at_minute,
                    features, funding_cost, opening_ranges, session_key, simulate)


def candles(n=241, value=100.0, start=0):
    return pd.DataFrame({k: np.full(n, value) for k in ("open", "high", "low", "close")},
                        index=np.arange(n, dtype=np.int64) * MIN + start)


def funding(events=()):
    return pd.DataFrame(events, columns=["ts", "markPrice", "fundingRate"]).set_index("ts")


def order(side=1, **extra):
    return {"strategy": "P1", "entry_ts": 0, "confirm_ts": -B15,
            "signal_ts": -2 * B15, "signal_id": "synthetic", "side": side,
            "atr": 1.0, "sl": 99.0 if side == 1 else 101.0,
            "confirm_close": 100.0, **extra}


def p1row(**extra):
    return {"open": 100., "high": 102., "low": 100., "close": 101., "atr": 1.,
            "trend": 1., "trend_bar_end": 0., "h20": 100., "l20": 95.,
            "prev_close": 99., "prev_h20": 100., "prev_l20": 95., "contiguous_prev": True, **extra}


def utc(s):
    return int(datetime.fromisoformat(s).replace(tzinfo=timezone.utc).timestamp() * 1000)


class ReplayTests(unittest.TestCase):
    def test_exact_15m_grid_rejects_duplicate_and_missing_minute(self):
        m = candles(15)
        self.assertEqual(len(aggregate_full(m, B15)), 1)
        self.assertEqual(len(aggregate_full(m.drop(7 * MIN), B15)), 0)
        duplicate = pd.concat([m.drop(7 * MIN), m.loc[[6 * MIN]]]).sort_index()
        self.assertEqual(len(aggregate_full(duplicate, B15)), 0)

    def test_full_4h_requires_240_unique_minutes(self):
        m = candles(240)
        self.assertEqual(len(aggregate_full(m, H4)), 1)
        self.assertEqual(len(aggregate_full(m.drop(57 * MIN), H4)), 0)
        self.assertEqual(len(aggregate_full(m.iloc[:-1], H4)), 0)

    def test_4h_ema_uses_closed_bar_and_never_future_close(self):
        ht = np.arange(52, dtype=np.int64) * H4
        hc = 100. + np.arange(52) * .01
        h = pd.DataFrame({k: hc.copy() for k in ("open", "high", "low", "close")}, index=ht)
        bt = np.arange(197 * 60 * MIN, 207 * 60 * MIN, B15, dtype=np.int64)
        b = pd.DataFrame({k: np.full(len(bt), 100.) for k in ("open", "high", "low", "close")}, index=bt)
        f = features(b, h)
        mutate = h.copy()
        mutate.loc[200 * 60 * MIN:, "close"] = 1.
        g = features(b, mutate)
        # At 201:00 UTC-relative, 200-204h has not completed yet.
        when = 201 * 60 * MIN - B15
        self.assertEqual(f.loc[when, "trend_bar_end"], 200 * 60 * MIN)
        self.assertEqual(f.loc[when, "trend"], g.loc[when, "trend"])
        self.assertEqual(f.loc[204 * 60 * MIN - B15, "trend_bar_end"], 204 * 60 * MIN)
        self.assertNotEqual(f.loc[204 * 60 * MIN - B15, "trend"], g.loc[204 * 60 * MIN - B15, "trend"])

    def test_donchian_excludes_current_and_future_bar(self):
        b = candles(30)
        b.index = np.arange(30, dtype=np.int64) * B15
        b.loc[20 * B15, "high"] = 1000.
        f = features(b, pd.DataFrame(columns=["open", "high", "low", "close"], index=pd.Index([], dtype="int64")))
        self.assertEqual(f.loc[20 * B15, "h20"], 100.)
        self.assertEqual(f.loc[21 * B15, "h20"], 1000.)
        b.loc[29 * B15, "high"] = 1e8
        g = features(b, pd.DataFrame(columns=["open", "high", "low", "close"], index=pd.Index([], dtype="int64")))
        self.assertEqual(f.loc[21 * B15, "h20"], g.loc[21 * B15, "h20"])

    def test_atr_resets_after_gap(self):
        b = candles(40)
        b.index = np.arange(40, dtype=np.int64) * B15
        b.high = 101.
        b.low = 99.
        b = b.drop(20 * B15)
        f = features(b, pd.DataFrame(columns=["open", "high", "low", "close"], index=pd.Index([], dtype="int64")))
        self.assertTrue(np.isnan(f.loc[21 * B15, "atr"]))
        self.assertTrue(np.isnan(f.loc[33 * B15, "atr"]))
        self.assertEqual(f.loc[34 * B15, "atr"], 2.)

    def test_p1_third_retest_allowed_fourth_expired(self):
        m = Machine("P1")
        self.assertIsNone(m.on_bar(0, p1row()))
        for i in (1, 2):
            self.assertIsNone(m.on_bar(i * B15, p1row(low=101.)))
        confirmed = m.on_bar(3 * B15, p1row(low=99.8, close=100.1))
        self.assertEqual(confirmed["entry_ts"], 4 * B15)
        self.assertAlmostEqual(confirmed["sl"], 99.7)
        m = Machine("P1")
        m.on_bar(0, p1row())
        for i in (1, 2, 3):
            m.on_bar(i * B15, p1row(low=101.))
        self.assertIsNone(m.pending)
        self.assertEqual(m.counts["expire"], 1)
        self.assertIsNone(m.on_bar(4 * B15, p1row(low=99.8, close=100.1)))

    def test_p1_freezes_atr_and_level_from_breakout(self):
        m = Machine("P1")
        m.on_bar(0, p1row())
        confirm = m.on_bar(B15, p1row(atr=100., h20=1000., low=99.8, close=100.1))
        self.assertEqual(confirm["atr"], 1.)
        self.assertEqual(confirm["level"], 100.)
        self.assertAlmostEqual(confirm["sl"], 99.7)

    def test_p1_invalid_close_or_opposite_trend_cancels(self):
        for r, counter in ((p1row(close=99.7), "cancel_price"), (p1row(trend=-1), "cancel_trend")):
            m = Machine("P1")
            m.on_bar(0, p1row())
            self.assertIsNone(m.on_bar(B15, r))
            self.assertIsNone(m.pending)
            self.assertEqual(m.counts[counter], 1)

    def test_pending_gap_cancels_instead_of_reaching_over_hole(self):
        m = Machine("P1")
        m.on_bar(0, p1row())
        m.on_bar(2 * B15, p1row(low=99.8, close=100.1))
        self.assertEqual(m.counts["cancel_data_gap"], 1)
        self.assertEqual(m.counts["confirm"], 0)

    def test_stop_first_same_minute_and_adverse_gap(self):
        reason, price, both = exit_at_minute(1, 100., 103., 98., 99., 102.)
        self.assertEqual((reason, price, both), ("SL", 99., True))
        self.assertEqual(exit_at_minute(1, 98., 104., 97., 99., 102.)[:2], ("SL_GAP", 98.))
        self.assertEqual(exit_at_minute(-1, 102., 104., 97., 101., 98.)[:2], ("SL_GAP", 102.))

    def test_tp_gap_only_credits_target(self):
        self.assertEqual(exit_at_minute(1, 105., 106., 104., 99., 102.)[:2], ("TP", 102.))
        self.assertEqual(exit_at_minute(-1, 95., 96., 94., 101., 98.)[:2], ("TP", 98.))

    def test_deadline_uses_open_not_later_minute_high_low(self):
        self.assertEqual(exit_at_minute(1, 100., 110., 90., 99., 102., True), ("TIME", 100., False))
        m = candles(241)
        m.loc[H4, ["high", "low"]] = [110., 90.]
        r, error, _ = simulate(order(), m, funding(), Costs("zero", 0., 0.))
        self.assertIsNone(error)
        self.assertEqual(r["reason"], "TIME")
        self.assertEqual(r["exit_ts"], H4)
        self.assertEqual(r["net_return"], 0.)

    def test_signed_funding_long_cost_short_credit(self):
        self.assertAlmostEqual(funding_cost(1, .01, 110., .01), .011)
        self.assertAlmostEqual(funding_cost(-1, .01, 110., .01), -.011)
        for side in (1, -1):
            m = candles(3)
            m.loc[MIN, "high" if side == 1 else "low"] = 102. if side == 1 else 98.
            r, _, _ = simulate(order(side), m, funding([(MIN, 110., .01)]), Costs("zero", 0., 0.))
            self.assertEqual(r["funding_count"], 1)
            self.assertAlmostEqual(r["net_return"], .02 - side * .011)

    def test_funding_boundary_entry_excluded_existing_exit_included(self):
        r, _, _ = simulate(order(), candles(241), funding([(0, 100., .01), (H4, 100., .01)]), Costs("zero", 0., 0.))
        self.assertEqual(r["funding_count"], 1)
        self.assertAlmostEqual(r["funding_signed_cost"], .01)
        self.assertAlmostEqual(r["net_return"], -.01)

    def test_settlement_after_open_gap_exit_not_charged(self):
        m = candles(3)
        m.loc[MIN, ["open", "high", "low", "close"]] = [98., 98., 98., 98.]
        r, _, _ = simulate(order(), m, funding([(MIN + 1, 100., .01)]), Costs("zero", 0., 0.))
        self.assertEqual(r["reason"], "SL_GAP")
        self.assertEqual(r["funding_count"], 0)

    def test_missing_funding_coverage_censors_not_zero_cost(self):
        f = funding()
        f.attrs["missing_nominal_settlements"] = [MIN]
        r, _, _ = simulate(order(), candles(4), f, Costs("zero", 0., 0.))
        self.assertEqual(r["reason"], "CENSORED_FUNDING_COVERAGE")
        self.assertIsNone(r["net_return"])
        m = candles(4)
        m.loc[0, "high"] = 102.
        r, _, _ = simulate(order(), m, f, Costs("zero", 0., 0.))
        self.assertEqual(r["reason"], "TP")

    def test_exit_minute_drawdown_envelope_is_bounded_before_exit(self):
        m = candles(2)
        m.loc[0, ["high", "low"]] = [101., 98.5]
        r, _, points = simulate(order(), m, funding(), Costs("zero", 0., 0.))
        self.assertEqual(r["reason"], "SL")
        self.assertAlmostEqual(max(points), .01)
        self.assertAlmostEqual(max(points) - min(points), .02)
        m.loc[0, ["open", "high", "low", "close"]] = [98., 200., 97., 100.]
        # Reuse the ordinary entry, put the gap on minute 1 instead.
        m.loc[0, :] = 100.
        m.loc[MIN, ["open", "high", "low", "close"]] = [98., 200., 97., 100.]
        r, _, points = simulate(order(), m, funding(), Costs("zero", 0., 0.))
        self.assertEqual(r["reason"], "SL_GAP")
        self.assertLessEqual(max(points), 0.)

    def test_gap_censored_but_earlier_exit_retained(self):
        m = candles(5).drop(2 * MIN)
        r, _, _ = simulate(order(), m, funding(), Costs("zero", 0., 0.))
        self.assertEqual(r["reason"], "CENSORED_GAP")
        self.assertIsNone(r["net_return"])
        m.loc[MIN, "high"] = 102.
        r, _, _ = simulate(order(), m, funding(), Costs("zero", 0., 0.))
        self.assertEqual(r["reason"], "TP")
        self.assertAlmostEqual(r["net_return"], .02)

    def test_eof_censored_no_free_close(self):
        r, _, _ = simulate(order(), candles(4), funding(), Costs("zero", 0., 0.))
        self.assertEqual(r["reason"], "CENSORED_EOF")
        self.assertIsNone(r["exit_actual"])
        self.assertIsNone(r["net_R"])

    def test_missing_next_open_and_drift_skip(self):
        self.assertEqual(simulate(order(), candles(2, start=MIN), funding(), Costs("zero", 0., 0.))[1], "skip_missing_entry")
        self.assertEqual(simulate(order(), candles(2, value=100.2), funding(), Costs("zero", 0., 0.))[1], "skip_drift")

    def test_stop_width_gate_and_stress_recomputes_entry_tp(self):
        self.assertEqual(simulate(order(sl=99.9), candles(), funding(), Costs("zero", 0., 0.))[1], "skip_stop_width")
        base, _, _ = simulate(order(), candles(), funding(), Costs("base", .00048, .0002))
        stress, _, _ = simulate(order(), candles(), funding(), Costs("stress", .00048, .0004))
        self.assertNotEqual(base["entry_actual"], stress["entry_actual"])
        self.assertNotEqual(base["tp"], stress["tp"])
        self.assertAlmostEqual(base["tp"], base["entry_actual"] + 2 * base["distance"])
        self.assertAlmostEqual(stress["tp"], stress["entry_actual"] + 2 * stress["distance"])

    def test_ny_dst_changes_utc_or_start(self):
        winter, summer = utc("2026-01-08T14:30:00"), utc("2026-07-08T13:30:00")
        self.assertEqual(session_key(winter)[2], 570)
        self.assertEqual(session_key(summer)[2], 570)
        self.assertEqual(session_key(utc("2026-03-06T14:30:00"))[2], 570)
        self.assertEqual(session_key(utc("2026-03-09T13:30:00"))[2], 570)
        self.assertEqual(session_key(utc("2026-11-02T14:30:00"))[2], 570)

    def test_or_requires_both_closed_bars(self):
        t = utc("2026-05-08T13:30:00")
        bars = pd.DataFrame({"open": [100., 100.], "high": [106., 105.], "low": [101., 100.], "close": [100., 100.]}, index=[t, t + B15])
        self.assertEqual(opening_ranges(bars)["2026-05-08"][:2], (106., 100.))
        self.assertEqual(opening_ranges(bars.iloc[:1]), {})

    def test_p2_new_low_cancels_even_if_close_would_confirm(self):
        t = utc("2026-05-08T14:00:00")
        m = Machine("P2", {"2026-05-08": (106., 100., t + 90 * MIN)})
        m.on_bar(t, p1row(low=99.8, high=101., close=100.1))
        self.assertIsNone(m.on_bar(t + B15, p1row(low=99.7, high=102., close=101.2)))
        self.assertEqual(m.counts["cancel_new_extreme"], 1)

    def test_p2_both_or_edges_ignored(self):
        t = utc("2026-05-08T14:00:00")
        m = Machine("P2", {"2026-05-08": (106., 100., t + 90 * MIN)})
        m.on_bar(t, p1row(low=99.8, high=106.1, close=100.1))
        self.assertIsNone(m.pending)
        self.assertEqual(m.counts["both_or_edges"], 1)

    def test_p2_confirmation_must_finish_by_1130_and_one_fill_per_day(self):
        t = utc("2026-05-08T15:00:00")  # 11:00 NY
        cutoff = utc("2026-05-08T15:30:00")
        m = Machine("P2", {"2026-05-08": (106., 100., cutoff)})
        m.on_bar(t, p1row(low=99.8, high=101., close=100.1))
        confirm = m.on_bar(t + B15, p1row(low=99.9, high=102., close=101.2))
        self.assertEqual(confirm["entry_ts"], cutoff)
        m.entered(confirm)
        m.on_bar(t, p1row(low=99.8, high=101., close=100.1))
        self.assertIsNone(m.pending)
        m = Machine("P2", {"2026-05-08": (106., 100., cutoff)})
        m.on_bar(t + B15, p1row(low=99.8, high=101., close=100.1))
        self.assertIsNone(m.on_bar(t + 2 * B15, p1row(low=99.9, high=102., close=101.2)))
        self.assertEqual(m.counts["expire"], 1)

    def test_p2_requires_2r_space_to_opposite_edge(self):
        r, reason, _ = simulate(order(strategy="P2", or_high=101.9, or_low=98.), candles(), funding(), Costs("zero", 0., 0.))
        self.assertIsNone(r)
        self.assertEqual(reason, "skip_or_space")
        r, reason, _ = simulate(order(strategy="P2", or_high=102., or_low=98.), candles(), funding(), Costs("zero", 0., 0.))
        self.assertIsNotNone(r)
        self.assertIsNone(reason)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ReplayTests)
    names = [t.id() for t in suite]
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    payload = {"tests_run": result.testsRun, "successful": result.wasSuccessful(), "test_ids": names,
               "failures": [(t.id(), e) for t, e in result.failures], "errors": [(t.id(), e) for t, e in result.errors]}
    (ROOT / "test_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)
