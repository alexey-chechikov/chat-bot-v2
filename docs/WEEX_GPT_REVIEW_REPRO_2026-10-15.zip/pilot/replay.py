"""Offline, causal P1/P2 replay. No account sizing, API or parameter search."""
from __future__ import annotations

import argparse
from bisect import bisect_right
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
from typing import Any
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

MIN = 60_000
B15 = 15 * MIN
H4 = 240 * MIN
F8 = 480 * MIN  # Locally verified nominal BTC/ETH settlement grid, not a strategy parameter.
NY = ZoneInfo("America/New_York")
ROOT = Path(__file__).resolve().parent
PROTOCOL = ROOT.parent / "MANUAL_15M_PILOT_PROTOCOL_2026-10-14.md"
INPUT_ROOT = ROOT.parents[1] / "expectancy_20261006" / "public_data"


@dataclass(frozen=True)
class Costs:
    name: str
    fee: float
    slip: float


SCENARIOS = (
    Costs("base", 0.00048, 0.0002),
    Costs("stress", 0.00048, 0.0004),
    Costs("manual_lowfee_unverified", 0.0001, 0.0002),
)


def iso(ts: int) -> str:
    return datetime.fromtimestamp(int(ts) / 1000, timezone.utc).isoformat()


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def jsonable(x: Any) -> Any:
    if isinstance(x, dict):
        return {str(k): jsonable(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)):
        return [jsonable(v) for v in x]
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        x = float(x)
    if isinstance(x, float) and not np.isfinite(x):
        return None
    return x


def save_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(jsonable(obj), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def aggregate_full(minutes: pd.DataFrame, width: int) -> pd.DataFrame:
    """Inputs have a unique minute-grid index. Count+endpoints prove exact grid."""
    d = minutes.copy()
    d["minute_ts"] = d.index
    d["bucket"] = d.index // width * width
    bars = d.groupby("bucket", sort=True).agg(
        open=("open", "first"), high=("high", "max"), low=("low", "min"),
        close=("close", "last"), n=("minute_ts", "size"), unique=("minute_ts", "nunique"),
        first=("minute_ts", "min"), last=("minute_ts", "max"),
    )
    full = (bars.n == width // MIN) & (bars.unique == width // MIN) & (bars["first"] == bars.index) & (bars["last"] == bars.index + width - MIN)
    return bars.loc[full, ["open", "high", "low", "close"]].copy()


def reset_rma(values: np.ndarray, ts: np.ndarray, step: int, period: int, alpha: float) -> np.ndarray:
    out = np.full(len(values), np.nan)
    pending: list[float] = []
    last = np.nan
    for i, v in enumerate(values):
        if i == 0 or ts[i] - ts[i - 1] != step or not np.isfinite(v):
            pending = []
            last = np.nan
        if not np.isfinite(v):
            continue
        if np.isnan(last):
            pending.append(float(v))
            if len(pending) == period:
                last = float(np.mean(pending))
                out[i] = last
        else:
            last = alpha * float(v) + (1 - alpha) * last
            out[i] = last
    return out


def features(bars: pd.DataFrame, h4: pd.DataFrame) -> pd.DataFrame:
    f = bars.copy()
    ts = f.index.to_numpy(np.int64)
    o, h, l, c = (f[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    tr = h - l
    if len(ts) > 1:
        contiguous = ts[1:] - ts[:-1] == B15
        true = np.maximum(h[1:] - l[1:], np.maximum(abs(h[1:] - c[:-1]), abs(l[1:] - c[:-1])))
        tr[1:] = np.where(contiguous, true, tr[1:])
    f["atr"] = reset_rma(tr, ts, B15, 14, 1 / 14)
    segment = np.cumsum(np.r_[True, np.diff(ts) != B15])
    f["h20"] = f.high.groupby(segment).transform(lambda x: x.shift(1).rolling(20).max())
    f["l20"] = f.low.groupby(segment).transform(lambda x: x.shift(1).rolling(20).min())
    hts = h4.index.to_numpy(np.int64)
    hc = h4.close.to_numpy(float)
    ema = reset_rma(hc, hts, H4, 50, 2 / 51)
    ends = hts + H4
    close_times = ts + B15
    idx = np.searchsorted(ends, close_times, side="right") - 1
    trend = np.full(len(ts), np.nan)
    known_end = np.full(len(ts), np.nan)
    for j, k in enumerate(idx):
        expected_end = close_times[j] // H4 * H4
        if k >= 0 and ends[k] == expected_end and np.isfinite(ema[k]):
            trend[j] = np.sign(hc[k] - ema[k])
            known_end[j] = ends[k]
    f["trend"] = trend
    f["trend_bar_end"] = known_end
    f["prev_close"] = f.close.shift(1)
    f["prev_h20"] = f.h20.shift(1)
    f["prev_l20"] = f.l20.shift(1)
    f["contiguous_prev"] = np.r_[False, np.diff(ts) == B15]
    return f


def session_key(ts: int) -> tuple[str, int, int]:
    d = datetime.fromtimestamp(int(ts) / 1000, timezone.utc).astimezone(NY)
    return d.date().isoformat(), d.weekday(), d.hour * 60 + d.minute


def opening_ranges(bars: pd.DataFrame) -> dict[str, tuple[float, float, int]]:
    first: dict[str, tuple[int, float, float]] = {}
    out: dict[str, tuple[float, float, int]] = {}
    for ts, row in bars.iterrows():
        key, wd, minute = session_key(int(ts))
        if wd >= 5:
            continue
        if minute == 570:
            first[key] = (int(ts), float(row.high), float(row.low))
        elif minute == 585 and key in first:
            prior, high, low = first[key]
            if int(ts) == prior + B15:
                # 11:30 local is two hours after 09:30 in both DST regimes.
                out[key] = (max(high, float(row.high)), min(low, float(row.low)), prior + 120 * MIN)
    return out


class Machine:
    def __init__(self, strategy: str, ranges: dict[str, tuple[float, float, int]] | None = None):
        self.strategy = strategy
        self.ranges = ranges or {}
        self.pending: dict | None = None
        self.last_ts: int | None = None
        self.executed_days: set[str] = set()
        self.counts: Counter = Counter()
        self.events: list[dict] = []

    def event(self, ts: int, name: str, p: dict | None = None) -> None:
        self.counts[name] += 1
        self.events.append({"bar_ts": ts, "event": name, "signal_id": (p or {}).get("signal_id"), "side": (p or {}).get("side")})

    def entered(self, order: dict) -> None:
        if self.strategy == "P2":
            self.executed_days.add(order["day"])

    def on_bar(self, ts: int, r: dict, busy: bool = False) -> dict | None:
        end = ts + B15
        if self.last_ts is not None and ts - self.last_ts != B15 and self.pending:
            self.event(ts, "cancel_data_gap", self.pending)
            self.pending = None
        self.last_ts = ts
        if busy:
            self.event(ts, "bar_while_position")
            return None
        p = self.pending
        if p is not None:
            self.pending = None
            side, A, L = p["side"], p["atr"], p["level"]
            if end > p["deadline"]:
                self.event(ts, "expire", p)
                return None
            if self.strategy == "P1":
                tr = r["trend"]
                if not np.isfinite(tr):
                    self.event(ts, "cancel_trend_data", p)
                    return None
                if tr * side < 0:
                    self.event(ts, "cancel_trend", p)
                    return None
                if side * (r["close"] - L) < -0.25 * A:
                    self.event(ts, "cancel_price", p)
                    return None
                edge = r["low"] if side == 1 else r["high"]
                distance_edge = side * (edge - L)
                confirm = -0.25 * A <= distance_edge <= 0.1 * A and side * (r["close"] - L) >= 0.05 * A
                sl = edge - side * 0.1 * A
            else:
                edge = r["low"] if side == 1 else r["high"]
                old_edge = p["signal_low"] if side == 1 else p["signal_high"]
                if side * (edge - old_edge) < 0:
                    self.event(ts, "cancel_new_extreme", p)
                    return None
                reference = p["signal_high"] if side == 1 else p["signal_low"]
                confirm = side * (r["close"] - reference) > 0
                sl = old_edge - side * 0.1 * A
            if confirm:
                self.event(ts, "confirm", p)
                return {**p, "confirm_ts": ts, "confirm_close": r["close"], "entry_ts": end, "sl": sl}
            if end == p["deadline"]:
                self.event(ts, "expire", p)
                return None
            self.pending = p
            return None

        A = r["atr"]
        if not np.isfinite(A) or A <= 0:
            self.counts["bar_atr_unavailable"] += 1
            return None
        if self.strategy == "P1":
            if not r["contiguous_prev"] or not np.isfinite(r["trend"]) or not np.isfinite(r["h20"]) or not np.isfinite(r["prev_h20"]):
                self.counts["bar_context_unavailable"] += 1
                return None
            long = r["trend"] == 1 and r["close"] > r["h20"] + 0.1 * A and r["prev_close"] <= r["prev_h20"]
            short = r["trend"] == -1 and r["close"] < r["l20"] - 0.1 * A and r["prev_close"] >= r["prev_l20"]
            if not (long or short):
                return None
            side = 1 if long else -1
            L = r["h20"] if long else r["l20"]
            p = {"strategy": "P1", "side": side, "signal_ts": ts, "signal_id": f"P1:{ts}:{side}",
                 "atr": A, "level": L, "deadline": end + 3 * B15,
                 "signal_low": r["low"], "signal_high": r["high"], "trend_bar_end": r["trend_bar_end"]}
        else:
            day, wd, minute = session_key(ts)
            if wd >= 5 or minute < 600 or minute >= 690 or day in self.executed_days:
                return None
            if day not in self.ranges:
                self.counts["bar_missing_or"] += 1
                return None
            high, low, cutoff = self.ranges[day]
            if r["low"] < low and r["high"] > high:
                self.event(ts, "both_or_edges")
                return None
            long = r["low"] <= low - 0.1 * A and low + 0.05 * A <= r["close"] <= high
            short = r["high"] >= high + 0.1 * A and low <= r["close"] <= high - 0.05 * A
            if not (long or short):
                return None
            side = 1 if long else -1
            p = {"strategy": "P2", "side": side, "signal_ts": ts, "signal_id": f"P2:{ts}:{side}",
                 "atr": A, "level": low if long else high, "deadline": min(end + 3 * B15, cutoff),
                 "signal_low": r["low"], "signal_high": r["high"], "or_low": low, "or_high": high, "day": day}
        self.pending = p
        self.event(ts, "signal", p)
        return None


def funding_cost(side: int, qty: float, mark: float, rate: float) -> float:
    return side * qty * mark * rate


def exit_at_minute(side: int, o: float, h: float, l: float, sl: float, tp: float, deadline: bool = False) -> tuple[str | None, float | None, bool]:
    gap_stop = o <= sl if side == 1 else o >= sl
    if gap_stop:
        return "SL_GAP", min(o, sl) if side == 1 else max(o, sl), False
    gap_tp = o >= tp if side == 1 else o <= tp
    if gap_tp:
        return "TP", tp, False
    if deadline:
        return "TIME", o, False
    stop_hit = l <= sl if side == 1 else h >= sl
    tp_hit = h >= tp if side == 1 else l <= tp
    if stop_hit:
        return "SL", sl, bool(tp_hit)
    if tp_hit:
        return "TP", tp, False
    return None, None, False


def simulate(order: dict, minutes: pd.DataFrame, funding: pd.DataFrame, costs: Costs) -> tuple[dict | None, str | None, list[float]]:
    entry_ts, side, A, sl = int(order["entry_ts"]), int(order["side"]), float(order["atr"]), float(order["sl"])
    idx = int(minutes.index.searchsorted(entry_ts))
    if idx >= len(minutes) or int(minutes.index[idx]) != entry_ts:
        return None, "skip_missing_entry", []
    E0 = float(minutes.iloc[idx].open)
    if abs(E0 - order["confirm_close"]) > 0.1 * A + 1e-12:
        return None, "skip_drift", []
    E = E0 * (1 + side * costs.slip)
    distance = side * (E - sl)
    width = distance / E
    if not (0.005 - 1e-12 <= width <= 0.015 + 1e-12):
        return None, "skip_stop_width", []
    tp = E + side * 2 * distance
    if order["strategy"] == "P2":
        edge = order["or_high"] if side == 1 else order["or_low"]
        if side * (edge - tp) < -1e-12:
            return None, "skip_or_space", []
    limit = entry_ts + H4
    qty = 1 / E
    Ftimes = funding.index.to_numpy(np.int64)
    fk = int(np.searchsorted(Ftimes, entry_ts, side="right"))
    missing_funding = funding.attrs.get("missing_nominal_settlements", [])
    mk = bisect_right(missing_funding, entry_ts)
    fund = 0.0
    fcount = 0
    fdetails = []
    entry_mtm = side * (E0 - E) / E - costs.fee
    points = [entry_mtm]
    MAE, MFE = entry_mtm, entry_mtm
    exit_raw, exit_fill, exit_ts, reason = None, None, None, None
    ambiguous = False
    last_close, last_seen = E0, entry_ts
    mark_complete = True
    rows = minutes.iloc[idx:].to_numpy(float)
    mtimes = minutes.index.to_numpy(np.int64)[idx:]
    for k, ts0 in enumerate(mtimes):
        ts = int(ts0)
        expected = entry_ts + k * MIN
        if ts != expected:
            reason = "CENSORED_GAP"
            break
        o, h, l, c = (float(rows[k, j]) for j in range(4))
        reason0, raw0, both = exit_at_minute(side, o, h, l, sl, tp, ts == limit)
        open_exit = reason0 in ("SL_GAP", "TIME") or (reason0 == "TP" and ((o >= tp) if side == 1 else (o <= tp)))
        # Never charge a settlement after a modeled exit at this minute's open.
        minute_end = ts if open_exit else ts + MIN - 1
        if mk < len(missing_funding) and missing_funding[mk] <= minute_end:
            reason = "CENSORED_FUNDING_COVERAGE"
            break
        while fk < len(Ftimes) and int(Ftimes[fk]) <= minute_end:
            ft = int(Ftimes[fk])
            f = funding.iloc[fk]
            if not np.isfinite(f.markPrice) or f.markPrice <= 0 or not np.isfinite(f.fundingRate):
                mark_complete = False
                reason = "CENSORED_FUNDING"
                break
            cost = funding_cost(side, qty, float(f.markPrice), float(f.fundingRate))
            fund += cost
            fcount += 1
            fdetails.append({"ts": ft, "mark": float(f.markPrice), "rate": float(f.fundingRate), "signed_cost": cost})
            fk += 1
        if not mark_complete:
            break
        # An observed full minute can only be used after its open for price exits.
        if reason0:
            reason, exit_raw, ambiguous = reason0, float(raw0), both
            exit_fill = exit_raw * (1 - side * costs.slip)
            exit_ts = ts if open_exit else ts + MIN - 1
            if not open_exit:
                # Pessimistic pre-exit path envelope. A favourable excursion
                # cannot exceed TP before SL, or TP would have ended the trade.
                pre_tp = np.nextafter(tp, -np.inf if side == 1 else np.inf)
                good = min(h, pre_tp) if side == 1 else max(l, pre_tp)
                val_good = side * (good - E) / E - costs.fee - fund
                points.append(val_good)
                MFE, MAE = max(MFE, val_good), min(MAE, val_good)
                if reason0 == "TP":
                    # Any pre-TP adverse excursion must remain inside SL.
                    bad = max(l, np.nextafter(sl, np.inf)) if side == 1 else min(h, np.nextafter(sl, -np.inf))
                    val_bad = side * (bad - E) / E - costs.fee - fund
                    points.append(val_bad)
                    MFE, MAE = max(MFE, val_bad), min(MAE, val_bad)
            net = side * (exit_fill - E) / E - costs.fee * (1 + exit_fill / E) - fund
            points.append(net)
            MAE = min(MAE, net)
            MFE = max(MFE, net)
            last_seen, last_close = exit_ts, exit_raw
            break
        # Envelope is explicit, not a claim about unknowable within-minute order.
        good, bad = (h, l) if side == 1 else (l, h)
        vals = [side * (p - E) / E - costs.fee - fund for p in (good, bad, c)]
        points.extend(vals)
        MFE, MAE = max(MFE, *vals), min(MAE, *vals)
        last_seen, last_close = ts + MIN - 1, c
        if ts > limit:
            raise AssertionError("Replay passed deadline")
    if reason is None:
        reason = "CENSORED_EOF"
    status = "censored" if reason.startswith("CENSORED") else "closed"
    record = {**order, "scenario": costs.name, "entry_raw": E0, "entry_actual": E, "qty_unit_notional": qty,
              "stop": sl, "distance": distance, "stop_fraction": width, "tp": tp, "deadline_ts": limit,
              "exit_ts": exit_ts, "exit_raw": exit_raw, "exit_actual": exit_fill, "reason": reason,
              "status": status, "funding_signed_cost": fund, "funding_count": fcount,
              "funding_details": json.dumps(fdetails, separators=(",", ":")), "fee_rate": costs.fee,
              "slippage_rate": costs.slip, "ambiguous_same_minute": ambiguous, "mae_net": MAE, "mfe_net": MFE,
              "last_observed_ts": last_seen, "last_observed_price": last_close, "entry_fee": costs.fee,
              "mtm_last": side * (last_close - E) / E - costs.fee - fund}
    if status == "closed":
        record.update({"gross_raw_return": side * (exit_raw - E0) / E0,
                       "price_return_after_slip": side * (exit_fill - E) / E,
                       "exit_fee": costs.fee * exit_fill / E,
                       "fees": costs.fee * (1 + exit_fill / E), "net_return": net, "net_R": net / width})
    else:
        record.update({"gross_raw_return": None, "price_return_after_slip": None, "exit_fee": None,
                       "fees": None, "net_return": None, "net_R": None})
    record["busy_until"] = exit_ts if status == "closed" else limit
    return record, None, points


def run_replay(strategy: str, symbol: str, minutes: pd.DataFrame, funding: pd.DataFrame, f: pd.DataFrame, costs: Costs) -> tuple[pd.DataFrame, dict, pd.DataFrame]:
    machine = Machine(strategy, opening_ranges(f) if strategy == "P2" else None)
    ledger = []
    busy_until = -1
    closed = peak = max_dd = max_closed_dd = closed_peak = 0.0
    for ts0, row in f.iterrows():
        ts = int(ts0)
        order = machine.on_bar(ts, row.to_dict(), busy_until > ts + B15)
        if order is None:
            continue
        trade, rejected, points = simulate(order, minutes, funding, costs)
        if rejected:
            machine.event(ts, rejected, order)
            continue
        machine.entered(order)
        machine.event(ts, "entered", order)
        trade["symbol"] = symbol
        trade["episode_id"] = f"{symbol}:{trade['signal_id']}:{trade['confirm_ts']}"
        ledger.append(trade)
        busy_until = trade["busy_until"]
        for x in points:
            val = closed + x
            peak = max(peak, val)
            max_dd = max(max_dd, peak - val)
        if trade["status"] == "closed":
            closed += trade["net_return"]
            closed_peak = max(closed_peak, closed)
            max_closed_dd = max(max_closed_dd, closed_peak - closed)
    if machine.pending:
        machine.event(int(f.index[-1]), "pending_at_eof", machine.pending)
    events = pd.DataFrame(machine.events)
    return pd.DataFrame(ledger), {"counts": dict(machine.counts), "max_closed_floating_dd_fixed_notional": max_dd,
                                  "max_closed_dd_fixed_notional": max_closed_dd,
                                  "drawdown_path_complete": all(x["status"] == "closed" for x in ledger)}, events


def stats(rows: pd.DataFrame) -> dict:
    if len(rows) == 0:
        return {"n": 0, "censored": 0, "mean_net_return": None, "mean_net_R": None, "WR": None, "PF": None}
    closed = rows.loc[rows.status == "closed"]
    n = len(closed)
    if n == 0:
        return {"n": 0, "censored": len(rows), "mean_net_return": None, "mean_net_R": None, "WR": None, "PF": None,
                "censored_last_mtm": float(rows.mtm_last.sum()), "reasons": rows.reason.value_counts().to_dict()}
    net = closed.net_return.to_numpy(float)
    positive, negative = float(net[net > 0].sum()), float(-net[net < 0].sum())
    return {"n": n, "censored": len(rows) - n, "mean_net_return": float(net.mean()),
            "mean_net_R": float(closed.net_R.mean()), "median_net_R": float(closed.net_R.median()),
            "WR": float((net > 0).mean()), "PF": positive / negative if negative > 0 else None,
            "PF_no_losses": bool(negative == 0 and positive > 0), "sum_net_return_fixed_notional": float(net.sum()),
            "mean_raw_return": float(closed.gross_raw_return.mean()), "mean_after_slip_return": float(closed.price_return_after_slip.mean()),
            "mean_fees": float(closed.fees.mean()), "mean_signed_funding_cost": float(closed.funding_signed_cost.mean()),
            "funded_trades": int((closed.funding_count > 0).sum()), "funding_events": int(closed.funding_count.sum()),
            "median_stop_fraction": float(closed.stop_fraction.median()), "mean_win": float(net[net > 0].mean()) if positive else None,
            "mean_loss": float(net[net < 0].mean()) if negative else None,
            "max_mae_net": float(closed.mae_net.min()), "max_mfe_net": float(closed.mfe_net.max()),
            "reasons": rows.reason.value_counts().to_dict(), "sides": closed.side.value_counts().to_dict(),
            "ambiguous_same_minute": int(closed.ambiguous_same_minute.sum()),
            "censored_last_mtm": float(rows.loc[rows.status != "closed", "mtm_last"].sum())}


def weekly_ci(rows: pd.DataFrame, start: int, end: int, draws: int = 9999) -> dict:
    a = pd.Timestamp(start, unit="ms", tz="UTC").date()
    b = pd.Timestamp(end, unit="ms", tz="UTC").date()
    all_dates = pd.date_range(a, b, freq="D")
    weeks = sorted({d.strftime("%G-W%V") for d in all_dates})
    totals = {w: [0.0, 0.0, 0] for w in weeks}
    if len(rows):
        for row in rows.loc[rows.status == "closed"].itertuples():
            w = datetime.fromtimestamp(int(row.entry_ts) / 1000, timezone.utc).strftime("%G-W%V")
            totals[w][0] += row.net_return
            totals[w][1] += row.net_R
            totals[w][2] += 1
    vals = np.asarray(list(totals.values()), dtype=float)
    nonempty = vals[vals[:, 2] > 0]
    result = {"all_calendar_clusters": len(vals), "nonempty_clusters": len(nonempty), "draws": draws, "seed": 20261014,
              "weekly": [{"week": w, "sum_net_return": v[0], "sum_net_R": v[1], "n": int(v[2])} for w, v in totals.items()]}
    for key, pool in (("all_calendar_weeks", vals), ("nonempty_weeks", nonempty)):
        if len(nonempty) < 2:
            result[key] = {"net_return_CI95": None, "net_R_CI95": None, "reason": "fewer_than_two_nonempty_clusters"}
            continue
        rng = np.random.default_rng(20261014)
        sampled = pool[rng.integers(0, len(pool), size=(draws, len(pool)))].sum(axis=1)
        sampled = sampled[sampled[:, 2] > 0]
        means = sampled[:, :2] / sampled[:, 2:]
        q = np.quantile(means, [0.025, 0.975], axis=0)
        result[key] = {"net_return_CI95": q[:, 0].tolist(), "net_R_CI95": q[:, 1].tolist(),
                       "valid_draws": len(sampled), "zero_count_draws": draws - len(sampled)}
    return result


def load_inputs(symbol: str) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    p = INPUT_ROOT / f"binance_futures_{symbol}_1m.csv"
    q = INPUT_ROOT / f"binance_futures_{symbol}_funding.csv"
    d = pd.read_csv(p, usecols=["ts", "open", "high", "low", "close", "close_ts"])
    duplicate = int(d.ts.duplicated().sum())
    unsorted = int((d.ts.diff().dropna() <= 0).sum())
    if duplicate or unsorted:
        raise ValueError(f"{symbol}: duplicate/unsorted source timestamps: {duplicate}/{unsorted}")
    numeric = d[["open", "high", "low", "close"]].to_numpy(float)
    valid = (np.isfinite(numeric).all(axis=1) & (numeric > 0).all(axis=1) & (d.ts % MIN == 0) & (d.close_ts == d.ts + MIN - 1)
             & (d.high >= d[["open", "close"]].max(axis=1)) & (d.low <= d[["open", "close"]].min(axis=1)) & (d.high >= d.low))
    invalid = int((~valid).sum())
    m = d.loc[valid, ["ts", "open", "high", "low", "close"]].set_index("ts")
    diffs = np.diff(m.index.to_numpy(np.int64))
    gaps = [{"after": iso(int(m.index[i])), "next": iso(int(m.index[i + 1])), "missing_minutes": int(diffs[i] // MIN - 1)}
            for i in np.flatnonzero(diffs != MIN)]
    fund = pd.read_csv(q)
    if fund.fundingTime.duplicated().any() or (fund.fundingTime.diff().dropna() <= 0).any():
        raise ValueError(f"{symbol}: duplicate/unsorted funding timestamps")
    if (fund.symbol != symbol).any():
        raise ValueError("Funding symbol mismatch")
    fund = fund.set_index("fundingTime")
    start, end = int(m.index[0]), int(m.index[-1] + MIN)
    # Source timestamps include small positive millisecond settlement jitter.
    # Preserve exact times for costs; use nominal slots only to detect missing rows.
    nominal = fund.index.to_numpy(np.int64) // F8 * F8
    jitter = fund.index.to_numpy(np.int64) - nominal
    if len(set(map(int, nominal))) != len(fund) or np.any(jitter > MIN):
        raise ValueError(f"{symbol}: funding source does not match the locally checked nominal 8h grid")
    expected_nominal = range((start + F8 - 1) // F8 * F8, end, F8)
    present_nominal = set(map(int, nominal))
    missing_nominal = [x for x in expected_nominal if x not in present_nominal]
    fund.attrs["missing_nominal_settlements"] = missing_nominal
    ff = fund[(fund.index > start) & (fund.index <= end)]
    funding_diffs = np.diff(ff.index.to_numpy(np.int64))
    fund_bad = int((~np.isfinite(ff.fundingRate.to_numpy(float)) | ~np.isfinite(ff.markPrice.to_numpy(float)) | (ff.markPrice <= 0)).sum())
    b15, b4 = aggregate_full(m, B15), aggregate_full(m, H4)
    report = {"symbol": symbol, "minute_path": str(p), "minute_sha256": sha(p), "minute_rows_source": len(d),
              "minute_rows_valid": len(m), "invalid_rows": invalid, "duplicates": duplicate, "unsorted": unsorted,
              "start_utc": iso(start), "end_exclusive_utc": iso(end), "start_ms": start, "end_ms": end,
              "missing_minutes": int(sum(x["missing_minutes"] for x in gaps)), "gaps": gaps,
              "full_15m_bars": len(b15), "full_4h_bars": len(b4), "funding_path": str(q), "funding_sha256": sha(q),
              "funding_rows_source": len(fund), "funding_rows_in_minute_period": len(ff), "funding_invalid_marks_or_rates": fund_bad,
              "funding_non_minute_aligned": int((ff.index % MIN != 0).sum()),
              "funding_nominal_8h_missing": len(missing_nominal), "funding_missing_nominal_ms": missing_nominal,
              "funding_max_jitter_ms": int(jitter.max()),
              "funding_cadence_ms_counts": dict(Counter(map(int, funding_diffs))),
              "funding_first_utc": iso(int(fund.index[0])), "funding_last_utc": iso(int(fund.index[-1])),
              "split70_ms": int(start + (end - start) * 0.7), "split70_utc": iso(int(start + (end - start) * 0.7))}
    return m, fund, report


def summarize(ledger: pd.DataFrame, run: dict, provenance: dict) -> dict:
    split = provenance["split70_ms"]
    months = pd.period_range(pd.Timestamp(provenance["start_ms"], unit="ms").to_period("M"),
                             pd.Timestamp(provenance["end_ms"] - 1, unit="ms").to_period("M"), freq="M")
    result = {"all": stats(ledger), **run}
    result["first70"] = stats(ledger.loc[ledger.entry_ts < split]) if len(ledger) else stats(ledger)
    result["last30_diagnostic_not_OOS"] = stats(ledger.loc[ledger.entry_ts >= split]) if len(ledger) else stats(ledger)
    result["monthly"] = {}
    entry_months = pd.to_datetime(ledger.entry_ts, unit="ms", utc=True).dt.strftime("%Y-%m") if len(ledger) else pd.Series(dtype=str)
    for month in months:
        result["monthly"][str(month)] = stats(ledger.loc[entry_months == str(month)]) if len(ledger) else stats(ledger)
    result["weekly_block_CI"] = weekly_ci(ledger, provenance["start_ms"], provenance["end_ms"])
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT)
    args = parser.parse_args()
    out = args.output.resolve()
    if out != ROOT:
        raise ValueError("All pilot artifacts must remain in the declared pilot directory")
    out.mkdir(exist_ok=True)
    manifests = []
    summaries = {}
    ledgers = {}
    event_frames = []
    for symbol in ("BTCUSDT", "ETHUSDT"):
        print(f"Reading native futures {symbol}", flush=True)
        minutes, fund, provenance = load_inputs(symbol)
        manifests.append(provenance)
        f = features(aggregate_full(minutes, B15), aggregate_full(minutes, H4))
        for strategy in ("P1", "P2"):
            for costs in SCENARIOS:
                print(f"Replay {strategy} {symbol} {costs.name}", flush=True)
                ledger, run, events = run_replay(strategy, symbol, minutes, fund, f, costs)
                key = f"{strategy}_{symbol}_{costs.name}"
                if not len(ledger):
                    ledger = pd.DataFrame(columns=["entry_ts", "episode_id", "status", "net_return", "net_R", "reason", "mtm_last"])
                ledger.to_csv(out / f"ledger_{key}.csv", index=False)
                ledgers[key] = ledger
                summaries[key] = summarize(ledger, run, provenance)
                if len(events):
                    events["strategy"], events["symbol"], events["scenario"] = strategy, symbol, costs.name
                    event_frames.append(events)
                s = summaries[key]["all"]
                print(json.dumps({"key": key, "n": s["n"], "mean_net_R": s["mean_net_R"], "mean_net_return": s["mean_net_return"]}), flush=True)
    matching = {}
    for strategy in ("P1", "P2"):
        for symbol in ("BTCUSDT", "ETHUSDT"):
            base = set(ledgers[f"{strategy}_{symbol}_base"].episode_id)
            for costs in SCENARIOS[1:]:
                other = set(ledgers[f"{strategy}_{symbol}_{costs.name}"].episode_id)
                matching[f"{strategy}_{symbol}_{costs.name}"] = {"matched_episode_ids": len(base & other),
                      "base_only": len(base - other), "scenario_only": len(other - base)}
    if event_frames:
        pd.concat(event_frames, ignore_index=True).to_csv(out / "events.csv", index=False)
    summary = {"protocol": str(PROTOCOL), "protocol_sha256": sha(PROTOCOL), "rules": "P1/P2 only; no search",
               "return_units": "unit initial notional per episode; net_return is fraction; not account compounded return",
               "R_definition": "net_return / abs(actual entry - fixed SL) * actual entry",
               "split": "diagnostic on previously used data; not new OOS", "scenarios": [vars(c) for c in SCENARIOS],
               "results": summaries, "scenario_episode_matching": matching}
    save_json(out / "summary.json", summary)
    manifest = {"created_utc": datetime.now(timezone.utc).isoformat(), "runtime": platform.python_version(),
                "numpy": np.__version__, "pandas": pd.__version__, "network": "No network/API code; local CSV only",
                "protocol_sha256": sha(PROTOCOL), "implementation_sha256": sha(Path(__file__)),
                "assumptions_sha256": sha(ROOT / "IMPLEMENTATION_ASSUMPTIONS.md"), "inputs": manifests}
    tests = ROOT / "test_replay.py"
    if tests.exists():
        manifest["tests_sha256"] = sha(tests)
    save_json(out / "manifest.json", manifest)
    print("Saved summary.json, manifest.json, events.csv and all 12 ledgers", flush=True)


if __name__ == "__main__":
    main()
