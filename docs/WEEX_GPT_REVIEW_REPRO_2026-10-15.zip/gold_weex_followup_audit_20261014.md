# Follow-up audit of pin e1fe76a — 14 October 2026

Scope: handoff and answer documents, current grid/client/loop, monitoring scripts, research/data helpers, new tests, and comparison against the 13 October audit. No API or live restart. Public snapshot only; no current private deployment/account receipts. Files in this directory are working audit artifacts, not publication.

## Independent validation

Offline subset: **272 passed**, comprising grid tests, monitoring, data tools except the POSIX-lock file, and gold tests. The wrapper denies outbound socket connections, removes credentials, binds imports to the snapshot, uses UTF-8, and redirects automatically created dry trend/portfolio defaults into `offline_runtime`. No trading source was edited. `tests/research_tools/test_frozen_lock_repair.py` was excluded because Windows lacks `fcntl`; lock code/tests were inspected statically. The 873-test total and live deployment receipts in Claude's document remain author-reported rather than independently verified here.

Six additional artificial counterexample cases were independently confirmed using `test_audit_alert_delivery.py`; a passing counterexample means the problematic behavior was reproduced, not that its implementation is correct. JSON results are saved separately beside this note. All quantities/IDs in these cases are synthetic.

## Evidence status of prior requests

| Prior request | Source hooks and test evidence | Status at this pin |
|---|---|---|
| W1 — missing TP/entry detail must not mean terminal | `engine.py:_detail/_detail_problem`1215–1269; ordinary paths1106/1133/1147, cancellation1039/1317, flatten1504. `test_weex_gpt1013` checks8 malformed details, missing entry, mismatched TP, partial final fills, market pending; `gpt1014` adds terminal missing executedQty and numeric-ID/string-quantity schema. | Implemented and tested for the accepted detail scenarios. **Overall UNKNOWN safety remains incomplete:** null/empty-object history can expire a pending intention and create a second live entry (new finding below). |
| W2 — unknown stray and release must preserve ownership | `_process_strays`713–765 keeps UNKNOWN and retries cancel; `release_side`1326–1383 waits on pending/flatten/entry/TP/stray. Restart and terminal-status tests pass. | Implemented and tested for accepted scenarios. The known returned-side/second-empty-transfer epoch omission remains acknowledged. Exact-once journal handoff still has an uncovered post-append crash window. |
| Transfer MTM and daily-risk boundary | `_migrate_transfers`277–319, `bot_pnl`453–459, release1361–1375; positive/negative MTM, price movement after transfer, restart, migration and daily-stop neutrality tests pass. | Implemented/tested with clean records. Current raw account and historical ownership epochs are not independently verified. Duplicate journal event issue can corrupt reconciliation while state PnL stays stable. |
| Q1 — genuine successful tick; owner/history/regime checks | `tick`773–799 records success only after full tick; `_mark_tick_failed`864–877. Monitoring common78–156 rejects invalid trade history and uses durable own-order registry; account54–117 uses success/error keys and engine's causal/fresh SMA check.61 monitoring tests pass collectively. | Core requests implemented/tested. Current account state/after-release activity not validated without14October private receipts. |
| Client truncated open list | `_open_pages`121–140 raises after10 full pages or truthy non-list error object; dedicated fake-client tests pass and tick fails before orphan decisions. | Implemented/tested for those cases. `None` and `{}` remain converted to[]; this should be distinguished from proven complete empty responses. |
| Q2 — orphan detail/coverage instead of list absence | `orphan_check.py:classify_tp`33–72 and main123–136; filled/live-unlisted/partial/canceled/mismatched-side/price/undersized-TP tests pass. | Implemented/tested. This checker still defines UNKNOWN from details separately from grid's classifier; it is a read-only diagnosis, not execution proof. |
| Q3 — historic sides and transferred MTM | `pnl_reconcile.py:ever_owned`36–40, ownership selection92–97, transfer accounting100–154; formerly empty removed side, unknown owner, invalid history, before/after-transfer tests pass. | Implemented/tested for one ownership epoch. Multiple return/release epochs still need an explicit model; duplicate journals after crash are not deduplicated. Funding/account-wide equity remain outside this script's scope. |
| Errors coverage | `errors_today.py` combines ERROR/CRITICAL file and console records and prints source coverage; new dedup/distinct-ms/missing-source tests pass. | Implemented/tested. Source coverage is reported; actual present service logs were not supplied. |
| Q4 — gapfill/repair race and full hours | Shared`.ingest.lock` exists in repair and actual `scripts/ohlcv_ingest.py`; writer reopens/rechecks tail under lock, resamples1h under lock. Repair's `_full_hours`222–239 requires60 unique on-grid valid bars. | Source implementation confirmed; POSIX synchronization tests not rerun on Windows. **Producer's own1h resampler still accepts incomplete hours** (new finding). |
| B1 — midpoint before boundary actions | `regime_grid.py:109–114` now snapshots before switching.10 regime-cut cases and complete-warmup tests pass. | Implemented/tested. Old affected half-results need recalculation; no raw replay was performed here. |
| B2 — UTC month boundary every minute | `fast_grid.py:76–88` uses each minute's calendar month and previous equity. Original3-minute example and offset/gapped calendar tests pass. | Implemented/tested. Old positive-month counts are not independently recomputed. |
| B3 — fetch closed minutes and repair tail | `fetch_1m.py` uses server time, explicit endTime, close_time check, refetches/replaces last saved row;4 fake-server tests pass; import no longer downloads. | Implemented/tested for future collection/tail. Previously damaged interior research/data rows are explicitly not repaired by this change. |
| Full warmup / GinArea key | Regime loader validates ascending grid/duplicates and100 consecutive full UTC days. GinArea uses exact endpoints/full effective config/data hashes, readback checks, includes Dynamic so/ioo. Corresponding tests pass. | Implemented/tested mechanically. Actual corrected GinArea benchmarks and same-exposure999 controls were not supplied. Default controls are still12, explicitly marked preliminary. |
| Gold implementation/control requests | LVN selected-day slice, XAU coverage-versus-volume, signed funding requirement for XAU, EOF costs/censoring, historical ticks/TP rounding, SPEC cancellation sensitivity and late-exit flags, two R definitions on one ledger, day-consistent random zones and fresh E executions, paired weekly B−A CI. All27 research_gold tests pass. | Implemented/tested on synthetic data. Updated historical values are author-reported; no market CSV/funding CSV/trade JSON for exact reproduction. Gold loader still has duplicate/minute-coverage validation limitations (parallel Atlas audit provides its counterexample). |

## New open findings

### P1: invalid history can erase a pending intention and duplicate a live entry

`client.py:145` and `engine.py:585–591` use `order_history(...) or []`. A `None` or `{}` response becomes a supposedly complete negative search. After PENDING_TTL, `_resolve_pending` removes the intention at 619–622. If the accepted old entry is absent from the open-list response, `_side` creates a new entry while the old remains live. Both null/object artificial cases resulted in **two live entries and cleared pending**. No actual WEEX occurrence is alleged.

This bypasses the corrected `_detail`: pending has only CID until resolved. It is the key remaining gap in the claim that all unknown outcomes retain ownership. Required regression: malformed/null history must be a read error and preserve pending; only a verified complete list can support the existing negative-search policy. Source and results: `test_audit_alert_delivery.py`, `pending_history_null_probe_results.json`, `pending_history_empty_object_probe_results.json`.

### P2: handoff journaling is not idempotent after a post-append crash

`_journal_handover` 1385–1394 appends, then clears `handover_unjournaled`, then saves. Crash after append leaves the durable flag. Restart appends the same event again. Artificial result: **2 journal handoffs, 1 state transfer**, unchanged earned state PnL. `pnl_reconcile` nevertheless sums both journal records and flags repeated transfer, so money/MTM reconciliation can be wrong.

Existing crash tests cover failure before append and the first state save; they do not cover append-success/state-clear-failure. Needed: persisted transfer identity and idempotent append/reconciliation. Result:`handover_append_crash_probe_results.json`.

### P2: failed first escalation is suppressed for an hour

`_escalations` 822–825 persists `unknown_alert_ts` before `tick` sends at 797–799; `_notify` 329–335 logs and swallows delivery exceptions. One failed artificial Telegram callback resulted in no delivered alert for the first 30 minutes and a retry only **3600 seconds** after the failed attempt. UNKNOWN trading ownership remained protected.

Tests check message counts with a successful list-append callback, not delivery failure. Needed: durable pending alert delivery with controlled retries and throttle based on successful delivery/acknowledged attempt semantics. Result:`alert_delivery_probe_results.json`.

### P2: ingest itself still creates incomplete 1h bars

`scripts/ohlcv_ingest.py:_fill_1h_from_1m` resamples OHLCV and filters by timestamp age; it does not validate 60 distinct minutes. The artificial producer case wrote a 1h bar from **one observed minute**, because a later timestamp made that hour old enough. Repair's complete-hour guard is correct but does not guard this producer path. Shared lock fixes concurrency, not this input-completeness problem. Historical effect unknown. Result: `ingest_incomplete_hour_probe_results.json`.

## Strategic work still outstanding

1. Exact live LONG/SMA100 BTC+ETH replay in `eg.Grid`, with current fixed quantities/caps, matching order lifecycle, venue prices/execution, then continuous combined-account equity including signed funding/closing fees and shared exposure. Current `validate_fast` remains the old both-side calibration. A new `--max-lots` comparison is still the separate fast/regime loop, not this verification.
2. Same-exposure/time-in-market control (and suitable smaller-size benchmark) on the same continuous risk curve.999 random assignments alone do not match exposure;12 default assignments are not final evidence. GinArea Dynamic effects are now recorded/read back, but their empirical effect and corrected end-of-segment exit costs are not demonstrated by the handoff.
3. Money loss budget, exchange-resident emergency protection, and an explicit loss-exit rule. Q5 is openly marked operator decision/not implemented; nominal caps and SMA are still not an account loss bound.
4. Repair/revalidate previously collected interior research/data bars and recompute affected calendar/half metrics on immutable inputs. The tail collector fix only stops future persistence of an unfinished final bar.
5. Gold-specific authentic footprint/native GC/MGC validation remains separate. BTC/ETH Atlas footprint research does not complete the original gold C/D test, and proxy stop-width screening is not an MGC execution backtest. Prior corrected gold historical statistics still need raw immutable files to independently reproduce them.

The handoff's deployment18:13UTC is temporally plausible at the audit time, but its receipts were not supplied. Mechanical fixes should be credited; source/tests and reported historical/live outcomes must remain distinct.
