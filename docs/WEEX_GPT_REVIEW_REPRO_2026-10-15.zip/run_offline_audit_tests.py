"""Offline tests for a public snapshot: outbound sockets denied; no credentials."""
from pathlib import Path
import json
import os
import socket
import sys
import time
from types import ModuleType

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE / 'snapshot'))
os.chdir(HERE / 'snapshot')
for name in ('services','tests'):
    pkg = ModuleType(name)
    pkg.__path__ = [str(HERE / 'snapshot' / name)]
    sys.modules[name] = pkg
pkg = ModuleType('services.ginarea_api')
pkg.__path__ = [str(HERE / 'snapshot' / 'services' / 'ginarea_api')]
sys.modules['services.ginarea_api'] = pkg
def denied(*a, **kw):
    raise RuntimeError('Offline audit: outbound connection prohibited')
socket.socket.connect = denied
socket.socket.connect_ex = denied
socket.create_connection = denied
for key in ('WEEX_API_KEY','WEEX_API_SECRET','WEEX_API_PASSPHRASE','WEEX_PASSPHRASE'):
    os.environ.pop(key, None)
native_replace, retry_count = os.replace, 0
def replace(src,dst,*a,**kw):
    global retry_count
    for attempt in range(20):
        try:
            return native_replace(src,dst,*a,**kw)
        except PermissionError as e:
            if getattr(e,'winerror',None) != 5 or attempt == 19:
                raise
            retry_count += 1
            time.sleep(.025)
os.replace = replace
# The partial public snapshot has no state/config files. Keep the dry default
# trend config created by one runner test in a separate offline runtime folder.
from services.weex_trend import engine as te
from services.weex_grid import portfolio
runtime = HERE / 'offline_runtime'
runtime.mkdir(exist_ok=True)
te.CONFIG = runtime / 'weex_trend_config.json'
te.STATE = runtime / 'weex_trend_state.json'
te.JOURNAL = runtime / 'weex_trend_journal.jsonl'
te.load_config.__defaults__ = (te.CONFIG,)
portfolio.CONFIG = runtime / 'weex_portfolio_config.json'
import pytest
args = sys.argv[1:]
rc = pytest.main(args)
(HERE / 'offline_audit_test_summary.json').write_text(json.dumps({'rc':int(rc),'args':args,
    'outbound_network':'blocked','actual_replace_retries':retry_count},indent=2),encoding='utf-8')
sys.exit(rc)
