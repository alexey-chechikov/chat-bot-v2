"""Offline counterexamples. Artificial exchange and Telegram callback only."""
import json
from pathlib import Path
from services.weex_grid import engine as eg
from services.weex_api import client as wc
from tests.services.weex_grid.test_weex_gpt1014 import live_grid, hide
from tests.services.weex_grid.test_weex_gpt1013 import _short_bag, HAND, handovers
import pytest
from tests.research_tools._util import load


def test_failed_first_unknown_alert_is_suppressed_until_hourly_retry(tmp_path):
    t = live_grid(tmp_path)
    tp = t.g.st['LONG']['lots'][0]['tp_order']['id']
    hide(t.ex, tp, {})
    attempts, delivered = [], []
    def send(message):
        attempts.append(t.clock['t'])
        if len(attempts) == 1:
            raise TimeoutError('synthetic Telegram delivery failure')
        delivered.append(message)
    for _ in range(30 * 60 // 10):
        t.clock['t'] += 10
        g = t.build()
        g.send = send
        g.tick()
    assert len(attempts) == 1 and delivered == []
    disk = json.loads((tmp_path/'st.json').read_text(encoding='utf-8'))
    assert disk['unknown_alert_ts'] == attempts[0]
    for _ in range(40 * 60 // 10):
        t.clock['t'] += 10
        g = t.build()
        g.send = send
        g.tick()
    assert len(delivered) == 1 and len(attempts) == 2
    result = {'data':'synthetic only','first_attempt_failed':True,
              'delivered_during_first_30_minutes':0,'retry_after_seconds':attempts[1]-attempts[0],
              'cause':'unknown_alert_ts persisted before send; _notify swallows send failure'}
    Path(__file__).with_name('alert_delivery_probe_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')


def test_null_open_orders_is_still_accepted_as_empty():
    class Null(wc.WeexClient):
        def __init__(self):
            pass
        def get(self,*a,**kw):
            return None
    assert Null().open_orders('BTCUSDT') == []


def test_crash_after_handover_journal_append_duplicates_event_on_restart(tmp_path):
    g, ex, px, clock, build, tick, cfg = _short_bag(tmp_path, 100350.)
    before = g.bot_pnl(px.mid)
    original = g._journal
    def append_then_crash(rec):
        original(rec)
        if rec.get('kind') == HAND:
            raise RuntimeError('synthetic crash after journal append')
    g._journal = append_then_crash
    cfg['sides'], cfg['release_sides'] = [], ['SHORT']
    with pytest.raises(RuntimeError, match='synthetic crash after journal append'):
        tick(g)
    assert len(handovers(tmp_path)) == 1
    g = build()
    tick(g)
    assert len(handovers(tmp_path)) == 2
    assert len(g.st['SHORT']['transfers']) == 1
    assert g.bot_pnl(px.mid) == pytest.approx(before)
    result = {'data':'synthetic only','journal_handover_events_after_restart':2,
              'state_transfers_after_restart':1,'earned_result_changes':False,
              'cause':'handover_unjournaled is replayed after append succeeded but before state flag cleared'}
    Path(__file__).with_name('handover_append_crash_probe_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')


@pytest.mark.parametrize('bad_history',[None,{}])
def test_unknown_history_expires_pending_and_duplicates_hidden_live_entry(tmp_path,bad_history):
    t = live_grid(tmp_path,filled=False)
    entry = dict(t.g.st['LONG']['entry'])
    old_id = entry['id']
    t.g.st['LONG']['entry'] = None
    t.g.st['LONG']['pending'] = {'cid':entry['cid'],'kind':'e','price':entry['price'],
                               'qty':entry['qty'],'t':t.clock['t'],'srv':t.clock['t']}
    t.g.save()
    real_open = t.ex.open_orders
    t.ex.open_orders = lambda sym: [o for o in real_open(sym) if str(o['orderId']) != old_id]
    t.ex.order_history = lambda *a,**kw: bad_history
    t.clock['t'] += eg.PENDING_TTL + 10
    g = t.build()
    g.tick()
    live = [o for o in real_open('BTCUSDT') if not o.get('reduceOnly')]
    assert len(live) == 2 and not g.st['LONG'].get('pending')
    assert g.st['LONG']['entry']['id'] != old_id
    result = {'data':'synthetic only','bad_history':bad_history,'live_entries':2,
              'pending_intent_cleared':True,'cause':'order_history or [] is called a complete negative search after TTL'}
    name = 'null' if bad_history is None else 'empty_object'
    Path(__file__).with_name(f'pending_history_{name}_probe_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')


def test_ingest_hour_resample_still_accepts_one_minute_hour(tmp_path):
    oi = load('scripts/ohlcv_ingest.py')
    start = 1_760_000_000_000 // 3_600_000 * 3_600_000
    path = tmp_path/'FAKEUSDT_1m_2y.csv'
    path.write_text('ts,open,high,low,close,volume\n'
                    + f'{start},100,101,99,100,1\n'
                    + f'{start+2*3_600_000},100,101,99,100,1\n',encoding='utf-8')
    out = oi._fill_1h_from_1m('FAKEUSDT',tmp_path,False)
    written = (tmp_path/'FAKEUSDT_1h_2y.csv').read_text(encoding='utf-8').splitlines()
    assert out['hours_added'] == 1 and len(written) == 2
    assert written[1].startswith(f'{start},')
    result = {'data':'synthetic only','observed_minutes_in_written_hour':1,
              'hour_accepted_by_ingest':True,'cause':'ingest resample checks age, not unique minute coverage'}
    Path(__file__).with_name('ingest_incomplete_hour_probe_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
