# Офлайн-воспроизведение проверки 15.10.2026

Архив для отдельной исследовательской копии. Он не содержит ключей, приватного счёта, production state/config,
журнала живых сделок, больших market CSV или полного текста видео. `snapshot/` содержит только публичные
Python-файлы закреплённого `e1fe76a50c226872de6831edaa23c2ef3f30f466`; не подменяйте ими живую службу.

## Пилот P1/P2

Проверенный runtime: Python3.12.14, pandas3.0.1, numpy2.3.5; pytest нужен для code counterexamples.
Распаковать в `research/strategy_review_20261014/` исследовательской копии. В соседней
`research/expectancy_20261006/public_data/` должны быть ровно эти native Binance USD-M CSV:

- `binance_futures_BTCUSDT_1m.csv`
- `binance_futures_ETHUSDT_1m.csv`
- `binance_futures_BTCUSDT_funding.csv`
- `binance_futures_ETHUSDT_funding.csv`

Их SHA256, диапазон, формат и completeness — `pilot/manifest.json`/`pilot/preflight.json`. Полные файлы уже
использовались проектом; архив их не дублирует. Расположение важно: у replay нет arbitrary data-dir.

Из распакованной папки:

```text
python pilot/test_replay.py
python pilot/replay.py
python pilot/report.py
```

Повтор перезапишет исследовательские outputs в `pilot/`, сохраните исходный архив отдельно для сравнения.
`--output` replay разрешён только равным папке скрипта. Никаких `--data-dir`/`--out-dir` нет. Протокол лежит
на уровень выше `pilot/`. `report.py` сверяет inputs/source hashes, ledger и split/month/week, пишет notes.

`pilot_stats_result_audit.py` — отдельная проверка reported fills/признаков/CI плюс полный scanner P2;
в этом исходном скрипте INPUT задан абсолютным `C:\bot7\research\expectancy_20261006\public_data`.
При другом расположении меняйте только INPUT и фиксируйте изменение SHA; торговые правила не меняйте.
Независимые результаты исходного запуска сохранены рядом. Не утверждается второй полный enumeration P1.

## Контрпримеры публичного кода

Включены `test_audit_alert_delivery.py`, `atlas_audit_probes.py`, `session_legacy_probes.py`, offline runners,
отчёты и JSON искусственных случаев. Здесь passing counterexample означает **дефект воспроизведён**.
Source manifest и packaging manifest позволяют проверить байты и состав архива.

В отдельной исследовательской среде с зависимостями проекта:

```text
python -X utf8 run_offline_audit_tests.py test_audit_alert_delivery.py -q -p no:cacheprovider
python -X utf8 atlas_audit_test_runner.py
python -X utf8 atlas_audit_probes.py
python -X utf8 session_legacy_probes.py
```

Runner запрещает outbound sockets, убирает credential env, использует namespace snapshot и направляет
автоматически создаваемые dry defaults в `offline_runtime/`. На Windows POSIX fcntl lock tests не запускать.
272-pass status перечисляет проверенные группы; 40 Atlas tests и 27 pilot tests указаны отдельно. Снимок
частичный: если вашей среде не хватает зависимости проекта, берите её из чистого публичного checkout
того же коммита, а не из private runtime. Сетевые ответы в контрпримерах — только fakes.

Код нового recorder отдельно прочитан из public pin и проверен четырьмя FakeWS fixtures с синхронным
coroutine adapter; это не тест реального network, asyncio timeout/concurrency или живой записи. Его
рабочий probe не включён, так как привязан к локальному read-only git checkout; описание в backlog.

## Ограничения интерпретации

P1/P2 — unit-notional screening Binance proxy, не полный WEEX/account risk simulation. Старый chronological
70/30 — не unseen OOS. P2 n=0: expectancy не измерена. P3, maker и cross-venue — гипотезы из итогового
отчёта, их результатов/готовых production исполнителей архив не содержит. Исходные Atlas ZIP/CSV и
исправленная gold market history для полного повторения их авторских сумм не представлены.
