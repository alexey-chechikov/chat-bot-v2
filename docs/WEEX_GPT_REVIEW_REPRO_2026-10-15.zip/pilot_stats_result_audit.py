"""Independent native-input ledger/feature/stat checks for frozen pilot. No API or source edits."""
from pathlib import Path
import json,sys,hashlib
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent;PILOT=HERE/'pilot'
INPUT=Path(r'C:\bot7\research\expectancy_20261006\public_data')
MIN=60_000;B15=15*MIN;H4=240*MIN
def near(a,b):return abs(float(a)-float(b))<=1e-9*max(1.,abs(float(b)))

def check_stats(ledger,s):
    assert len(ledger)==s['n'] and s['censored']==0
    if not len(ledger):
        assert all(s[k] is None for k in ('mean_net_return','mean_net_R','WR','PF'))
        return
    net=ledger.net_return.to_numpy();R=ledger.net_R.to_numpy()
    positive=net[net>0].sum();negative=-net[net<0].sum()
    assert near(net.mean(),s['mean_net_return']) and near(R.mean(),s['mean_net_R'])
    assert near(net.sum(),s['sum_net_return_fixed_notional']) and near((net>0).mean(),s['WR'])
    assert (s['PF'] is None if negative==0 else near(positive/negative,s['PF']))
    assert near(ledger.fees.mean(),s['mean_fees']) and near(ledger.funding_signed_cost.mean(),s['mean_signed_funding_cost'])
    assert near(ledger.gross_raw_return.mean(),s['mean_raw_return']) and near(ledger.price_return_after_slip.mean(),s['mean_after_slip_return'])
    assert ledger.reason.value_counts().to_dict()==s['reasons']

def check_ci(group,reported):
    pool=group.to_numpy();rng=np.random.default_rng(20261014)
    sampled=pool[rng.integers(0,len(pool),size=(9999,len(pool)))].sum(1)
    kept=sampled[sampled[:,2]>0]
    ci=np.quantile(kept[:,:2]/kept[:,2:],[.025,.975],axis=0)
    assert np.allclose(ci[:,0],reported['net_return_CI95'],atol=1e-12)
    assert np.allclose(ci[:,1],reported['net_R_CI95'],atol=1e-12)
    assert len(kept)==reported['valid_draws'] and len(sampled)-len(kept)==reported['zero_count_draws']

def native(symbol):
    d=pd.read_csv(INPUT/f'binance_futures_{symbol}_1m.csv').set_index('ts')
    fund=pd.read_csv(INPUT/f'binance_futures_{symbol}_funding.csv').set_index('fundingTime')
    def bars(step):
        return d.groupby(d.index//step*step).agg(open=('open','first'),high=('high','max'),low=('low','min'),close=('close','last'))
    b,h=bars(B15),bars(H4)
    tr=np.maximum(b.high-b.low,np.maximum(abs(b.high-b.close.shift(1)),abs(b.low-b.close.shift(1)))).to_numpy().copy()
    tr[0]=b.high.iloc[0]-b.low.iloc[0]
    atr=np.full(len(b),np.nan);atr[13]=tr[:14].mean()
    for i in range(14,len(b)):atr[i]=(atr[i-1]*13+tr[i])/14
    ema=np.full(len(h),np.nan);ema[49]=h.close.iloc[:50].mean()
    for i in range(50,len(h)):ema[i]=ema[i-1]+(2/51)*(h.close.iloc[i]-ema[i-1])
    b['atr']=atr;b['h20']=b.high.rolling(20).max().shift(1);b['l20']=b.low.rolling(20).min().shift(1)
    h['ema']=ema
    return d,fund,b,h

def evaluate_p2_candidates(events,d,b,cost):
    # Rebuild every confirmed P2 order from native prices, without producer simulate/Machine.
    rows=events.loc[events.event=='confirm'];counts={'confirmations':len(rows),'skip_width':0,'skip_space':0,'otherwise_fillable':0}
    for ev in rows.itertuples():
        signal_ts=int(ev.signal_id.split(':')[1]);side=int(ev.side);sig=b.loc[signal_ts];confirm=b.loc[int(ev.bar_ts)]
        A=float(sig.atr);sl=float(sig.low-.1*A if side==1 else sig.high+.1*A)
        raw=float(d.loc[int(ev.bar_ts)+B15,'open'])
        assert abs(raw-float(confirm.close))<=.1*A+1e-12
        E=raw*(1+side*cost['slip']);width=side*(E-sl)/E
        if not .005-1e-12<=width<=.015+1e-12:counts['skip_width']+=1;continue
        local=pd.Timestamp(signal_ts,unit='ms',tz='UTC').tz_convert('America/New_York')
        ort=pd.Timestamp(str(local.date())+' 09:30',tz='America/New_York').tz_convert('UTC').value//1_000_000
        high=float(b.loc[ort:ort+B15,'high'].max());low=float(b.loc[ort:ort+B15,'low'].min())
        TP=E+side*2*side*(E-sl);edge=high if side==1 else low
        if side*(edge-TP)<-1e-12:counts['skip_space']+=1
        else:counts['otherwise_fillable']+=1
    return counts

def independent_p2_scan(b):
    ranges={}
    for ts,row in b.iterrows():
        local=pd.Timestamp(ts,unit='ms',tz='UTC').tz_convert('America/New_York')
        if local.weekday()<5 and local.hour==9 and local.minute==30 and ts+B15 in b.index:
            other=b.loc[ts+B15]
            ranges[str(local.date())]=(max(row.high,other.high),min(row.low,other.low),int(ts+120*MIN))
    pending=None;signals=0;confirmations=[]
    for ts,row in b.iterrows():
        end=int(ts+B15)
        if pending:
            p=pending;pending=None
            if end>p['deadline']:continue
            side=p['side'];newedge=row.low if side==1 else row.high
            oldedge=p['low'] if side==1 else p['high']
            if side*(newedge-oldedge)<0:continue
            reference=p['high'] if side==1 else p['low']
            if side*(row.close-reference)>0:
                confirmations.append((int(p['ts']),int(ts),side));continue
            if end==p['deadline']:continue
            pending=p;continue
        if not np.isfinite(row.atr) or row.atr<=0:continue
        local=pd.Timestamp(ts,unit='ms',tz='UTC').tz_convert('America/New_York')
        clock=local.hour*60+local.minute;day=str(local.date())
        if local.weekday()>=5 or not 600<=clock<690 or day not in ranges:continue
        high,low,cutoff=ranges[day]
        if row.low<low and row.high>high:continue
        lng=row.low<=low-.1*row.atr and low+.05*row.atr<=row.close<=high
        sht=row.high>=high+.1*row.atr and low<=row.close<=high-.05*row.atr
        if not (lng or sht):continue
        signals+=1;side=1 if lng else -1
        pending={'ts':int(ts),'side':side,'low':row.low,'high':row.high,'deadline':min(end+3*B15,cutoff)}
    return signals,confirmations

def main():
    summary=json.loads((PILOT/'summary.json').read_text());manifest=json.loads((PILOT/'manifest.json').read_text())
    assert hashlib.sha256((PILOT/'replay.py').read_bytes()).hexdigest()==manifest['implementation_sha256']
    assert hashlib.sha256(Path(summary['protocol']).read_bytes()).hexdigest()==manifest['protocol_sha256']==summary['protocol_sha256']
    events=pd.read_csv(PILOT/'events.csv');costs={c['name']:c for c in summary['scenarios']}
    output={'scope':'native CSV ledger replay checks; no account portfolio or unseen holdout','rows':{},'P2_geometry':{}}
    for symbol in ('BTCUSDT','ETHUSDT'):
        d,fund,b,h=native(symbol)
        provenance=next(p for p in manifest['inputs'] if p['symbol']==symbol)
        for kind in ('minute','funding'):
            assert hashlib.sha256(Path(provenance[kind+'_path']).read_bytes()).hexdigest()==provenance[kind+'_sha256']
        dates=pd.date_range(pd.Timestamp(provenance['start_ms'],unit='ms',tz='UTC').date(),pd.Timestamp(provenance['end_ms'],unit='ms',tz='UTC').date(),freq='D')
        weeks=sorted({x.strftime('%G-W%V') for x in dates})
        independent_signals,independent_confirmations=independent_p2_scan(b)
        for scenario,cost in costs.items():
            key='P1_'+symbol+'_'+scenario
            ledger=pd.read_csv(PILOT/f'ledger_{key}.csv');fail=[]
            for row in ledger.itertuples():
                side=int(row.side);sig=b.loc[int(row.signal_ts)];conf=b.loc[int(row.confirm_ts)]
                idx=b.index.get_loc(int(row.signal_ts));prev=b.iloc[idx-1]
                L=float(sig.h20 if side==1 else sig.l20)
                expected_end=(int(row.signal_ts)+B15)//H4*H4
                hr=h.loc[expected_end-H4]
                checks=[near(row.atr,sig.atr),near(row.level,L),row.trend_bar_end==expected_end,
                        side*(hr.close-hr.ema)>0,side*(sig.close-L)>.1*sig.atr,
                        side*(prev.close-(prev.h20 if side==1 else prev.l20))<=0,
                        row.entry_ts==row.confirm_ts+B15,0<row.confirm_ts-row.signal_ts<=3*B15,
                        near(row.sl,conf.low-.1*row.atr if side==1 else conf.high+.1*row.atr),
                        abs(row.entry_raw-conf.close)<=.1*row.atr+1e-12,
                        near(row.entry_raw,d.loc[int(row.entry_ts),'open']),
                        near(row.entry_actual,row.entry_raw*(1+side*cost['slip'])),
                        near(row.tp,row.entry_actual+side*2*row.distance),
                        .005-1e-12<=row.stop_fraction<=.015+1e-12]
                for pending_ts,pending_bar in b.loc[int(row.signal_ts)+B15:int(row.confirm_ts)].iterrows():
                    pending_end=(int(pending_ts)+B15)//H4*H4
                    trend=h.loc[pending_end-H4]
                    edge=pending_bar.low if side==1 else pending_bar.high
                    confirmed=(-.25*row.atr<=side*(edge-L)<=.1*row.atr and side*(pending_bar.close-L)>=.05*row.atr)
                    checks.extend([side*(trend.close-trend.ema)>=0,side*(pending_bar.close-L)>=-.25*row.atr,
                                   confirmed==(pending_ts==row.confirm_ts)])
                for ts,minute in d.loc[int(row.entry_ts):int(row.exit_ts)].iterrows():
                    reason=None;raw=None
                    if side*(minute.open-row.stop)<=0:reason='SL_GAP';raw=float(minute.open)
                    elif side*(minute.open-row.tp)>=0:reason='TP';raw=row.tp
                    elif ts==row.deadline_ts:reason='TIME';raw=float(minute.open)
                    elif (minute.low<=row.stop if side==1 else minute.high>=row.stop):reason='SL';raw=row.stop
                    elif (minute.high>=row.tp if side==1 else minute.low<=row.tp):reason='TP';raw=row.tp
                    if reason:
                        checks.extend([reason==row.reason,near(raw,row.exit_raw)])
                        break
                F=fund.loc[(fund.index>row.entry_ts)&(fund.index<=row.exit_ts)]
                funding=side/row.entry_actual*float((F.markPrice*F.fundingRate).sum())
                fee=cost['fee']*(1+row.exit_actual/row.entry_actual)
                net=side*(row.exit_actual-row.entry_actual)/row.entry_actual-fee-funding
                checks.extend([near(row.exit_actual,row.exit_raw*(1-side*cost['slip'])),
                               near(row.funding_signed_cost,funding),row.funding_count==len(F),
                               near(row.fees,fee),near(row.net_return,net),near(row.net_R,net/row.stop_fraction)])
                if not all(checks):fail.append(row.episode_id)
            assert not fail,(key,fail)
            s=summary['results'][key]['all'];n=len(ledger);net=ledger.net_return.to_numpy();R=ledger.net_R.to_numpy()
            check_stats(ledger,s)
            result=summary['results'][key];split=provenance['split70_ms']
            check_stats(ledger.loc[ledger.entry_ts<split],result['first70'])
            check_stats(ledger.loc[ledger.entry_ts>=split],result['last30_diagnostic_not_OOS'])
            month=pd.to_datetime(ledger.entry_ts,unit='ms',utc=True).dt.strftime('%Y-%m')
            for name,monthly in result['monthly'].items():check_stats(ledger.loc[month==name],monthly)
            PF=net[net>0].sum()/-net[net<0].sum()
            assert n==s['n'] and near(net.mean(),s['mean_net_return']) and near(R.mean(),s['mean_net_R'])
            assert near(PF,s['PF']) and near((net>0).mean(),s['WR'])
            assert np.all(ledger.entry_ts.to_numpy()[1:]>=ledger.exit_ts.to_numpy()[:-1])
            wk=pd.to_datetime(ledger.entry_ts,unit='ms',utc=True).dt.strftime('%G-W%V')
            group=pd.DataFrame({'wk':wk,'net':net,'R':R}).groupby('wk').agg(net=('net','sum'),R=('R','sum'),n=('net','size'))
            old=summary['results'][key]['weekly_block_CI']
            check_ci(group,old['nonempty_weeks'])
            full=group.reindex(weeks,fill_value=0)
            check_ci(full,old['all_calendar_weeks'])
            assert len(group)==old['nonempty_clusters'] and len(full)==old['all_calendar_clusters']
            output['rows'][key]={'n':n,'all_trade_feature_fill_funding_checks_passed':True,
                                'stats_months_split_and_both_week_CIs_reproduced':True,'PF':float(PF),
                                'mean_net_pct':100*float(net.mean()),'mean_net_price_stop_R':float(R.mean())}
            key2='P2_'+symbol+'_'+scenario
            ev=events.loc[(events.strategy=='P2')&(events.symbol==symbol)&(events.scenario==scenario)]
            reported=[(int(e.signal_id.split(':')[1]),int(e.bar_ts),int(e.side)) for e in ev.loc[ev.event=='confirm'].itertuples()]
            assert reported==independent_confirmations
            assert independent_signals==summary['results'][key2]['counts']['signal']
            counts=evaluate_p2_candidates(ev,d,b,cost)
            counts['signals_independently_rebuilt']=independent_signals
            counts['confirmation_times_independently_rebuilt']=True
            assert counts['otherwise_fillable']==0
            assert counts['skip_width']==summary['results'][key2]['counts']['skip_stop_width']
            assert counts['skip_space']==summary['results'][key2]['counts']['skip_or_space']
            output['P2_geometry'][key2]=counts
    (HERE/'pilot_stats_result_audit.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    print(json.dumps({'ledger_rows_checked':sum(x['n'] for x in output['rows'].values()),
                      'all_checks_pass':True,'P2_geometry':output['P2_geometry']},indent=2))

if __name__=='__main__':main()
