"""Independent offline P1/P2 edge probes; synthetic inputs, no source changes or network."""
from pathlib import Path
import importlib.util,json,sys,hashlib
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'pilot/replay.py'
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('pilot_replay_independent',SOURCE)
r=importlib.util.module_from_spec(spec);sys.modules[spec.name]=r;spec.loader.exec_module(r)

def order():
    return {'strategy':'P1','side':1,'entry_ts':0,'atr':1.,'sl':99.,'confirm_close':100.,
            'signal_ts':-2*r.B15,'confirm_ts':-r.B15,'signal_id':'synthetic'}

def funding_gap_probe():
    m=pd.DataFrame({'open':[100.,98.,98.],'high':[100.,98.,98.],
                    'low':[100.,97.,98.],'close':[100.,98.,98.]},index=[0,r.MIN,2*r.MIN])
    f=pd.DataFrame({'markPrice':[100.],'fundingRate':[.001]},index=[r.MIN+1])
    t,rejected,points=r.simulate(order(),m,f,r.SCENARIOS[0])
    assert rejected is None and t['reason']=='SL_GAP' and t['exit_ts']==r.MIN
    details=json.loads(t['funding_details'])
    return {'data':'synthetic gap exit at minute open','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            'entry_ts':t['entry_ts'],'exit_ts':t['exit_ts'],'settlement_ts':r.MIN+1,
            'reason':t['reason'],'funding_count':t['funding_count'],
            'funding_signed_cost':t['funding_signed_cost'],
            'funding_details_after_exit':sum(x['ts']>t['exit_ts'] for x in details),
            'expected_funding_count':0,'funding_invariant_pass':t['funding_count']==0}

def exit_minute_drawdown_probe():
    m=pd.DataFrame({'open':[100.],'high':[101.],'low':[98.5],'close':[99.]},index=[0])
    f=pd.DataFrame({'markPrice':[],'fundingRate':[]},index=pd.Index([],dtype=np.int64))
    t,rejected,points=r.simulate(order(),m,f,r.SCENARIOS[0])
    E=t['entry_actual'];fee=r.SCENARIOS[0].fee
    possible_favourable=(101.-E)/E-fee
    reported_dd=max(np.maximum.accumulate(np.r_[0.,points])-np.r_[0.,points])
    possible_favourable_then_exit_dd=possible_favourable-t['net_return']
    return {'data':'synthetic SL-only exit minute; high could precede stop and remains below TP',
            'reason':t['reason'],'reported_points':points,
            'drawdown_of_reported_points':float(reported_dd),
            'possible_observed_favourable_before_SL_drawdown':possible_favourable_then_exit_dd,
            'actual_intraminute_sequence_known':False,
            'drawdown_envelope_covers_fixture':bool(reported_dd+1e-12>=possible_favourable_then_exit_dd),
            'meaning':'The pre-exit envelope covers this fixture after the pre-run fix; exact intraminute ordering and account drawdown remain unknown'}

def main():
    out={'funding_at_gap_exit':funding_gap_probe(),'drawdown_scope':exit_minute_drawdown_probe()}
    (HERE/'pilot_stats_independent_probe_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
