"""Synthetic inspection of legacy session-backtest execution, no API/import main."""
from pathlib import Path
import ast
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
source=HERE/'snapshot/tools/_backtest_session_breakout.py'
tree=ast.parse(source.read_text(encoding='utf-8-sig'))
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='simulate')
ns={'np':np,'pd':pd,'TRANS_MAP':{'asia_to_london':('asia','london')},
    'BASE_SIZE_USD':1000.,'TAKER_FEE_PCT':.075}
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(source),'exec'),ns)
data=pd.DataFrame({'open':[99.,110.,110.],'high':[100.,111.,110.],
                   'low':[98.,109.,110.],'close':[99.,110.,110.],
                   'session_active':['asia','london','london'],
                   'time_in_session_min':[479,0,1], 'asia_high':[100.,100.,100.],
                   'asia_low':[98.,98.,98.]})
got=ns['simulate'](data,entry_window_min=15,buffer_pct=0.,hold_hours=1,transition='asia_to_london')
t=got['trades'][0]
assert t['entry']==100. and data.iloc[1]['low']==109. and t['pnl_usd']>98.
out={'data':'synthetic only; no historical PF reproduction',
     'gap_entry_credit':{'bar_open':110.,'bar_low':109.,'bar_high':111.,'credited_entry':t['entry'],
                        'model_pnl':t['pnl_usd'],'feasible_price_floor':109.,
                        'meaning':'Level 100 was never traded in entry bar; stop-market breakout cannot fill there'},
     'structural_limitations':['simulate has no SL/TP though live doc declares them',
         'walk_forward applies the same full-window-selected parameters to all four splits',
         'DD uses cumulative closed results in grouped transition order and omits initial zero']}
(HERE/'session_legacy_probe_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
