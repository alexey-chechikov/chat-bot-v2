"""Independent, read-only arithmetic audit of frozen public-market ledgers.

Does not import the producer or contact any API. Only creates QA files beside it.
"""
from pathlib import Path
import json
import hashlib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SRC = ROOT.parent / 'expectancy_20261006' / 'intraday'
reported = pd.read_csv(ROOT / 'fee_004_sensitivity.csv')
payload = json.loads((ROOT / 'fee_004_sensitivity.json').read_text(encoding='utf-8'))
checks = []
fresh = []
old = {}
files = sorted(SRC.glob('trades_*.csv')) + sorted(SRC.glob('fresh_trades_*.csv'))
assert len(files) == 72
for path in files:
    t = pd.read_csv(path)
    is_fresh = path.name.startswith('fresh_')
    prefix = 'fresh_trades_' if is_fresh else 'trades_'
    name = path.stem[len(prefix):]
    raw = t.side.to_numpy() * (t.exit_mid.to_numpy() - t.entry_mid.to_numpy()) / t.entry_mid.to_numpy()
    assert np.max(np.abs(raw-t.gross)) < 1e-12
    assert pd.to_datetime(t.entry_time, utc=True).dt.strftime('%Y-%m').eq(t.month).all()
    for cost in (.04, .06, .08):
        keep_reported = reported[(reported.name == name) & (reported.source_kind == ('fresh_futures' if is_fresh else 'old_spot_proxy')) & (reported.period == 'all') & (reported.round_trip_cost_pct == cost)]
        assert len(keep_reported) == 1
        expected = float((raw-cost/100).mean()*100)
        assert abs(float(keep_reported.iloc[0].net_avg_pct)-expected) < 1e-12
        # Funding is excluded from the primary ALL-IN scenario, applied exactly
        # once in the separately labelled execution-plus-funding scenario.
        fund = t.funding_return.to_numpy() if 'funding_return' in t else np.zeros(len(t))
        assert abs(float(keep_reported.iloc[0].execution_cost_plus_actual_funding_net_avg_pct)-float((raw-cost/100+fund).mean()*100)) < 1e-12
    if is_fresh:
        fresh.append({'name':name, 'n':len(t), 'net_004_pct':float((raw-.0004).mean()*100), 'net_008_pct':float((raw-.0008).mean()*100)})
    else:
        old[name] = {period: float((raw[t.segment.eq(period)]-.0004).mean()*100) for period in ('train','validation','test')}

representatives = []
for symbol in ('BTCUSDT','ETHUSDT','XRPUSDT'):
    name = f'{symbol}_intraday_impulse_follow_z2.5_h120'
    path = SRC / f'fresh_trades_{name}.csv'
    t = pd.read_csv(path)
    raw = t.side.to_numpy() * (t.exit_mid.to_numpy()-t.entry_mid.to_numpy())/t.entry_mid.to_numpy()
    net = raw-.0004
    grouped = pd.DataFrame({'month':pd.to_datetime(t.entry_time, utc=True).dt.strftime('%Y-%m'), 'net':net}).groupby('month').net.agg(['sum','count'])
    generator = np.random.default_rng(20261006)
    samples = generator.integers(0,len(grouped), size=(4000,len(grouped)))
    sums = grouped['sum'].to_numpy()[samples].sum(axis=1)
    counts = grouped['count'].to_numpy()[samples].sum(axis=1)
    ci = np.quantile(100*sums/counts, [.025,.975])
    r=reported[(reported.name==name)&(reported.source_kind=='fresh_futures')&(reported.period=='all')&(reported.round_trip_cost_pct==.04)].iloc[0]
    assert abs(ci[0]-r.ci95_low_pct)<1e-12 and abs(ci[1]-r.ci95_high_pct)<1e-12
    assert ci[0]<0<ci[1]
    pf=float(net[net>0].sum()/-net[net<0].sum())
    assert abs(pf-r.PF)<1e-12
    representatives.append({'symbol':symbol,'n':len(t),'gross_pct':float(raw.mean()*100),'net_004_pct':float(net.mean()*100),'ci95_pct':ci.tolist(),'PF':pf})

stable = [r['name'] for r in fresh if r['net_004_pct']>0 and all(v>0 for v in old[r['name']].values())]
assert stable == ['ETHUSDT_intraday_impulse_follow_z2.5_h120']
assert all(r['net_008_pct']<0 for r in fresh)
manifest={r['file']:r for r in payload['source_manifest']}
for path in files:
    assert hashlib.sha256(path.read_bytes()).hexdigest()==manifest[path.name]['sha256']

result={'status':'PASS','independent_market_ledgers_checked':len(files),'fresh_cells':len(fresh),'representatives':representatives,'positive_on_old_three_segments_and_fresh_at_004':stable,'all_36_fresh_negative_at_008':True,'primary_does_not_double_count_fees_or_funding':True,'source_scope':'Frozen public-market historical simulations; no account balances, actual user fills, credentials or deposit data.','limitation':'Fixed original trade entry/exit trajectories, with costs re-priced. Not an independently executed maker fill backtest or portfolio replay. Bootstrap is descriptive after candidate selection and six-month fresh sample.'}
(ROOT/'qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
lines=['# Independent QA — 2026-10-15','','PASS: independently reconstructed signed gross from entry_mid/exit_mid/side in all 72 market-only ledgers, then subtracted the all-in round trip exactly once. Compared 216 all-period sensitivity rows, hashes and separately labelled funding scenario. No producer functions imported.','','Representative fresh z2.5/120:']
for r in representatives:
    lines.append(f"- {r['symbol']}: N={r['n']}, gross={r['gross_pct']:+.9f}%, net={r['net_004_pct']:+.9f}%, PF={r['PF']:.9f}; independently re-derived month-block CI={r['ci95_pct']}.")
lines+=['','Only ETH z2.5/120 has a positive point estimate in all old three segments and the fresh period at all-in 0.04%. All 36 fresh cells are negative at all-in 0.08%. All three representative CIs cross zero.','','Primary all-in 0.04% already includes both sides and the assumed funding budget: no extra fee/slippage/funding subtraction or addition. The separate execution-only-plus-real-funding column is correctly labelled.','','Scope/privacy: these are frozen public-market simulated trade ledgers, not the user account journal. No balances, actual personal trades, credentials or deposit values are included.','','Interpretation: cost sensitivity changes the economic screen but does not validate limit-order fills, queue priority, adverse selection or recomputed exit paths; sample reused and 36-cell selection remains.']
(ROOT/'qa.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
