# Чувствительность прежних 36 ячеек к полным издержкам 0,04% за круг

Дата: 15.10.2026.

Это арифметический пересчёт уже зафиксированных ценовых траекторий, а не новое тестирование исполнения лимитных заявок. Новых сигналов, фильтров, данных и подборов параметров нет.

В основном сценарии: net = прежний gross − 0,04% (полный all-in круг, без повторного начисления funding). В 0,04% уже входят обе комиссии, spread, slippage и прочие предполагаемые издержки. Повторно 0,02% slippage не вычитается. Ещё рассчитаны 0,06% и 0,08% за круг.

## Все 12 свежих ячеек продолжения часового импульса при 0,04%

| Актив | z | Минут | N | Gross % | Funding отдельно % | All-in Net % | PF | 95% месячный CI net % |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| BTCUSDT | 2.5 | 120 | 158 | +0.070028 | -0.000108 | +0.030028 | 1.110 | [-0.080067; +0.097310] |
| BTCUSDT | 2.5 | 60 | 158 | +0.049634 | +0.000008 | +0.009634 | 1.045 | [-0.075644; +0.083543] |
| BTCUSDT | 2 | 120 | 214 | +0.028978 | -0.000106 | -0.011022 | 0.961 | [-0.094553; +0.063249] |
| BTCUSDT | 2 | 60 | 214 | +0.012054 | +0.000012 | -0.027946 | 0.878 | [-0.084524; +0.030076] |
| ETHUSDT | 2.5 | 120 | 174 | +0.065744 | -0.000222 | +0.025744 | 1.078 | [-0.070411; +0.128122] |
| ETHUSDT | 2.5 | 60 | 174 | +0.031076 | -0.000020 | -0.008924 | 0.968 | [-0.069653; +0.049736] |
| ETHUSDT | 2 | 120 | 247 | +0.019038 | -0.000075 | -0.020962 | 0.938 | [-0.082998; +0.040215] |
| ETHUSDT | 2 | 60 | 247 | -0.018401 | +0.000022 | -0.058401 | 0.793 | [-0.088349; -0.024644] |
| XRPUSDT | 2.5 | 120 | 154 | +0.064792 | -0.000076 | +0.024792 | 1.064 | [-0.116196; +0.152520] |
| XRPUSDT | 2.5 | 60 | 154 | +0.021467 | +0.000086 | -0.018533 | 0.941 | [-0.107944; +0.055852] |
| XRPUSDT | 2 | 120 | 212 | -0.018201 | -0.000157 | -0.058201 | 0.856 | [-0.110955; -0.017819] |
| XRPUSDT | 2 | 60 | 212 | -0.050622 | +0.000052 | -0.090622 | 0.727 | [-0.140161; -0.048124] |

Funding в таблице показан справочно: он не прибавлен к главному all-in Net. Если 0,04% обозначает только исполнение, а funding учитывается сверх него, отдельная колонка execution_cost_plus_actual_funding_net_avg_pct даёт этот второй сценарий. Прибавлять funding в обоих местах нельзя.

## Охват всех семейств

| Данные | Отрезок | Семейство | Круг % | Положительных /12 | CI целиком >0 /12 | Диапазон net % |
|---|---|---|---:|---:|---:|---:|
| old_spot_proxy | all | intraday_impulse_fade_control | 0.04 | 0 | 0 | -0.113898…-0.002332 |
| old_spot_proxy | all | intraday_impulse_fade_control | 0.06 | 0 | 0 | -0.133898…-0.022332 |
| old_spot_proxy | all | intraday_impulse_fade_control | 0.08 | 0 | 0 | -0.153898…-0.042332 |
| old_spot_proxy | train | intraday_impulse_fade_control | 0.04 | 0 | 0 | -0.088708…-0.020221 |
| old_spot_proxy | train | intraday_impulse_fade_control | 0.06 | 0 | 0 | -0.108708…-0.040221 |
| old_spot_proxy | train | intraday_impulse_fade_control | 0.08 | 0 | 0 | -0.128708…-0.060221 |
| old_spot_proxy | validation | intraday_impulse_fade_control | 0.04 | 2 | 0 | -0.134163…+0.047232 |
| old_spot_proxy | validation | intraday_impulse_fade_control | 0.06 | 2 | 0 | -0.154163…+0.027232 |
| old_spot_proxy | validation | intraday_impulse_fade_control | 0.08 | 1 | 0 | -0.174163…+0.007232 |
| old_spot_proxy | test | intraday_impulse_fade_control | 0.04 | 1 | 0 | -0.177273…+0.003074 |
| old_spot_proxy | test | intraday_impulse_fade_control | 0.06 | 0 | 0 | -0.197273…-0.016926 |
| old_spot_proxy | test | intraday_impulse_fade_control | 0.08 | 0 | 0 | -0.217273…-0.036926 |
| old_spot_proxy | all | intraday_impulse_follow | 0.04 | 4 | 0 | -0.092608…+0.032990 |
| old_spot_proxy | all | intraday_impulse_follow | 0.06 | 2 | 0 | -0.112608…+0.012990 |
| old_spot_proxy | all | intraday_impulse_follow | 0.08 | 0 | 0 | -0.132608…-0.007010 |
| old_spot_proxy | train | intraday_impulse_follow | 0.04 | 2 | 0 | -0.131221…+0.010164 |
| old_spot_proxy | train | intraday_impulse_follow | 0.06 | 0 | 0 | -0.151221…-0.009836 |
| old_spot_proxy | train | intraday_impulse_follow | 0.08 | 0 | 0 | -0.171221…-0.029836 |
| old_spot_proxy | validation | intraday_impulse_follow | 0.04 | 7 | 0 | -0.130744…+0.028747 |
| old_spot_proxy | validation | intraday_impulse_follow | 0.06 | 2 | 0 | -0.150744…+0.008747 |
| old_spot_proxy | validation | intraday_impulse_follow | 0.08 | 0 | 0 | -0.170744…-0.011253 |
| old_spot_proxy | test | intraday_impulse_follow | 0.04 | 5 | 0 | -0.040183…+0.080595 |
| old_spot_proxy | test | intraday_impulse_follow | 0.06 | 4 | 0 | -0.060183…+0.060595 |
| old_spot_proxy | test | intraday_impulse_follow | 0.08 | 4 | 0 | -0.080183…+0.040595 |
| old_spot_proxy | all | scalp_impulse_follow | 0.04 | 0 | 0 | -0.062065…-0.036593 |
| old_spot_proxy | all | scalp_impulse_follow | 0.06 | 0 | 0 | -0.082065…-0.056593 |
| old_spot_proxy | all | scalp_impulse_follow | 0.08 | 0 | 0 | -0.102065…-0.076593 |
| old_spot_proxy | train | scalp_impulse_follow | 0.04 | 0 | 0 | -0.055650…-0.025079 |
| old_spot_proxy | train | scalp_impulse_follow | 0.06 | 0 | 0 | -0.075650…-0.045079 |
| old_spot_proxy | train | scalp_impulse_follow | 0.08 | 0 | 0 | -0.095650…-0.065079 |
| old_spot_proxy | validation | scalp_impulse_follow | 0.04 | 0 | 0 | -0.076927…-0.029013 |
| old_spot_proxy | validation | scalp_impulse_follow | 0.06 | 0 | 0 | -0.096927…-0.049013 |
| old_spot_proxy | validation | scalp_impulse_follow | 0.08 | 0 | 0 | -0.116927…-0.069013 |
| old_spot_proxy | test | scalp_impulse_follow | 0.04 | 0 | 0 | -0.072956…-0.034416 |
| old_spot_proxy | test | scalp_impulse_follow | 0.06 | 0 | 0 | -0.092956…-0.054416 |
| old_spot_proxy | test | scalp_impulse_follow | 0.08 | 0 | 0 | -0.112956…-0.074416 |
| fresh_futures | all | intraday_impulse_fade_control | 0.04 | 1 | 0 | -0.106445…+0.005946 |
| fresh_futures | all | intraday_impulse_fade_control | 0.06 | 0 | 0 | -0.126445…-0.014054 |
| fresh_futures | all | intraday_impulse_fade_control | 0.08 | 0 | 0 | -0.146445…-0.034054 |
| fresh_futures | all | intraday_impulse_follow | 0.04 | 4 | 0 | -0.090622…+0.030028 |
| fresh_futures | all | intraday_impulse_follow | 0.06 | 3 | 0 | -0.110622…+0.010028 |
| fresh_futures | all | intraday_impulse_follow | 0.08 | 0 | 0 | -0.130622…-0.009972 |
| fresh_futures | all | scalp_impulse_follow | 0.04 | 0 | 0 | -0.088045…-0.035839 |
| fresh_futures | all | scalp_impulse_follow | 0.06 | 0 | 0 | -0.108045…-0.055839 |
| fresh_futures | all | scalp_impulse_follow | 0.08 | 0 | 0 | -0.128045…-0.075839 |

## Что это позволяет и чего ещё не доказывает

- Прежнее утверждение, что комиссия 0,10% сама превышает лучший gross, относится к прежнему тарифу. При заданных пользователем полных расходах 0,04% экономический отсев нужно пересмотреть.
- ETH follow z2.5/120 при 0,04% имеет положительную точечную оценку на всех трёх прежних третях и свежем периоде; это единственная из 36 ячеек с таким свойством. При этом все её месячные интервалы пересекают ноль, а значение 0,04% остаётся допущением об исполнении. Поэтому новая причина для исследования появилась, статистически доказанной готовой стратегии пока нет.
- Старые цены выхода и порядок сделок сохранены. В оригинале стопы и цели построены от входа со slippage 0,02% на сторону. Это фиксированный сценарий чувствительности, а не полный пересчёт новых входных цен/порогов и следующих доступных входов.
- Дополнительная колонка exact_fee_001_slip_001_net_avg_pct точно переоценивает те же входы/выходы при комиссии 0,01% и adverse slippage 0,01% на сторону, с комиссией фактического выходного нотионала и нормировкой funding. Она всё равно не меняет исходные пути выхода.
- Для maker нужны очередь, вероятность и задержка исполнения, частичные исполнения, post-only rejects, пропущенные сделки и условный adverse selection. Снижение расходов не подтверждает, что все прежние market-входы исполнились бы лимитно.
- Свежая история — Binance USD-M май–октябрь; перенос котировок и исполнения на целевую биржу не проверен. Старая история — spot proxy без funding. После просмотра и повторного использования данных это больше не новая независимая проверка будущего кандидата.
- CI — те же 4000 bootstrap-выборок месячных блоков, seed 20261006. На свежем периоде только шесть календарных месяцев с торгами, включая неполный май. Выбор лучшей из 36 ячеек не учтён поправкой CI.
- Просадка в CSV — только по закрытым сделкам, не непрерывная floating equity. Фиксированный нотионал $1000 на отдельную сделку, суммы не являются доходностью депозита и не складываются по альтернативным ячейкам.

Воспроизведение: запустить recalculate.py в этой папке bundled Python; исходные оригинальные trade ledgers требуются в соседней expectancy_20261006/intraday. Исходные файлы не изменяются.
