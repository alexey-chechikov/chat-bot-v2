"""Cost sensitivity on frozen public-market trade ledgers; no trading/API calls.

Primary model: original gross - assumed TOTAL round-trip all-in cost.
Secondary model: execution costs only, with signed original funding separately.
This preserves entry events and all old exit paths. It is NOT a maker fill model.
Run with bundled Python. Only reads expectancy_20261006/intraday; writes here.
"""
from pathlib import Path
import hashlib
import json
import math
import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / "expectancy_20261006" / "intraday"
COSTS_PCT = (0.04, 0.06, 0.08)
SEED = 20261006
REPS = 4000
NOTIONAL = 1000.0


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def net_exact(entry, exit_, side, fee=0.0001, slip=0.0001):
    ratio = exit_ * (1 - side * slip) / (entry * (1 + side * slip))
    return side * (ratio - 1) - fee * (1 + ratio)


def stats(t, net):
    up = float(net[net > 0].sum())
    down = float(-net[net < 0].sum())
    by_month = pd.DataFrame({"net": net, "month": t.month.to_numpy()}).groupby("month").agg(total=("net", "sum"), n=("net", "size"))
    a = by_month.to_numpy()
    rng = np.random.default_rng(SEED)
    draws = rng.integers(0, len(a), (REPS, len(a)))
    sampled = a[draws].sum(axis=1)
    ci = np.quantile(sampled[:, 0] / sampled[:, 1] * 100, [.025, .975])
    # Completed-trade equity only: minute-close mark-to-market cannot be recovered
    # from a trade ledger and must not be described as floating/full-equity DD.
    equity = np.r_[NOTIONAL, NOTIONAL + np.cumsum(net * NOTIONAL)]
    dd = float((np.maximum.accumulate(equity) - equity).max())
    return {
        "n": int(len(t)), "net_avg_pct": float(net.mean() * 100),
        "net_usd_fixed_1000": float(net.sum() * NOTIONAL),
        "PF": up / down if down else None,
        "win_rate": float((net > 0).mean()),
        "ci95_low_pct": float(ci[0]), "ci95_high_pct": float(ci[1]),
        "months_with_trades": len(by_month),
        "completed_trade_dd_usd": dd,
        "completed_trade_capital_breached": bool((equity <= 0).any()),
    }


def main():
    OUT.mkdir(exist_ok=True)
    manifest = []
    rows = []
    baseline_errors = []
    for source_kind, prefix in (("old_spot_proxy", "trades_"), ("fresh_futures", "fresh_trades_")):
        paths = sorted(SOURCE.glob(prefix + "*.csv"))
        assert len(paths) == 36, (source_kind, len(paths))
        for path in paths:
            t = pd.read_csv(path)
            name = path.stem[len(prefix):]
            symbol = name.split("_")[0]
            family = name[len(symbol) + 1:].rsplit("_z", 1)[0]
            threshold, hold = name.rsplit("_z", 1)[1].split("_h")
            assert t.entry_time.notna().all() and t.exit_time.notna().all()
            assert pd.to_datetime(t.entry_time, utc=True).is_monotonic_increasing
            assert ((t.side == 1) | (t.side == -1)).all()
            fund = t.funding_return.to_numpy() if "funding_return" in t else np.zeros(len(t))
            old_exact = net_exact(t.entry_mid.to_numpy(), t.exit_mid.to_numpy(), t.side.to_numpy(), .0005, .0002) + fund
            baseline_error = float(np.max(np.abs(old_exact - t.net.to_numpy())))
            baseline_errors.append(baseline_error)
            assert baseline_error < 1e-12, (path.name, baseline_error)
            assert np.max(np.abs(t.gross.to_numpy() - t.side.to_numpy() * (t.exit_mid.to_numpy() / t.entry_mid.to_numpy() - 1))) < 1e-12
            manifest.append({"file": path.name, "sha256": sha(path), "rows": len(t), "source_kind": source_kind})
            periods = [("all", np.ones(len(t), dtype=bool))] if source_kind == "fresh_futures" else [("all", np.ones(len(t), dtype=bool))] + [(p, t.segment.eq(p).to_numpy()) for p in ("train", "validation", "test")]
            for period, keep in periods:
                q = t.loc[keep].copy().reset_index(drop=True)
                fq = fund[keep]
                exact_entry = q.entry_mid.to_numpy() * (1 + q.side.to_numpy() * .0001)
                # Preserve settlement cashflow and quantity convention under exact
                # repricing: funding per $1000 rescales with changed entry price.
                exact_fund = fq * q.entry_exec.to_numpy() / exact_entry
                exact_004 = net_exact(q.entry_mid.to_numpy(), q.exit_mid.to_numpy(), q.side.to_numpy()) + exact_fund
                for cost_pct in COSTS_PCT:
                    net = q.gross.to_numpy() - cost_pct / 100
                    net_plus_actual_funding = net + fq
                    r = {
                        "name": name, "symbol": symbol, "family": family,
                        "threshold": float(threshold), "hold_minutes": int(hold),
                        "source_kind": source_kind, "period": period,
                        "round_trip_cost_pct": cost_pct,
                        "entry_start_utc": str(q.entry_time.iloc[0]),
                        "entry_end_utc": str(q.entry_time.iloc[-1]),
                        "gross_avg_pct": float(q.gross.mean() * 100),
                        "funding_avg_pct": float(fq.mean() * 100),
                        "old_net_avg_pct": float(q.net.mean() * 100),
                        "execution_cost_plus_actual_funding_net_avg_pct": float(net_plus_actual_funding.mean() * 100),
                        "exact_fee_001_slip_001_net_avg_pct": float(exact_004.mean() * 100),
                        **stats(q, net),
                    }
                    rows.append(r)
    result = pd.DataFrame(rows)
    assert len(result) == 540
    assert result.groupby(["name", "source_kind", "period"]).size().eq(3).all()
    # Known arithmetic, position signs, all-in cost definition, no funding doublecount.
    assert abs((.0007 - .0004) * 100 - .03) < 1e-12
    for side in (-1, 1):
        assert abs(net_exact(np.array([100.]), np.array([100.]), np.array([side]))[0] + .0004) < 1e-7
    for _, g in result.groupby(["name", "source_kind", "period"]):
        g = g.sort_values("round_trip_cost_pct")
        assert np.allclose(np.diff(g.net_avg_pct), -.02, atol=1e-12)
    result.to_csv(OUT / "fee_004_sensitivity.csv", index=False, encoding="utf-8-sig")
    manifest.append({"file": "run_intraday.py", "sha256": sha(SOURCE / "run_intraday.py")})
    manifest.append({"file": "validate_fresh.py", "sha256": sha(SOURCE / "validate_fresh.py")})
    counts = []
    for (kind, period, family, cost), g in result.groupby(["source_kind", "period", "family", "round_trip_cost_pct"], sort=False):
        counts.append({"source_kind": kind, "period": period, "family": family,
                       "round_trip_cost_pct": float(cost), "positive_cells": int((g.net_avg_pct > 0).sum()),
                       "ci_lower_positive_cells": int((g.ci95_low_pct > 0).sum()), "cells": len(g),
                       "min_net_avg_pct": float(g.net_avg_pct.min()), "max_net_avg_pct": float(g.net_avg_pct.max())})
    payload = {
        "as_of": "2026-10-15", "method": "Frozen original trade paths; primary net=gross-total_round_trip_all_in_cost; secondary execution_cost_plus_actual_funding is separately labelled",
        "not_a_maker_fill_backtest": True, "fixed_notional_per_trade_usd": NOTIONAL,
        "bootstrap": {"unit": "calendar months with trades", "reps": REPS, "seed": SEED},
        "old_source_is_spot_proxy_no_funding": True,
        "fresh_source_is_Binance_futures_not_WEEX": True,
        "exit_paths_anchored_to_old_002pct_side_entry_slippage": True,
        "dd_is_completed_trade_only": True,
        "old_baseline_max_abs_reconciliation_error": max(baseline_errors),
        "output_rows": len(result), "source_manifest": manifest,
        "cell_counts": counts, "results": result.to_dict(orient="records"),
    }
    (OUT / "fee_004_sensitivity.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    selected = result[(result.source_kind == "fresh_futures") & (result.family == "intraday_impulse_follow") & (result.round_trip_cost_pct == .04)]
    lines = ["# Чувствительность прежних 36 ячеек к полным издержкам 0,04% за круг", "", "Дата: 15.10.2026.", "", "Это арифметический пересчёт уже зафиксированных ценовых траекторий, а не новое тестирование исполнения лимитных заявок. Новых сигналов, фильтров, данных и подборов параметров нет.", "", "В основном сценарии: net = прежний gross − 0,04% (полный all-in круг, без повторного начисления funding). В 0,04% уже входят обе комиссии, spread, slippage и прочие предполагаемые издержки. Повторно 0,02% slippage не вычитается. Ещё рассчитаны 0,06% и 0,08% за круг.", "", "## Все 12 свежих ячеек продолжения часового импульса при 0,04%", "", "| Актив | z | Минут | N | Gross % | Funding отдельно % | All-in Net % | PF | 95% месячный CI net % |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for _, r in selected.iterrows():
        lines.append(f"| {r.symbol} | {r.threshold:g} | {r.hold_minutes} | {r.n} | {r.gross_avg_pct:+.6f} | {r.funding_avg_pct:+.6f} | {r.net_avg_pct:+.6f} | {r.PF:.3f} | [{r.ci95_low_pct:+.6f}; {r.ci95_high_pct:+.6f}] |")
    lines += ["", "Funding в таблице показан справочно: он не прибавлен к главному all-in Net. Если 0,04% обозначает только исполнение, а funding учитывается сверх него, отдельная колонка execution_cost_plus_actual_funding_net_avg_pct даёт этот второй сценарий. Прибавлять funding в обоих местах нельзя.", "", "## Охват всех семейств", "", "| Данные | Отрезок | Семейство | Круг % | Положительных /12 | CI целиком >0 /12 | Диапазон net % |", "|---|---|---|---:|---:|---:|---:|"]
    for r in counts:
        lines.append(f"| {r['source_kind']} | {r['period']} | {r['family']} | {r['round_trip_cost_pct']:.2f} | {r['positive_cells']} | {r['ci_lower_positive_cells']} | {r['min_net_avg_pct']:+.6f}…{r['max_net_avg_pct']:+.6f} |")
    lines += ["", "## Что это позволяет и чего ещё не доказывает", "", "- Прежнее утверждение, что комиссия 0,10% сама превышает лучший gross, относится к прежнему тарифу. При заданных пользователем полных расходах 0,04% экономический отсев нужно пересмотреть.", "- ETH follow z2.5/120 при 0,04% имеет положительную точечную оценку на всех трёх прежних третях и свежем периоде; это единственная из 36 ячеек с таким свойством. При этом все её месячные интервалы пересекают ноль, а значение 0,04% остаётся допущением об исполнении. Поэтому новая причина для исследования появилась, статистически доказанной готовой стратегии пока нет.", "- Старые цены выхода и порядок сделок сохранены. В оригинале стопы и цели построены от входа со slippage 0,02% на сторону. Это фиксированный сценарий чувствительности, а не полный пересчёт новых входных цен/порогов и следующих доступных входов.", "- Дополнительная колонка exact_fee_001_slip_001_net_avg_pct точно переоценивает те же входы/выходы при комиссии 0,01% и adverse slippage 0,01% на сторону, с комиссией фактического выходного нотионала и нормировкой funding. Она всё равно не меняет исходные пути выхода.", "- Для maker нужны очередь, вероятность и задержка исполнения, частичные исполнения, post-only rejects, пропущенные сделки и условный adverse selection. Снижение расходов не подтверждает, что все прежние market-входы исполнились бы лимитно.", "- Свежая история — Binance USD-M май–октябрь; перенос котировок и исполнения на целевую биржу не проверен. Старая история — spot proxy без funding. После просмотра и повторного использования данных это больше не новая независимая проверка будущего кандидата.", "- CI — те же 4000 bootstrap-выборок месячных блоков, seed 20261006. На свежем периоде только шесть календарных месяцев с торгами, включая неполный май. Выбор лучшей из 36 ячеек не учтён поправкой CI.", "- Просадка в CSV — только по закрытым сделкам, не непрерывная floating equity. Фиксированный нотионал $1000 на отдельную сделку, суммы не являются доходностью депозита и не складываются по альтернативным ячейкам.", "", "Воспроизведение: запустить recalculate.py в этой папке bundled Python; исходные оригинальные trade ledgers требуются в соседней expectancy_20261006/intraday. Исходные файлы не изменяются."]
    (OUT / "fee_004_sensitivity.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output_rows": len(result), "max_baseline_error": max(baseline_errors), "fresh_intraday_follow_004": selected[["symbol", "threshold", "hold_minutes", "net_avg_pct", "ci95_low_pct", "ci95_high_pct", "PF"]].to_dict(orient="records"), "counts": [r for r in counts if r["period"] == "all"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
