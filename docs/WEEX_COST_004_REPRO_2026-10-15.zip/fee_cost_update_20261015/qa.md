# Independent QA — 2026-10-15

PASS: independently reconstructed signed gross from entry_mid/exit_mid/side in all 72 market-only ledgers, then subtracted the all-in round trip exactly once. Compared 216 all-period sensitivity rows, hashes and separately labelled funding scenario. No producer functions imported.

Representative fresh z2.5/120:
- BTCUSDT: N=158, gross=+0.070028361%, net=+0.030028361%, PF=1.109745611; independently re-derived month-block CI=[-0.08006714923586522, 0.09730979950054203].
- ETHUSDT: N=174, gross=+0.065743801%, net=+0.025743801%, PF=1.078138183; independently re-derived month-block CI=[-0.07041116373987001, 0.12812170752143134].
- XRPUSDT: N=154, gross=+0.064791929%, net=+0.024791929%, PF=1.064159650; independently re-derived month-block CI=[-0.11619571610171575, 0.1525201960005831].

Only ETH z2.5/120 has a positive point estimate in all old three segments and the fresh period at all-in 0.04%. All 36 fresh cells are negative at all-in 0.08%. All three representative CIs cross zero.

Primary all-in 0.04% already includes both sides and the assumed funding budget: no extra fee/slippage/funding subtraction or addition. The separate execution-only-plus-real-funding column is correctly labelled.

Scope/privacy: these are frozen public-market simulated trade ledgers, not the user account journal. No balances, actual personal trades, credentials or deposit values are included.

Interpretation: cost sensitivity changes the economic screen but does not validate limit-order fills, queue priority, adverse selection or recomputed exit paths; sample reused and 36-cell selection remains.
